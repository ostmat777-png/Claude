﻿
translate russian strings:

    # renpy/common/00console.rpy:179
    old "%(version)s console, originally by Shiz, C, and delta.\n"
    new "Консоль %(version)s, оригинальная работа Shiz, C и delta.\n"

    # renpy/common/00console.rpy:180
    old "Press <esc> to exit console. Type help for help.\n"
    new "Нажмите <esc> чтобы покинуть консоль. Наберите help для получения помощи.\n"

    # renpy/common/00console.rpy:184
    old "Ren'Py script enabled."
    new "Сценарии Ren'Py включены."

    # renpy/common/00console.rpy:186
    old "Ren'Py script disabled."
    new "Сценарии Ren'Py выключены."

    # renpy/common/00console.rpy:392
    old "help: show this help"
    new "help: показать это сообщение"

    # renpy/common/00console.rpy:397
    old "commands:\n"
    new "команды:\n"

    # renpy/common/00console.rpy:407
    old " <renpy script statement>: run the statement\n"
    new " <оператор renpy>: выполнить оператор\n"

    # renpy/common/00console.rpy:409
    old " <python expression or statement>: run the expression or statement"
    new " <оператор или выражение python>: выполнить выражение или оператор"

    # renpy/common/00console.rpy:417
    old "clear: clear the console history"
    new "clear: очистить историю консоли"

    # renpy/common/00console.rpy:421
    old "exit: exit the console"
    new "exit: покинуть консоль"

    # renpy/common/00console.rpy:429
    old "load <slot>: loads the game from slot"
    new "load <слот>: загружает игру из слота"

    # renpy/common/00console.rpy:442
    old "save <slot>: saves the game in slot"
    new "save <слот>: сохраняет игру в слот"

    # renpy/common/00console.rpy:453
    old "reload: reloads the game, refreshing the scripts"
    new "reload: перезапускает игру и перекомпилирует сценарии"

    # renpy/common/00console.rpy:461
    old "watch <expression>: watch a python expression"
    new "watch <выражение>: отслеживает выражение python"

    # renpy/common/00console.rpy:470
    old "unwatch <expression>: stop watching an expression"
    new "unwatch <выражение>: отменяет отслеживание выражения"

    # renpy/common/00console.rpy:478
    old "unwatchall: stop watching all expressions"
    new "unwatchall: полностью прекращает слежку"

    # renpy/common/00console.rpy:484
    old "jump <label>: jumps to label"
    new "jump <метка>: переходит к метке"


translate russian strings:

    # renpy/common/00gltest.rpy:68
    old "Graphics Acceleration"
    new "Ускорение графики"

    # renpy/common/00gltest.rpy:72
    old "Automatically Choose"
    new "Выбирать автоматически"

    # renpy/common/00gltest.rpy:77
    old "Force Angle/DirectX Renderer"
    new "Angle/DirectX"

    # renpy/common/00gltest.rpy:81
    old "Force OpenGL Renderer"
    new "OpenGL"

    # renpy/common/00gltest.rpy:85
    old "Force Software Renderer"
    new "Программное"

    # renpy/common/00gltest.rpy:91
    old "Changes will take effect the next time this program is run."
    new "Изменения вступят в силу при следующем запуске программы."

    # renpy/common/00gltest.rpy:130
    old "Performance Warning"
    new "Предупреждение о производительности."

    # renpy/common/00gltest.rpy:135
    old "This computer is using software rendering."
    new "Этот компьютер использует программную обработку изображений."

    # renpy/common/00gltest.rpy:137
    old "This computer is not using shaders."
    new "Этот компьютер не использует шейдеры."

    # renpy/common/00gltest.rpy:139
    old "This computer is displaying graphics slowly."
    new "Этот компьютер медленно отображает графику."

    # renpy/common/00gltest.rpy:141
    old "This computer has a problem displaying graphics: [problem]."
    new "У этого компьютера проблема с отображением графики: [problem]."

    # renpy/common/00gltest.rpy:146
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display. Updating DirectX could fix this problem."
    new "Графические драйверы устарели или работают неправильно. Это может привести к медленному или неправильному отображению графики. Вы можете попытаться обновить DirectX для устранения проблемы."

    # renpy/common/00gltest.rpy:148
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Графические драйверы устарели или работают неправильно. Это может привести к медленному или неправильному отображению графики."

    # renpy/common/00gltest.rpy:153
    old "Update DirectX"
    new "Обновить DirectX"

    # renpy/common/00gltest.rpy:159
    old "Continue, Show this warning again"
    new "Продолжить, показать это сообщение в следующий раз"

    # renpy/common/00gltest.rpy:163
    old "Continue, Don't show warning again"
    new "Продолжить, не показывать это сообщение в следующий раз"

    # renpy/common/00gltest.rpy:189
    old "Updating DirectX."
    new "Обновление DirectX."

    # renpy/common/00gltest.rpy:193
    old "DirectX web setup has been started. It may start minimized in the taskbar. Please follow the prompts to install DirectX."
    new "Была запущена программа установки DirectX. Пожалуйста, следуйте её инструкциям для установки DirectX."

    # renpy/common/00gltest.rpy:197
    old "{b}Note:{/b} Microsoft's DirectX web setup program will, by default, install the Bing toolbar. If you do not want this toolbar, uncheck the appropriate box."
    new "{b}Заметка:{/b} Установщик DirectX может попытаться установить Bing Toolbar. Если такое поведение нежелательно, снимите соответствующую галочку."

    # renpy/common/00gltest.rpy:201
    old "When setup finishes, please click below to restart this program."
    new "Когда установка завершиться, щёлкните ниже, чтобы перезапустить эту программу."

    # renpy/common/00gltest.rpy:203
    old "Restart"
    new "Перезапуск"


translate russian strings:









    # renpy/common/00layout.rpy:452
    old "Are you sure you want to skip to unseen dialogue or the next choice?"
    new "Вы уверены, что хотите пропустить невиданный диалог или следующий выбор?"


translate russian strings:


    # renpy/common/00library.rpy:152
    old "Fast Skip Mode"
    new "Быстрый режим пропуска"


translate russian strings:


    # renpy/common/00updater.rpy:1382
    old "An error has occured:"
    new "Произошла ошибка:"

    # renpy/common/00updater.rpy:1384
    old "Checking for updates."
    new "Проверка обновлений."






    # renpy/common/00updater.rpy:1396
    old "Finishing up."
    new "Завершение."




    # renpy/common/00updater.rpy:1416
    old "Proceed"
    new "Продолжить"

    # renpy/common/00updater.rpy:1419
    old "Cancel"
    new "Отменить"


translate russian strings:










    # renpy/common/_developer/developer.rpym:150
    old "No variables have changed since the game started."
    new "С момента запуска игры никакие переменные не изменялись."





    # renpy/common/_developer/developer.rpym:443
    old "Done"
    new "Конец"


translate russian strings:


    # renpy/common/_errorhandling.rpym:477
    old "Rollback"
    new "Откат"

    # renpy/common/_errorhandling.rpym:479
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Выполняет откат к более раннему периоду времени, что позволит вам сохранить игру или выбрать другую опцию."

    # renpy/common/_errorhandling.rpym:482
    old "Ignore"
    new "Игнорировать"

    # renpy/common/_errorhandling.rpym:484
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Игнорирует исключение, позволяя вам продолжить. Это зачастую вызовет ещё больше ошибок."

    # renpy/common/_errorhandling.rpym:487
    old "Reload"
    new "Перезапуск"

    # renpy/common/_errorhandling.rpym:489
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Перезагружает игру с диска, сохраняя и восстанавливая игровое состояние при наличии возможности."

    # renpy/common/_errorhandling.rpym:491
    old "Open Traceback"
    new "Открыть журнал"

    # renpy/common/_errorhandling.rpym:493
    old "Opens the traceback.txt file in a text editor."
    new "Открывает файл traceback.txt в текстовом редакторе."

    # renpy/common/_errorhandling.rpym:499
    old "Quits the game."
    new "Выходит из игры."

    # renpy/common/_errorhandling.rpym:526
    old "Parsing the script failed."
    new "Ошибка обработки сценария."

    # renpy/common/_errorhandling.rpym:553
    old "Open Parse Errors"
    new "Открыть журнал ошибок"

    # renpy/common/_errorhandling.rpym:555
    old "Opens the errors.txt file in a text editor."
    new "Открывает файл errors.txt в текстовом редакторе."
