# Русский перевод: script-exclusives-sayori

translate russian sayori_exclusive_1_ebd278f3:
    "Ну и ну..."

translate russian sayori_exclusive_1_75a8ab85:
    "Похоже, сегодня никто не хочет, чтобы его беспокоили."

translate russian sayori_exclusive_1_a3dd5dba:
    "Я плюхаюсь за ближайшую парту."

translate russian sayori_exclusive_1_140dc341:
    "И как мне в одиночку заняться чем-нибудь литературным?"

translate russian sayori_exclusive_1_b96163c6:
    "Можно, конечно, почитать книгу, которую дала мне Юри..."

translate russian sayori_exclusive_1_c6d56ac0:
    "...Но для чтения я слишком устал."

translate russian sayori_exclusive_1_c374df0f:
    "Пожалуй, я бы сейчас запросто уснул."

translate russian sayori_exclusive_1_70925125:
    "Я закрываю глаза и невольно прислушиваюсь к разговору Сайори с Моникой."

translate russian sayori_exclusive_1_09fc8625:
    s "Но на фоне других клубов мы, наверное, будем выглядеть совсем скучно..."

translate russian sayori_exclusive_1_6d1d2d28:
    m "Хм-м..."

translate russian sayori_exclusive_1_10dbd395:
    m 2b "Ну, сдаваться нельзя."

translate russian sayori_exclusive_1_8920eea6:
    m "Фестиваль — наш шанс показать всем, что такое литература!"

translate russian sayori_exclusive_1_ebb868c8:
    m 2d "Проблема в том, что литературный клуб звучит слишком уж заумно и интеллектуально..."

translate russian sayori_exclusive_1_9bd0888b:
    m "Но ведь на самом деле всё совсем не так, понимаешь?"

translate russian sayori_exclusive_1_82578239:
    m 2a "Нам просто нужно как-то показать это всем..."

translate russian sayori_exclusive_1_3384cee9:
    m "Что-то, что найдёт отклик в их творческих душах."

translate russian sayori_exclusive_1_607ebf69:
    s 1i "М-м-м-м-м-м-м-м-м-м....."

translate russian sayori_exclusive_1_95130e53:
    s "Но это же не решает проблему!"

translate russian sayori_exclusive_1_037a4dfd:
    m 2d "А? Ты о чём?"

translate russian sayori_exclusive_1_9111b144:
    s 1c "Даже если мы придумаем самую весёлую штуку на свете..."

translate russian sayori_exclusive_1_2f7dad10:
    s "Никто просто не придёт, если это литературное мероприятие."

translate russian sayori_exclusive_1_64881939:
    s "Так что важнее придумать, как вообще заманить людей, понимаешь?"

translate russian sayori_exclusive_1_51184aa2:
    s 1a "А когда они придут, уже можно будет сделать то, что найдёт отклик в их творческих душах."

translate russian sayori_exclusive_1_14278efc:
    "...Что это?"

translate russian sayori_exclusive_1_55b7d1b5:
    "Сайори относится к этому очень серьёзно."

translate russian sayori_exclusive_1_7dcbbe2f:
    "Редко услышишь, чтобы она вот так рассуждала."

translate russian sayori_exclusive_1_821bebf6:
    m 2a "Хм, хорошая мысль..."

translate russian sayori_exclusive_1_5a567997:
    m "Тогда как думаешь, еда поможет?"

translate russian sayori_exclusive_1_4e085cf3:
    s 1n "К-какая?!"

translate russian sayori_exclusive_1_e67c3d03:
    m 2b "А... Ну, можно было бы—"

translate russian sayori_exclusive_1_47b1e3cd:
    s "Капкейки!"

translate russian sayori_exclusive_1_2f575b47:
    m "А-ха-ха. Хорошая идея."

translate russian sayori_exclusive_1_52375000:
    m 1a "Нацуки с удовольствием этим займётся."

translate russian sayori_exclusive_1_5f170b21:
    s 4x "Ах! Точно!"

translate russian sayori_exclusive_1_1589bf64:
    s "Нацуки печёт самые лучшие капкейки!"

translate russian sayori_exclusive_1_8824af48:
    s "Всё идеально складывается~"

translate russian sayori_exclusive_1_0633c181:
    m 1d "Разве ты не поэтому их предложила...?"

translate russian sayori_exclusive_1_f27be215:
    s 4q "Капкейки находят отклик в моём творческом животике~"

translate russian sayori_exclusive_1_a01fa8fe:
    m 1l "..."

translate russian sayori_exclusive_1_f6310840:
    m "Значит, решено — капкейки."

translate russian sayori_exclusive_1_38cfa41d:
    s 1g "Я проголодалась..."

translate russian sayori_exclusive_1_bd7ee0bf:
    m 1a "В общем, нам ещё нужно продумать детали самого мероприятия..."

translate russian sayori_exclusive_1_383b3fe0:
    "Я ловлю себя на том, что улыбаюсь."

translate russian sayori_exclusive_1_62cb7948:
    "В итоге Сайори всё та же."

translate russian sayori_exclusive_1_467d437c:
    "Но в этом и кроется неожиданная причина, по которой я ею восхищаюсь."

translate russian sayori_exclusive_1_43defa01:
    "В отличие от меня, кому сложно найти хоть какую-то мотивацию..."

translate russian sayori_exclusive_1_756297ea:
    "Сайори умеет за что-то взяться и воплотить это в жизнь."

translate russian sayori_exclusive_1_4e902aa7:
    "Наверное, поэтому я и позволяю ей меня донимать."

translate russian sayori_exclusive_1_1c49757d:
    "Невольно задумываюсь: каково это — смотреть на мир её глазами..."

translate russian sayori_exclusive_1_54a76a80:
    mc "Уа-а—!"

translate russian sayori_exclusive_1_023cfb54:
    "Я открываю глаза, и всё поле зрения заполняет лицо Сайори."

translate russian sayori_exclusive_1_23680e41:
    "Я чуть не падаю со стула."

translate russian sayori_exclusive_1_e69f2726:
    s 4q "Э-хе-хе, прости~"

translate russian sayori_exclusive_1_02f1b11d:
    s 4i "Стоп!"

translate russian sayori_exclusive_1_62d4f5b3:
    s 1j "Вообще-то, мне совсем не жаль!"

translate russian sayori_exclusive_1_c56a577b:
    s "Сам виноват, что так спишь!"

translate russian sayori_exclusive_1_dcb0fc40:
    s "Это тебе не клуб любителей поспать!"

translate russian sayori_exclusive_1_7d7d37ba:
    mc "А у нас в школе есть клуб любителей поспать...?"

translate russian sayori_exclusive_1_4b3db410:
    s 1h "Ты опять поздно ложишься, да?"

translate russian sayori_exclusive_1_1d7ac73a:
    s "Теперь, когда ты в клубе, времени на аниме будет меньше, знаешь ли!"

translate russian sayori_exclusive_1_5214e4eb:
    s "Придётся привыкать!"

translate russian sayori_exclusive_1_1eee5de8:
    mc "Не говори так громко...!"

translate russian sayori_exclusive_1_18e51069:
    "Я оглядываюсь через плечо, чтобы проверить, не услышала ли Моника."

translate russian sayori_exclusive_1_f99f8ce0:
    s 1g "Но это же правда..."

translate russian sayori_exclusive_1_69c25b65:
    mc "Да..."

translate russian sayori_exclusive_1_6f1767e0:
    mc "Знаю, знаю."

translate russian sayori_exclusive_1_c99f2adc:
    mc "Ты вечно обо мне заботишься, Сайори."

translate russian sayori_exclusive_1_e688cc67:
    s 4q "Э-хе-хе~"

translate russian sayori_exclusive_1_f3388382:
    s "Это у меня лучше всего получается!"

translate russian sayori_exclusive_1_8ac2b061:
    mc "...В том-то и проблема!"

translate russian sayori_exclusive_1_4db03926:
    mc "А как же ты?"

translate russian sayori_exclusive_1_3e38066e:
    mc "Обо мне ты заботишься лучше, чем о себе."

translate russian sayori_exclusive_1_7f241ab9:
    mc "Ты ведь до сих пор каждый день просыпаешь, да?"

translate russian sayori_exclusive_1_4512d6c1:
    s 1l "А?"

translate russian sayori_exclusive_1_6a695de0:
    s "Н-не каждый день!"

translate russian sayori_exclusive_1_60d030b6:
    mc "Не очень-то убедительно..."

translate russian sayori_exclusive_1_8f1c24ad:
    mc "Сколько дней на этой неделе ты встала вовремя?"

translate russian sayori_exclusive_1_30451397:
    s 1m "Это..."

translate russian sayori_exclusive_1_a5d16478:
    s 1o "...Это секрет!"

translate russian sayori_exclusive_1_8c3318a5:
    mc "Так я и знал..."

translate russian sayori_exclusive_1_8793bcb9:
    s 5a "Ну пожа-а-алуйста!"

translate russian sayori_exclusive_1_6803c906:
    s "Мог бы хоть немножко мне поверить..."

translate russian sayori_exclusive_1_d086a905:
    mc "Даже этого не могу."

translate russian sayori_exclusive_1_1fb2352a:
    mc "Слушай, Сайори, у тебя же на лбу всё написано."

translate russian sayori_exclusive_1_2e7893cd:
    s 1b "А...?"

translate russian sayori_exclusive_1_c3e7bdce:
    "Сайори оглядывает себя."

translate russian sayori_exclusive_1_e032ee06:
    s "Где это у меня написано?"

translate russian sayori_exclusive_1_85ddd496:
    mc "Ты явно сегодня утром торопилась..."

translate russian sayori_exclusive_1_442e54ad:
    mc "Смотри, у тебя волосы вот тут во все стороны торчат."

translate russian sayori_exclusive_1_f57f6de7:
    s 1e "А—"

translate russian sayori_exclusive_1_8bb7c20a:
    "Я провожу кончиками пальцев по прядям Сайори, пытаясь их пригладить."

translate russian sayori_exclusive_1_71887ffc:
    mc "Ну и ну, тебе бы правда расчёску..."

translate russian sayori_exclusive_1_d61f01c7:
    s 1y "Просто мои волосы очень трудно уложить..."

translate russian sayori_exclusive_1_c375aed4:
    mc "Не прокатит."

translate russian sayori_exclusive_1_6eed6851:
    mc "Дело не только в волосах."

translate russian sayori_exclusive_1_1c664c25:
    mc "Смотри, и бантик у тебя криво."

translate russian sayori_exclusive_1_f67e2522:
    mc "А вот тут на воротнике пятно от зубной пасты."

translate russian sayori_exclusive_1_d975f34f:
    "Я пытаюсь стереть пятно пальцем."

translate russian sayori_exclusive_1_4c981d96:
    s "Н-но никто бы этого не заметил..."

translate russian sayori_exclusive_1_c21e6c0b:
    mc "Конечно, заметили бы."

translate russian sayori_exclusive_1_6bbbe8c8:
    mc "Просто никто тебе не скажет, потому что не хочет тебя смущать."

translate russian sayori_exclusive_1_b1102581:
    mc "К счастью, мне на это совершенно наплевать."

translate russian sayori_exclusive_1_6b261d64:
    s 5c "Эй, вредина..."

translate russian sayori_exclusive_1_9d2ccf73:
    mc "А ещё ты даже пиджак не застёгиваешь."

translate russian sayori_exclusive_1_7088cb16:
    mc "Серьёзно, Сайори..."

translate russian sayori_exclusive_1_c3daf6f0:
    mc "Как думаешь, почему у тебя до сих пор нет парня?"

translate russian sayori_exclusive_1_3cd77e3d:
    s "Э-э??"

translate russian sayori_exclusive_1_66638312:
    s "Это {i}очень{/i} жестоко!"

translate russian sayori_exclusive_1_0bd0c01c:
    mc "Прости, но потом ты мне ещё спасибо скажешь..."

translate russian sayori_exclusive_1_192cdae5:
    "Я начинаю застёгивать её пиджак снизу."

translate russian sayori_exclusive_1_b05e7ba0:
    mc "Вот увидишь, насколько так лучше, и передумаешь."

translate russian sayori_exclusive_1_c98e38ed:
    s "Э-хе-хе~"

translate russian sayori_exclusive_1_e508380c:
    s "Это так забавно."

translate russian sayori_exclusive_1_e4068727:
    mc "Что именно?"

translate russian sayori_exclusive_1_93f8ec4b:
    s "Ну..."

translate russian sayori_exclusive_1_b37f6e0a:
    s "Я просто подумала, как странно, что у меня есть друг, который делает такие вещи."

translate russian sayori_exclusive_1_fb2e5377:
    mc "А?"

translate russian sayori_exclusive_1_c981a875:
    mc "Н-не говори так!"

translate russian sayori_exclusive_1_c38e4c0d:
    mc "Из-за тебя {i}мне{/i} теперь неловко, глупая..."

translate russian sayori_exclusive_1_1d44c08f:
    s "Но всё хорошо."

translate russian sayori_exclusive_1_630495a9:
    s "Я рада, что у нас всё вот так."

translate russian sayori_exclusive_1_74ba5981:
    s "А ты разве нет?"

translate russian sayori_exclusive_1_f9d65918:
    mc "А—"

translate russian sayori_exclusive_1_3a09390a:
    mc "Н-наверное..."

translate russian sayori_exclusive_1_56a12c3e:
    s "Эй, осторожнее..."

translate russian sayori_exclusive_1_a11bc557:
    s "Пуговица может оторваться!"

translate russian sayori_exclusive_1_1a327ede:
    mc "Почему эта так плохо застёгивается...?"

translate russian sayori_exclusive_1_6ffc432e:
    "Я с трудом пытаюсь застегнуть пуговицу у неё на груди."

translate russian sayori_exclusive_1_16e1e85b:
    mc "Он тебе вообще по размеру?"

translate russian sayori_exclusive_1_c98e38ed_1:
    s "Э-хе-хе~"

translate russian sayori_exclusive_1_956085d7:
    s "Был, когда я его покупала."

translate russian sayori_exclusive_1_0a69f768:
    mc "Эх..."

translate russian sayori_exclusive_1_ddaf00ce:
    mc "Если бы ты его хоть раз застегнула, то давно бы заметила, что он тебе мал."

translate russian sayori_exclusive_1_4f1389df:
    mc "Чему это ты улыбаешься?"

translate russian sayori_exclusive_1_7c1d17ee:
    s "Значит, у меня опять выросла грудь!"

translate russian sayori_exclusive_1_dbe188cc:
    mc "Н-не говори такое вслух!!"

translate russian sayori_exclusive_1_c98e38ed_2:
    s "Э-хе-хе~"

translate russian sayori_exclusive_1_7e00e9ab:
    mc "Как бы то ни было..."

translate russian sayori_exclusive_1_e8dff0de:
    mc "Теперь ты выглядишь гораздо лучше, так что..."

translate russian sayori_exclusive_1_93deaf69:
    mc "А..."

translate russian sayori_exclusive_1_8a634766:
    "...Почему так странно видеть Сайори с застёгнутым пиджаком?"

translate russian sayori_exclusive_1_b1aa4bc1:
    s "Но в нём так тесно..."

translate russian sayori_exclusive_1_20d2fea2:
    s "У-у-у..."

translate russian sayori_exclusive_1_08daea23:
    s "Оно совсем того не стоит!"

translate russian sayori_exclusive_1_dae903cd:
    "Сайори торопливо снова расстёгивает пиджак."

translate russian sayori_exclusive_1_1272fd90:
    s "Фух!"

translate russian sayori_exclusive_1_f1a38fad:
    s "Так гораздо лучше~"

translate russian sayori_exclusive_1_16f5bea5:
    "Сайори раскидывает руки и кружится."

translate russian sayori_exclusive_1_83fa40f8:
    s 1a "Значит, если не застёгиваться, у меня не будет парня, да?"

translate russian sayori_exclusive_1_a4c5b234:
    mc "Это что за логика?"

translate russian sayori_exclusive_1_1679f655:
    mc "И почему ты так говоришь, будто это хорошо?"

translate russian sayori_exclusive_1_c8a163c1:
    s "Потому что..."

translate russian sayori_exclusive_1_44265465:
    s 4h "...Если бы у меня был парень, он бы тебе даже не разрешил вот так со мной возиться!"

translate russian sayori_exclusive_1_14d1b661:
    s 4y "Да и всё равно ты заботишься обо мне лучше, чем кто-либо другой..."

translate russian sayori_exclusive_1_25daa4ab:
    s "Вот поэтому я и не застёгиваюсь!"

translate russian sayori_exclusive_1_e9b09b46:
    mc "Хватит говорить такие смущающие вещи!"

translate russian sayori_exclusive_1_1a235903:
    s 1b "А?"

translate russian sayori_exclusive_1_bbfc9766:
    s "Ничего смущающего я не говорила..."

translate russian sayori_exclusive_1_9098da49:
    mc "Ну ты даёшь..."

translate russian sayori_exclusive_1_118d63e5:
    mc "Ну, в общем, постарайся просыпаться хоть чуть-чуть пораньше..."

translate russian sayori_exclusive_1_e94e689d:
    s 1j "Только если ты постараешься пораньше ложиться!"

translate russian sayori_exclusive_1_e65657c9:
    mc "Ладно, ладно..."

translate russian sayori_exclusive_1_e4338661:
    mc "Договорились."

translate russian sayori_exclusive_1_e688cc67_1:
    s 4q "Э-хе-хе~"

translate russian sayori_exclusive_1_f12eef29:
    s 4x "Похоже, мы и правда лучше заботимся друг о друге, чем о себе."

translate russian sayori_exclusive_1_760566c8:
    mc "Да, похоже на то..."

translate russian sayori_exclusive_1_9ce18680:
    s 4y "Так, может, ты будешь приходить будить меня по утрам!"

translate russian sayori_exclusive_1_3523f30e:
    mc "Ты опять за своё, Сайори..."

translate russian sayori_exclusive_1_8d0c9209:
    s 1h "Ну, в этот раз я же пошутила!"

translate russian sayori_exclusive_1_bd8edec3:
    mc "Ну и ну, иногда с тобой совершенно не поймёшь."

translate russian sayori_exclusive_1_90de9c4d:
    m "Итак, ребята!"

translate russian sayori_exclusive_1_fb2e5377_1:
    mc "А?"

translate russian sayori_exclusive_1_f9710377:
    "Вдруг раздаётся голос Моники."

translate russian sayori_exclusive_1_9fb616df:
    m "Может, теперь поделимся стихами, которые написали?"

translate russian sayori_exclusive_1_3f5fc96c:
    s "Ура~!"

translate russian sayori_exclusive_1_d44f1914:
    s 4x "[player], мне не терпится прочитать твоё!"

translate russian sayori_exclusive_1_ae6b61bd:
    mc "Да, мне тоже..."

translate russian sayori_exclusive_1_def52e15:
    "Энтузиазма в моём голосе не слышно, но Сайори всё равно вприпрыжку убегает за своим стихотворением."

translate russian sayori_exclusive_2_4ea6d987:
    s "[player], [player]!"

translate russian sayori_exclusive_2_bd4767d3:
    "Сайори вдруг подходит ко мне."

translate russian sayori_exclusive_2_ef4c0d72:
    s "Я схожу в другой класс за принадлежностями."

translate russian sayori_exclusive_2_08f7835f:
    s "Хочешь со мной?"

translate russian sayori_exclusive_2_ad189183:
    mc "За принадлежностями?"

translate russian sayori_exclusive_2_66a7a5ca:
    mc "Для чего?"

translate russian sayori_exclusive_2_860d16e7:
    s 2a "Ну, ты же знаешь, что скоро фестиваль?"

translate russian sayori_exclusive_2_e7fb537c:
    s "Мы с Моникой собирались сделать плакаты и всё такое."

translate russian sayori_exclusive_2_5e7c5b37:
    s "Так что мне надо найти мелки, фломастеры, клей-карандаши..."

translate russian sayori_exclusive_2_236ab8d0:
    mc "А, понятно."

translate russian sayori_exclusive_2_a48cc7e3:
    mc "Конечно, пойдём вместе."

translate russian sayori_exclusive_2_df253bf7:
    s 4q "Ура-а~"

translate russian sayori_exclusive_2_3a535a22:
    s 4x "Моника, мы скоро вернёмся!"

translate russian sayori_exclusive_2_7490c240:
    m "А, [player] идёт с тобой за принадлежностями?"

translate russian sayori_exclusive_2_20c5f655:
    m "Не стоит утруждаться."

translate russian sayori_exclusive_2_5ba710fc:
    m "Я с радостью схожу с ним сама."

translate russian sayori_exclusive_2_9417fd73:
    s "Ну-у, а я хотела пойти!"

translate russian sayori_exclusive_2_a99fc349:
    s "Так весело исследовать пустые классы и всё такое!"

translate russian sayori_exclusive_2_cd00b7dc:
    m 2j "Хи-хи, ладно, ладно."

translate russian sayori_exclusive_2_1ac309ef:
    m 2a "Это было просто предложение."

translate russian sayori_exclusive_2_255cf63e:
    m "Поищи заодно бумагу для плакатов, хорошо?"

translate russian sayori_exclusive_2_8f60e528:
    s 1r "Хорошо-о~!"

translate russian sayori_exclusive_2_1b885327:
    s 1a "Готов, [player]?"

translate russian sayori_exclusive_2_92bcf7c6:
    mc "Ага, пошли."

translate russian sayori_exclusive_2_0af638b7:
    "Мы с Сайори выходим из клубной комнаты."

translate russian sayori_exclusive_2_a4b4ac63:
    "Я иду следом, а Сайори напевает и скачет по коридору."

translate russian sayori_exclusive_2_76811081:
    "Честное слово..."

translate russian sayori_exclusive_2_91daf522:
    "Такое чувство, будто я веду ребёнка в торговый центр или вроде того."

translate russian sayori_exclusive_2_f8d41feb:
    "Иногда Сайори радуется самым простым вещам."

translate russian sayori_exclusive_2_2d47587c:
    mc "Слушай, Сайори..."

translate russian sayori_exclusive_2_4b05586c:
    mc "А что именно мы будем делать на фестивале?"

translate russian sayori_exclusive_2_4f166585:
    mc "Не очень представляю, как устроить мероприятие из литературы..."

translate russian sayori_exclusive_2_8de11f01:
    s 1q "Э-хе-хе!"

translate russian sayori_exclusive_2_52245927:
    s 1x "Мы с Моникой всё спланировали!"

translate russian sayori_exclusive_2_663bc887:
    s "Не волнуйся~"

translate russian sayori_exclusive_2_85d4ab1c:
    mc "Правда...?"

translate russian sayori_exclusive_2_ea9b5b89:
    s "Ага!"

translate russian sayori_exclusive_2_a41131c3:
    s "Мы устроим поэтическое выступление!"

translate russian sayori_exclusive_2_0d8074de:
    mc "Выступление...?"

translate russian sayori_exclusive_2_299338ca:
    mc "Какое?"

translate russian sayori_exclusive_2_9ff618f7:
    s 1c "Ну..."

translate russian sayori_exclusive_2_6670a996:
    s "Все будут по очереди выходить на сцену..."

translate russian sayori_exclusive_2_cdfe97c1:
    s 1x "И читать свои любимые стихи!"

translate russian sayori_exclusive_2_93deaf69:
    mc "А..."

translate russian sayori_exclusive_2_73f95e7a:
    mc "Звучит..."

translate russian sayori_exclusive_2_4c0925b0:
    "...как-то скучновато?"

translate russian sayori_exclusive_2_f1a0ab05:
    s 1h "[player]!"

translate russian sayori_exclusive_2_d686af31:
    s "Ты совсем не так об этом думаешь!"

translate russian sayori_exclusive_2_9b6ebf73:
    s "Дело не просто в том, чтобы читать стихи..."

translate russian sayori_exclusive_2_75b44070:
    s 1x "А в том, чтобы их исполнять!"

translate russian sayori_exclusive_2_9c670c78:
    s "Ну, например, произносишь строчки вот так..."

translate russian sayori_exclusive_2_0286134c:
    s 2j "{i}У самых ног моих...{/i}"

translate russian sayori_exclusive_2_bb922589:
    s "{i}Последний уцелевший цветок манит меня.{/i}"

translate russian sayori_exclusive_2_05ce6477:
    s 1c "{i}Я скручиваю стебель, вызволяя его из цепких корней...{/i}"

translate russian sayori_exclusive_2_4ddd1d04:
    s "{i}И ласкаю меж пальцев последний миг радости.{/i}"

translate russian sayori_exclusive_2_c332976a:
    s 3g "{i}Но ради чего я призвала эту радость?{/i}"

translate russian sayori_exclusive_2_931328e8:
    s "{i}Ведь теперь, куда бы я ни взглянула...{/i}"

translate russian sayori_exclusive_2_702aa864:
    s 1j "{i}Некогда цветущее поле предо мной...{/i}"

translate russian sayori_exclusive_2_60a94cb5:
    s 4m "{i}Лишь бесплодная пустошь!{/i}"

translate russian sayori_exclusive_2_e1554201:
    s "..."

translate russian sayori_exclusive_2_f6880599:
    s 1r "Вот так!!"

translate russian sayori_exclusive_2_e87e0575:
    mc "Сайори..."

translate russian sayori_exclusive_2_be7a0933:
    "Как бы это сказать..."

translate russian sayori_exclusive_2_42174e2a:
    mc "Наверное, дело только во мне, но когда ты так говоришь, тебя просто невозможно воспринимать всерьёз..."

translate russian sayori_exclusive_2_035f27af:
    s "Э-э-э?"

translate russian sayori_exclusive_2_b2a92813:
    s "Вредина!"

translate russian sayori_exclusive_2_c570716f:
    s "Вообще-то, я над этим очень стараюсь!"

translate russian sayori_exclusive_2_e60f2295:
    mc "А, знаю, знаю!"

translate russian sayori_exclusive_2_6d8aa85e:
    mc "Я просто имел в виду, что это очень уж непривычно контрастирует с твоей милотой."

translate russian sayori_exclusive_2_25cb994e:
    s "А-ха-ха! Не говори так, мне стыдно!"

translate russian sayori_exclusive_2_2e362b7a:
    s 4y "Но, наверное, это значит, что у меня хорошо получается~"

translate russian sayori_exclusive_2_8e64bc71:
    mc "Да, наверное..."

translate russian sayori_exclusive_2_4f04f7f7:
    s 4r "А-а-ах, я так волнуюсь!"

translate russian sayori_exclusive_2_94e07e55:
    s "Фестиваль будет таким весёлым~"

translate russian sayori_exclusive_2_1c93e58a:
    "Сайори снова кружится посреди коридора."

translate russian sayori_exclusive_2_8f8d3042:
    s 1x "Эй, [player], вот этот класс пустой!"

translate russian sayori_exclusive_2_a99c4f07:
    s "Начинаем миссию!"

translate russian sayori_exclusive_2_f3a0c4df:
    mc "Миссию, значит...?"

translate russian sayori_exclusive_2_9ecaa5bb:
    "Я давно уже не проводил время с Сайори вот так."

translate russian sayori_exclusive_2_a6362831:
    "Но в итоге она ни капельки не изменилась."

translate russian sayori_exclusive_2_c71b5972:
    "Она — сплошной сгусток солнечного света, черпающий радость из всего вокруг."

translate russian sayori_exclusive_2_9a65522f:
    "Меня это наполняет ностальгией."

translate russian sayori_exclusive_2_0cf21e0c:
    "С годами я стал всё чаще запираться у себя в комнате."

translate russian sayori_exclusive_2_1d55b454:
    "Поэтому приключения с Сайори пробуждают во мне особое чувство, о котором я уже успел забыть."

translate russian sayori_exclusive_2_e0ed16fc:
    "Мы вдвоём заходим в класс."

translate russian sayori_exclusive_2_179ec64e:
    "Сайори направляется прямиком к шкафу, я за ней."

translate russian sayori_exclusive_2_f0e3351f:
    s "Посмотрим, что тут у нас..."

translate russian sayori_exclusive_2_07bebb17:
    s 4x "...Мелки!!"

translate russian sayori_exclusive_2_57c414dc:
    "Сайори снимает с полки коробку, полную восковых мелков."

translate russian sayori_exclusive_2_598d87eb:
    s "И фирма самая лучшая!"

translate russian sayori_exclusive_2_c5710f8d:
    s 1b "Правда, они какие-то грязные..."

translate russian sayori_exclusive_2_bd4d817a:
    "Сайори начинает доставать из коробки мелки один за другим и читать названия цветов."

translate russian sayori_exclusive_2_81fcee2b:
    mc "Так, одно есть."

translate russian sayori_exclusive_2_dfb86c80:
    mc "Не отвлекайся, нам ещё нужно найти—"

translate russian sayori_exclusive_2_4ec0bcfa:
    s 1a "Подожди, я ищу свой любимый цвет..."

translate russian sayori_exclusive_2_e65657c9:
    mc "Ладно, ладно..."

translate russian sayori_exclusive_2_83ba12df:
    mc "Тогда хотя бы подвинься, чтобы я поискал бумагу для плакатов."

translate russian sayori_exclusive_2_a649150f:
    s 1b "Ой, я случайно один уронила—"

translate russian sayori_exclusive_2_24482806:
    "{i}Бум!{/i}"

translate russian sayori_exclusive_2_128c9be0:
    s "Кья—!"

translate russian sayori_exclusive_2_bf4b55c4:
    "Сайори наклоняется и со всего размаху бьётся лбом о полку."

translate russian sayori_exclusive_2_7d4acd5c:
    "Она падает на пол, и мелки рассыпаются у неё по коленям."

translate russian sayori_exclusive_2_8235b7df:
    s "Ай-ай-ай-ай-ай..."

translate russian sayori_exclusive_2_91d8a70c:
    mc "Ты в порядке?"

translate russian sayori_exclusive_2_5fd88654:
    s "Мой лоб..."

translate russian sayori_exclusive_2_e9ad7b56:
    "Сайори держится за лоб."

translate russian sayori_exclusive_2_0bd48947:
    mc "Боже, Сайори..."

translate russian sayori_exclusive_2_2fcf2d8a:
    mc "Это так на тебя похоже, правда?"

translate russian sayori_exclusive_2_63a8816a:
    mc "Давай, дай посмотрю."

translate russian sayori_exclusive_2_a0abe84c:
    "Раз уж Сайори сидит на полу, я беру её за талию и вытаскиваю из шкафа."

translate russian sayori_exclusive_2_e46cef12:
    mc "Убери руки, Сайори..."

translate russian sayori_exclusive_2_0bd9c1ff:
    s 4g "Но мне больно..."

translate russian sayori_exclusive_2_340b8199:
    mc "Всего на секундочку."

translate russian sayori_exclusive_2_f1e5f04f:
    "Сайори медленно отнимает руки ото лба."

translate russian sayori_exclusive_2_2574e759:
    "Я осторожно отвожу её чёлку в сторону."

translate russian sayori_exclusive_2_16b0e42e:
    s "Ай—!"

translate russian sayori_exclusive_2_4bbe5891:
    mc "Прости..."

translate russian sayori_exclusive_2_98f59a1c:
    "Посреди лба у неё огромное красное пятно."

translate russian sayori_exclusive_2_3e18c6f9:
    "К тому же начинает вскакивать шишка."

translate russian sayori_exclusive_2_2083a2a7:
    mc "Ну и ну, сейчас опухнет."

translate russian sayori_exclusive_2_1f3388f4:
    mc "Надо найти тебе лёд..."

translate russian sayori_exclusive_2_23d81314:
    s "[player]..."

translate russian sayori_exclusive_2_2c59ee1e:
    mc "Где вообще найти лёд в такое время...?"

translate russian sayori_exclusive_2_4a820da6:
    mc "А, наверное, сойдёт и холодный напиток..."

translate russian sayori_exclusive_2_e483a67e:
    s "Не надо—!"

translate russian sayori_exclusive_2_62d43352:
    s "Я и так согласна— походить на единорога—"

translate russian sayori_exclusive_2_7fddee82:
    "Даже морщась от боли, Сайори умудряется глупо пошутить."

translate russian sayori_exclusive_2_4e8c6ca5:
    mc "А-ха-ха, что ты несёшь?"

translate russian sayori_exclusive_2_96860542:
    mc "Я сейчас вернусь, ладно?"

translate russian sayori_exclusive_2_7b5965f1:
    s "Л-ладно..."

translate russian sayori_exclusive_2_1e90206b:
    "Я хлопаю Сайори по плечу и выбегаю в коридор."

translate russian sayori_exclusive_2_f17da94c:
    "Нахожу ближайший торговый автомат."

translate russian sayori_exclusive_2_bf030138:
    mc "Что бы взять...?"

translate russian sayori_exclusive_2_1c9f3d77:
    "В общем-то, неважно — пить это никто не будет, это вместо пакета со льдом."

translate russian sayori_exclusive_2_e0fd23a5:
    "Но я знаю, что Сайори любит яблочный сок, поэтому покупаю его."

translate russian sayori_exclusive_2_e4b80c9d:
    "Всего через минуту я уже возвращаюсь в класс, где оставил Сайори."

translate russian sayori_exclusive_2_0b8ae710:
    "Одной ладонью она держится за лоб, а другой неуклюже сгребает мелки обратно в коробку."

translate russian sayori_exclusive_2_9c106c29:
    s "Хорошо хоть, они и до того, как я их рассыпала, лежали не на своих местах..."

translate russian sayori_exclusive_2_f1d182b3:
    mc "Сайори, держи."

translate russian sayori_exclusive_2_317cfd53:
    "Я протягиваю Сайори бутылку яблочного сока."

translate russian sayori_exclusive_2_65e752ae:
    s "Какая холодненькая..."

translate russian sayori_exclusive_2_282d250c:
    "Сайори открывает крышку и начинает пить."

translate russian sayori_exclusive_2_828bf0f4:
    mc "Сайори, ты что делаешь?!"

translate russian sayori_exclusive_2_7cc88e1d:
    mc "Это для лба, дурочка!"

translate russian sayori_exclusive_2_57cb4d56:
    s "А—"

translate russian sayori_exclusive_2_9d1bbf1f:
    s "Прости, я забыла~"

translate russian sayori_exclusive_2_47abfe8d:
    s "А-ха-ха-ха!"

translate russian sayori_exclusive_2_313f87a2:
    mc "Насколько сильно ты ударилась головой...?"

translate russian sayori_exclusive_2_fe626b9d:
    "Сайори прикладывает бутылку к шишке."

translate russian sayori_exclusive_2_76e246b9:
    s "Щиплет..."

translate russian sayori_exclusive_2_562bd154:
    mc "Потерпи, скоро станет легче."

translate russian sayori_exclusive_2_f0acd59c:
    mc "Похоже, ты собрала почти все мелки, это хорошо."

translate russian sayori_exclusive_2_63ef6bb1:
    s "Эй, [player]..."

translate russian sayori_exclusive_2_7c4d0989:
    s "Это немножко напоминает детство, правда...?"

translate russian sayori_exclusive_2_11fc065b:
    mc "А? Ты о чём?"

translate russian sayori_exclusive_2_af2aa01c:
    s "Ну, помнишь, как мы всё время играли на улице..."

translate russian sayori_exclusive_2_6fe60d8b:
    s "Я всегда старалась за тобой поспевать."

translate russian sayori_exclusive_2_6e9f2e68:
    s "А ты кое в чём был немножко невнимательным..."

translate russian sayori_exclusive_2_39600e47:
    s "Например, я обычно отставала или не могла залезть туда же, куда ты..."

translate russian sayori_exclusive_2_65995028:
    s "Но иногда, когда я пыталась сделать то, что у меня не получалось, я ушибалась."

translate russian sayori_exclusive_2_9c939182:
    s "Падала и обдирала коленки или набивала шишку..."

translate russian sayori_exclusive_2_b153374a:
    s "И начинала очень громко плакать."

translate russian sayori_exclusive_2_fc5de902:
    s "А-ха-ха!"

translate russian sayori_exclusive_2_8d3c6891:
    s "А ты прибегал так быстро, как только мог."

translate russian sayori_exclusive_2_538f8ebe:
    s "И очень старался меня успокоить."

translate russian sayori_exclusive_2_fb6182dd:
    s "Будто винил себя и боялся, что тебе влетит, если кто-нибудь узнает..."

translate russian sayori_exclusive_2_4e4e18ef:
    s "Хотя ты был совсем-совсем не виноват, понимаешь?"

translate russian sayori_exclusive_2_0b40f342:
    mc "Неужели я правда так делал...?"

translate russian sayori_exclusive_2_6aaa6b13:
    s "Ага... ты не помнишь?"

translate russian sayori_exclusive_2_a25340ed:
    mc "Если подумать, может, немного и помню..."

translate russian sayori_exclusive_2_b2c73dc7:
    mc "Наверное, я всегда был так увлечён своими играми, что не обращал на тебя достаточно внимания."

translate russian sayori_exclusive_2_8ba352b0:
    mc "Так что в каком-то смысле это была моя вина."

translate russian sayori_exclusive_2_94693cef:
    mc "Как и в этот раз..."

translate russian sayori_exclusive_2_f546ba9c:
    mc "Если бы я не торопил тебя вылезать из шкафа, ты бы, наверное, не ударилась."

translate russian sayori_exclusive_2_23d81314_1:
    s "[player]..."

translate russian sayori_exclusive_2_9f2f68b4:
    s "Ты, кажется, сам этого не замечаешь, но ты всегда думаешь о других."

translate russian sayori_exclusive_2_9f14e418:
    s "Даже спустя столько лет..."

translate russian sayori_exclusive_2_94254a75:
    s "Ты бежишь мне на помощь, хотя я просто неуклюжая."

translate russian sayori_exclusive_2_f6a70330:
    s "Ты такой душка..."

translate russian sayori_exclusive_2_c83dc539:
    mc "Н-не называй меня так!"

translate russian sayori_exclusive_2_3947a85e:
    mc "И вообще, я не всегда так делаю..."

translate russian sayori_exclusive_2_f3b701ba:
    mc "Наверное, когда дело касается тебя, это получается само собой."

translate russian sayori_exclusive_2_a24cb8db:
    mc "Не успеваю опомниться, как уже веду себя с тобой вот так."

translate russian sayori_exclusive_2_6b862d7d:
    mc "Наверное, так бывает, когда очень давно дружишь."

translate russian sayori_exclusive_2_9f4c69bc:
    s "Правда...?"

translate russian sayori_exclusive_2_aceff536:
    s "Может, ты и прав..."

translate russian sayori_exclusive_2_23d81314_2:
    s "[player]..."

translate russian sayori_exclusive_2_de28276d:
    s "Я так рада, что между нами ничего не изменилось."

translate russian sayori_exclusive_2_d0478868:
    s "Думаешь, так будет всегда?"

translate russian sayori_exclusive_2_c3eb8a5f:
    mc "Всегда...?"

translate russian sayori_exclusive_2_84a398b9:
    "Если быть честным с самим собой..."

translate russian sayori_exclusive_2_4f62e153:
    "Неизвестно, куда каждый из нас поступит после школы и что будет дальше."

translate russian sayori_exclusive_2_5750840d:
    "Так что давать какие-то обещания было бы нечестно."

translate russian sayori_exclusive_2_bf0874e3:
    "Но..."

translate russian sayori_exclusive_2_32da8be5:
    mc "Ну, надеюсь."

translate russian sayori_exclusive_2_d0bf2071:
    mc "Мы ведь уже столько лет дружим, правда?"

translate russian sayori_exclusive_2_2f2b523a:
    mc "Не могу представить, чтобы ты когда-нибудь изменилась, так что я полон надежд."

translate russian sayori_exclusive_2_7c28ceed:
    s "Я так счастлива..."

translate russian sayori_exclusive_2_dd608be3:
    "В глазах у Сайори мечтательное выражение."

translate russian sayori_exclusive_2_592bb0c1:
    "Какое-то время мы молчим."

translate russian sayori_exclusive_2_afced0ef:
    "Снаружи она такая глупенькая и неуклюжая, что когда я вижу её вот так погружённой в мысли..."

translate russian sayori_exclusive_2_b2985e6c:
    "Мне не хочется её тревожить."

translate russian sayori_exclusive_2_e34b90af:
    s "Наверное, нам пора возвращаться..."

translate russian sayori_exclusive_2_5c870fd0:
    s "Не хочу, чтобы Моника волновалась, понимаешь?"

translate russian sayori_exclusive_2_32472eec:
    mc "Ну-ну, удачи."

translate russian sayori_exclusive_2_03477bd7:
    mc "Она всё равно увидит твой лоб."

translate russian sayori_exclusive_2_dd3c98d4:
    s "Не увидит, если я спрячу его под чёлкой~"

translate russian sayori_exclusive_2_723967cd:
    "Сайори вскакивает на ноги."

translate russian sayori_exclusive_2_5c3181d9:
    s "А-а-а-ай—!"

translate russian sayori_exclusive_2_0ea983ff:
    "Она снова хватается за лоб."

translate russian sayori_exclusive_2_c27fc0da:
    mc "Не вставай так резко, если только что ударилась!"

translate russian sayori_exclusive_2_772b7720:
    s "У-у-у-у..."

translate russian sayori_exclusive_2_d61cd406:
    mc "Ну, теперь уже поздно..."

translate russian sayori_exclusive_2_ab004c1f:
    mc "Ладно, пошли."

translate russian sayori_exclusive_2_272a0f53:
    "Я выхожу из класса вслед за Сайори."

translate russian sayori_exclusive_2_ab1fd0d2:
    "Сайори теребит чёлку, пытаясь спрятать шишку, но без особого успеха."

translate russian sayori_exclusive_2_0c55e269:
    "Через минуту мы возвращаемся в клубную комнату."

translate russian sayori_exclusive_2_25f9f91b:
    m "А, вы вернулись!"

translate russian sayori_exclusive_2_d67d39ac:
    m "Как раз вовремя, я уже собиралась начать делиться стихами."

translate russian sayori_exclusive_2_62a8336a:
    m 1d "А? Сайори, твой лоб..."

translate russian sayori_exclusive_2_f3d25d58:
    mc "С ней всё хорошо, не беспокойся—"

translate russian sayori_exclusive_2_6c376380:
    s "Я играла с мелками и треснулась лбом о полку!"

translate russian sayori_exclusive_2_2b35b6fe:
    mc "..."

translate russian sayori_exclusive_2_e612037c:
    m "..."

translate russian sayori_exclusive_2_13e59773:
    m 3l "...Ну, как бы то ни было!"

translate russian sayori_exclusive_2_30129c4d:
    m 1a "Вам удалось найти всё, что нужно?"

translate russian sayori_exclusive_2_464e4b1d:
    s "Ага! Всё у меня прямо—"

translate russian sayori_exclusive_2_bf069d85:
    s 1n "...А?"

translate russian sayori_exclusive_2_134b9320:
    "Сайори лихорадочно оглядывается."

translate russian sayori_exclusive_2_2829fbdb:
    s "Я... всё забыла!!"

translate russian sayori_exclusive_2_da2075e7:
    mc "Успокойся, Сайори."

translate russian sayori_exclusive_2_12353a31:
    mc "Всё здесь, у меня."

translate russian sayori_exclusive_2_51155624:
    mc "Бумагу для плакатов я тоже нашёл."

translate russian sayori_exclusive_2_30727938:
    m "А-ха-ха!"

translate russian sayori_exclusive_2_4a72d8e0:
    m "Похоже, всю работу в итоге сделал ты, [player]."

translate russian sayori_exclusive_2_c322804d:
    mc "А, ну, Сайори—"

translate russian sayori_exclusive_2_2295a512:
    "Мне так и не удаётся придумать для Сайори оправдание."

translate russian sayori_exclusive_2_f60f0a2a:
    s "Я превратила это в приключение!"

translate russian sayori_exclusive_2_cb79e6c0:
    mc "...Ага, вот."

translate russian sayori_exclusive_2_41b5dc26:
    m "А-ха-ха, ладно, ладно."

translate russian sayori_exclusive_2_ccb28dcf:
    m 1a "Как бы то ни было, отличная работа!"

translate russian sayori_exclusive_2_201a0e97:
    m "Сегодня вечером начну делать плакаты."

translate russian sayori_exclusive_2_207bcd32:
    s "Я тоже!"

translate russian sayori_exclusive_2_6234334a:
    m 4b "...Итак, ребята!"

translate russian sayori_exclusive_2_20dbe677:
    m "Готовы делиться стихами?"

translate russian sayori_exclusive_2_728dbcca:
    mc "Пожалуй, надо взять своё..."

translate russian sayori_exclusive_2_3d059004:
    "Убедившись, что коробка с мелками плотно закрыта, я возвращаюсь на своё место."
