# Русский перевод: script-exclusives2-yuri

translate russian yuri_exclusive2_1_e440bb66:
    "Мне очень хочется ещё немного поговорить с Юри..."

translate russian yuri_exclusive2_1_621b29bd:
    "Но в то же время неловко отвлекать её от чтения."

translate russian yuri_exclusive2_1_98b79815:
    "Я мельком вижу обложку её книги."

translate russian yuri_exclusive2_1_1385bf59:
    "Похоже, это та же книга, которую она одолжила мне..."

translate russian yuri_exclusive2_1_e35e4f57:
    "Более того, она, кажется, только на первых страницах."

translate russian yuri_exclusive2_1_728dcbc5:
    y "Ах..."

translate russian yuri_exclusive2_1_a3e7f3d1:
    "Чёрт—"

translate russian yuri_exclusive2_1_f669242a:
    "Кажется, она заметила, что я на неё смотрю..."

translate russian yuri_exclusive2_1_990b5d3a:
    "Она снова украдкой бросает на меня взгляд, и на долю секунды наши глаза встречаются."

translate russian yuri_exclusive2_1_0dbaabdd:
    y 4b "..."

translate russian yuri_exclusive2_1_aef29682:
    "Но от этого она лишь глубже прячет лицо в книгу."

translate russian yuri_exclusive2_1_4bbe5891:
    mc "Прости..."

translate russian yuri_exclusive2_1_225dcd47:
    mc "Я просто задумался..."

translate russian yuri_exclusive2_1_9a0048e8:
    "Я бормочу это, чувствуя, что смутил её."

translate russian yuri_exclusive2_1_e02af5ad:
    y oneeye "Ох..."

translate russian yuri_exclusive2_1_a41cea99:
    y "Ничего..."

translate russian yuri_exclusive2_1_3b99d5e9:
    y "Если бы я была сосредоточена, то, наверное, и не заметила бы."

translate russian yuri_exclusive2_1_749d562e:
    y "Но я просто немного перечитываю это, так что..."

translate russian yuri_exclusive2_1_8dcab0c1:
    mc "Это та книга, которую ты мне дала, да?"

translate russian yuri_exclusive2_1_7b0a03ee:
    y "Угу."

translate russian yuri_exclusive2_1_9de78180:
    y "Мне захотелось перечитать её кусочек."

translate russian yuri_exclusive2_1_b6b08cc7:
    y 2q "Без какой-то особой причины...!"

translate russian yuri_exclusive2_1_63031f4d:
    mc "Просто любопытно — откуда у тебя два экземпляра одной книги?"

translate russian yuri_exclusive2_1_728dcbc5_1:
    y "Ах..."

translate russian yuri_exclusive2_1_8be5857f:
    y "Ну, когда я вчера зашла в книжный—"

translate russian yuri_exclusive2_1_56924230:
    y 3o "Ах, я не это хотела сказать..."

translate russian yuri_exclusive2_1_5daab38f:
    y "То есть—"

translate russian yuri_exclusive2_1_1fb27bb9:
    y 1w "Я... просто так вышло, что купила две."

translate russian yuri_exclusive2_1_236ab8d0:
    mc "А, понятно."

translate russian yuri_exclusive2_1_40855474:
    "Тут есть что-то довольно очевидное, о чём Юри мне не говорит, но я решаю не допытываться."

translate russian yuri_exclusive2_1_4f372d32:
    mc "Я обязательно скоро начну её читать!"

translate russian yuri_exclusive2_1_9fa7e925:
    y 2u "Рада это слышать..."

translate russian yuri_exclusive2_1_6a834c69:
    y "Когда сюжет начнёт набирать обороты, тебе, возможно, будет трудно оторваться."

translate russian yuri_exclusive2_1_336b89ef:
    y 2c "Это очень увлекательная история, в которой легко узнать себя."

translate russian yuri_exclusive2_1_85d4ab1c:
    mc "Правда...?"

translate russian yuri_exclusive2_1_ch22_5345ad5d:
    mc "А о чём вообще эта история?"

translate russian yuri_exclusive2_1_ch22_cae7b7d0:
    y 1f "Ну..."

translate russian yuri_exclusive2_1_ch22_5c53d1aa:
    y "М-м-м..."

translate russian yuri_exclusive2_1_ch22_4330ddf7:
    "Я смотрю на обложку книги."

translate russian yuri_exclusive2_1_ch22_0c75c656:
    "Книга называется «Портрет Маркова»."

translate russian yuri_exclusive2_1_ch22_fd714eb0:
    "На передней обложке зловещий символ в виде глаза."

translate russian yuri_exclusive2_1_ch22_1cb43c2f:
    y 1a "Если вкратце, это о религиозном лагере, который превратили в тюрьму для опытов над людьми..."

translate russian yuri_exclusive2_1_ch22_554d83a6:
    y "И у тех, кто там заперт, есть особенность, которая превращает их в машины для убийства, жаждущие крови."

translate russian yuri_exclusive2_1_ch22_461c88e8:
    y 1m "Но в лаборатории становится ещё хуже, и там начинают выводить людей селекцией, отрезая им конечности и прикрепляя их к—"

translate russian yuri_exclusive2_1_ch22_cfffa461:
    y 1q "О-ой, это, кажется, немного спойлер..."

translate russian yuri_exclusive2_1_ch22_4b29aa25:
    y 3q "Но в общем, м-мне правда очень нравится!"

translate russian yuri_exclusive2_1_ch22_00ecd4f3:
    y 3n "...Книга, я имею в виду!"

translate russian yuri_exclusive2_1_ch22_48f0c396:
    y 3q "Н-не то, что с конечностями..."

translate russian yuri_exclusive2_1_ch22_0a469adb:
    mc "Это как-то—!"

translate russian yuri_exclusive2_1_ch22_89546258:
    "Это как-то мрачновато, нет?"

translate russian yuri_exclusive2_1_ch22_7bcce1db:
    "Юри так это преподнесла, будто история будет милой, так что этот мрачный поворот взялся словно из ниоткуда."

translate russian yuri_exclusive2_1_ch22_948c895b:
    y 1s "Ах..."

translate russian yuri_exclusive2_1_ch22_7bc89322:
    y "Тебе такое не по душе, [player]?"

translate russian yuri_exclusive2_1_ch22_ce487936:
    mc "Нет, дело не в этом..."

translate russian yuri_exclusive2_1_ch22_7c7d4031:
    mc "В смысле, мне такие истории вполне могут нравиться, так что не волнуйся."

translate russian yuri_exclusive2_1_ch22_3c899c8c:
    y 2u "Надеюсь..."

translate russian yuri_exclusive2_1_ch22_2269e4aa:
    "Да... Я совсем забыл, что Юри такое любит."

translate russian yuri_exclusive2_1_ch22_b87c0f68:
    "Снаружи она такая застенчивая и замкнутая, но, похоже, внутри у неё совсем другой мир."

translate russian yuri_exclusive2_1_ch22_79229864:
    y "Просто такая история..."

translate russian yuri_exclusive2_1_ch22_1abf1220:
    y 1a "Она из тех, что заставляют взглянуть на жизнь под странным новым углом."

translate russian yuri_exclusive2_1_ch22_93e29306:
    y "Когда ужасные вещи происходят не просто потому, что кто-то хочет творить зло..."

translate russian yuri_exclusive2_1_ch22_3ff5a78e:
    y "Но потому, что мир полон ужасных людей, а мы все и так ничего не стоим."

translate russian yuri_exclusive2_1_ch22_2257168a:
    y "И вдруггггггггггггггггггггггг ггггггггггггггггггггг{nw}"

translate russian yuri_exclusive2_1_ch22_2d6e3c72:
    y 3v "Я... я заболталась, да...?"

translate russian yuri_exclusive2_1_ch22_5dac5c99:
    y "Опять..."

translate russian yuri_exclusive2_1_ch22_d287205e:
    y 4b "Прости..."

translate russian yuri_exclusive2_1_ch22_47b1016d:
    mc "Эй, не извиняйся...!"

translate russian yuri_exclusive2_1_ch22_0fbafffa:
    mc "Мне вовсе не стало скучно."

translate russian yuri_exclusive2_1_ch22_ae7f22e8:
    y "Ну..."

translate russian yuri_exclusive2_1_ch22_9520be33:
    y "Тогда, наверное, всё в порядке..."

translate russian yuri_exclusive2_1_ch22_432dd786:
    y 4a "Но мне кажется, стоит предупредить тебя, что у меня есть такая проблема..."

translate russian yuri_exclusive2_1_ch22_f902f7cf:
    y "Когда я позволяю книгам и писательству заполнить мои мысли..."

translate russian yuri_exclusive2_1_ch22_f1d585ba:
    y "всё моё тело становится невероятно [gtext]{nw}"

translate russian yuri_exclusive2_1_ch22_cbb32f29:
    y "Я как будто забываю обращать внимание на других людей..."

translate russian yuri_exclusive2_1_ch22_1b4a2d9b:
    y 3t "Так что прости, если я вдруг скажу что-нибудь странное!"

translate russian yuri_exclusive2_1_ch22_7e573792:
    y "И, пожалуйста, останови меня, если начну слишком много болтать!"

translate russian yuri_exclusive2_1_ch22_db2f7cec:
    mc "Это—"

translate russian yuri_exclusive2_1_ch22_c443f13d:
    mc "По-моему, тебе правда не о чем беспокоиться..."

translate russian yuri_exclusive2_1_ch22_9c6f8ec5:
    mc "Это просто значит, что ты увлечена чтением."

translate russian yuri_exclusive2_1_ch22_7bfa8270:
    mc "Меньшее, что я могу сделать, — это послушать."

translate russian yuri_exclusive2_1_ch22_3bea2478:
    mc "Это ведь всё-таки литературный клуб..."

translate russian yuri_exclusive2_1_ch22_c2dd3459:
    y 4a "А—"

translate russian yuri_exclusive2_1_ch22_717cb0f3:
    y "Это..."

translate russian yuri_exclusive2_1_ch22_7c11a798:
    y "Что ж, это правда..."

translate russian yuri_exclusive2_1_ch22_0a788c2f:
    mc "Вообще-то..."

translate russian yuri_exclusive2_1_ch22_23631788:
    mc "Почему бы мне не начать её читать прямо сейчас?"

translate russian yuri_exclusive2_1_ch22_6961466a:
    y dragon "Д-да!"

translate russian yuri_exclusive2_1_ch22_3a42219b:
    y 3n "Т-то есть ты не обязан, но...!"

translate russian yuri_exclusive2_1_ch22_4e8c6ca5:
    mc "А-ха-ха, что ты несёшь?"

translate russian yuri_exclusive2_1_ch22_5a6499dc:
    y 3o "..."

translate russian yuri_exclusive2_1_ch22_d671f554:
    mc "Дай только возьму книгу..."

translate russian yuri_exclusive2_1_ch22_5b5dd31b:
    "Я быстро достаю книгу, которую положил в сумку."

translate russian yuri_exclusive2_1_ch22_64614a30:
    mc "Так... можно я сяду здесь?"

translate russian yuri_exclusive2_1_ch22_6ab0c7c0:
    "Я сажусь за парту рядом с Юри."

translate russian yuri_exclusive2_1_ch22_acedfa3b:
    y 3n "Ах...!"

translate russian yuri_exclusive2_1_ch22_92fa2786:
    y "Ну вот..."

translate russian yuri_exclusive2_1_ch22_cfce055e:
    mc "Точно можно?"

translate russian yuri_exclusive2_1_ch22_17b81435:
    mc "Ты, кажется, немного напряглась..."

translate russian yuri_exclusive2_1_ch22_717cb0f3_1:
    y "Это..."

translate russian yuri_exclusive2_1_ch22_d287205e_1:
    y 4b "Прости..."

translate russian yuri_exclusive2_1_ch22_678618c7:
    y "Дело не в том, что я не хочу!"

translate russian yuri_exclusive2_1_ch22_b683d384:
    y "Просто я к такому не очень привыкла..."

translate russian yuri_exclusive2_1_ch22_a44cd31c:
    y "В смысле, читать в чьей-то компании."

translate russian yuri_exclusive2_1_ch22_a7bcf340:
    mc "Понятно..."

translate russian yuri_exclusive2_1_ch22_7ddffb3c:
    mc "Ну, просто скажи, если я буду тебя отвлекать или вроде того."

translate russian yuri_exclusive2_1_ch22_6efff781:
    y "Х-хорошо..."

translate russian yuri_exclusive2_1_ch22_b7550a3e:
    "Я открываю книгу и начинаю читать пролог."

translate russian yuri_exclusive2_1_ch22_695b1b6b:
    "Вскоре я понимаю, что Юри имела в виду, говоря о чтении в компании."

translate russian yuri_exclusive2_1_ch22_d2bc4359:
    "Я словно чувствую её присутствие у себя за плечом, пока читаю."

translate russian yuri_exclusive2_1_ch22_336c3ecb:
    "Ничего плохого в этом нет."

translate russian yuri_exclusive2_1_ch22_7099b9f9:
    "Может, немного отвлекает, но это чувство даже успокаивает."

translate russian yuri_exclusive2_1_ch22_79904e73:
    "Краем глаза я вижу Юри."

translate russian yuri_exclusive2_1_ch22_ffe5cfa7:
    "И понимаю, что на самом деле она не смотрит в свою книгу."

translate russian yuri_exclusive2_1_ch22_e241e6b4:
    "Я бросаю на неё взгляд."

translate russian yuri_exclusive2_1_ch22_c5bc1b32:
    "Похоже, вместо этого она читает из моей книги—"

translate russian yuri_exclusive2_1_ch22_510cdaf3:
    y "П-прости!"

translate russian yuri_exclusive2_1_ch22_0a665800:
    y "Я просто—!{nw}"

translate russian yuri_exclusive2_1_ch22_167110f3:
    y "Я просто{fast} купалась в жаре твоего тела жжжжжжжжаре аре аррррррр{nw}"

translate russian yuri_exclusive2_1_ch22_d23d4ffa:
    mc "Юри, ты правда очень часто извиняешься, да?"

translate russian yuri_exclusive2_1_ch22_4712ee86:
    y "Я... правда?"

translate russian yuri_exclusive2_1_ch22_6e71265b:
    y 4a "Я не нарочно..."

translate russian yuri_exclusive2_1_ch22_485fb852:
    y "Прости..."

translate russian yuri_exclusive2_1_ch22_89f89f32:
    y 4c "То есть—!"

translate russian yuri_exclusive2_1_ch22_ee7d9dbd:
    mc "А-ха-ха."

translate russian yuri_exclusive2_1_ch22_42937a87:
    mc "Вот, так ведь будет удобнее?"

translate russian yuri_exclusive2_1_ch22_4be018f3:
    "Я придвигаю свою парту вплотную к парте Юри и держу книгу между нами."

translate russian yuri_exclusive2_1_ch22_74f60a14:
    y 2v "Ах..."

translate russian yuri_exclusive2_1_ch22_adb995cc:
    y "П-пожалуй..."

translate russian yuri_exclusive2_1_ch22_bdf7b243:
    "Юри робко закрывает свой экземпляр."

translate russian yuri_exclusive2_1_ch22_c8915827:
    "Стоит нам обоим чуть наклониться, как наши плечи почти соприкасаются."

translate russian yuri_exclusive2_1_ch22_ffa8cf07:
    "Левая рука будто мешает, поэтому я держу книгу открытой правой."

translate russian yuri_exclusive2_1_ch22_7d3a640c:
    mc "А, кажется, так неудобно переворачивать страницы..."

translate russian yuri_exclusive2_1_ch22_9572fcba:
    y "Давай так..."

translate russian yuri_exclusive2_1_ch22_e50b1a55:
    "Юри левой рукой придерживает левую сторону книги большим и указательным пальцами."

translate russian yuri_exclusive2_1_ch22_93deaf69:
    mc "А..."

translate russian yuri_exclusive2_1_ch22_8aa7edbf:
    "Я делаю то же самое правой рукой с правой стороной."

translate russian yuri_exclusive2_1_ch22_f4605bd6:
    "Так я переворачиваю страницу, а Юри, когда та перелистывается на её сторону, прижимает её большим пальцем."

translate russian yuri_exclusive2_1_ch22_24340c2f:
    "Но если держать книгу вот так..."

translate russian yuri_exclusive2_1_ch22_34a46315:
    "Мы сидим, прижавшись друг к другу ещё теснее, чем раньше."

translate russian yuri_exclusive2_1_ch22_274fbd4a:
    "Это меня, вообще-то, здорово отвлекает...!"

translate russian yuri_exclusive2_1_ch22_e1a2be34:
    "Будто я чувствую тепло её лица, и она всё время у меня на краю зрения..."

translate russian yuri_exclusive2_1_ch22_44384bd1:
    y "...Ты готов?"

translate russian yuri_exclusive2_1_ch22_fb2e5377:
    mc "А?"

translate russian yuri_exclusive2_1_ch22_22bd46cd:
    y "Перевернуть страницу..."

translate russian yuri_exclusive2_1_ch22_960cc2a4:
    mc "А... прости!"

translate russian yuri_exclusive2_1_ch22_103817d4:
    mc "Кажется, я на секунду отвлёкся..."

translate russian yuri_exclusive2_1_ch22_5252b0b0:
    "Я снова бросаю взгляд на лицо Юри, и наши глаза встречаются."

translate russian yuri_exclusive2_1_ch22_7a860699:
    "Не знаю, как мне за ней поспевать..."

translate russian yuri_exclusive2_1_ch22_728dcbc5:
    y "Ах..."

translate russian yuri_exclusive2_1_ch22_6668580d:
    y "Ничего страшного."

translate russian yuri_exclusive2_1_ch22_dd97e184:
    y "Ты ведь не так привык читать, верно?"

translate russian yuri_exclusive2_1_ch22_f5f71ae0:
    y "Я не против подождать, если у тебя уйдёт чуть больше времени..."

translate russian yuri_exclusive2_1_ch22_506c74d6:
    y "Это, наверное, меньшее, что я могу сделать..."

translate russian yuri_exclusive2_1_ch22_9f203c74:
    y "Раз ты был со мной так терпелив..."

translate russian yuri_exclusive2_1_ch22_5aa72ccd:
    mc "Д-да..."

translate russian yuri_exclusive2_1_ch22_a64e8bc0:
    mc "Спасибо."

translate russian yuri_exclusive2_1_ch22_880606e6:
    "Мы продолжаем читать."

translate russian yuri_exclusive2_1_ch22_91dcd78e:
    "Юри больше не спрашивает, готов ли я перевернуть страницу."

translate russian yuri_exclusive2_1_ch22_6051933b:
    "Вместо этого я просто исхожу из того, что она дочитывает страницу раньше меня, и переворачиваю её сам."

translate russian yuri_exclusive2_1_ch22_e76a0690:
    "Первую главу мы дочитываем молча."

translate russian yuri_exclusive2_1_ch22_94aeb271:
    "И всё же каждая перевёрнутая страница кажется почти интимным обменом..."

translate russian yuri_exclusive2_1_ch22_b3d1da47:
    "Мой большой палец мягко отпускает страницу, позволяя ей перелететь на её сторону, где она ловит её своим."

translate russian yuri_exclusive2_1_ch22_54daf6f3:
    mc "Слушай, Юри..."

translate russian yuri_exclusive2_1_ch22_a38f93a8:
    mc "Может, это глупая мысль, но..."

translate russian yuri_exclusive2_1_ch22_dc2668cf:
    mc "Главная героиня мне немного напоминает тебя."

translate russian yuri_exclusive2_1_ch22_9d8b3104:
    y "А-а??"

translate russian yuri_exclusive2_1_ch22_ba519416:
    y "Н-нет, я совершенно не узнаю себя в этой героине!"

translate russian yuri_exclusive2_1_ch22_c0929641:
    y "Точно нет!"

translate russian yuri_exclusive2_1_ch22_72610a7c:
    mc "Правда...?"

translate russian yuri_exclusive2_1_ch22_e73bd860:
    mc "Я просто подумал о том, как она сомневается во всём, что говорит, и всё такое..."

translate russian yuri_exclusive2_1_ch22_ceede073:
    y "А-ах..."

translate russian yuri_exclusive2_1_ch22_1781bc54:
    y "Так вот ты о чём..."

translate russian yuri_exclusive2_1_ch22_485fb852_1:
    y "Прости..."

translate russian yuri_exclusive2_1_ch22_e72103a9:
    y "А я подумала, ты имел в виду... что-то другое в ней."

translate russian yuri_exclusive2_1_ch22_982ae76b:
    mc "Что-то другое...?"

translate russian yuri_exclusive2_1_ch22_1b764312:
    y "Н-ничего!"

translate russian yuri_exclusive2_1_ch22_16fb9d35:
    y "Мы же ещё даже до этого не дочитали..."

translate russian yuri_exclusive2_1_ch22_435cedc6:
    y "Так что не знаю, почему мне это пришло в голову..."

translate russian yuri_exclusive2_1_ch22_0c3b4eb3:
    y "А-ха-ха!"

translate russian yuri_exclusive2_1_ch22_a57fba06:
    mc "Юри, ты хорошо себя чувствуешь?"

translate russian yuri_exclusive2_1_ch22_5121d691:
    y "А—?"

translate russian yuri_exclusive2_1_ch22_88f6e69b:
    "С тех пор как мы начали читать, Юри как-то беспокойно ёрзает..."

translate russian yuri_exclusive2_1_ch22_f719f5f3:
    mc "Можешь отдохнуть, если тебе нехорошо."

translate russian yuri_exclusive2_1_ch22_a5ab9975:
    mc "Ты как-то... тяжело дышишь..."

translate russian yuri_exclusive2_1_ch22_31f57b57:
    y "Дышу...?"

translate russian yuri_exclusive2_1_ch22_a117d3a8:
    "Юри прикладывает руки к груди, будто проверяя сердцебиение."

translate russian yuri_exclusive2_1_ch22_2d7a579e:
    y "Я-я даже... не заметила..."

translate russian yuri_exclusive2_1_ch22_eefb49b8:
    y "...В общем, я в порядке!"

translate russian yuri_exclusive2_1_ch22_b97476b1:
    y "Мне просто нужно попить воды...!"

translate russian yuri_exclusive2_1_ch22_a7ea9b30:
    mc "Ладно... не перенапрягайся."

translate russian yuri_exclusive2_1_ch22_75dbc8b4:
    "Юри встаёт и чуть ли не бегом выскакивает из класса."

translate russian yuri_exclusive2_1_ch22_6455f543:
    mc "Что это вообще было...?"

translate russian yuri_exclusive2_1_ch22_de87a206:
    m "[player]?"

translate russian yuri_exclusive2_1_ch22_a5c5f36b:
    m "Что-то сейчас случилось?"

translate russian yuri_exclusive2_1_ch22_fb2e5377_1:
    mc "А?"

translate russian yuri_exclusive2_1_ch22_e818ac0a:
    mc "Понятия не имею..."

translate russian yuri_exclusive2_1_ch22_2f09279f:
    mc "Юри вела себя немного странно, наверное..."

translate russian yuri_exclusive2_1_ch22_6fa2f8f2:
    m 1r "Значит, ты ничего не знаешь..."

translate russian yuri_exclusive2_1_ch22_586d91c8:
    mc "Прости, не могу сказать, что знаю."

translate russian yuri_exclusive2_1_ch22_99f8c0f4:
    mc "Ты за неё волнуешься?"

translate russian yuri_exclusive2_1_ch22_77db1662:
    m 1a "Ох... нет, не особо."

translate russian yuri_exclusive2_1_ch22_33736deb:
    m "Я просто хотела убедиться, что ты ничего ей не сделал."

translate russian yuri_exclusive2_1_ch22_4eb2d28b:
    mc "Н-нет, ничего!"

translate russian yuri_exclusive2_1_ch22_12430d68:
    m 5 "А-ха-ха, не волнуйся... я тебе верю, глупенький."

translate russian yuri_exclusive2_1_ch22_f38c45b0:
    m "Юри иногда так делает, так что ничего тревожного."

translate russian yuri_exclusive2_1_ch22_12d62518:
    mc "Ладно... раз ты так говоришь."

translate russian yuri_exclusive2_1_ch22_cfc78ab0:
    m 2b "В общем, может, начнём делиться стихами?"

translate russian yuri_exclusive2_1_ch22_fb2e5377_2:
    mc "А?"

translate russian yuri_exclusive2_1_ch22_09c5199e:
    mc "Разве не стоит подождать Юри?"

translate russian yuri_exclusive2_1_ch22_fb54e9d7:
    m 2a "Ну, она может задержаться, вот я и подумала, что начнём без неё."

translate russian yuri_exclusive2_1_ch22_2780ba84:
    m "Так можно?"

translate russian yuri_exclusive2_1_ch22_63b0d5d4:
    mc "Да я просто спросил..."

translate russian yuri_exclusive2_1_ch22_1950528a:
    "Я встаю."

translate russian yuri_exclusive2_1_ch22_c0c90965:
    "Я запоминаю, где остановился, и снова убираю книгу в сумку."

translate russian yuri_exclusive2_2_e72920b3:
    mc "Эй, Юри."

translate russian yuri_exclusive2_2_444e7092:
    y "А?"

translate russian yuri_exclusive2_2_93deaf69:
    mc "А..."

translate russian yuri_exclusive2_2_826f0290:
    "Вдруг я замечаю, что Юри читает не ту книгу, которую мы читаем вместе."

translate russian yuri_exclusive2_2_58cac761:
    mc "Прости! Я не хотел мешать..."

translate russian yuri_exclusive2_2_8849a940:
    y 2m "Ах, нет..."

translate russian yuri_exclusive2_2_043b8fc5:
    y "Я, в общем-то, просто ждала тебя..."

translate russian yuri_exclusive2_2_17aaad6d:
    mc "А, раз так..."

translate russian yuri_exclusive2_2_9814a6fd:
    mc "Может, сразу и начнём?"

translate russian yuri_exclusive2_2_fb0e5788:
    y 2c "Да, давай!"

translate russian yuri_exclusive2_2_ch22_8bdc1c86:
    y 3a "Вообще-то, у меня есть просьба..."

translate russian yuri_exclusive2_2_ch22_8649e7f4:
    y "...Ты не против, если я сначала заварю чай?"

translate russian yuri_exclusive2_2_ch22_5a86862f:
    mc "Вовсе нет."

translate russian yuri_exclusive2_2_ch22_61544195:
    y 1c "Большое спасибо."

translate russian yuri_exclusive2_2_ch22_68e78420:
    y 1a "Если что-то и может сделать моё время для чтения здесь ещё лучше, так это хорошая чашка чая."

translate russian yuri_exclusive2_2_ch22_1ac81ad1:
    y "Не говоря уже о тебе."

translate russian yuri_exclusive2_2_ch22_f364f34f:
    "Юри встаёт и направляется к шкафу."

translate russian yuri_exclusive2_2_ch22_2a287e1b:
    "Я иду следом и смотрю, как она достаёт с полки небольшой кувшин для воды — из тех, что с фильтром внутри."

translate russian yuri_exclusive2_2_ch22_ec60897b:
    y "Подержишь секунду?"

translate russian yuri_exclusive2_2_ch22_2fcc7ac5:
    mc "Конечно..."

translate russian yuri_exclusive2_2_ch22_bd9eb39a:
    "Юри отдаёт мне кувшин и достаёт ещё и электрический чайник."

translate russian yuri_exclusive2_2_ch22_1db2bb6a:
    y "Я включу его в розетку у учительского стола, а потом схожу за водой."

translate russian yuri_exclusive2_2_ch22_35920c24:
    "Она проходит мимо меня и ставит чайник на учительский стол."

translate russian yuri_exclusive2_2_ch22_ecb93295:
    "Я просто наблюдаю за её движениями."

translate russian yuri_exclusive2_2_ch22_1c3b026c:
    "К моему удивлению, то, как она двигается, разительно отличается от её манеры говорить."

translate russian yuri_exclusive2_2_ch22_c89e5a0e:
    "Особенно благодаря длинным ногам Юри выглядит изящной и собранной."

translate russian yuri_exclusive2_2_ch22_38a1bb11:
    y "Так, можно мне кувшин?"

translate russian yuri_exclusive2_2_ch22_5219ddb4:
    y 1a "Спасибо. Я скоро вернусь."

translate russian yuri_exclusive2_2_ch22_9e2c0e50:
    mc "А, давай я лучше схожу с тобой..."

translate russian yuri_exclusive2_2_ch22_19cc1f85:
    y 1q "Н-не надо!"

translate russian yuri_exclusive2_2_ch22_e63c264e:
    y "Ты оставайся здесь..."

translate russian yuri_exclusive2_2_ch22_6b56a0d7:
    y "Это ненадолго."

translate russian yuri_exclusive2_2_ch22_dbe6ffb8:
    "С кувшином в руке Юри торопливо выходит из класса."

translate russian yuri_exclusive2_2_ch22_f0139694:
    m "Ах..."

translate russian yuri_exclusive2_2_ch22_6d1a8f0e:
    m "Юри опять тебя бросила?"

translate russian yuri_exclusive2_2_ch22_beb1eb80:
    mc "Нет, в этот раз всё не так."

translate russian yuri_exclusive2_2_ch22_65fc93d4:
    mc "Она просто набирает воду в кувшин, чтобы заварить чай."

translate russian yuri_exclusive2_2_ch22_9b88e971:
    m 5 "О, понятно!"

translate russian yuri_exclusive2_2_ch22_fcdac63a:
    m "Прости, что не так поняла~"

translate russian yuri_exclusive2_2_ch22_a20cefa7:
    "..."

translate russian yuri_exclusive2_2_ch22_b3947111:
    "Проходит десять минут."

translate russian yuri_exclusive2_2_ch22_de8365b1:
    "Юри сказала, что это ненадолго..."

translate russian yuri_exclusive2_2_ch22_fec3b346:
    "Её что-то задерживает?"

translate russian yuri_exclusive2_2_ch22_50bc102a:
    "Мне скучно просто сидеть и ждать, так что я решаю пойти её поискать."

translate russian yuri_exclusive2_2_ch22_d24bc72b:
    mc "Так..."

translate russian yuri_exclusive2_2_ch22_a09a01c8:
    "Логичнее всего искать Юри у ближайшего питьевого фонтанчика..."

translate russian yuri_exclusive2_2_ch22_ddee1921:
    "Я иду по коридору."

translate russian yuri_exclusive2_2_ch22_c9858fd4:
    y "Ха-а.....ха-а...."

translate russian yuri_exclusive2_2_ch22_b426398d:
    y "....Ха-а.....ха-а...."

translate russian yuri_exclusive2_2_ch22_e9a92b61:
    "...Что это за звук?"

translate russian yuri_exclusive2_2_ch22_ec9aa814:
    "Он доносится из-за угла..."

translate russian yuri_exclusive2_2_ch22_9c10999d:
    "Похоже на дыхание."

translate russian yuri_exclusive2_2_ch22_57bf0dd5:
    y "Кх-х-х-х—"

translate russian yuri_exclusive2_2_ch22_39b8793e:
    "Резкий вдох, будто кто-то втягивает воздух сквозь зубы."

translate russian yuri_exclusive2_2_ch22_7198b1bf:
    "Кому-то больно...?"

translate russian yuri_exclusive2_2_ch22_d5819e1c:
    "Я дохожу до угла и заглядываю за него."

translate russian yuri_exclusive2_2_ch22_c934e5a0:
    mc "Юри...?"

translate russian yuri_exclusive2_2_ch22_8bb5a442:
    y "Кья—!"

translate russian yuri_exclusive2_2_ch22_d1bae097:
    mc "{cps=150}Юри...?{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_e6152f36:
    "{cps=150}Я дохожу до угла и заглядываю за него.{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_32ca75d9:
    "{cps=150}Кому-то больно...?{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_4bb5f0fa:
    "{cps=150}Резкий вдох, будто кто-то втягивает воздух сквозь зубы.{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_58bb6295:
    y "{cps=150}Кх-х-х-х—{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_08f21ca7:
    "{cps=150}Похоже на дыхание.{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_8cbb7ddd:
    "{cps=150}Он доносится из-за угла...{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_9efe41bb:
    "{cps=150}...Что это за звук?{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_2170fe8c:
    y "{cps=150}....Ха-а.....ха-а....{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_931edd08:
    y "{cps=150}Ха-а.....ха-а....{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_88faba50:
    "{cps=150}Я иду по коридору.{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_e4fb0c07:
    "{cps=150}Логичнее всего искать Юри у ближайшего питьевого фонтанчика...{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_bd04a622:
    mc "{cps=150}Так...{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_6e4de4a6:
    "{cps=150}Мне скучно просто сидеть и ждать, так что я решаю пойти её поискать.{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_023a44ec:
    "{cps=150}Её что-то задерживает?{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_e4a41be3:
    "{cps=150}Юри сказала, что это ненадолго...{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_aba8093d:
    "{cps=150}Проходит десять минут.{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_231f46ba:
    "{cps=150}...{/cps}{nw}"

translate russian yuri_exclusive2_2_ch22_deebf71c:
    y "Я вернулась."

translate russian yuri_exclusive2_2_ch22_a0dcfa6e:
    y "Спасибо, что терпеливо ждал."

translate russian yuri_exclusive2_2_ch22_ca073357:
    y "[player], ты любишь улун?"

translate russian yuri_exclusive2_2_ch22_eafd0bfb:
    mc "А, да."

translate russian yuri_exclusive2_2_ch22_1c080aaf:
    mc "Мне любой подойдёт."

translate russian yuri_exclusive2_2_ch22_5304a307:
    y "Очень хорошо."

translate russian yuri_exclusive2_2_ch22_b1265635:
    "Юри выставляет на чайнике температуру девяносто три градуса."

translate russian yuri_exclusive2_2_ch22_cbbbfba3:
    y 1f "Теперь пора достать заварочный чайник."

translate russian yuri_exclusive2_2_ch22_e0a461fa:
    mc "Ты и правда всё делаешь как положено, да?"

translate russian yuri_exclusive2_2_ch22_ac6b359f:
    y 1u "Конечно..."

translate russian yuri_exclusive2_2_ch22_9eec2a3c:
    y "Когда я завариваю чай для других, нельзя делать это кое-как."

translate russian yuri_exclusive2_2_ch22_5199bad0:
    mc "Даже если я совсем не разбираюсь в чае?"

translate russian yuri_exclusive2_2_ch22_976e8033:
    y 2m "Хи-хи."

translate russian yuri_exclusive2_2_ch22_38b77528:
    y 2a "Тогда тем сильнее ты будешь впечатлён."

translate russian yuri_exclusive2_2_ch22_beb50f2c:
    mc "А... может, и буду!"

translate russian yuri_exclusive2_2_ch22_bd6ceeb4:
    "Юри достаёт заварочный чайник и начинает отмерять чайные листья."

translate russian yuri_exclusive2_2_ch22_b78eae4f:
    "К моему удивлению, она даже начинает тихонько напевать себе под нос."

translate russian yuri_exclusive2_2_ch22_ba599efa:
    mc "У тебя, похоже, хорошее настроение..."

translate russian yuri_exclusive2_2_ch22_c32eedbb:
    y 1a "Правда?"

translate russian yuri_exclusive2_2_ch22_ab893d32:
    y "Я дала этому проявиться..."

translate russian yuri_exclusive2_2_ch22_7f41b19f:
    y "И ты заметил."

translate russian yuri_exclusive2_2_ch22_bca12f15:
    y 2u "Я немного подумала..."

translate russian yuri_exclusive2_2_ch22_0164772c:
    y "И решила, что попробую чуть больше себя проявлять."

translate russian yuri_exclusive2_2_ch22_b699d4da:
    y "Оказывается, это не так уж трудно..."

translate russian yuri_exclusive2_2_ch22_c52c4a97:
    y 1c "По крайней мере, когда рядом ты."

translate russian yuri_exclusive2_2_ch22_93deaf69:
    mc "А..."

translate russian yuri_exclusive2_2_ch22_1c90c29a:
    mc "Это здорово, Юри!"

translate russian yuri_exclusive2_2_ch22_28e6d662:
    mc "Только не перенапрягайся."

translate russian yuri_exclusive2_2_ch22_5aab8dd2:
    y 3u "Ты вечно обо мне беспокоишься, [player]..."

translate russian yuri_exclusive2_2_ch22_6f88fe35:
    y "Это очень трогательно."

translate russian yuri_exclusive2_2_ch22_b7f7559b:
    mc "Это..."

translate russian yuri_exclusive2_2_ch22_04ca9dc1:
    "Юри не шутила..."

translate russian yuri_exclusive2_2_ch22_7604063e:
    "Даже не знаю, смогу ли я за этим поспеть...!"

translate russian yuri_exclusive2_2_ch22_58805ea1:
    "Я смотрю, как Юри наливает каждому из нас по чашке чая."

translate russian yuri_exclusive2_2_ch22_f2be1624:
    y 1a "[player], у меня ещё одна просьба."

translate russian yuri_exclusive2_2_ch22_dcf2efbc:
    y "Ты не против, если сегодня мы сядем на пол?"

translate russian yuri_exclusive2_2_ch22_635adbe8:
    mc "А? Почему?"

translate russian yuri_exclusive2_2_ch22_953ca257:
    y 1h "Так моей спине немного легче..."

translate russian yuri_exclusive2_2_ch22_4b80e874:
    y "Я смогу читать, прислонившись к стене, а не сгорбившись над партой."

translate russian yuri_exclusive2_2_ch22_c34e0b47:
    mc "А, прости, я не знал."

translate russian yuri_exclusive2_2_ch22_1b0a66cf:
    y 1a "Ничего страшного."

translate russian yuri_exclusive2_2_ch22_d5b75401:
    y "Просто у меня довольно часто болит спина, вот я и стараюсь с этим справляться."

translate russian yuri_exclusive2_2_ch22_09f2de35:
    mc "Правда?"

translate russian yuri_exclusive2_2_ch22_f735ccd8:
    mc "Интересно, отчего это..."

translate russian yuri_exclusive2_2_ch22_e8d54652:
    y 1f "Скорее всего, это из-за моей—"

translate russian yuri_exclusive2_2_ch22_504ba04a:
    y 1n "А—"

translate russian yuri_exclusive2_2_ch22_68c6e8a6:
    y 1o "М-моей..."

translate russian yuri_exclusive2_2_ch22_3c30f162:
    mc "Осанки, да?"

translate russian yuri_exclusive2_2_ch22_2462174e:
    mc "Вечно сутулишься, пока читаешь..."

translate russian yuri_exclusive2_2_ch22_579a96b7:
    y 2p "Да!"

translate russian yuri_exclusive2_2_ch22_ef46eb2d:
    y 2q "У меня ужасная осанка, когда я читаю!"

translate russian yuri_exclusive2_2_ch22_5a43e3b2:
    y "Поэтому нам и стоит сесть на пол."

translate russian yuri_exclusive2_2_ch22_d5ae2301:
    mc "Справедливо."

translate russian yuri_exclusive2_2_ch22_ba08de52:
    mc "Сейчас возьму книгу."

translate russian yuri_exclusive2_2_ch22_fa75c129:
    "Я достаю книгу из сумки."

translate russian yuri_exclusive2_2_ch22_33179bd7:
    mc "А, у меня ещё и шоколадки есть..."

translate russian yuri_exclusive2_2_ch22_0c515ba0:
    "Это пакетик маленьких шоколадных конфет."

translate russian yuri_exclusive2_2_ch22_e1063e85:
    "Беру его — к чаю как раз подойдёт."

translate russian yuri_exclusive2_2_ch22_d9a2ecee:
    "Мы с Юри садимся у стены, поставив чашки рядом."

translate russian yuri_exclusive2_2_ch22_ad740ef3:
    "Словно по команде, мы устраиваемся так же, как в прошлый раз, — каждый держит свою половину книги."

translate russian yuri_exclusive2_2_ch22_308596e5:
    "Вот только на этот раз..."

translate russian yuri_exclusive2_2_ch22_de366d08:
    "Мы сидим ещё ближе друг к другу."

translate russian yuri_exclusive2_2_ch22_5d023884:
    y "Мне не очень хорошо видно..."

translate russian yuri_exclusive2_2_ch22_55feb8f4:
    mc "—!"

translate russian yuri_exclusive2_2_ch22_b25a40d6:
    "Юри придвигается, пока наши плечи не соприкасаются."

translate russian yuri_exclusive2_2_ch22_85980a12:
    "И как мне сосредоточиться на чтении в таком положении...?!"

translate russian yuri_exclusive2_2_ch22_73b16b02:
    "Юри всегда была милой, но..."

translate russian yuri_exclusive2_2_ch22_784f0af8:
    "Когда она не так скованна, это почти выше моих сил!"

translate russian yuri_exclusive2_2_ch22_afd2de9d:
    y 2f "Твоя чашка..."

translate russian yuri_exclusive2_2_ch22_7075f030:
    "Юри протягивает мне мою чашку."

translate russian yuri_exclusive2_2_ch22_b94c1535:
    "Я держу её свободной от книги рукой и оказываюсь в позе, в которой сосредоточиться ещё сложнее."

translate russian yuri_exclusive2_2_ch22_738fef00:
    "Потому что теперь приходится следить, чтобы случайно не коснуться её груди...!"

translate russian yuri_exclusive2_2_ch22_31a38b20:
    "А Юри тем временем ничего не замечает."

translate russian yuri_exclusive2_2_ch22_cb5218b7:
    "У неё то самое сосредоточенное выражение лица, и, могу лишь предположить, весь мир вокруг для неё исчез."

translate russian yuri_exclusive2_2_ch22_8b064b16:
    "Я напрягаю всю силу воли, чтобы сосредоточиться на чтении."

translate russian yuri_exclusive2_2_ch22_a20cefa7_1:
    "..."

translate russian yuri_exclusive2_2_ch22_c510b9b5:
    "Через несколько минут мне наконец удаётся немного расслабиться."

translate russian yuri_exclusive2_2_ch22_76549943:
    "Я ставлю чашку между ног и вожусь с обёрткой шоколадок."

translate russian yuri_exclusive2_2_ch22_2787f9a7:
    mc "Ой, прости..."

translate russian yuri_exclusive2_2_ch22_61683ed9:
    "Я ненадолго отпускаю книгу, чтобы открыть пакетик."

translate russian yuri_exclusive2_2_ch22_0183dede:
    mc "Бери сколько хочешь."

translate russian yuri_exclusive2_2_ch22_a9ce267b:
    y 2s "Ах, это..."

translate russian yuri_exclusive2_2_ch22_54b4955c:
    y "Ничего, я не буду..."

translate russian yuri_exclusive2_2_ch22_276afef2:
    mc "А? Точно?"

translate russian yuri_exclusive2_2_ch22_de41a4f9:
    y 2v "Ну..."

translate russian yuri_exclusive2_2_ch22_701aa4c1:
    y "Если я её возьму, на страницах могут остаться пятна..."

translate russian yuri_exclusive2_2_ch22_6a87efd4:
    mc "А, ты права..."

translate russian yuri_exclusive2_2_ch22_db8aec53:
    mc "Я даже не подумал об этом."

translate russian yuri_exclusive2_2_ch22_9e480491:
    mc "Мой косяк..."

translate russian yuri_exclusive2_2_ch22_0eb2861d:
    y 2a "Не нужно извиняться."

translate russian yuri_exclusive2_2_ch22_13b3e059:
    y "Давай я подержу книгу, хорошо?"

translate russian yuri_exclusive2_2_ch22_977e733b:
    mc "Ты уверена...?"

translate russian yuri_exclusive2_2_ch22_d32f8ecc:
    y "Конечно."

translate russian yuri_exclusive2_2_ch22_f9749fd6:
    "Юри раскрывает книгу обеими руками."

translate russian yuri_exclusive2_2_ch22_d4c91dff:
    "Она держит её так, чтобы мне было так же удобно читать."

translate russian yuri_exclusive2_2_ch22_d764c329:
    "Но в результате её левая рука практически лежит у меня на ноге."

translate russian yuri_exclusive2_2_ch22_59dd503e:
    mc "Что ж, раз так..."

translate russian yuri_exclusive2_2_ch22_54138664:
    "Юри уже снова полностью погружена в чтение."

translate russian yuri_exclusive2_2_ch22_a28daeb1:
    "Я беру шоколадную конфетку и кладу её в рот."

translate russian yuri_exclusive2_2_ch22_2fbb5434:
    "Потом беру ещё одну..."

translate russian yuri_exclusive2_2_ch22_6bf56b05:
    "И подношу её к Юри."

translate russian yuri_exclusive2_2_ch22_73bd295b:
    "Она даже не отрывает взгляда от книги."

translate russian yuri_exclusive2_2_ch22_b1c5258a:
    "Она просто приоткрывает губы, будто всё это совершенно естественно."

translate russian yuri_exclusive2_2_ch22_cd91f7db:
    "Но тогда отступать уже нельзя!"

translate russian yuri_exclusive2_2_ch22_dd709b9d:
    "Я с опаской кладу конфету ей в рот."

translate russian yuri_exclusive2_2_ch22_ff42d43c:
    "Вот так просто Юри смыкает губы."

translate russian yuri_exclusive2_2_ch22_d1820aca:
    y "А...?"

translate russian yuri_exclusive2_2_ch22_5dbb8342:
    "Выражение лица Юри вдруг меняется."

translate russian yuri_exclusive2_2_ch22_66238965:
    y "Я..."

translate russian yuri_exclusive2_2_ch22_64718e50:
    y "Я что, только что..."

translate russian yuri_exclusive2_2_ch22_f2565bf9:
    "Юри смотрит на меня так, словно ей нужно убедиться в том, что сейчас произошло."

translate russian yuri_exclusive2_2_ch22_35dc00ff:
    y "Э-э..."

translate russian yuri_exclusive2_2_ch22_c60c5441:
    y "[player]..."

translate russian yuri_exclusive2_2_ch22_c817a551:
    mc "П-прости!"

translate russian yuri_exclusive2_2_ch22_304b7207:
    mc "Наверное, не стоило так делать..."

translate russian yuri_exclusive2_2_ch22_ceede073:
    y "А-ах..."

translate russian yuri_exclusive2_2_ch22_66721784:
    "Юри начинает тяжело дышать."

translate russian yuri_exclusive2_2_ch22_507dcdd3:
    y "Я..."

translate russian yuri_exclusive2_2_ch22_622ccc92:
    y "Я не могу..."

translate russian yuri_exclusive2_2_ch22_c60c5441_1:
    y "[player]..."

translate russian yuri_exclusive2_2_ch22_c67875db:
    "Вдруг Юри резко хватает меня за руку и рывком поднимает на ноги."

translate russian yuri_exclusive2_2_ch22_5030e90f:
    "Моя чашка опрокидывается."

translate russian yuri_exclusive2_2_ch22_c60c5441_2:
    y "[player]..."

translate russian yuri_exclusive2_2_ch22_dc13b2d4:
    y "Моё сердце..."

translate russian yuri_exclusive2_2_ch22_b1a7b8eb:
    y 2y6 "Моё сердце не перестаёт колотиться, [player]..."

translate russian yuri_exclusive2_2_ch22_4ac7b4fd:
    y "Я не могу успокоиться."

translate russian yuri_exclusive2_2_ch22_590afa30:
    y "Я больше ни на чём не могу сосредоточиться...!"

translate russian yuri_exclusive2_2_ch22_aade508a:
    y "Ты чувствуешь, [player]?"

translate russian yuri_exclusive2_2_ch22_598578e6:
    "Юри вдруг прижимает мою ладонь к своей груди."

translate russian yuri_exclusive2_2_ch22_263af7c8:
    y 3t "Почему со мной такое происходит?"

translate russian yuri_exclusive2_2_ch22_74c994c6:
    y "Мне кажется, я схожу с ума..."

translate russian yuri_exclusive2_2_ch22_6f78b6f9:
    y 3y4 "Я не могу это остановить."

translate russian yuri_exclusive2_2_ch22_a9ecf625:
    y 3y6 "Мне из-за этого даже не хочется читать..."

translate russian yuri_exclusive2_2_ch22_8d2e9564:
    y "Я просто хочу..."

translate russian yuri_exclusive2_2_ch22_03b1703d:
    y 3s "...хочется смотреть..."

translate russian yuri_exclusive2_2_ch22_ee16f3da:
    y "...на тебя."

translate russian yuri_exclusive2_2_ch22_dd745922:
    y "...Ха-а..."

translate russian yuri_exclusive2_2_ch22_dd745922_1:
    y "...Ха-а..."

translate russian yuri_exclusive2_2_ch22_dd745922_2:
    y "...Ха-а..."

translate russian yuri_exclusive2_2_ch22_d0015b90:
    m "Э-э..."

translate russian yuri_exclusive2_2_ch22_5f395221:
    m "Пора... делиться стихами..."

translate russian yuri_exclusive2_2_ch23_7461c080:
    y "{cps=70}[gtext]{nw}"

translate russian yuri_exclusive2_2_ch23_a1300026:
    y "Э-э..."

translate russian yuri_exclusive2_2_ch23_eaa24d5f:
    y "Подожди..."

translate russian yuri_exclusive2_2_ch23_e59a21cd:
    y 2o "Как я..."

translate russian yuri_exclusive2_2_ch23_a41c7fe0:
    y 2y6 "...Прости, у меня просто было очень странное дежавю..."

translate russian yuri_exclusive2_2_ch23_43020291:
    y "Такое ведь раньше не случалось... правда?"

translate russian yuri_exclusive2_2_ch23_cc28ec22:
    y 2t "В последнее время у меня в голове какой-то туман..."

translate russian yuri_exclusive2_2_ch23_c581930f:
    y 3t "Надеюсь, это не слишком заметно!"

translate russian yuri_exclusive2_2_ch23_3aa2ff40:
    y "Мне бы очень не хотелось, чтобы ты счёл меня странной, когда мы только начали проводить время вместе..."

translate russian yuri_exclusive2_2_ch23_e70a97ca:
    y "Ну..."

translate russian yuri_exclusive2_2_ch23_2cbb2905:
    y "У каждого есть свои странности."

translate russian yuri_exclusive2_2_ch23_ca668879:
    y 1v "Но если показывать их так скоро после знакомства, это обычно считают неуместным... или отталкивающим."

translate russian yuri_exclusive2_2_ch23_ef82f4ff:
    y "По крайней мере, так я поняла."

translate russian yuri_exclusive2_2_ch23_738f216d:
    y "Когда я была помладше, мне кажется, я слишком напирала и становилась чересчур пылкой..."

translate russian yuri_exclusive2_2_ch23_6f9e2416:
    y "И людям не хотелось быть рядом со мной."

translate russian yuri_exclusive2_2_ch23_3a913476:
    y 2w "Так что... я начала ненавидеть это в себе."

translate russian yuri_exclusive2_2_ch23_a8f348de:
    y "Свою одержимость некоторыми увлечениями."

translate russian yuri_exclusive2_2_ch23_44f7a0aa:
    y "И то, что я не могу себя контролировать, когда чем-то слишком увлекаюсь."

translate russian yuri_exclusive2_2_ch23_87f9f194:
    y "Так что..."

translate russian yuri_exclusive2_2_ch23_89d13a9a:
    y 1v "В конце концов я перестала пытаться разговаривать с людьми."

translate russian yuri_exclusive2_2_ch23_381c8c0e:
    y "Если никто никогда не полюбит меня за то, что для меня важнее всего..."

translate russian yuri_exclusive2_2_ch23_4c886802:
    y 1u "...То проще просто закрыться."

translate russian yuri_exclusive2_2_ch23_54893c14:
    y 1h "Но в последнее время что-то не так."

translate russian yuri_exclusive2_2_ch23_395e518a:
    y "Не знаю, в чём дело."

translate russian yuri_exclusive2_2_ch23_9d91c401:
    y 2y6 "Но каждый раз, когда мы приходим в клуб, моё сердце начинает сходить с ума."

translate russian yuri_exclusive2_2_ch23_a1554ded:
    y "Будто вот-вот вырвется из груди."

translate russian yuri_exclusive2_2_ch23_5b616b7e:
    y "Меня переполняют энергия и чувства, которым я не могу дать выход."

translate russian yuri_exclusive2_2_ch23_02da2bfb:
    y "Из-за этого я делаю странные вещи."

translate russian yuri_exclusive2_2_ch23_f6492765:
    y 2t "Я не знаю, почему это происходит!"

translate russian yuri_exclusive2_2_ch23_35c52eb9:
    y 1t "[player]..."

translate russian yuri_exclusive2_2_ch23_7c954359:
    y "Мне кажется или Моника в последнее время ведёт себя как-то странно?"

translate russian yuri_exclusive2_2_ch23_a00a2313:
    y 1v "С тех пор как я вступила в клуб, она всегда была такой милой..."

translate russian yuri_exclusive2_2_ch23_ff2cf4af:
    y "Но в последнее время, когда она рядом, я чувствую что-то острое."

translate russian yuri_exclusive2_2_ch23_fef409f9:
    y 2y4 "Я ведь не сошла с ума, правда?"

translate russian yuri_exclusive2_2_ch23_e36cb463:
    y 2y1 "Пожалуйста, скажи, что нет!"

translate russian yuri_exclusive2_2_ch23_a4b9217e:
    y "Я не могла сказать раньше, потому что она всегда подслушивает!"

translate russian yuri_exclusive2_2_ch23_aa31091b:
    y 2y3 "Но наконец-то мы одни..."

translate russian yuri_exclusive2_2_ch23_a13c78e2:
    y "Может, просто побудем здесь немного?"

translate russian yuri_exclusive2_2_ch23_3cbd3d18:
    y 1m "Ну вот..."

translate russian yuri_exclusive2_2_ch23_71a86863:
    y "..."

translate russian yuri_exclusive2_2_ch23_4feeb32b:
    y 1s "Я просто хочу остаться здесь."

translate russian yuri_exclusive2_2_ch23_e5b9c767:
    y "Только мы вдвоём."

translate russian yuri_exclusive2_2_ch23_7765130f:
    y "Можем остаться здесь, пока не закончится клуб."

translate russian yuri_exclusive2_2_ch23_9cd0b4f3:
    y 1m "А потом клубная комната будет только нашей."

translate russian yuri_exclusive2_2_ch23_66f5f2c5:
    y "Никто не помешает нашему чтению."

translate russian yuri_exclusive2_2_ch23_c8630bd0:
    y 1y4 "Никто не заставит меня хотеть вонзить себе нож в горло."

translate russian yuri_exclusive2_2_ch23_005963c5:
    y 1q "А-ха-ха..."

translate russian yuri_exclusive2_2_ch23_d51fbac1:
    y "Это была шутка!"

translate russian yuri_exclusive2_2_ch23_f1b4cee4:
    y "Просто шутка."

translate russian yuri_exclusive2_2_ch23_5f26be37:
    y 1i "Хотя ножи я правда люблю..."

translate russian yuri_exclusive2_2_ch23_f22eb532:
    y "Звучит странно, но тебе не понять, если ты не видел, какими красивыми они бывают."

translate russian yuri_exclusive2_2_ch23_f28e832b:
    y 1f "У меня идея."

translate russian yuri_exclusive2_2_ch23_3a824372:
    y "Может, зайдёшь как-нибудь ко мне домой?"

translate russian yuri_exclusive2_2_ch23_6889177e:
    y 1y6 "Я покажу тебе свою коллекцию."

translate russian yuri_exclusive2_2_ch23_fb548a0a:
    y "Все они от разных мастеров."

translate russian yuri_exclusive2_2_ch23_80953160:
    y 1a "Я слежу, чтобы каждым пользовались как следует."

translate russian yuri_exclusive2_2_ch23_17db3fe0:
    y 1m "Не хочу, чтобы им было одиноко или что-то такое..."

translate russian yuri_exclusive2_2_ch23_cbb586c0:
    y 1y6 "Никто не заслуживает одиночества."

translate russian yuri_exclusive2_2_ch23_dc605710:
    y 1y4 "Никто."

translate russian yuri_exclusive2_2_ch23_baa8fe98:
    y 1c "И поэтому я так рада, что ты вступил в Литературный клуб, [player]."

translate russian yuri_exclusive2_2_ch23_a3a8a9dc:
    y 1a "Теперь нам больше не нужно быть одинокими."

translate russian yuri_exclusive2_2_ch23_464732f9:
    y "Потому что у нас есть мы."

translate russian yuri_exclusive2_2_ch23_04a4a8fa:
    y "Каждый день."

translate russian yuri_exclusive2_2_ch23_b39fee82:
    y "Больше нам ничего и не нужно."

translate russian yuri_exclusive2_2_ch23_74f96658:
    y 1y6 "Знаешь что?"

translate russian yuri_exclusive2_2_ch23_5b22e0ca:
    y "Давай уйдём из Литературного клуба."

translate russian yuri_exclusive2_2_ch23_7eac0191:
    y "Нам больше незачем терпеть скользкий язык Моники."

translate russian yuri_exclusive2_2_ch23_1bda629e:
    y 1y4 "Не говоря уже о той жалкой малявке."

translate russian yuri_exclusive2_2_ch23_a56f179c:
    y 1s "Мы сможем каждый день после уроков ходить домой вместе."

translate russian yuri_exclusive2_2_ch23_2a27761b:
    y "И читать вместе."

translate russian yuri_exclusive2_2_ch23_09d3f053:
    y 1m "Есть вместе."

translate russian yuri_exclusive2_2_ch23_4d3956a3:
    y "Спать вместе."

translate russian yuri_exclusive2_2_ch23_3c4f300f:
    y 1s "Разве это не идеально?"

translate russian yuri_exclusive2_2_ch23_1f89728f:
    y "Это всё, чего мы только можем пожелать."

translate russian yuri_exclusive2_2_ch23_9ada9c67:
    y 1a "Разве не ради этого ты вообще вступил в клуб?"

translate russian yuri_exclusive2_2_ch23_76ed8bee:
    y "Это почти как судьба."

translate russian yuri_exclusive2_2_ch23_0805f258:
    y "Судьба, что мы встретили друг друга."

translate russian yuri_exclusive2_2_ch23_ae9873ce:
    y "И теперь у нас будет счастливый конец, которого я терпеливо ждала годами."

translate russian yuri_exclusive2_2_ch23_ab92186d:
    y "Ты сделаешь это со мной, [player]?"

translate russian yuri_exclusive2_2_ch23_993e4d8e:
    y "Ты{space=60}[gtext]{nw}"
