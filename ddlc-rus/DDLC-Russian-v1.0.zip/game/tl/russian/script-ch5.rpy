# Русский перевод: script-ch5

translate russian ch5_main_291cd73e:
    "Наступил день фестиваля."

translate russian ch5_main_f55f58cd:
    "Из всех дней я ожидал, что именно сегодня пойду в школу вместе с Сайори."

translate russian ch5_main_5f35e367:
    "Но Сайори не берёт трубку."

translate russian ch5_main_aa057f44:
    "Я думал зайти к ней домой и разбудить, но решил, что это уже слишком."

translate russian ch5_main_66ad1f62:
    "Тем временем подготовка к мероприятию должна быть почти завершена."

translate russian ch5_main_e71f443a:
    "Мне удалось донести все капкейки самому, аккуратно поставив два противня друг на друга."

translate russian ch5_main_5f772eb6:
    "Нацуки уже вовсю строчит сообщения, но я не могу ответить — руки заняты."

translate russian ch5_main_01a9488e:
    "Растяжка, которую мы с Юри раскрасили, высохла, и я аккуратно свернул её, чтобы взять с собой."

translate russian ch5_main_6156c542:
    "Она прислала мне милое сообщение с напоминанием ничего не забыть, и я её успокоил."

translate russian ch5_main_12c35a24:
    "Забавно, но, наверное, я отношусь к мероприятию так же, как Нацуки."

translate russian ch5_main_201144fc:
    "Мне скорее хочется, чтобы оно закончилось и я смог провести время на фестивале с Сайори и [ch4_name!t]."

translate russian ch5_main_8ede78be:
    "Но, зная Монику, уверен, мероприятие тоже пройдёт отлично."

translate russian ch5_main_f6a40c3b:
    m "[player]!"

translate russian ch5_main_83e6198b:
    m "Ты первый."

translate russian ch5_main_cbd0885b:
    m "Спасибо, что пришёл пораньше!"

translate russian ch5_main_b16212d3:
    mc "Забавно, я думал, что уж Юри-то точно уже здесь."

translate russian ch5_main_869ed546:
    "Моника раскладывает по партам маленькие буклеты."

translate russian ch5_main_158d922b:
    "Наверное, это те самые, что она подготовила, со всеми стихами, которые мы будем читать."

translate russian ch5_main_1fd6873b:
    "В итоге я нашёл в интернете какое-то стихотворение, которое, как мне показалось, понравится Монике, и отдал его ей."

translate russian ch5_main_8185735f:
    "Его-то я и буду читать."

translate russian ch5_main_185b9181:
    m 1d "Удивительно, что ты не привёл с собой Сайори."

translate russian ch5_main_c458dfb9:
    mc "Ага, она опять проспала..."

translate russian ch5_main_b260a3a6:
    mc "Вот дурочка."

translate russian ch5_main_81fc5eee:
    mc "Казалось бы, в такие важные дни можно и постараться..."

translate russian ch5_main_e8c60bf9:
    "Я говорю это, но вдруг вспоминаю, что сказала мне вчера Сайори..."

translate russian ch5_main_bfc9484c:
    "И мне вдруг становится ужасно стыдно, ведь я знаю, что для неё всё далеко не так просто."

translate russian ch5_main_804f14c9:
    "Я сказал это только потому, что привык так думать."

translate russian ch5_main_bf0874e3:
    "Но..."

translate russian ch5_main_b06045eb:
    "Может, всё-таки стоило пойти её разбудить?"

translate russian ch5_main_716c1a0f:
    m 1k "А-ха-ха."

translate russian ch5_main_39018d06:
    m 4b "Тебе стоит взять за неё хоть немного ответственности, [player]!"

translate russian ch5_main_a7c132be:
    m "Особенно после того, что было между вами вчера..."

translate russian ch5_main_8ad57878:
    m "Ты, знаешь ли, бросил её сегодня утром на произвол судьбы."

translate russian ch5_main_2a8e5cd8:
    mc "Что было между нами...?"

translate russian ch5_main_fae1792d:
    mc "Моника— Ты об этом знаешь??"

translate russian ch5_main_22f1452d:
    m 2a "Конечно, знаю."

translate russian ch5_main_bad6f1a7:
    m "Я ведь всё-таки президент клуба."

translate russian ch5_main_bcfeb37f:
    mc "Но—!"

translate russian ch5_main_13e443ec:
    "Я смущённо запинаюсь."

translate russian ch5_main_14d59814:
    "Неужели Сайори так быстро ей рассказала?"

translate russian ch5_main_7b4085e0:
    "Что мы теперь... пара?"

translate russian ch5_main_e98494a0:
    "Я пока не собирался никому об этом говорить..."

translate russian ch5_main_7078ecec:
    "О том, что я, по сути, отверг её признание?"

translate russian ch5_main_841118bf:
    "Из-за этого я действительно выгляжу злодеем..."

translate russian ch5_main_bea221f2:
    "Но ведь это я знаю, что для неё лучше, правда?"

translate russian ch5_main_9098da49:
    mc "Ну ты даёшь..."

translate russian ch5_main_c012ccb9:
    mc "Ты совсем не знаешь всей истории, так что..."

translate russian ch5_main_61ca7335:
    m 2j "Не волнуйтесь."

translate russian ch5_main_8a0a254a:
    m "Наверное, я знаю гораздо больше, чем ты думаешь."

translate russian ch5_main_bbe4458e:
    mc "А...?"

translate russian ch5_main_0ad66631:
    "Моника, как всегда, дружелюбна, но от этих слов у меня почему-то пробегает холодок по спине."

translate russian ch5_main_115550e4:
    m 5 "Слушай, хочешь посмотреть буклеты?"

translate russian ch5_main_3dd8757c:
    m "Они получились очень красивые!"

translate russian ch5_main_b1ac94f7:
    mc "Да, конечно."

translate russian ch5_main_cf774ef8:
    "Я беру один из буклетов, разложенных по партам."

translate russian ch5_main_c358e345:
    mc "О да, и правда красивые."

translate russian ch5_main_2dd533a0:
    mc "С чем-то таким к клубу точно начнут относиться серьёзнее."

translate russian ch5_main_9d72086a:
    m "Да, я тоже так подумала!"

translate russian ch5_main_e9739dad:
    "Я листаю страницы."

translate russian ch5_main_dcc9e068:
    "Стихотворение каждой участницы аккуратно напечатано на отдельной странице, и это выглядит почти профессионально."

translate russian ch5_main_d58b0f7f:
    "Я узнаю стихи Нацуки и Юри — те, что они читали на репетиции."

translate russian ch5_main_4ad8684c:
    mc "Что это...?"

translate russian ch5_main_781439d4:
    "Я открываю страницу со стихотворением Сайори."

translate russian ch5_main_48cf059d:
    "Оно не то, которое она репетировала."

translate russian ch5_main_d1acea01:
    "Это стихотворение я раньше не читал..."

translate russian ch5_main_f9d65918:
    mc "А—"

translate russian ch5_main_ce9ffd82:
    "Что это...?"

translate russian ch5_main_f8df116d:
    "Пока я читаю, у меня холодеет внутри."

translate russian ch5_main_de87a206:
    m "[player]?"

translate russian ch5_main_6a3f2020:
    m "Что случилось?"

translate russian ch5_main_ef5f85f4:
    mc "А, ничего..."

translate russian ch5_main_db0952f0:
    "Это стихотворение совершенно не похоже на всё, что Сайори писала раньше."

translate russian ch5_main_38f127a1:
    "Но более того..."

translate russian ch5_main_d0abb0e9:
    mc "Я-я передумал!"

translate russian ch5_main_45476ba9:
    mc "Я схожу за Сайори, так что..."

translate russian ch5_main_4db600d5:
    m "А—"

translate russian ch5_main_0ceabd85:
    m 1b "Ну, хорошо!"

translate russian ch5_main_69a061e2:
    m "Постарайся не задерживаться, ладно?"

translate russian ch5_main_80ea11e1:
    "Я быстро выхожу из класса."

translate russian ch5_main_08b7a135:
    m "Не перенапрягайся~"

translate russian ch5_main_e2a4926d:
    "Моника кричит это мне вслед."

translate russian ch5_main_a2c82474:
    "Я ускоряю шаг."

translate russian ch5_main_1642a559:
    "О чём я только думал?"

translate russian ch5_main_b22de3d6:
    "Нужно было постараться ради Сайори хоть немного больше."

translate russian ch5_main_bf20ec7b:
    "Что такого в том, чтобы хотя бы подождать её или помочь проснуться?"

translate russian ch5_main_e601aa4e:
    "Даже просто проводить её до школы — для неё уже большая радость."

translate russian ch5_main_70e7cabf:
    "К тому же..."

translate russian ch5_main_68430306:
    "Вчера я сказал ей, что всё будет так же, как всегда."

translate russian ch5_main_e35fe926:
    "Это всё, что ей нужно, и то, что я хочу ей дать."

translate russian ch5_main_558b962d:
    "Я дохожу до дома Сайори и стучу в дверь."

translate russian ch5_main_b8d78e77:
    "Ответа я не жду — трубку она тоже не берёт."

translate russian ch5_main_a19898c6:
    "Как и вчера, я открываю дверь и захожу сам."

translate russian ch5_main_e766b9e2:
    mc "Сайори?"

translate russian ch5_main_4f4ec354:
    "Она и правда спит как убитая..."

translate russian ch5_main_17df0a8d:
    "Я сглатываю."

translate russian ch5_main_5166b167:
    "Не верится, что я всё-таки этим занимаюсь."

translate russian ch5_main_66baf796:
    "Будить её у неё же дома..."

translate russian ch5_main_7e7f0370:
    "Так ведь и правда поступил бы её парень, разве нет?"

translate russian ch5_main_d39780a5:
    "Разве так не поступил бы скорее её парень?"

translate russian ch5_main_cc4d5947:
    "В любом случае..."

translate russian ch5_main_eff61fd1:
    "Это кажется правильным."

translate russian ch5_main_b771a755:
    "Я стучу в дверь комнаты Сайори."

translate russian ch5_main_e766b9e2_1:
    mc "Сайори?"

translate russian ch5_main_2d697678:
    mc "Просыпайся, соня..."

translate russian ch5_main_4f673053:
    "Ответа нет."

translate russian ch5_main_e55755b1:
    "Мне правда не хотелось вот так входить к ней в комнату..."

translate russian ch5_main_5f524499:
    "Это ведь как-то нарушает её личное пространство?"

translate russian ch5_main_92ad08b5:
    "Но она просто не оставляет мне выбора."

translate russian ch5_main_b0993b5c:
    "Я осторожно открываю дверь."

translate russian ch5_main_414399e6:
    mc "{cps=30}.......Сайо—{/cps}{nw}"

translate russian ch5_main_a20cefa7:
    "..."

translate russian ch5_main_d9da181d:
    "Что за чёрт...?"

translate russian ch5_main_3f892db7:
    "{i}Что за чёрт??{/i}"

translate russian ch5_main_3e132bf6:
    "Это кошмар?"

translate russian ch5_main_bee33b8a:
    "Это... должен быть кошмар."

translate russian ch5_main_b79b8271:
    "Это не по-настоящему."

translate russian ch5_main_f7d3bace:
    "Это никак не может быть по-настоящему."

translate russian ch5_main_d463aeb5:
    "Сайори бы так не поступила."

translate russian ch5_main_80b8347e:
    "Ещё несколько дней назад всё было нормально."

translate russian ch5_main_bcc0cf21:
    "Поэтому я не могу поверить своим глазам...!"

translate russian ch5_main_14052544:
    "Я подавляю рвотный позыв."

translate russian ch5_main_83c08dc6:
    "Ещё вчера..."

translate russian ch5_main_63d916b6:
    "Я сказал Сайори, что буду рядом."

translate russian ch5_main_60eed88f:
    "Я сказал ей, что знаю, как лучше, и что всё будет хорошо."

translate russian ch5_main_d7afa724:
    "Тогда почему...?"

translate russian ch5_main_b65618dd:
    "Зачем она это сделала...?"

translate russian ch5_main_914b926a:
    "Как я мог быть таким беспомощным?"

translate russian ch5_main_ef4dcc76:
    "Что я сделал не так?"

translate russian ch5_main_be3441df:
    "Признание..."

translate russian ch5_main_5d397de2:
    "Мне не стоило ей признаваться."

translate russian ch5_main_28eecbc0:
    "Это совсем не то, что было нужно Сайори."

translate russian ch5_main_83b32ad7:
    "Она ведь даже говорила мне, как больно ей, когда о ней заботятся."

translate russian ch5_main_866f2bae:
    "Тогда зачем я признался и сделал ей ещё хуже?"

translate russian ch5_main_c298f032:
    "Отказ на её признание..."

translate russian ch5_main_43f22dd0:
    "Должно быть, именно это её и сломило."

translate russian ch5_main_ed1a20bb:
    "Её мучительный крик до сих пор звенит у меня в ушах."

translate russian ch5_main_390af3d1:
    "Зачем я так с ней поступил, когда был нужен ей больше всего?"

translate russian ch5_main_52adb6dd:
    "Почему я был таким эгоистом?"

translate russian ch5_main_b8970560:
    "Это моя вина—!"

translate russian ch5_main_784c9188:
    "Роящиеся мысли наперебой твердят мне обо всём, что я мог сделать, чтобы это предотвратить."

translate russian ch5_main_38a05e13:
    "Если бы я проводил с ней больше времени."

translate russian ch5_main_61323b0a:
    "Провожал её до школы."

translate russian ch5_main_fafa7f27:
    "И оставался её другом, как было всегда..."

translate russian ch5_main_40330930:
    "И дал ей то, чего, я знаю, она хотела от наших отношений..."

translate russian ch5_main_b500c19c:
    "...То я мог бы это предотвратить."

translate russian ch5_main_3fb68386:
    "Я знаю, что мог это предотвратить!"

translate russian ch5_main_dbc1a352:
    "К чёрту Литературный клуб."

translate russian ch5_main_6ca38f65:
    "К чёрту фестиваль."

translate russian ch5_main_9e6ea412:
    "Я только что... потерял лучшего друга."

translate russian ch5_main_bf83b2a4:
    "Человека, с которым вырос."

translate russian ch5_main_8166b65b:
    "Её больше нет. Навсегда."

translate russian ch5_main_1346d49e:
    "Что бы я ни делал, её не вернуть."

translate russian ch5_main_47810304:
    "Это не какая-то игра, где можно начать заново и попробовать иначе."

translate russian ch5_main_061507cc:
    "У меня был только один шанс, а я оказался недостаточно осторожен."

translate russian ch5_main_34819040:
    "И теперь я буду нести эту вину до самой смерти."

translate russian ch5_main_aa24ed84:
    "Ничто в моей жизни не стоит больше, чем её жизнь..."

translate russian ch5_main_96fa7cd8:
    "Но я всё равно не смог дать ей то, что ей было нужно."

translate russian ch5_main_226d890f:
    "И теперь..."

translate russian ch5_main_ad63a323:
    "Ничего уже не вернуть."

translate russian ch5_main_b8dc6375:
    "Никогда."

translate russian ch5_main_b8dc6375_1:
    "Никогда."

translate russian ch5_main_b8dc6375_2:
    "Никогда."

translate russian ch5_main_b8dc6375_3:
    "Никогда."

translate russian ch5_main_e650a699:
    "Никогда..."
