# Русский перевод: script-ch23

translate russian ch23_main_7050b825:
    y "Привет, [player]!"

translate russian ch23_main_1df6e5d1:
    y "Я тебя ждала."

translate russian ch23_main_710e8cd1:
    y 2d "Готов читать дальше?"

translate russian ch23_main_7ae62c8f:
    y "Я сегодня принесла свой лучший чай—"

translate russian ch23_main_f551a3f1:
    n "Моника!"

translate russian ch23_main_9e09898f:
    n "Я же сказала не—"

translate russian ch23_main_51576242:
    n 1g "Фу..."

translate russian ch23_main_2ea6ab87:
    n "Она что, опять опаздывает?"

translate russian ch23_main_ce267a6e:
    y 1h "Бестактна, как всегда, Нацуки."

translate russian ch23_main_ea04149f:
    n 4c "Прошу прощения?"

translate russian ch23_main_ff693c61:
    y 1r "Тебе обязательно вечно прерывать мои разговоры своими непрерывными воплями?"

translate russian ch23_main_f3c12a1b:
    n 1o "Ты о чём вообще?!"

translate russian ch23_main_3c0c663d:
    n 1q "Ты так говоришь, будто я это постоянно делаю."

translate russian ch23_main_61fe94b7:
    n "Я просто не обратила внимания, ясно? Прости."

translate russian ch23_main_688e23bd:
    n 4u "Серьёзно... Что на тебя в последнее время нашло?"

translate russian ch23_main_aec99ee7:
    n "Слушай..."

translate russian ch23_main_77a57419:
    n "Я тут подумала насчёт вчерашнего."

translate russian ch23_main_b06fe910:
    n 2q "Я была немного враждебнее, чем собиралась..."

translate russian ch23_main_6a970664:
    n 1q "Наверное, я правда почувствовала угрозу или что-то такое."

translate russian ch23_main_c611de3f:
    n 1h "Но я знаю, что мы делаем это вместе."

translate russian ch23_main_9d78240c:
    n 1q "Ещё один новенький не помешает, если он нормальный..."

translate russian ch23_main_3f2648e5:
    n 5w "И, пожалуй, в этот раз было бы неплохо, если бы это была девчонка..."

translate russian ch23_main_d3a83711:
    n 5u "Так что..."

translate russian ch23_main_61e07ad0:
    y 2u "Нацуки..."

translate russian ch23_main_2c85ff6d:
    y 1f "Всем плевать."

translate russian ch23_main_83c58f04:
    y "Может, сходишь поищешь мелочь под торговыми автоматами или ещё где?"

translate russian ch23_main_a2465aed:
    n 1p "—!"

translate russian ch23_main_80e20624:
    n 1r "..."

translate russian ch23_main_03fdb2df:
    n 12f "..."

translate russian ch23_main_9f4a56c4:
    m "Ну вот..."

translate russian ch23_main_055e03b2:
    m "Я опять пришла последней!"

translate russian ch23_main_6add972a:
    y 1f "Ты опять занималась на пианино?"

translate russian ch23_main_36ae6554:
    m 5a "Ну вот..."

translate russian ch23_main_f6daf90a:
    m "А-ха-ха..."

translate russian ch23_main_f6674ca2:
    y 1m "У тебя, должно быть, огромная целеустремлённость."

translate russian ch23_main_2e753773:
    y "Основать этот клуб и всё равно находить время для пианино..."

translate russian ch23_main_d085cf7d:
    m 1a "Ну, может, и не целеустремлённость..."

translate russian ch23_main_1c6578c8:
    m 3a "Скорее страсть."

translate russian ch23_main_d97c7a77:
    m "Это ещё и мотивирует меня как следует поработать к фестивалю."

translate russian ch23_main_e28db252:
    y 2n "Мне?"

translate russian ch23_main_6707b26d:
    y 2o "Н-ничего..."

translate russian ch23_main_bb2cf764:
    n "..."

translate russian ch23_main_18e5bacb:
    y 2v "Неужели всё так плохо...?"

translate russian ch23_main_3cc8808d:
    n 2m "Вот видишь, {i}что-то{/i} всё-таки есть."

translate russian ch23_main_08cc4542:
    y 3p "Я справлюсь!"

translate russian ch23_main_47f66db8:
    y 3y6 "Это даже ничего особенного..."

translate russian ch23_main_48539aa4:
    y 3o "Просто в последнее время я немного на взводе..."

translate russian ch23_main_c4a524c3:
    y 3n "В-в общем, не нужно об этом говорить!"

translate russian ch23_main_3259bf54:
    n 2q "Ну, мне просто показалось, что надо об этом сказать."

translate russian ch23_main_83be9d6f:
    n 5q "Не то чтобы мне было не всё равно..."

translate russian ch23_main_9f4a56c4_1:
    m "Ну вот..."

translate russian ch23_main_055e03b2_1:
    m "Я опять пришла последней!"

translate russian ch23_main_e9f977cc:
    n 2c "Ну вот, и [player] как раз пришёл."

translate russian ch23_main_6add972a_1:
    y 1f "Ты опять занималась на пианино?"

translate russian ch23_main_36ae6554_1:
    m 5a "Ну вот..."

translate russian ch23_main_f6daf90a_1:
    m "А-ха-ха..."

translate russian ch23_main_f6674ca2_1:
    y 1m "У тебя, должно быть, огромная целеустремлённость."

translate russian ch23_main_2e753773_1:
    y "Основать этот клуб и всё равно находить время для пианино..."

translate russian ch23_main_d085cf7d_1:
    m 1a "Ну, может, и не целеустремлённость..."

translate russian ch23_main_1c6578c8_1:
    m 3a "Скорее страсть."

translate russian ch23_main_baac88a3:
    m "Это мотивирует меня как следует поработать к фестивалю и..."

translate russian ch23_main_a9dfe205:
    m 3n "Э-э..."

translate russian ch23_main_9977936e:
    n 5s "..."

translate russian ch23_main_a2744047:
    m 1l "Точно..."

translate russian ch23_main_fd135007:
    m "Я-я забыла..."

translate russian ch23_main_3754a60b:
    y 2v "Э-э, насчёт этого, Нацуки..."

translate russian ch23_main_6f1da170:
    y "Мы вчера все поговорили и..."

translate russian ch23_main_93c7a69f:
    y 2t "В общем... мы решили, что тоже хотим поддержать фестиваль."

translate russian ch23_main_a7088884:
    y 2l "Однако...!"

translate russian ch23_main_dac27ea1:
    y 2h "Я понимаю, почему тебе не хочется, чтобы клуб менялся."

translate russian ch23_main_edf39968:
    y "Думаю, мы все чувствуем примерно то же."

translate russian ch23_main_8a809ddc:
    y 2f "Так что пока мы все работаем вместе, этот клуб никогда не станет тем, чего мы не хотим."

translate russian ch23_main_bb2cf764_1:
    n "..."

translate russian ch23_main_c6a1d93a:
    y 2v "Э-э, а ещё..."

translate russian ch23_main_fadce1c3:
    y "Если ты поможешь нам с фестивалем..."

translate russian ch23_main_f9ac06bc:
    y 3r "...То я куплю тебе новую мангу!"

translate russian ch23_main_00e847a6:
    n 5h "..."

translate russian ch23_main_b932777d:
    n 2z "А-ха-ха-ха!"

translate russian ch23_main_5a4d1655:
    n "Прости, последнее было очень смешно."

translate russian ch23_main_795c1df2:
    n 2c "Слушай..."

translate russian ch23_main_77a57419_1:
    n "Я тут подумала насчёт вчерашнего."

translate russian ch23_main_b06fe910_1:
    n 2q "Я была немного враждебнее, чем собиралась..."

translate russian ch23_main_6a970664_1:
    n 1q "Наверное, я правда почувствовала угрозу или что-то такое."

translate russian ch23_main_c611de3f_1:
    n 1h "Но я знаю, что мы делаем это вместе."

translate russian ch23_main_9d78240c_1:
    n 1q "Ещё один новенький не помешает, если он нормальный..."

translate russian ch23_main_3f2648e5_1:
    n 5w "И, пожалуй, в этот раз было бы неплохо, если бы это была девчонка..."

translate russian ch23_main_5b5b4f34:
    n 5e "...Но, что важнее, мне бы очень не хотелось, чтобы мероприятие провалилось только потому, что я решила отказаться!"

translate russian ch23_main_0dc50158:
    n "Я ведь профи, знаешь ли!"

translate russian ch23_main_6991fd65:
    n 5c "Так что я тоже помогу, и мы сделаем всё как надо."

translate russian ch23_main_6405094c:
    y 2s "Слава богу..."

translate russian ch23_main_bc78cc3f:
    y "Здорово, правда, Моника?"

translate russian ch23_main_c3e4602b:
    n 2k "...Моника?"

translate russian ch23_main_4db600d5:
    m "А—"

translate russian ch23_main_357961d6:
    m 1n "Да, это чудесно!"

translate russian ch23_main_2e60affc:
    m "Без тебя всё было бы не то, Нацуки."

translate russian ch23_main_96ff8363:
    m 5 "В общем, [player]..."

translate russian ch23_main_ba6cd59b:
    m "Чем ты сегодня хочешь заняться?"

translate russian ch23_main_c183fdb2:
    m "Я подумала, может, мы могли бы—"

translate russian ch23_main_5cfe00eb:
    y 1l "У нас уже есть планы на сегодня."

translate russian ch23_main_07eab780:
    m 1r "Ах..."

translate russian ch23_main_56ad88e4:
    m "Правда, Юри?"

translate russian ch23_main_d470cf0a:
    y 1y6 "Совершенно верно."

translate russian ch23_main_8a88fa85:
    y "[player] уже увлечён романом, который мы читаем вместе."

translate russian ch23_main_c4c4045b:
    y 1y5 "Разве ты не рада, что я уже приобщила его к литературе, Моника?"

translate russian ch23_main_a7c87622:
    m 2l "Я..."

translate russian ch23_main_1164b425:
    m "Пожалуй..."

translate russian ch23_main_4ada0fd4:
    m "Я просто—"

translate russian ch23_main_a5ae1347:
    m 1r "Вообще-то, неважно."

translate russian ch23_main_09d0fb57:
    m 1i "Правда неважно."

translate russian ch23_main_79fd62df:
    m "Делайте что хотите."

translate russian ch23_main_13ff9bc7:
    y 2y1 "{i}(Да!){/i}{w=0.5}{nw}"

translate russian ch23_main_727caeb4:
    y 2u "Э-э... Спасибо за понимание, Моника."

translate russian ch23_end_90de9c4d:
    m "Итак, ребята!"

translate russian ch23_end_0993759e:
    m "Пора решить, как готовиться к фестивалю."

translate russian ch23_end_772ec4c7:
    m 1i "Давайте поскорее с этим разделаемся."

translate russian ch23_end_bb2cf764:
    n "..."

translate russian ch23_end_a8557d5c:
    n "Блин..."

translate russian ch23_end_2035e967:
    n "Почему сегодня такая странная атмосфера?"

translate russian ch23_end_42c8edbf:
    n "Смотри, даже Юри не устояла."

translate russian ch23_end_6559e79e:
    y "У-у..."

translate russian ch23_end_3d9092ae:
    y "Застоявшийся воздух — частое предзнаменование того, что вот-вот случится что-то ужасное..."

translate russian ch23_end_08590660:
    m 2r "Слушайте, может, просто сделаем это?"

translate russian ch23_end_5a08f549:
    m 2d "Я буду печатать и собирать все поэтические буклеты."

translate russian ch23_end_dd665f4a:
    m 2i "Нацуки, ты можешь испечь капкейки."

translate russian ch23_end_18c7cbb6:
    m "Уж это у тебя хотя бы получается."

translate russian ch23_end_07a96f6a:
    n 5u "..."

translate russian ch23_end_770e4677:
    m "Нацуки, я тут подумала—"

translate russian ch23_end_b0ad33ab:
    n 2d "Я хочу испечь капкейки!"

translate russian ch23_end_b02e47f8:
    m 2a "...Ага, это."

translate russian ch23_end_58304296:
    m "Рада, что мы друг друга понимаем."

translate russian ch23_end_31d39fd0:
    m 1m "Юри, ты можешь..."

translate russian ch23_end_bed9d866:
    m 1r "...Ладно, неважно."

translate russian ch23_end_222e42cb:
    m 1i "Делайте что хотите, лишь бы, по-вашему, это помогло."

translate russian ch23_end_a17b13bf:
    y 2h "Моника..."

translate russian ch23_end_c0d26207:
    y "Я, между прочим, не бесполезная!"

translate russian ch23_end_acf82de7:
    m 2p "Я-я это поняла!"

translate russian ch23_end_78d0b4fa:
    y 1l "Я уже знаю, чем хочу заняться."

translate russian ch23_end_364de31c:
    y 1h "Удачный поэтический вечер невозможен без подходящей атмосферы."

translate russian ch23_end_e9660d91:
    y "Поэтому я сделаю украшения и устрою красивое приглушённое освещение."

translate russian ch23_end_19a8f971:
    m 2j "Ну вот, видите?"

translate russian ch23_end_2d145eae:
    m "Отличная идея!"

translate russian ch23_end_2ef36761:
    m 1a "И теперь у всех есть занятие."

translate russian ch23_end_5f1028e8:
    y 2f "А?"

translate russian ch23_end_69b689b0:
    y "А как же [player]?"

translate russian ch23_end_f12d9d00:
    m 2b "[player] будет помогать мне."

translate russian ch23_end_03042821:
    n 4e "Стоп, тебе?"

translate russian ch23_end_1cff0263:
    n "У тебя самая лёгкая работа, Моника!"

translate russian ch23_end_ec97ece1:
    m 1i "Прости, но так уж решено."

translate russian ch23_end_1cadb8f9:
    n 1f "Чёрта с два!"

translate russian ch23_end_8c2e73b8:
    n "Ты что задумала?"

translate russian ch23_end_2d1ca9bc:
    y 3h "Я-я согласна с Нацуки!"

translate russian ch23_end_2fcdee48:
    y "Мало того что с твоей работой лучше всего справится один человек..."

translate russian ch23_end_916ef5f0:
    y 3l "Моя задача достаточно трудоёмкая, чтобы пригодилась лишняя пара рук."

translate russian ch23_end_613a8351:
    n 4c "Моя тоже!"

translate russian ch23_end_55f6cc17:
    y 1h "Что, твои капкейки?"

translate russian ch23_end_43eb3793:
    y "Умоляю."

translate russian ch23_end_6c43f72e:
    n 1o "Можно подумать, {i}ты{/i} хоть хрена в этом смыслишь!"

translate russian ch23_end_337d9e3a:
    n 1x "Тебе теперь лишь бы [player] таскался за тобой и твоими дурацкими книжками."

translate russian ch23_end_65c4d2ca:
    n 1f "Тебе {i}и{/i} Монике!"

translate russian ch23_end_302246ea:
    m 2g "Эй!"

translate russian ch23_end_c61da5ee:
    m "Я вообще ничего не сделала!"

translate russian ch23_end_83974bd9:
    n 3e "Ладно, тогда пусть [player] сам решит, кому помогать, а ты не злоупотребляй властью!"

translate russian ch23_end_53e2984b:
    m 1p "Я не... злоупотребляю властью."

translate russian ch23_end_5c462463:
    y 2h "Ещё как злоупотребляешь, Моника."

translate russian ch23_end_6cda4708:
    y "Пусть [player] сам выберет, хорошо?"

translate russian ch23_end_c26d6924:
    m 1r "Ладно, хорошо!"

translate russian ch23_end_34212887:
    m "Ладно."

translate russian ch23_end_cc188cde:
    n 3w "Блин..."

translate russian ch23_end_73b7482c:
    n "[player], я знаю, как тебя уже достали эти двое."

translate russian ch23_end_c9ec79af:
    n 3c "Мы можем просто—"

translate russian ch23_end_f1c1e0f4:
    y 2r "Нацуки, закрой свой поганый рот и дай ему решить самому."

translate russian ch23_end_01f5b930:
    n 1o "{i}Сама{/i} закрой рот!"

translate russian ch23_end_9976091a:
    m 1r "Господи боже..."

translate russian ch23_end_bf2e6adc:
    m 1i "Это никогда не закончится. Просто сделай выбор, ладно?"

translate russian ch23_end_9128784d:
    m 5a "Ура, ты выбрал меня!"

translate russian ch23_end_8c48ee6a:
    m "Можем встретиться у тебя дома на выходных."

translate russian ch23_end_bb9bc753:
    m "Обещаю, будет весело."

translate russian ch23_end_67ca5074:
    m "Воскресенье тебе подходит?"

translate russian ch23_end_308070ea:
    n "Ты, мать твою, издеваешься?"

translate russian ch23_end_77a6e6ae:
    n "Это совсем нечестно!"

translate russian ch23_end_08045a7c:
    m 2i "Это честно, Нацуки."

translate russian ch23_end_a5a60aa3:
    m "Он сам так выбрал."

translate russian ch23_end_c092a8ae:
    y "Нет, это нечестно!"

translate russian ch23_end_c3761d87:
    y "Взвалить на нас всю работу, чтобы [player] достался тебе одной."

translate russian ch23_end_de7db816:
    y "Как постыдно!"

translate russian ch23_end_eb1ce579:
    m 2r "Юри, я тебе вообще никакой работы не давала."

translate russian ch23_end_882dcfe0:
    m 2i "Ты сама её себе выбрала."

translate russian ch23_end_0f02c58e:
    m "Ты ведёшь себя немного неразумно."

translate russian ch23_end_ab03ad61:
    y 2y4 "Это я веду себя неразумно?"

translate russian ch23_end_f0b3f2ff:
    y 2y3 "А-ха-ха-ха!"

translate russian ch23_end_18e83623:
    y "Моника, поверить не могу, насколько ты заблуждаешься и как много о себе возомнила!"

translate russian ch23_end_545f48d9:
    y "Каждый раз, когда тебя куда-то не зовут, ты делаешь так, чтобы [player] ушёл от меня."

translate russian ch23_end_97fd4494:
    y 1y1 "Ревнуешь?"

translate russian ch23_end_c6ade6c2:
    y "С ума сошла?"

translate russian ch23_end_d50febc8:
    y 1y3 "Или, может, ты так себя ненавидишь, что вымещаешь это на других?"

translate russian ch23_end_c3d21cd4:
    y 1y4 "Вот тебе предложение. Ты не думала покончить с собой?"

translate russian ch23_end_07331406:
    y "Это пошло бы на пользу твоему психическому здоровью."

translate russian ch23_end_930a0609:
    n 5u "Юри, ты меня немного пугаешь..."

translate russian ch23_end_f56c7ce9:
    m 1r "Нацуки, давай просто уйдём."

translate russian ch23_end_21e3a942:
    m 1i "Не думаю, что она сейчас хочет нас видеть."

translate russian ch23_end_7dedcc9b:
    y 2y3 "Видишь, это было не так уж трудно."

translate russian ch23_end_3556f8ae:
    y "Всё, чего я хочу, — немного побыть с ним."

translate russian ch23_end_24e5486c:
    y "Разве я так много прошу?"

translate russian ch23_end_745f0277:
    "Юри идёт за Моникой и Нацуки к двери."

translate russian ch23_end_a6fb49ba:
    m "Эй, [player]..."

translate russian ch23_end_289f2833:
    m "Юри — это нечто, правда?"

translate russian ch23_end_1bd53e19:
    "Моника хихикает, пока Юри выталкивает её за дверь."

translate russian ch23_end_48472cac:
    y "Наконец-то."

translate russian ch23_end_6f7becde:
    y 2y1 "Наконец-то!"

translate russian ch23_end_0ea00341:
    y 2s "Это и есть всё, чего я хотела."

translate russian ch23_end_e0675fad:
    y 1y6 "[player], не нужно проводить выходные с Моникой."

translate russian ch23_end_1c42a8cc:
    y "Не слушай её."

translate russian ch23_end_8b46655e:
    y 1y5 "Лучше приходи ко мне домой."

translate russian ch23_end_0c29b271:
    y 3y5 "Весь день, только мы вдвоём..."

translate russian ch23_end_def926ca:
    y "Разве это не чудесно звучит?"

translate russian ch23_end_fd7f98ce:
    y 3y1 "А-ха-ха-ха!"

translate russian ch23_end_90d54275:
    y 3y4 "Ух ты... Со мной ведь и правда что-то не так, да?"

translate russian ch23_end_84558ab0:
    y "Но знаешь что?"

translate russian ch23_end_5b7c6a6a:
    y 1y3 "Мне уже всё равно."

translate russian ch23_end_7c8fd563:
    y "Мне никогда в жизни не было так хорошо."

translate russian ch23_end_112ff60f:
    y 1y4 "Просто быть с тобой — наслаждение куда большее, чем всё, что я могу себе представить."

translate russian ch23_end_1362d6af:
    y "Я зависима от тебя."

translate russian ch23_end_5e6ebd2a:
    y 3y4 "Мне кажется, я умру, если не буду дышать одним с тобой воздухом."

translate russian ch23_end_14185dfe:
    y 4a "Разве не приятно, когда о тебе кто-то так сильно заботится?"

translate russian ch23_end_9de8a560:
    y "Когда кто-то хочет, чтобы вся его жизнь вращалась вокруг тебя?"

translate russian ch23_end_d81ffb78:
    y 2y6 "Но если это так приятно..."

translate russian ch23_end_e06606db:
    y 2y4 "Почему мне всё сильнее кажется, что вот-вот случится что-то ужасное?"

translate russian ch23_end_36ddf789:
    y 2y6 "Может, поэтому я поначалу пыталась себя остановить..."

translate russian ch23_end_3bbfc16f:
    y "Но теперь это чувство слишком сильное."

translate russian ch23_end_17c9d53a:
    y 3y1 "Мне уже всё равно, [player]!"

translate russian ch23_end_b7ae0f1d:
    y "Я должна тебе сказать!"

translate russian ch23_end_80a57d60:
    y 3y4 "Я... Я безумно в тебя влюблена!"

translate russian ch23_end_343025a1:
    y "Мне кажется, что каждый сантиметр моего тела... каждая капля моей крови... выкрикивает твоё имя."

translate russian ch23_end_715e5a8d:
    y 3y3 "Мне уже всё равно, какими будут последствия!"

translate russian ch23_end_3927c53b:
    y "Мне всё равно, даже если Моника подслушивает!"

translate russian ch23_end_9d16ea33:
    y 3w "Пожалуйста, [player], просто знай, как сильно я тебя люблю."

translate russian ch23_end_fd055dd7:
    y 3m "Я люблю тебя так сильно, что даже трогаю себя ручкой, которую у тебя украла."

translate russian ch23_end_1e8884fa:
    y 3y4 "Мне хочется просто разорвать твою кожу и забраться внутрь тебя."

translate russian ch23_end_e203cdfd:
    y 3y6 "Я хочу, чтобы ты был только моим."

translate russian ch23_end_149971d3:
    y "А я буду только твоей."

translate russian ch23_end_b99df2bd:
    y "Разве это не идеально?"

translate russian ch23_end_e11c83e6:
    y 3s "Скажи мне, [player]."

translate russian ch23_end_c162d243:
    y "Скажи, что хочешь быть моим возлюбленным."

translate russian ch23_end_ce414874:
    y "Ты принимаешь моё признание?"

translate russian yuri_kill_1_4d4c9c12:
    y "...А-ха-ха-ха."

translate russian yuri_kill_1_3d40b880:
    y "А-ха-ха-ха-ха-ха-ха!"

translate russian yuri_kill_1_4ddc816c:
    y 3y5 "А-ха-ха-ха-ха-ха-ха-ха-ха!"

translate russian yuri_kill_1_76475273:
    y 3y3 "А-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА-ХА{nw}"

translate russian yuri_kill_loop_18a69774:
    y "[persistent.yuri_kill] [gtext]"

translate russian yuri_kill_loop_356cde31:
    y "[gtext]"

translate russian yuri_kill_3_b1967a39:
    "[gtext]"

translate russian yuri_kill_3_090fa498:
    n "Ну всё, фестиваль начинается!"

translate russian yuri_kill_3_b205d720:
    n "Ого, ты пришёл раньше меня?"

translate russian yuri_kill_3_c740f295:
    n "А я-то думала, что пришла довольно ра—{nw}"

translate russian yuri_kill_3_05b631cb:
    n "И-И-И!"

translate russian yuri_kill_3_1e7c525c:
    n "А-А-А-А-А-А-А-А-А-А-А-А-А-А-Х!!!"

translate russian yuri_kill_3_a59d99d8:
    "Нацуки убегает."

translate russian yuri_kill_3_e612037c:
    m "..."

translate russian yuri_kill_3_49be24e9:
    m "Я пришла!"

translate russian yuri_kill_3_bac95057:
    m 2d "[player], что-то случилось?"

translate russian yuri_kill_3_1913d5f2:
    m "Мимо меня только что пробежала Нацуки..."

translate russian yuri_kill_3_3ac5a02b:
    m 2i "...Ох..."

translate russian yuri_kill_3_0362ff41:
    m "...Ох."

translate russian yuri_kill_3_f1cff12f:
    m 2r "..."

translate russian yuri_kill_3_3cbf362f:
    m 2l "А-ха-ха-ха!"

translate russian yuri_kill_3_6834df2a:
    m "Что ж, жаль."

translate russian yuri_kill_3_49f56652:
    m 2d "Стоп, ты что, провёл тут все выходные, [player]?"

translate russian yuri_kill_3_fe7c1a9b:
    m "Ох, ну надо же..."

translate russian yuri_kill_3_7f0b2e96:
    m 2g "Я и не знала, что скрипт настолько сломался."

translate russian yuri_kill_3_6ea274cb:
    m "Мне ужасно жаль!"

translate russian yuri_kill_3_afa45be0:
    m "Тебе, наверное, было очень скучно..."

translate russian yuri_kill_3_989d77b0:
    m 2e "Я всё заглажу, хорошо?"

translate russian yuri_kill_3_0fc97937:
    m "Дай мне секундочку..."

translate russian yuri_kill_3_da4f4260:
    m 2a "Я почти закончила."

translate russian yuri_kill_3_4fdfebc5:
    m 2j "Я только быстренько съем капкейк!"

translate russian yuri_kill_3_651eefb8:
    "Моника приподнимает фольгу с подноса [gtext] и берёт капкейк."

translate russian yuri_kill_3_c05aafc0:
    m 2b "Серьёзно, они просто лучшие!"

translate russian yuri_kill_3_38b79e4c:
    m "Мне правда нужно было съесть хоть один, ведь это мой последний шанс."

translate russian yuri_kill_3_19b43c0c:
    m 2a "Ну, знаешь, пока они не перестали существовать и всё такое."

translate russian yuri_kill_3_0b28b069:
    m "...Но в любом случае мне правда не стоит заставлять тебя ждать."

translate russian yuri_kill_3_78bd679a:
    m 2j "Просто потерпи немного, хорошо?"

translate russian yuri_kill_3_1ffc01fd:
    m 2a "Это займёт всего секунду."
