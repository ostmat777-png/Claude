# Русский перевод: script-exclusives2-natsuki

translate russian natsuki_exclusive2_1_f5f51468:
    n "Фу-у...!"

translate russian natsuki_exclusive2_1_e174f989:
    "Из шкафа доносится раздражённый вздох Нацуки."

translate russian natsuki_exclusive2_1_0fb627f5:
    "Похоже, её что-то бесит."

translate russian natsuki_exclusive2_1_e62c6690:
    "Я подхожу к ней — вдруг нужна помощь."

translate russian natsuki_exclusive2_1_32722f83:
    mc "Ищешь там что-то?"

translate russian natsuki_exclusive2_1_715b4d41:
    n 4x "чёртова моникамммммммммммммммммммммммммммммммммммммммммммммм"

translate russian natsuki_exclusive2_1_0e3ba913:
    n "Вечно она кладёт мои вещи не на место!"

translate russian natsuki_exclusive2_1_bbbe4215:
    n "Какой смысл держать коллекцию в порядке, если кто-то другой всё равно её перепутает?"

translate russian natsuki_exclusive2_1_19933c2f:
    "Нацуки передвигает по полке стопки книг и коробки."

translate russian natsuki_exclusive2_1_3d3a82c5:
    mc "Манга..."

translate russian natsuki_exclusive2_1_760f87e9:
    n 2c "Ты же читаешь мангу, да?"

translate russian natsuki_exclusive2_1_f9d65918:
    mc "А—"

translate russian natsuki_exclusive2_1_fdb5ed84:
    mc "...Иногда..."

translate russian natsuki_exclusive2_1_935299a4:
    "Манга — одна из тех вещей, в увлечении которыми нельзя признаваться, пока не поймёшь, как к ней относится собеседник."

translate russian natsuki_exclusive2_1_fe2f3706:
    mc "...А откуда ты вообще узнала?"

translate russian natsuki_exclusive2_1_d0e38205:
    n 2k "Слышала, как ты как-то об этом обмолвился."

translate russian natsuki_exclusive2_1_3688c727:
    n "К тому же это у тебя на лице написано."

translate russian natsuki_exclusive2_1_c145e81e:
    "Это ещё что значит...?"

translate russian natsuki_exclusive2_1_f11161d0:
    mc "П-понятно..."

translate russian natsuki_exclusive2_1_9262900f:
    "Сбоку на одной из полок, посреди стопки разных книг, лежит одинокий том манги."

translate russian natsuki_exclusive2_1_e06f14e6:
    "Из любопытства я вытаскиваю его из стопки."

translate russian natsuki_exclusive2_1_02dc322f:
    n 1b "Вот {i}он{/i} где!"

translate russian natsuki_exclusive2_1_df52ab96:
    "Нацуки выхватывает его у меня из рук."

translate russian natsuki_exclusive2_1_f2ebfaf0:
    "Потом поворачивается к коробке с мангой и вставляет том ровно в середину остальных."

translate russian natsuki_exclusive2_1_f7505123:
    n 4d "А-ах, так-то лучше!"

translate russian natsuki_exclusive2_1_41cc269d:
    n "Подарочное издание без одного тома — это, наверное, самое бесящее зрелище на свете."

translate russian natsuki_exclusive2_1_3405b196:
    mc "Понимаю тебя..."

translate russian natsuki_exclusive2_1_e9a28cdf:
    "Я присматриваюсь к коробке, которой она любуется."

translate russian natsuki_exclusive2_1_6c14e515:
    mc "«Девочки-парфе»...?"

translate russian natsuki_exclusive2_1_611bb932:
    "В жизни не слышал о такой серии."

translate russian natsuki_exclusive2_1_9063d972:
    "Наверное, значит, она либо совсем не для моей аудитории, либо просто ужасная."

translate russian natsuki_exclusive2_1_25561b25:
    n 5g "Если собираешься осуждать, можешь делать это через стекло вон той двери."

translate russian natsuki_exclusive2_1_62958553:
    "Она показывает на дверь класса."

translate russian natsuki_exclusive2_1_e0baf49e:
    mc "Э-эй, я ничего не осуждал...!"

translate russian natsuki_exclusive2_1_e11cdc69:
    mc "Я даже ничего не сказал."

translate russian natsuki_exclusive2_1_81abce97:
    n 5c "Это было по тону понятно."

translate russian natsuki_exclusive2_1_99d676ef:
    n "Но вот что я тебе скажу, [player]."

translate russian natsuki_exclusive2_1_f6db1694:
    n 4l "Считай это уроком прямо от Литературного клуба:{nw}"

translate russian natsuki_exclusive2_1_c002a680:
    n "не суди книгууууууууууууууууу ууууу уу{space=20}у{space=40}у{space=120}у{space=160}у{space=200}у"

translate russian natsuki_exclusive2_1_55994a4c:
    n "Вообще—"

translate russian natsuki_exclusive2_1_c864c1c4:
    "Нацуки вытаскивает из коробки первый том «Девочек-парфе»."

translate russian natsuki_exclusive2_1_6ca1c062:
    n "Сейчас я тебе докажу почему!"

translate russian natsuki_exclusive2_1_8c231d22:
    "Она пихает книгу прямо мне в руки."

translate russian natsuki_exclusive2_1_93deaf69:
    mc "А..."

translate russian natsuki_exclusive2_1_ea5a5f1b:
    "Я смотрю на обложку."

translate russian natsuki_exclusive2_1_e3a67a99:
    "На ней четыре девочки в ярких нарядах в нарочито девчачьих позах."

translate russian natsuki_exclusive2_1_d546682a:
    "Она... невероятно «моэ»."

translate russian natsuki_exclusive2_1_2530be57:
    n 4b "Не стой столбом!"

translate russian natsuki_exclusive2_1_f0b857d1:
    mc "Уа—"

translate russian natsuki_exclusive2_1_7bb26e7b:
    "Нацуки хватает меня за руку и вытаскивает из шкафа."

translate russian natsuki_exclusive2_1_dd24a43a:
    "Потом садится на пол у стены, под подоконниками."

translate russian natsuki_exclusive2_1_257d9d09:
    "Она похлопывает по полу рядом с собой — мол, садись сюда."

translate russian natsuki_exclusive2_1_a388cb6c:
    mc "На стульях разве не удобнее...?"

translate russian natsuki_exclusive2_1_6b32c532:
    "Я сажусь."

translate russian natsuki_exclusive2_1_8664d124:
    n 2k "На стульях не получится."

translate russian natsuki_exclusive2_1_5e4bb5e8:
    n "Так мы не сможем читать одновременно."

translate russian natsuki_exclusive2_1_635adbe8:
    mc "А? Почему?"

translate russian natsuki_exclusive2_1_b57e800b:
    mc "А... Наверное, так проще сидеть поближе друг к другу..."

translate russian natsuki_exclusive2_1_b8d9f096:
    n 2o "—!"

translate russian natsuki_exclusive2_1_b2178e0d:
    n 5r "Н-не говори так!"

translate russian natsuki_exclusive2_1_0552d4c2:
    n "Из-за тебя мне теперь неловко!"

translate russian natsuki_exclusive2_1_8496ec88:
    "Нацуки скрещивает руки и отодвигается от меня на пару сантиметров."

translate russian natsuki_exclusive2_1_4bbe5891:
    mc "Прости..."

translate russian natsuki_exclusive2_1_1c753a2f:
    "Я и сам не ожидал, что буду сидеть к ней так близко..."

translate russian natsuki_exclusive2_1_980af971:
    "Не то чтобы это было так уж плохо."

translate russian natsuki_exclusive2_1_dabf6e7e:
    "Я открываю книгу."

translate russian natsuki_exclusive2_1_297d8d04:
    "Не проходит и нескольких секунд, как Нацуки снова потихоньку придвигается, возвращая себе отвоёванное место в надежде, что я не замечу."

translate russian natsuki_exclusive2_1_91c84663:
    "Я чувствую, как она заглядывает мне через плечо — ей куда больше не терпится начать читать, чем мне."

translate russian natsuki_exclusive2_1_e4b36a19:
    n 1k "Ого, сколько же я не перечитывала начало...?"

translate russian natsuki_exclusive2_1_582359ea:
    mc "Хм?"

translate russian natsuki_exclusive2_1_855a6256:
    mc "Ты разве не перелистываешь иногда старые тома?"

translate russian natsuki_exclusive2_1_94edd37c:
    n 2k "Не особо."

translate russian natsuki_exclusive2_1_694aae97:
    n "Ну, может, иногда, когда уже дочитаю серию."

translate russian natsuki_exclusive2_1_124c99bd:
    n 2c "Эй, ты вообще внимательно читаешь?"

translate russian natsuki_exclusive2_1_8114a09f:
    mc "Э-э..."

translate russian natsuki_exclusive2_1_7073f2ea:
    "Внимательно, просто пока ничего не происходит, так что я могу и поговорить."

translate russian natsuki_exclusive2_1_e0d85fbb:
    "Похоже, это про компанию подружек в старшей школе."

translate russian natsuki_exclusive2_1_511a3baf:
    "Типичная повседневность."

translate russian natsuki_exclusive2_1_7c851bd7:
    "Я вроде как из такого вырос — редко когда написано настолько увлекательно, чтобы это искупало отсутствие сюжета."

translate russian natsuki_exclusive2_1_7421f499:
    mc "...Тебе точно не скучно?"

translate russian natsuki_exclusive2_1_2d028262:
    n "Нет!"

translate russian natsuki_exclusive2_1_f92b8b31:
    mc "Даже притом что ты просто смотришь, как я читаю?"

translate russian natsuki_exclusive2_1_8d52f3b6:
    n "Ну...!"

translate russian natsuki_exclusive2_1_0d8d3782:
    n "Меня... это устраивает."

translate russian natsuki_exclusive2_1_0f240219:
    mc "Как скажешь..."

translate russian natsuki_exclusive2_1_e9a6fb41:
    mc "...Наверное, это весело — делиться с кем-то тем, что тебе нравится."

translate russian natsuki_exclusive2_1_62b59994:
    mc "Я всегда радуюсь, когда уговариваю кого-нибудь из друзей взяться за серию, которая мне нравится."

translate russian natsuki_exclusive2_1_fec87230:
    mc "Понимаешь, о чём я?"

translate russian natsuki_exclusive2_1_913a614e:
    n "...?"

translate russian natsuki_exclusive2_1_582359ea_1:
    mc "Хм?"

translate russian natsuki_exclusive2_1_02d45d2f:
    mc "Нет?"

translate russian natsuki_exclusive2_1_2889c693:
    n "Э-э..."

translate russian natsuki_exclusive2_1_5ca88476:
    n "Дело не..."

translate russian natsuki_exclusive2_1_5536a673:
    n "Ну, я бы не знала."

translate russian natsuki_exclusive2_1_5537750c:
    mc "...В смысле?"

translate russian natsuki_exclusive2_1_a5685cc1:
    mc "Ты разве не даёшь свою мангу почитать друзьям?"

translate russian natsuki_exclusive2_1_2595cac7:
    n "Можешь не сыпать соль на рану?"

translate russian natsuki_exclusive2_1_a8557d5c:
    n "Блин..."

translate russian natsuki_exclusive2_1_8c8bfeaa:
    mc "А... Прости..."

translate russian natsuki_exclusive2_1_ffa2b290:
    n "Хмф."

translate russian natsuki_exclusive2_1_ef747705:
    n "Как будто я когда-нибудь уговорю своих друзей это читать..."

translate russian natsuki_exclusive2_1_0b331d4f:
    n "Они считают, что манга — для детей."

translate russian natsuki_exclusive2_1_50b06aca:
    n "Я даже заикнуться о ней не могу, чтобы они не начали..."

translate russian natsuki_exclusive2_1_b1ca56d6:
    n "„А? Ты что, всё ещё из этого не выросла?“"

translate russian natsuki_exclusive2_1_446342e2:
    n "Так и хочется врезать им по лицу..."

translate russian natsuki_exclusive2_1_183334f1:
    mc "Фу, знаю я таких людей..."

translate russian natsuki_exclusive2_1_60cbb2cd:
    mc "Честно, найти друзей, которые не осуждают, и то непросто, а уж таких, кто сам этим увлекается..."

translate russian natsuki_exclusive2_1_d9a25b5a:
    mc "Я и так вроде как неудачник, так что со временем, наверное, просто прибился к другим неудачникам."

translate russian natsuki_exclusive2_1_18ccc31d:
    mc "Но такой, как ты, наверное, сложнее..."

translate russian natsuki_exclusive2_1_94e08ea3:
    n "Хм."

translate russian natsuki_exclusive2_1_3243cf7d:
    n "Да, в точку."

translate russian natsuki_exclusive2_1_6607ad07:
    "{i}...Стоп, в какую именно??{/i}"

translate russian natsuki_exclusive2_1_458559a0:
    n "Ну, мне кажется, я даже у себя в комнате её держать не могу..."

translate russian natsuki_exclusive2_1_52f40a00:
    n "Папа бы из меня всё дерьмо выбил, если бы это нашёл."

translate russian natsuki_exclusive2_1_df80381b:
    n "Здесь, в клубной комнате, хотя бы безопасно."

translate russian natsuki_exclusive2_1_2606ec80:
    n "Вот только Моника ведёт себя как-то по-свински..."

translate russian natsuki_exclusive2_1_d8940374:
    n "Фу! Ну никак мне не выиграть, да?"

translate russian natsuki_exclusive2_1_99eb6c77:
    mc "Ну, в итоге-то оно того стоило, разве нет?"

translate russian natsuki_exclusive2_1_c32a8e96:
    mc "В смысле, вот он я — читаю."

translate russian natsuki_exclusive2_1_8d57229c:
    n "Ну, это не решает ни одной моей проблемы."

translate russian natsuki_exclusive2_1_6ddddd1f:
    mc "Может быть..."

translate russian natsuki_exclusive2_1_cb991f4e:
    mc "Но тебе ведь хотя бы весело, правда?"

translate russian natsuki_exclusive2_1_b92ff8c5:
    n "—"

translate russian natsuki_exclusive2_1_bb2cf764:
    n "..."

translate russian natsuki_exclusive2_1_8e4ceee1:
    n "...И что?"

translate russian natsuki_exclusive2_1_ee7d9dbd:
    mc "А-ха-ха."

translate russian natsuki_exclusive2_1_4daa32b4:
    n "Блин, хватит уже!"

translate russian natsuki_exclusive2_1_1606fdc6:
    n "Ты будешь читать дальше или как?"

translate russian natsuki_exclusive2_1_e9ea92f3:
    mc "Да-да..."

translate russian natsuki_exclusive2_1_c1f9d35e:
    "Я переворачиваю страницу."

translate russian natsuki_exclusive2_1_a20cefa7:
    "..."

translate russian natsuki_exclusive2_1_a20cefa7_1:
    "..."

translate russian natsuki_exclusive2_1_07bdde05:
    "....."

translate russian natsuki_exclusive2_1_3928a113:
    "......."

translate russian natsuki_exclusive2_1_278c7e29:
    "........."

translate russian natsuki_exclusive2_1_0bee939a:
    "Проходит время."

translate russian natsuki_exclusive2_1_c0f5724d:
    "Нацуки теперь как-то странно притихла."

translate russian natsuki_exclusive2_1_eef18ffa:
    "Я бросаю на неё взгляд."

translate russian natsuki_exclusive2_1_67e00540:
    "Похоже, она начала засыпать."

translate russian natsuki_exclusive2_1_79ffc593:
    mc "Эй, Нацуки..."

translate russian natsuki_exclusive2_1_501d5288:
    n "Д-да...?"

translate russian natsuki_exclusive2_1_c8cc89df:
    "Вдруг Нацуки обмякает и валится прямо на меня."

translate russian natsuki_exclusive2_1_4fb65cd5:
    mc "Э-эй—"

translate russian natsuki_exclusive2_1_f87381f4:
    n "{color=#000}[ntext]{/color}"

translate russian natsuki_exclusive2_1_f87381f4_1:
    n "{color=#000}[ntext]{/color}"

translate russian natsuki_exclusive2_1_c8391422:
    m "Ох, ну вот..."

translate russian natsuki_exclusive2_1_c5ddee1a:
    m 1d "Нацуки, ты в порядке?"

translate russian natsuki_exclusive2_1_bb2cf764_1:
    n "..."

translate russian natsuki_exclusive2_1_cc15366d:
    m 1a "Давай так..."

translate russian natsuki_exclusive2_1_0a45cac5:
    "Моника лезет в сумку и достаёт какой-то протеиновый батончик."

translate russian natsuki_exclusive2_1_69169128:
    "Она бросает его в сторону Нацуки."

translate russian natsuki_exclusive2_1_c692e4c0:
    "Глаза Нацуки вдруг снова загораются."

translate russian natsuki_exclusive2_1_cd3c05c0:
    "Она хватает батончик с пола и тут же срывает обёртку."

translate russian natsuki_exclusive2_1_f5da6040:
    n 1s "Я же говорила не давать мм-мф..."

translate russian natsuki_exclusive2_1_fcd032e6:
    "Она даже не договаривает, прежде чем запихнуть его в рот."

translate russian natsuki_exclusive2_1_ab90997d:
    m "Не волнуйся, [player]."

translate russian natsuki_exclusive2_1_d7e7c863:
    m "С ней всё хорошо."

translate russian natsuki_exclusive2_1_6c52c412:
    m "Такое просто время от времени случается."

translate russian natsuki_exclusive2_1_6440edb9:
    m 1a "Поэтому я всегда ношу в сумке что-нибудь перекусить для неё."

translate russian natsuki_exclusive2_1_6b23c85a:
    m 5a "В общем...!"

translate russian natsuki_exclusive2_1_a968bb9a:
    m "Может, все поделимся стихами?"
