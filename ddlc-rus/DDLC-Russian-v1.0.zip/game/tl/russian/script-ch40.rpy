# Русский перевод: script-ch40

translate russian ch40_main_b68875d5:
    "Обычный учебный день, как и любой другой."

translate russian ch40_main_ee6fbe40:
    "Как обычно, вокруг меня парочки и компании друзей, идущие в школу вместе."

translate russian ch40_main_2848646c:
    "Я всё твержу себе, что пора бы уже познакомиться с какими-нибудь девушками или вроде того..."

translate russian ch40_main_63ef6bb1:
    s "Эй, [player]..."

translate russian ch40_main_3c88e505:
    "...Хотя одна девушка у меня уже есть."

translate russian ch40_main_80f1ba46:
    "Эта девчонка — Сайори, моя соседка и хорошая подруга с самого детства."

translate russian ch40_main_1c9ccf9b:
    "Раньше мы каждый день ходили в школу вместе..."

translate russian ch40_main_cf52369a:
    "...А недавно снова завели эту привычку."

translate russian ch40_main_7e0bee55:
    s "[player], ты мной гордишься?"

translate russian ch40_main_8543d31a:
    mc "А? За что?"

translate russian ch40_main_f76e9b54:
    s 1c "Знаешь..."

translate russian ch40_main_aa2880a0:
    s "За то, что я встаю вовремя!"

translate russian ch40_main_9536b810:
    mc "Ну, ты уже давно так делаешь..."

translate russian ch40_main_846c723f:
    s "Ага!"

translate russian ch40_main_f6da251f:
    s 4h "Но ты ни разу ничего об этом не сказал!"

translate russian ch40_main_e3994ac6:
    s "Хотя мы каждый день ходим в школу вместе..."

translate russian ch40_main_06097ca0:
    mc "Ну, да..."

translate russian ch40_main_3ff7743d:
    mc "Я всегда думал, что это и так понятно."

translate russian ch40_main_6da71713:
    mc "Стыдно говорить такое вслух."

translate russian ch40_main_772f4ee7:
    s 1d "Ну пожа-а-алуйста!"

translate russian ch40_main_defa84d9:
    s "Это хорошая мотивация~"

translate russian ch40_main_e65657c9:
    mc "Ладно, ладно..."

translate russian ch40_main_550a4957:
    mc "Я горжусь тобой, Сайори."

translate russian ch40_main_4fe8273d:
    s 1q "Э-хе-хе~"

translate russian ch40_main_f870d325:
    "Мы вместе переходим улицу и направляемся к школе."

translate russian ch40_main_6fc63fca:
    "Чем ближе мы подходим, тем больше на улицах других учеников, спешащих на занятия."

translate russian ch40_main_3142c5a4:
    s "Кстати, [player]..."

translate russian ch40_main_02182e1b:
    s "Ты уже решил, в какой клуб вступишь?"

translate russian ch40_main_0855e33f:
    mc "В клуб?"

translate russian ch40_main_74072316:
    mc "Я же тебе уже говорил, мне правда не—"

translate russian ch40_main_94a7f0e4:
    "Я начинаю говорить то, что говорю всегда, — что мне не интересно вступать ни в какие клубы."

translate russian ch40_main_b9300a78:
    "Но что-то мне подсказывает, что теперь Сайори сильнее на это обидится."

translate russian ch40_main_9e6d8d68:
    "В конце концов, как я могу сказать ей, что клубы — пустая трата времени..."

translate russian ch40_main_3e5004bd:
    "...когда она открывает свой собственный клуб?"

translate russian ch40_main_0021b572:
    mc "...Вообще-то, да."

translate russian ch40_main_73917420:
    mc "Кажется, я уже выбрал клуб."

translate russian ch40_main_33f39455:
    s 1m "Правда?!"

translate russian ch40_main_87e83572:
    s 1r "Какой? Расскажи!"

translate russian ch40_main_8fea2db2:
    mc "Хм-м..."

translate russian ch40_main_1388d67c:
    mc "Пожалуй, пусть это будет сюрпризом."

translate russian ch40_main_5ae4488f:
    s 5d "У-у..."

translate russian ch40_main_9c920c3b:
    s "Вредина."

translate russian ch40_main_50b00ba6:
    mc "Потерпи, скоро сама узнаешь."

translate russian ch40_main_0cf67faf:
    "Раньше я спрашивал себя, почему позволяю такой беззаботной девчонке читать мне нотации."

translate russian ch40_main_1b029c8d:
    "Но потом начал понимать, что в каком-то смысле ей завидую."

translate russian ch40_main_d6fe55c3:
    "Когда Сайори за что-то берётся, она может добиться великих вещей."

translate russian ch40_main_302f642e:
    "Поэтому мне кажется, что я должен сделать для неё что-то особенное."

translate russian ch40_main_d234f771:
    "Учебный день проходит как обычно и заканчивается прежде, чем я успеваю это заметить."

translate russian ch40_main_b631cf1e:
    "Собрав вещи, я встаю, собираясь с духом."

translate russian ch40_main_d24bc72b:
    mc "Так..."

translate russian ch40_main_22b81a23:
    "Я вспоминаю номер кабинета клуба с листовки, которую видел."

translate russian ch40_main_62b4dcc5:
    "Я иду через всю школу и поднимаюсь наверх — в ту часть здания, где почти не бываю: там в основном проходят занятия и мероприятия выпускных классов."

translate russian ch40_main_708503c4:
    "Вскоре я нахожу нужный класс."

translate russian ch40_main_999eef35:
    "Я робко открываю дверь."

translate russian ch40_main_a9e9fbb4:
    mc "Здравствуйте...?"

translate russian ch40_main_2c8e7b36:
    s "А!"

translate russian ch40_main_63c29fe1:
    s "[player]...?!"

translate russian ch40_main_671df9a9:
    s 1c "Ч-что ты здесь делаешь?"

translate russian ch40_main_5fd37868:
    mc "Ну... я просто—"

translate russian ch40_main_6c94972f:
    "А? Я оглядываю комнату."

translate russian ch40_main_68d84354:
    n "Хм."

translate russian ch40_main_254efd47:
    n "Так это ты тот самый [player], о котором вечно говорит Сайори?"

translate russian ch40_main_7b46cb63:
    y "С-спасибо, что заглянул!"

translate russian ch40_main_28252d68:
    y 2m "Рада познакомиться, [player]."

translate russian ch40_main_8b435113:
    y "Мы — Литературный клуб."

translate russian ch40_main_5de1f458:
    y 3v "Н-надеюсь, тебе здесь понравится!"

translate russian ch40_main_2cc0ec0a:
    n 3g "Да ладно тебе, Юри..."

translate russian ch40_main_a0f469df:
    n "Не надо так официально."

translate russian ch40_main_29138697:
    n "Он подумает, что у нас тут строгие порядки или что-то такое..."

translate russian ch40_main_b68fdac6:
    y 3q "Ах..."

translate russian ch40_main_4ae7e887:
    y "Прости, Нацуки..."

translate russian ch40_main_60902a07:
    "Высокая девушка, которую, видимо, зовут Юри, кажется довольно застенчивой по сравнению с остальными."

translate russian ch40_main_005915a3:
    "Зато девчонка по имени Нацуки — несмотря на свой рост — похоже, самая напористая."

translate russian ch40_main_2d746127:
    mc "Что ж, приятно познакомиться с вами обеими."

translate russian ch40_main_6f22151c:
    mc "Надеюсь, мы сработаемся."

translate russian ch40_main_9d02db25:
    s 1n "С-сработаемся...?"

translate russian ch40_main_97245026:
    s 1b "[player], только не говори..."

translate russian ch40_main_65340b8e:
    s "Ты..."

translate russian ch40_main_28ba79cd:
    mc "Именно."

translate russian ch40_main_85c56248:
    mc "Клуб, в который я решил вступить, — твой, Сайори."

translate russian ch40_main_a5c32c74:
    mc "Литературный клуб."

translate russian ch40_main_bb3f3385:
    "Глаза Сайори загораются."

translate russian ch40_main_164396a4:
    s 1n "...Не может быть."

translate russian ch40_main_3240d993:
    s 1s "Не может быть!"

translate russian ch40_main_6907a2b8:
    s 4s "А-а-а-а-а-ах!"

translate russian ch40_main_4037de6b:
    "Сайори обнимает меня и прыгает на месте."

translate russian ch40_main_4fb65cd5:
    mc "Э-эй—"

translate russian ch40_main_92ac2cee:
    n 3y "Э-хе-хе."

translate russian ch40_main_7db05435:
    n "Что ж, если Сайори так рада, то, уверена, с тобой будет не так уж плохо."

translate russian ch40_main_b0cbcca3:
    y 1s "Не говоря уже о том, что нас теперь четверо."

translate russian ch40_main_03965b43:
    y "А значит, мы можем стать официально признанным клубом."

translate russian ch40_main_8453a5be:
    s 1x "Даже не знаю, что сказать!"

translate russian ch40_main_be4a33b1:
    s "Надо это отпраздновать!"

translate russian ch40_main_d7a81f76:
    y 1m "Хи-хи."

translate russian ch40_main_61f6188b:
    y "Какой подходящий для этого день, правда?"

translate russian ch40_main_ceec42fd:
    s 1r "Да!"

translate russian ch40_main_fc2aa8be:
    s 1x "Ведь Нацуки решила—"

translate russian ch40_main_6fbb5999:
    n 1w "Эй, не порти сюрприз!"

translate russian ch40_main_42d3242c:
    s 5a "Э-хе-хе, прости..."

translate russian ch40_main_d147aae2:
    n 1k "Все садитесь за стол, ладно?"

translate russian ch40_main_8cbf123e:
    y 1a "А я, может, заварю чаю?"

translate russian ch40_main_9f8ec8cb:
    "Девушки сдвинули несколько парт, чтобы получился стол."

translate russian ch40_main_dd182ef4:
    "Нацуки и Юри идут в угол комнаты: Нацуки берёт накрытый поднос, а Юри открывает шкаф."

translate russian ch40_main_7b148be6:
    "Всё ещё чувствуя себя неловко, я сажусь рядом с Сайори."

translate russian ch40_main_f4e1d6dd:
    "Нацуки с гордым видом марширует обратно к столу с подносом в руках."

translate russian ch40_main_5be7519f:
    n "Та-а-ак, все готовы?"

translate russian ch40_main_a49f0dc7:
    n "...Та-да-а!"

translate russian ch40_main_496daacd:
    s "Ух ты-ы-ы-ы!"

translate russian ch40_main_f7578acc:
    "Нацуки снимает фольгу с подноса, и под ней оказывается дюжина белых пушистых капкейков, украшенных в виде маленьких котиков."

translate russian ch40_main_96ece77f:
    "Усики нарисованы глазурью, а ушки сделаны из кусочков шоколада."

translate russian ch40_main_697c694e:
    s 4r "Какая пре-е-елесть~!"

translate russian ch40_main_50448925:
    mc "Ого, выглядят потрясающе."

translate russian ch40_main_ab028ca4:
    n 2d "Э-хе-хе. Ну, сама понимаешь."

translate russian ch40_main_1b5731e3:
    n "Давайте уже, берите!"

translate russian ch40_main_7bdf2549:
    "Сайори хватает капкейк первой, я следом."

translate russian ch40_main_5fdd7380:
    s 4q "Вкуснотища!"

translate russian ch40_main_2e786edb:
    "Сайори говорит с набитым ртом и уже успела перемазаться глазурью."

translate russian ch40_main_9137625a:
    "Я верчу капкейк в пальцах, выбирая, с какой стороны лучше откусить."

translate russian ch40_main_2230ff25:
    "Нацуки молчит."

translate russian ch40_main_55d0254f:
    "Я не могу не заметить, что она украдкой поглядывает в мою сторону."

translate russian ch40_main_c0782073:
    "Ждёт, пока я откушу?"

translate russian ch40_main_894dc484:
    "Наконец я откусываю."

translate russian ch40_main_31cb8e28:
    "Глазурь сладкая и насыщенная — интересно, она сама её сделала?"

translate russian ch40_main_e31bb4c4:
    mc "Очень вкусно."

translate russian ch40_main_4c34725b:
    mc "Спасибо, Нацуки."

translate russian ch40_main_323a1890:
    n 42c "Н-ну... ещё бы!"

translate russian ch40_main_5c2252ac:
    n "Я ведь всё-таки профи!"

translate russian ch40_main_39d8bc27:
    n 42a "Не нужно меня благодарить или что-то такое..."

translate russian ch40_main_781be425:
    "Пока Нацуки пытается принять комплимент, Юри возвращается к столу с чайным сервизом."

translate russian ch40_main_3b0ad38e:
    "Она аккуратно ставит перед каждым из нас чашку, а потом опускает чайник рядом с подносом капкейков."

translate russian ch40_main_b0102204:
    mc "Вы держите в классе целый чайный сервиз?"

translate russian ch40_main_63fe0000:
    y "Не волнуйся, учителя нам разрешили."

translate russian ch40_main_efc4ed34:
    y "В конце концов, разве чашка горячего чая не помогает насладиться хорошей книгой?"

translate russian ch40_main_a3a3b943:
    mc "А... Н-наверное..."

translate russian ch40_main_0021ab32:
    n "Э-хе-хе. Уже пытаешься впечатлить нашего новенького, Юри?"

translate russian ch40_main_d1e9e5c9:
    y 3n "А?! Н-неправда..."

translate russian ch40_main_6f8e7fc9:
    "Обиженная Юри отводит взгляд."

translate russian ch40_main_0403ff06:
    y 4b "Я имела в виду, ну..."

translate russian ch40_main_03220b59:
    mc "Я тебе верю."

translate russian ch40_main_e29518b6:
    mc "Ну, чтение за чаем — это, может, и не моё, но чай я хотя бы люблю."

translate russian ch40_main_fb4dad3b:
    y 2u "Я рада..."

translate russian ch40_main_c171e465:
    "Юри с облегчением едва заметно улыбается."

translate russian ch40_main_b4264a81:
    y 1a "Итак, [player], что ты любишь читать?"

translate russian ch40_main_cf79ccdb:
    mc "Ну... Э-э..."

translate russian ch40_main_5fcc5273:
    "Учитывая, как мало я прочитал за последние несколько лет, внятно ответить на этот вопрос я не могу."

translate russian ch40_main_1947382b:
    mc "...Мангу..."

translate russian ch40_main_459c1918:
    "Я бормочу это себе под нос, наполовину в шутку."

translate russian ch40_main_c6e48974:
    "Нацуки вдруг резко поднимает голову."

translate russian ch40_main_9101cacb:
    "Кажется, она хочет что-то сказать, но молчит."

translate russian ch40_main_8c105e2a:
    y 3u "З-значит, ты не особо любишь читать..."

translate russian ch40_main_68d50b2d:
    mc "...Ну, это можно исправить..."

translate russian ch40_main_ccf38a3c:
    "Что я несу?"

translate russian ch40_main_3b4ce5c9:
    "Я ляпнул не подумав, когда увидел грустную улыбку Юри."

translate russian ch40_main_ca4f61b8:
    mc "В общем, а как насчёт тебя, Юри?"

translate russian ch40_main_a89289a8:
    y 1l "Ну, дай подумать..."

translate russian ch40_main_de0357e1:
    "Юри обводит пальцем край своей чашки."

translate russian ch40_main_17dec8ac:
    y 1a "Больше всего я люблю романы, в которых выстроены глубокие и сложные фантастические миры."

translate russian ch40_main_24dcace1:
    y "Меня поражает, сколько в них творческой фантазии и мастерства."

translate russian ch40_main_ff3c844f:
    y 1f "А рассказать хорошую историю в таком чуждом мире — это не менее впечатляюще."

translate russian ch40_main_c77e0dd8:
    "Юри продолжает, явно увлечённая своими книгами."

translate russian ch40_main_30d11e87:
    "С самого моего прихода она казалась такой сдержанной и робкой, но по тому, как загораются её глаза, ясно: утешение она находит в мире книг, а не людей."

translate russian ch40_main_830d7316:
    y 2m "Но, знаешь, мне нравится очень многое."

translate russian ch40_main_abdf0d4e:
    y 2a "Не тушуйся, если ты не особо много читаешь, хорошо?"

translate russian ch40_main_f1b6c589:
    y "Уверена, мы найдём что-то общее."

translate russian ch40_main_e05aea79:
    n "Слушай, Юри..."

translate russian ch40_main_5f1028e8:
    y 2f "А?"

translate russian ch40_main_d18e2de0:
    n 2h "Ну, насчёт... ну, того, что он сказал первым..."

translate russian ch40_main_d4e8eb89:
    mc "Мангу?"

translate russian ch40_main_b30e0e15:
    y 2i "Верно..."

translate russian ch40_main_b7637197:
    y "Нацуки обычно читает в клубной комнате мангу—"

translate russian ch40_main_efda0254:
    n 1r "Н-не говори прямо так!!"

translate russian ch40_main_918b56d0:
    "Почему-то Нацуки этого стесняется."

translate russian ch40_main_3cc0b1e4:
    n 1q "К тому же..."

translate russian ch40_main_43afa7c4:
    n "Манга... это тоже литература, знаешь ли?"

translate russian ch40_main_75f36a4d:
    n 1w "Так что... если [player] захочет почитать мою мангу, даже не пытайся ему мешать!"

translate russian ch40_main_797d25d7:
    y 1l "Нацуки..."

translate russian ch40_main_4589de0f:
    y "Я бы такого не сделала."

translate russian ch40_main_fda82f53:
    y 1i "Однако нам было бы неплохо и немного разнообразить чтение..."

translate russian ch40_main_91ddd17a:
    y "Он тоже может воспользоваться случаем и попробовать что-то новое."

translate russian ch40_main_d8d886eb:
    y 1s "Ты не согласен, [player]?"

translate russian ch40_main_88914525:
    s "М-может—"

translate russian ch40_main_ed427033:
    "Почувствовав напряжение, Сайори вмешивается."

translate russian ch40_main_cdebfad7:
    s 1x "Может, мы все попробуем что-нибудь новое!"

translate russian ch40_main_846d265b:
    s 1l "По-моему, будет весело..."

translate russian ch40_main_9e4443a7:
    s 1c "И мы все узнаем друг друга чуточку лучше!"

translate russian ch40_main_57eceffe:
    s 1l "Ну..."

translate russian ch40_main_87a214fd:
    s "Ведь литературные клубы этим и занимаются... правда?"

translate russian ch40_main_5e741960:
    y 1v "..."

translate russian ch40_main_e7d054a1:
    y "Я-я не против или что-то такое..."

translate russian ch40_main_8d1c118d:
    n 2j "Ну вот..."

translate russian ch40_main_3ed60310:
    n "Ты, как всегда, права, госпожа президент."

translate russian ch40_main_4fe8273d_1:
    s 1q "Э-хе-хе~"

translate russian ch40_main_98db7ced:
    n 2c "Похоже, мне придётся попробовать взяться за какой-нибудь роман, а...?"

translate russian ch40_main_84455872:
    mc "Ну, тогда нас таких двое..."

translate russian ch40_main_7cd29325:
    mc "Я не против, если я буду не один."

translate russian ch40_main_22243b84:
    n 2y "А что до Юри..."

translate russian ch40_main_742d1a6e:
    y 2n "А...?"

translate russian ch40_main_c60975f5:
    y "Мне... мне придётся читать мангу...?"

translate russian ch40_main_528cea06:
    n 4i "Блин..."

translate russian ch40_main_b1fef961:
    n 4h "Ты же сама предложила разнообразить чтение!"

translate russian ch40_main_d6488058:
    n "Тебе стоит быть немного непредвзятее..."

translate russian ch40_main_10ec8670:
    n 4u "Это даже немного обидно..."

translate russian ch40_main_6b3d7607:
    y 2t "Обидно...?"

translate russian ch40_main_1d69ce4c:
    y 2v "Я-я не понимала..."

translate russian ch40_main_71a86863:
    y "..."

translate russian ch40_main_ccba8a27:
    "С виноватым видом Юри о чём-то задумывается."

translate russian ch40_main_f9401190:
    y 2w "Прости, что не уважала твои увлечения, Нацуки."

translate russian ch40_main_b6d84637:
    y "Если... если тебе это нравится, то, уверена, это достойная форма литературы."

translate russian ch40_main_0459f517:
    n 5q "...Ты просто так говоришь?"

translate russian ch40_main_bfadd2bc:
    y "Нет..."

translate russian ch40_main_be597327:
    y "Я осознала свою ошибку."

translate russian ch40_main_dcf5a563:
    y 2t "Так что если ты готова начать читать роман..."

translate russian ch40_main_6ed6fc6c:
    y 2u "...То в знак благодарности я тоже найду мангу почитать."

translate russian ch40_main_f810abdc:
    n 1l "Правда?!"

translate russian ch40_main_70dd9f8b:
    n 12c "Т-то есть..."

translate russian ch40_main_9e153a58:
    n "Мне... очень приятно, что ты сделаешь это ради меня, Юри."

translate russian ch40_main_6cf822a0:
    n 2c "Можешь на меня положиться: я найду что-нибудь, что тебе очень понравится, ладно?"

translate russian ch40_main_c4b145bb:
    y 1m "Я тоже..."

translate russian ch40_main_770907e9:
    y 1h "Пожалуй, после собрания я зайду в книжный."

translate russian ch40_main_feeba340:
    n 1q "Ты... одна?"

translate russian ch40_main_4181bb38:
    y 3q "А-ах—"

translate russian ch40_main_c7131ac3:
    y 4a "Хочешь... пойти со мной?"

translate russian ch40_main_22f2e476:
    n 5s "Э-э..."

translate russian ch40_main_6016d9e2:
    n "Если ты не против..."

translate russian ch40_main_4659aa46:
    y 3t "Вовсе нет!"

translate russian ch40_main_32a48bab:
    y "Я всегда хожу одна, так что..."

translate russian ch40_main_ead94878:
    n "Ага, я тоже..."

translate russian ch40_main_5422bb09:
    s "Как это мило~!"

translate russian ch40_main_729e9906:
    mc "Сайори, помолчи..."

translate russian ch40_main_2a2a7049:
    n 2j "Я и там покажу тебе мангу, ладно?"

translate russian ch40_main_4523dd94:
    y 1a "Да."

translate russian ch40_main_795d2cfb:
    y "Буду ждать."

translate russian ch40_main_25223f82:
    "Нацуки и Юри начинают убирать со стола."

translate russian ch40_main_c98e38ed:
    s "Э-хе-хе~"

translate russian ch40_main_5547bba1:
    s 1x "Кажется, собрание закончилось, да?"

translate russian ch40_main_58cb3132:
    mc "Да, похоже на то..."

translate russian ch40_main_d6720cce:
    mc "Приятно видеть, что все ладят."

translate russian ch40_main_55daf1df:
    s 1q "Правда же?"

translate russian ch40_main_a2b5460f:
    s 1d "По-моему, ты тоже всем нравишься, [player]."

translate russian ch40_main_cfbafaa0:
    mc "Думаешь...?"

translate russian ch40_main_04c5e626:
    mc "Ну, рядом с тобой все всегда ладят чуточку лучше, Сайори."

translate russian ch40_main_b2dd1f92:
    s 1y "Ой, [player]~"

translate russian ch40_main_f6941301:
    s "Не говори такого, мне стыдно!"

translate russian ch40_main_826915c4:
    mc "Ну и ладно."

translate russian ch40_main_b752487d:
    mc "Я удивился, когда ты сказала, что открываешь клуб..."

translate russian ch40_main_3e26fce2:
    mc "Но, по-моему, у тебя отлично получается."

translate russian ch40_main_84fcec65:
    s 1r "Мы сделаем его лучшим клубом на свете!"

translate russian ch40_main_93dec7b0:
    s 1x "Теперь, когда ты вступил, каждый день будет таким весёлым."

translate russian ch40_main_023927ad:
    s 1a "Эй, [player]..."

translate russian ch40_main_430c9eff:
    s "Я очень хочу тебя поблагодарить."

translate russian ch40_main_87537ed2:
    s "Ну, я правда очень рада, что ты вступил в клуб и всё такое..."

translate russian ch40_main_4d0329fb:
    s "Но по правде говоря, я уже знала, что ты вступишь."

translate russian ch40_main_4fe8273d_2:
    s 1q "Э-хе-хе~"

translate russian ch40_main_202ffda4:
    s 1a "На самом деле есть кое-что ещё."

translate russian ch40_clearnormal_7ccd759f:
    s "Я хотела поблагодарить тебя за то, что ты избавился от Моники."

translate russian ch40_clearnormal_7b77cef2:
    s 1b "Верно..."

translate russian ch40_clearnormal_885c1c89:
    s "Я знаю всё, что она сделала."

translate russian ch40_clearnormal_002a8efc:
    s 1x "Может, потому, что теперь президент — я."

translate russian ch40_clearnormal_e6699bdd:
    s "Но я правда знаю всё, [player]."

translate russian ch40_clearnormal_4fe8273d:
    s 1q "Э-хе-хе~"

translate russian ch40_clearnormal_76bfc1fb:
    s 1d "Я знаю, как сильно ты старался, чтобы все были счастливы."

translate russian ch40_clearnormal_9542c607:
    s "Я знаю обо всех ужасных вещах, которые сделала Моника, чтобы всем было очень грустно..."

translate russian ch40_clearnormal_6da97eb6:
    s 1b "Но всё это больше не имеет значения."

translate russian ch40_clearnormal_448b97df:
    s "Теперь есть только мы.{nw}"

translate russian ch40_clearnormal_a33c2035:
    s "Теперь есть только мы.{fast}"

translate russian ch40_clearnormal_55730271:
    s 1d "И ты сделал меня самой счастливой девушкой на всём свете."

translate russian ch40_clearnormal_3dc32bca:
    s "Не могу дождаться, когда каждый день будет таким..."

translate russian ch40_clearnormal_125bc8cb:
    s "С тобой."

translate russian ch40_clearnormal_3e7dcf81:
    s 1q "Во веки веков..."

translate russian ch40_clearnormal_8c4452f1:
    s "В"

translate russian ch40_clearnormal_2be9a6aa:
    s "о"

translate russian ch40_clearnormal_4a0af362:
    s "в"

translate russian ch40_clearnormal_19f106c1:
    s "е"

translate russian ch40_clearnormal_96103152:
    s "к"

translate russian ch40_clearnormal_19f106c1_1:
    s "е"

translate russian ch40_clearnormal_c209040d:
    s "...А?"

translate russian ch40_clearnormal_98e66791:
    s "Ч-что происходит...?"

translate russian ch40_clearnormal_e5a493e9:
    s "Кто..."

translate russian ch40_clearnormal_0b07019b:
    s "Б-больно—"

translate russian ch40_clearnormal_57cb4d56:
    s "А—"

translate russian ch40_clearnormal_45bacf8a:
    s "[gtext]{nw}"

translate russian ch40_clearall_fda76630:
    s "Я хотела поблагодарить тебя за то, что ты проводил с нами всеми столько времени."

translate russian ch40_clearall_43d97ee0:
    s 2d "Ты так старался сделать счастливой каждую из нас."

translate russian ch40_clearall_b48e84f6:
    s "Ты утешал нас в трудные времена."

translate russian ch40_clearall_8fa6b836:
    s "И помог нам всем поладить друг с другом."

translate russian ch40_clearall_adf7d51d:
    s 1a "Понимаешь, [player]?"

translate russian ch40_clearall_a4c5c5af:
    s "Теперь, когда я президент, я понимаю всё."

translate russian ch40_clearall_060b13c5:
    s 1q "Ты правда не хотел пропустить в этой игре ни одной мелочи, да?"

translate russian ch40_clearall_b0337f7e:
    s 1a "Ты столько раз сохранялся и загружался, лишь бы провести время с каждой."

translate russian ch40_clearall_e22342d4:
    s "Так далеко пойдёт только тот, кому по-настоящему дорог Литературный клуб."

translate russian ch40_clearall_c9170687:
    s "Но..."

translate russian ch40_clearall_6ca82d95:
    s 4d "Всё это время я хотела только этого."

translate russian ch40_clearall_c4d3126b:
    s "Чтобы все были счастливы и заботились друг о друге."

translate russian ch40_clearall_088af359:
    s 4q "А-ха-ха..."

translate russian ch40_clearall_fe27e6dd:
    s 1t "Это даже немного грустно, понимаешь?"

translate russian ch40_clearall_825f6cc8:
    s "После всего, что ты для нас сделал, я мало что могу сделать для тебя в ответ."

translate russian ch40_clearall_d5e1c5f6:
    s "Мы уже дошли до конца игры."

translate russian ch40_clearall_62d42da5:
    s 1y "Так что..."

translate russian ch40_clearall_ee1b94f7:
    s "Здесь мы прощаемся."

translate russian ch40_clearall_fd583afc:
    s 1d "Спасибо, что сыграл в {i}Doki Doki Literature Club{/i}."

translate russian ch40_clearall_85a50317:
    s "Я буду скучать по тебе, [player]."

translate russian ch40_clearall_84432d26:
    s "Заходи как-нибудь, ладно?"

translate russian ch40_clearall_28b2bc84:
    s "Мы всегда будем здесь, для тебя."

translate russian ch40_clearall_ecf596c1:
    s 1t "Мы..."

translate russian ch40_clearall_35809bce:
    s "Мы все тебя любим."
