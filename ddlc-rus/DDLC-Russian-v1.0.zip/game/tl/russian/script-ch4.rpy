# Русский перевод: script-ch4

translate russian ch4_main_7f03563e:
    "Вот и воскресенье."

translate russian ch4_main_e8881ae0:
    "Чем ближе приход Нацуки, тем сильнее я волнуюсь."

translate russian ch4_main_1e3fd2be:
    "Я твержу себе, что нервничать незачем, но толку от этого мало."

translate russian ch4_main_d63e1a44:
    "Интересно, будет ли она вести себя иначе, когда мы останемся вдвоём?"

translate russian ch4_main_c1d95768:
    "Тем временем она пишет мне очень много сообщений."

translate russian ch4_main_a36be6d2:
    "После обмена номерами мы отправили друг другу по одному для проверки, и это переросло в переписку."

translate russian ch4_main_4ac86efe:
    "По телефону она почти другой человек: куча эмодзи и милых словечек."

translate russian ch4_main_51122e85:
    "А ещё она очень любит на всё жаловаться, но этого я, в общем-то, ожидал."

translate russian ch4_main_54fc51cb:
    "Но если отвлечься от Нацуки..."

translate russian ch4_main_533ca6d9:
    "Чем ближе приход Юри, тем сильнее я волнуюсь."

translate russian ch4_main_1e3fd2be_1:
    "Я твержу себе, что нервничать незачем, но толку от этого мало."

translate russian ch4_main_6a261072:
    "Юри явно интроверт и в целом человек очень закрытый."

translate russian ch4_main_172e5fe9:
    "Нет сомнений, что наедине со мной она немного раскроется."

translate russian ch4_main_dcb4a9fe:
    "Тем временем мы даже иногда переписываемся."

translate russian ch4_main_c1a6e593:
    "Поначалу она очень осторожничала, но вскоре я уже узнавал о ней всё больше."

translate russian ch4_main_3adbf0d5:
    "Но если отвлечься от Юри..."

translate russian ch4_main_e9699a3e:
    "С тех пор как Сайори в тот день ушла из клуба пораньше, от неё ни слуху ни духу."

translate russian ch4_main_25706431:
    "Не то чтобы мы постоянно переписывались..."

translate russian ch4_main_8e3af5cc:
    "Но где-то в глубине души я за неё волнуюсь."

translate russian ch4_main_77697156:
    "Между тем, что сказала Сайори, и тем, что сказала Моника..."

translate russian ch4_main_be038b9e:
    "Разве правильно отодвигать чувства Сайори на второй план, когда я, возможно, ей нужен?"

translate russian ch4_main_29ce83ba:
    "Я решаю зайти к Сайори до того, как придёт [ch4_name!t]."

translate russian ch4_main_f5e89c18:
    "Не спрашивая разрешения, я просто пишу ей: «Я зайду» — как мы делали раньше."

translate russian ch4_main_b6b01504:
    "Дойдя до дома Сайори, я стучу в дверь и сам захожу внутрь."

translate russian ch4_main_f3cf9c85:
    "Опять же, мы так часто играли вместе, что привыкли просто заходить друг к другу домой, будто мы одна семья."

translate russian ch4_main_d02cb356:
    "В доме тихо."

translate russian ch4_main_ba76d2b3:
    "На первом этаже Сайори нет, так что, наверное, она у себя в комнате."

translate russian ch4_main_122612c2:
    "Уже странно, что она не сбежала вниз меня встретить."

translate russian ch4_main_cfd27d7b:
    "Я поднимаюсь в её спальню, где наконец её нахожу."

translate russian ch4_main_e766b9e2:
    mc "Сайори?"

translate russian ch4_main_168027c8:
    s "Привет, [player]~"

translate russian ch4_main_d5c40262:
    "Я сажусь у неё в комнате."

translate russian ch4_main_cde4b14b:
    "Сайори через силу улыбается, но легко заметить, что она не такая, как обычно."

translate russian ch4_main_60097b82:
    "Целую минуту мы молчим."

translate russian ch4_main_91dd180c:
    s "Ты давно уже вот так не заходил, правда?"

translate russian ch4_main_39957f69:
    mc "А... Пожалуй, ты права."

translate russian ch4_main_bbd67548:
    mc "И правда давно."

translate russian ch4_main_9f9c925d:
    mc "Тут почти ничего не изменилось, да?"

translate russian ch4_main_3e8f239e:
    "В комнате Сайори всё такой же бардак, как и всегда."

translate russian ch4_main_aebaa3fb:
    "Я узнаю всё те же мягкие игрушки и украшения на стенах, что висят у неё уже много лет."

translate russian ch4_main_506cc7c0:
    s 2bl "Э-хе-хе~"

translate russian ch4_main_a8c5f7d4:
    s "Если бы ты заходил почаще, тут не было бы такого бардака."

translate russian ch4_main_7d0484ac:
    mc "Это потому, что в итоге убираюсь за тебя я..."

translate russian ch4_main_c067efa9:
    s 1bb "А почему ты вдруг сегодня решил зайти?"

translate russian ch4_main_9e1f01a3:
    s "Разве ты сегодня не встречаешься с [ch4_name!t]?"

translate russian ch4_main_3f1ca1d2:
    mc "Да, но..."

translate russian ch4_main_5f378027:
    mc "...Стоп, а откуда ты знаешь?"

translate russian ch4_main_be7d338c:
    "К тому моменту, как мы это решили на прошлом собрании, Сайори уже ушла."

translate russian ch4_main_aad7ca62:
    s 1ba "Моника мне рассказала."

translate russian ch4_main_c3ad1529:
    s "Это ведь естественно, что она держит меня в курсе подготовки к фестивалю, правда?"

translate russian ch4_main_29886549:
    mc "А, ну да..."

translate russian ch4_main_0e65e446:
    mc "А как же ты?"

translate russian ch4_main_230aada7:
    mc "Разве ты сегодня не помогаешь Монике?"

translate russian ch4_main_8bbf088c:
    s 4bb "Конечно!"

translate russian ch4_main_ce469512:
    s "Но я помогаю ей онлайн."

translate russian ch4_main_755e2699:
    s "Мы не договаривались встречаться или что-то такое."

translate russian ch4_main_95fc3bb8:
    mc "А, значит, только я и [ch4_name!t]..."

translate russian ch4_main_df50d1be:
    s 1ba "Ага~"

translate russian ch4_main_fab2261a:
    "Мы снова молчим."

translate russian ch4_main_afd64660:
    "Сайори смотрит куда-то в сторону."

translate russian ch4_main_ee146ae9:
    "Всё её поведение совершенно на неё не похоже."

translate russian ch4_main_ddfa6b61:
    "Наконец я перехожу к делу."

translate russian ch4_main_34fdc6c8:
    mc "Я просто... хотел узнать, как ты."

translate russian ch4_main_a133cd63:
    mc "После того как ты ушла в пятницу."

translate russian ch4_main_75a9201e:
    mc "Когда что-то не так, ты не можешь это от меня скрыть!"

translate russian ch4_main_c9b70b7c:
    mc "Я слишком хорошо тебя знаю."

translate russian ch4_main_cb70afb1:
    mc "Так..."

translate russian ch4_main_6a9ba0ff:
    "Сайори улыбается и качает головой."

translate russian ch4_main_55b00119:
    s 1bd "Так не годится, [player]."

translate russian ch4_main_fb2e5377:
    mc "А?"

translate russian ch4_main_e30500ac:
    s "Почему всё не может быть так, как было всегда?"

translate russian ch4_main_628ab9fa:
    s 1by "Это всё моя вина."

translate russian ch4_main_1e5e72c5:
    s "Если бы я не стала такой слабой и не выдала случайно свои чувства..."

translate russian ch4_main_f419234b:
    s 1bk "Если бы я не совершила эту глупую ошибку..."

translate russian ch4_main_d9944342:
    s "Ты бы совсем за меня не волновался."

translate russian ch4_main_c2ee41ba:
    s "Ты бы сюда не пришёл."

translate russian ch4_main_64624b6c:
    s 1bd "Ты бы сейчас даже не думал обо мне."

translate russian ch4_main_05305f6c:
    s "Но это... это ведь просто моё наказание, правда?"

translate russian ch4_main_35b0930c:
    s "Меня наказывают за то, что я такая эгоистка."

translate russian ch4_main_34af1de7:
    s "Наверное, поэтому мир и решил, чтобы ты сегодня пришёл."

translate russian ch4_main_7db33577:
    s "Он просто хочет меня помучить."

translate russian ch4_main_51280e41:
    s 4bq "Э-хе-хе~"

translate russian ch4_main_ce62c226:
    mc "Сайори!"

translate russian ch4_main_b91a73e8:
    "Я хватаю Сайори за плечи."

translate russian ch4_main_20fe6359:
    mc "Что ты такое говоришь?!"

translate russian ch4_main_cbefa080:
    mc "Ты сама себя сейчас слышишь?"

translate russian ch4_main_8246ee4c:
    mc "Я знаю, что с тобой что-то случилось."

translate russian ch4_main_5e1b9bed:
    mc "Иначе ты бы такой не была."

translate russian ch4_main_d778b065:
    mc "Так скажи уже...!"

translate russian ch4_main_5efb74b0:
    mc "Пока я не узнаю, я не смогу перестать об этом думать!"

translate russian ch4_main_08a841a6:
    s 4bl "Ах..."

translate russian ch4_main_81d59952:
    s "А-ха-ха..."

translate russian ch4_main_6dbc946c:
    "Сайори пусто мне улыбается."

translate russian ch4_main_95b305ce:
    s 4by "Ты правда загнал меня в ловушку, [player]."

translate russian ch4_main_c9170687:
    s "Но..."

translate russian ch4_main_05d3b914:
    s 1ba "Ты ошибаешься."

translate russian ch4_main_984fcfac:
    s "Со мной ничего не случилось."

translate russian ch4_main_3eab9950:
    s "Я всегда была такой."

translate russian ch4_main_07fedd4b:
    s "Просто ты видишь это впервые."

translate russian ch4_main_d540c013:
    mc "Видишь что?"

translate russian ch4_main_5ae14a76:
    mc "О чём ты говоришь, Сайори?"

translate russian ch4_main_67281b29:
    s 1bq "Э-хе-хе~"

translate russian ch4_main_c05b8cdb:
    s 1ba "Ты ведь правда заставишь меня это сказать, да, [player]?"

translate russian ch4_main_58e8d872:
    s "Похоже, в этот раз у меня нет выбора."

translate russian ch4_main_068d9aad:
    s 1bc "Дело в том..."

translate russian ch4_main_b9a43929:
    s "...что у меня всю жизнь была очень тяжёлая депрессия."

translate russian ch4_main_54937bac:
    s 1bb "Ты знал?"

translate russian ch4_main_bc5feba5:
    s "Как думаешь, почему я каждый день опаздываю в школу?"

translate russian ch4_main_968d7c40:
    s "Потому что чаще всего я даже не могу найти причину встать с кровати."

translate russian ch4_main_fd1c4b3e:
    s 1by "Зачем вообще что-то делать, когда прекрасно знаешь, какая ты никчёмная?"

translate russian ch4_main_86925814:
    s "Зачем ходить в школу?"

translate russian ch4_main_3120cbcb:
    s "Зачем есть?"

translate russian ch4_main_ce05cc1f:
    s "Зачем заводить друзей?"

translate russian ch4_main_b8110758:
    s "Зачем заставлять других людей впустую тратить на меня свои силы и заботу?"

translate russian ch4_main_49b2decf:
    s "Вот как это ощущается."

translate russian ch4_main_b903ffad:
    s "И поэтому я просто хочу, чтобы все были счастливы..."

translate russian ch4_main_d624f808:
    s "И чтобы никто за меня не волновался."

translate russian ch4_main_2b35b6fe:
    mc "..."

translate russian ch4_main_42dbe169:
    "Я в шоке."

translate russian ch4_main_f9ec361d:
    "Я даже не знаю, что ответить."

translate russian ch4_main_cdec7507:
    "Как Сайори удавалось скрывать это от меня всё то время, что я её знаю?"

translate russian ch4_main_aa509b9c:
    "Неужели ей так хотелось, чтобы я просто о ней не думал?"

translate russian ch4_main_8af8b405:
    mc "...Почему, Сайори?"

translate russian ch4_main_82fc61d6:
    s 1bg "А...?"

translate russian ch4_main_51dbc2b3:
    mc "Почему ты никогда мне об этом не говорила?"

translate russian ch4_main_8d0ee999:
    mc "Как будто ты предала меня как близкого друга."

translate russian ch4_main_31f6649c:
    mc "Ведь если бы я знал, я бы сделал всё, что в моих силах, чтобы тебя поддержать!"

translate russian ch4_main_687c50fd:
    mc "Пусть даже я мог не так уж много..."

translate russian ch4_main_ae3d12f1:
    mc "Я бы постарался хоть немного сильнее, чтобы каждый твой день был хоть чуточку лучше."

translate russian ch4_main_5d52395f:
    mc "Для этого я и твой друг!"

translate russian ch4_main_6adfa620:
    mc "Тебе нужно было просто сказать мне!"

translate russian ch4_main_4c272a4c:
    s 1bk "Ты совсем ничего не понимаешь, [player]."

translate russian ch4_main_eb166bd5:
    s "Как думаешь, почему я тебе не говорила?"

translate russian ch4_main_e2f0904b:
    s 1bd "Потому что если бы я сказала, тебе бы пришлось тратить силы на заботу обо мне вместо важных дел."

translate russian ch4_main_ecd4d1f8:
    s "Я не хочу, чтобы обо мне заботились."

translate russian ch4_main_ae9dc47d:
    s "Когда люди пытаются обо мне заботиться, это и радостно, и горько."

translate russian ch4_main_e40d4b16:
    s 1ba "Иногда это приятно."

translate russian ch4_main_ad157485:
    s "Но в то же время это как удар битой по голове."

translate russian ch4_main_01289f61:
    s 4bq "А-ха-ха~"

translate russian ch4_main_9911b1e5:
    s 4ba "Поэтому мне так хотелось, чтобы ты подружился со всеми остальными..."

translate russian ch4_main_1981af56:
    s "Помочь всем быть счастливыми вместе — для меня лучше всего."

translate russian ch4_main_7b6aa8b2:
    s 1bb "Но потом я поняла и кое-что ещё."

translate russian ch4_main_9374b73b:
    s "Когда я вижу, как ты заводишь друзей и сближаешься со всеми в клубе..."

translate russian ch4_main_77d5d91b:
    s 1bk "Это как копьё, пронзающее моё сердце."

translate russian ch4_main_dba77a8d:
    s "Вот поэтому."

translate russian ch4_main_6dbfc55a:
    s "Поэтому я и решила, что мир просто хочет меня помучить."

translate russian ch4_main_5f8787ec:
    s 1by "Каждая дорога ведёт только к боли."

translate russian ch4_main_1f3198b0:
    s "А-ха-ха~"

translate russian ch4_main_d753d516:
    mc "Ты права, я не понимаю..."

translate russian ch4_main_2def5ee1:
    mc "Я совсем не понимаю твоих чувств, Сайори."

translate russian ch4_main_ad069b67:
    mc "Но мне и не нужно понимать."

translate russian ch4_main_dce0f10f:
    mc "Чего бы это ни стоило, чтобы тебе перестало быть больно..."

translate russian ch4_main_dbb6df0a:
    mc "Я это сделаю."

translate russian ch4_main_4d3f0c17:
    s 1bd "Нет, [player]."

translate russian ch4_main_6918a69b:
    s "Ничего нет."

translate russian ch4_main_358610db:
    s "Совсем ничего."

translate russian ch4_main_e65deda1:
    s "Помочь могло только одно — если бы всё оставалось так, как было всегда."

translate russian ch4_main_45fcd8d1:
    s 1bk "Но я была эгоисткой."

translate russian ch4_main_6dfe5599:
    s "Я наконец показала тебе, какой я ужасный человек."

translate russian ch4_main_a1d72cb2:
    "По лицу Сайори текут слёзы."

translate russian ch4_main_6941b385:
    s 1bv "Я заставила тебя вступить в литературный клуб, потому что была эгоисткой."

translate russian ch4_main_51691290:
    s "И меня наказали — сердцу стало больно так, что я не могла этого понять."

translate russian ch4_main_3874471a:
    s "А теперь ты пришёл сюда, и я сделала больно и тебе."

translate russian ch4_main_7eb1ddf6:
    s 1bt "Я просто слабая эгоистка."

translate russian ch4_main_3d05c6aa:
    s "Вот и всё, что я такое."

translate russian ch4_main_e8a03dc8:
    s "И поэтому я приму эти наказания."

translate russian ch4_main_a8841dc8:
    s 1bv "Потому что заслуживаю каждое из них...!"

translate russian ch4_main_78e5f68c:
    "Не раздумывая, я снова хватаю Сайори за плечи."

translate russian ch4_main_af8cb833:
    "На этот раз я крепко прижимаю её к себе."

translate russian ch4_main_23743af4:
    s "А-ах—"

translate russian ch4_main_23d81314:
    s "[player]..."

translate russian ch4_main_bf3e34d4:
    mc "Сайори."

translate russian ch4_main_6c10d11d:
    mc "Мне всё равно, считаешь ли ты себя эгоисткой."

translate russian ch4_main_d279c67d:
    mc "Я очень рад, что ты уговорила меня вступить в клуб."

translate russian ch4_main_7dffacc8:
    mc "Видеть тебя каждый день — уже этого достаточно, чтобы оно того стоило."

translate russian ch4_main_4fd890e4:
    mc "А если я подружусь со всеми остальными, это просто приятное дополнение."

translate russian ch4_main_606cd387:
    mc "Но, пожалуйста, никогда не недооценивай, как ты мне дорога."

translate russian ch4_main_834094f7:
    mc "Я бы не хотел, чтобы было иначе."

translate russian ch4_main_23d81314_1:
    s "[player]..."

translate russian ch4_main_97239717:
    "Сайори не обнимает меня в ответ."

translate russian ch4_main_0d7e9765:
    "Хотя я обнимаю её, её руки так и остаются опущенными."

translate russian ch4_main_75921590:
    "Она начинает рыдать у самого моего уха."

translate russian ch4_main_fd408bf7:
    s "Нет..."

translate russian ch4_main_12f97b41:
    s "Не делай... так со мной..."

translate russian ch4_main_93c5b869:
    s "Пожалуйста, не делай так..."

translate russian ch4_main_23d81314_2:
    s "[player]..."

translate russian ch4_main_e8a331c8:
    s "Я..."

translate russian ch4_main_dcc226a3:
    "Сайори едва удаётся говорить сквозь рыдания."

translate russian ch4_main_451f1671:
    "Я не знаю, правильно ли поступаю."

translate russian ch4_main_8709e79b:
    "Но всё, чего я хочу, — чтобы она знала, что мне не всё равно."

translate russian ch4_main_9e467023:
    mc "Раз уж ты называешь себя эгоисткой, позволь и мне побыть эгоистом."

translate russian ch4_main_211c4d9a:
    mc "Чего бы это ни стоило, я пойму, что нужно изменить."

translate russian ch4_main_e00b981c:
    mc "Я сделаю так, чтобы эти чувства ушли."

translate russian ch4_main_4e1a31b1:
    mc "И если тебе нужно, чтобы я что-то сделал..."

translate russian ch4_main_e46ea2e5:
    mc "Ты обязательно мне скажи."

translate russian ch4_main_62646328:
    mc "Я рассержусь, если не скажешь."

translate russian ch4_main_e1554201:
    s "..."

translate russian ch4_main_e12a63c3:
    s "Я... не знаю..."

translate russian ch4_main_d9c81ff9:
    s "Я не знаю..."

translate russian ch4_main_61ecc309:
    s "Я не знаю."

translate russian ch4_main_6f0a7265:
    "Наконец Сайори осторожно обнимает меня в ответ."

translate russian ch4_main_d37409b2:
    s "Я ничего не знаю."

translate russian ch4_main_ceb757fb:
    s "Это всё так страшно..."

translate russian ch4_main_b17fbfd7:
    s "Я не понимаю ни одного своего чувства, [player]..."

translate russian ch4_main_c6417526:
    s "Единственное время, когда я не чувствую пустоты, — это когда мне больно."

translate russian ch4_main_c9170687_1:
    s "Но..."

translate russian ch4_main_16e388fe:
    s "Твои объятия такие тёплые..."

translate russian ch4_main_9b224a34:
    s "...И это тоже очень страшно."

translate russian ch4_main_6e1bca9b:
    "Сайори отпускает меня."

translate russian ch4_main_43a2a362:
    "И я тоже её отпускаю."

translate russian ch4_main_dd6142ec:
    mc "Фестиваль уже завтра."

translate russian ch4_main_d06a9bfe:
    s 1bk "Ну вот..."

translate russian ch4_main_de06eb82:
    mc "Будет весело, правда?"

translate russian ch4_main_036bd57a:
    s "Ага."

translate russian ch4_main_684b10e4:
    mc "Хочешь, я проведу его весь с тобой?"

translate russian ch4_main_c17de943:
    s 1bh "Э-э..."

translate russian ch4_main_57cb4d56:
    s "А—"

translate russian ch4_main_ceb1f637:
    mc "Я сам этого хочу."

translate russian ch4_main_0a4dbc8d:
    mc "Обещаю."

translate russian ch4_main_23615804:
    s 1bk "Я..."

translate russian ch4_main_f334bfcb:
    s "Тогда, наверное, это было бы здорово..."

translate russian ch4_main_cf1adef2:
    mc "Ага."

translate russian ch4_main_ad6d9b2c:
    "Сайори вытирает глаза."

translate russian ch4_main_2efa6d9b:
    "Если бы я мог провести здесь весь день, я бы так и сделал."

translate russian ch4_main_0d36eb63:
    mc "Из всех дней именно сегодня у меня другие планы..."

translate russian ch4_main_e068d329:
    mc "Может, мне отменить—"

translate russian ch4_main_8a85c027:
    s 1bh "Нет, не надо—!"

translate russian ch4_main_7e7ed6dc:
    s 1bg "Пожалуйста, не надо..."

translate russian ch4_main_fcaef8fa:
    s "Если ты так сделаешь... то я тебя правда не прощу."

translate russian ch4_main_fc896afd:
    mc "Но..."

translate russian ch4_main_0756728a:
    mc "Скоро ко мне домой должна прийти [ch4_name!t]..."

translate russian ch4_main_95533e69:
    mc "Может, хотя бы пойдёшь со мной и поможешь?"

translate russian ch4_main_4d4bb695:
    mc "Будет весело."

translate russian ch4_main_57d1a9b9:
    "К моему удивлению, Сайори качает головой."

translate russian ch4_main_3bf26e9f:
    s 1bd "Прости."

translate russian ch4_main_771c1295:
    s "Не уверена, что сегодня мне это пойдёт на пользу."

translate russian ch4_main_75d2f9e7:
    s "Ты ведь понимаешь, правда?"

translate russian ch4_main_93deaf69:
    mc "А..."

translate russian ch4_main_d8b1d200:
    mc "Мне... трудно понять до конца."

translate russian ch4_main_81f13121:
    mc "Но я очень стараюсь."

translate russian ch4_main_61c2e6b9:
    s "Всё хорошо."

translate russian ch4_main_b3911918:
    s "Не переживай об этом слишком сильно."

translate russian ch4_main_394a0e83:
    s 4ba "Увидимся завтра, ладно?"

translate russian ch4_main_44977a95:
    mc "...Ладно."

translate russian ch4_main_9c940590:
    mc "Буду ждать."

translate russian ch4_main_ee82c933:
    "Я прощаюсь с Сайори и выхожу из её дома."

translate russian ch4_main_75570300:
    "По дороге домой мне всё ещё неспокойно."

translate russian ch4_main_33401e76:
    "Но трудно продолжать об этом думать, когда вот-вот придёт [ch4_name!t]..."

translate russian ch4_main_3818a70d:
    "Думаю, Сайори права."

translate russian ch4_main_f04e1698:
    "Не стоит слишком переживать, и завтра мы точно отлично проведём время."

translate russian ch4_main_e9524105:
    "Нужно просто сосредоточиться на том, что впереди!"

translate russian ch4_exclusive_natsuki_1d4aa47f:
    "Вернувшись домой, я всего несколько минут нервно жду прихода Нацуки."

translate russian ch4_exclusive_natsuki_537efde1:
    "Не успеваю оглянуться, как она пишет, что стоит у входной двери."

translate russian ch4_exclusive_natsuki_e64a4a7f:
    "Не мешкая, я открываю дверь и впускаю её."

translate russian ch4_exclusive_natsuki_2b35b6fe:
    mc "..."

translate russian ch4_exclusive_natsuki_0d2ad34f:
    n "Здоро́во."

translate russian ch4_exclusive_natsuki_2c051c27:
    mc "...Привет."

translate russian ch4_exclusive_natsuki_6494ab20:
    "Не знаю, чего я ожидал, но вид Нацуки не в школьной форме меня совершенно выбил из колеи."

translate russian ch4_exclusive_natsuki_63fe56fe:
    "В такой милой одежде школьная форма на её фоне кажется совершенно неподходящей."

translate russian ch4_exclusive_natsuki_f74f1c23:
    n 4bc "Блин, не делай так, чтобы уже было неловко!"

translate russian ch4_exclusive_natsuki_4a59d6bb:
    n "Впереди долгий день, так что не веди себя странно только потому, что не привык видеть меня вне школы."

translate russian ch4_exclusive_natsuki_eed86774:
    n "В общем, я захожу."

translate russian ch4_exclusive_natsuki_89364159:
    mc "Смотрю, ты принесла кучу всего..."

translate russian ch4_exclusive_natsuki_9e86c3cb:
    "Нацуки тащит большую сумку, наверное, набитую всем для выпечки."

translate russian ch4_exclusive_natsuki_2e21fa61:
    n 2bj "Ну, не хотелось проделать такой путь и выяснить, что твоя кухня для этого не годится."

translate russian ch4_exclusive_natsuki_2db4838b:
    n "Ты ведь купил всё, что я просила?"

translate russian ch4_exclusive_natsuki_78215334:
    mc "Ага, купил."

translate russian ch4_exclusive_natsuki_52ce3b53:
    "Вчера Нацуки попросила меня купить кучу продуктов, если их у меня дома нет."

translate russian ch4_exclusive_natsuki_31621867:
    n 2bl "Отлично!"

translate russian ch4_exclusive_natsuki_9e5fbd01:
    n "Рада, что на тебя можно положиться."

translate russian ch4_exclusive_natsuki_2f47e14a:
    mc "Ну... конечно."

translate russian ch4_exclusive_natsuki_001c40d3:
    "Удивительно слышать от Нацуки такое вместо обычной язвительной фразочки."

translate russian ch4_exclusive_natsuki_1c7146ba:
    "Может, вне школы она и правда немного другая?"

translate russian ch4_exclusive_natsuki_b0555a7b:
    mc "В общем, пошли на кухню..."

translate russian ch4_exclusive_natsuki_afe013d6:
    n 2by "Что, даже не предложишь забрать у меня тяжёлую сумку?"

translate russian ch4_exclusive_natsuki_0fc09c1a:
    n "Где твоё гостеприимство, [player]?"

translate russian ch4_exclusive_natsuki_768f756d:
    mc "Да ладно тебе..."

translate russian ch4_exclusive_natsuki_ba6a6b45:
    mc "С каких это пор мне надо быть джентльменом?"

translate russian ch4_exclusive_natsuki_6f86acad:
    "Я беру сумку, которую протягивает мне Нацуки."

translate russian ch4_exclusive_natsuki_c58540b7:
    mc "Кх—"

translate russian ch4_exclusive_natsuki_414dcba8:
    mc "Да она неподъёмная—!"

translate russian ch4_exclusive_natsuki_12060962:
    n 4bz "А-ха-ха!"

translate russian ch4_exclusive_natsuki_c66aafd1:
    n "Я её всю дорогу сюда несла."

translate russian ch4_exclusive_natsuki_b3f61d6f:
    n 4bl "Впечатлён?"

translate russian ch4_exclusive_natsuki_32af17a7:
    mc "Теперь понятно..."

translate russian ch4_exclusive_natsuki_45e183b7:
    mc "Да, впечатлён, Нацуки."

translate russian ch4_exclusive_natsuki_78845028:
    mc "Похоже, я тебя вечно недооцениваю."

translate russian ch4_exclusive_natsuki_be1477dd:
    n 4by "Э-хе-хе~"

translate russian ch4_exclusive_natsuki_9aa6b112:
    n "Это потому, что я такая маленькая, да?"

translate russian ch4_exclusive_natsuki_273ba5ff:
    n 4ba "Гад."

translate russian ch4_exclusive_natsuki_eb4674bb:
    "Нацуки бьёт меня кулаком в грудь."

translate russian ch4_exclusive_natsuki_b7c13526:
    mc "Эй, эй."

translate russian ch4_exclusive_natsuki_e5ab9b75:
    mc "Твой рост тут совершенно ни при чём."

translate russian ch4_exclusive_natsuki_1c775f69:
    mc "Тебе правда так не нравится быть маленькой?"

translate russian ch4_exclusive_natsuki_24879b72:
    n 1bk "А?"

translate russian ch4_exclusive_natsuki_2889c693:
    n "Э-э..."

translate russian ch4_exclusive_natsuki_d515057d:
    n 1bc "Не то чтобы не нравится..."

translate russian ch4_exclusive_natsuki_701e54b4:
    n "В смысле, иногда мне нравится доказывать, что люди ошибаются, когда судят обо мне по росту."

translate russian ch4_exclusive_natsuki_ee4f1e67:
    n 1ba "Весело быть маленькой и при этом лучше других."

translate russian ch4_exclusive_natsuki_a28869be:
    n "Но..."

translate russian ch4_exclusive_natsuki_b547b135:
    n 5bw "...Блин, забудь!"

translate russian ch4_exclusive_natsuki_3721c19e:
    n "Что ты меня заставляешь говорить?"

translate russian ch4_exclusive_natsuki_08fb5a08:
    n 5bq "Не думай, что можешь вытягивать из меня всякие странности только потому, что мы не в школе!"

translate russian ch4_exclusive_natsuki_64dfef8b:
    n "Мы начинаем или как? Мне тебя ещё многому учить."

translate russian ch4_exclusive_natsuki_ee7d9dbd:
    mc "А-ха-ха."

translate russian ch4_exclusive_natsuki_74b16515:
    n 5bn "Что??"

translate russian ch4_exclusive_natsuki_11f09ade:
    mc "Вот это уже больше на тебя похоже."

translate russian ch4_exclusive_natsuki_9e602d6d:
    mc "Ты интереснее, когда просто говоришь, что думаешь."

translate russian ch4_exclusive_natsuki_1c5495a8:
    n 1bm "Э-эй!"

translate russian ch4_exclusive_natsuki_602b8c5b:
    n "Вот теперь ты {i}точно{/i} обращаешься со мной как с ребёнком!"

translate russian ch4_exclusive_natsuki_eaa235ff:
    n "Я, между прочим, просто пыталась быть с тобой чуть повежливее."

translate russian ch4_exclusive_natsuki_8bd6a7af:
    n 1br "И то, что у меня нет взрослой сексуальной фигуры, как у Юри, ещё не значит, что ты можешь обращаться со мной как с—"

translate russian ch4_exclusive_natsuki_21ffec45:
    n 1bo "А-ах—"

translate russian ch4_exclusive_natsuki_bbf5340c:
    "Нацуки осекается, и её лицо заливается краской."

translate russian ch4_exclusive_natsuki_3aa42c3b:
    mc "Нацуки..."

translate russian ch4_exclusive_natsuki_80a55c2c:
    n 1bp "Забудь!"

translate russian ch4_exclusive_natsuki_c610ee5f:
    n "Я ничего не говорила!"

translate russian ch4_exclusive_natsuki_b5571e35:
    mc "Мне стоит извиниться."

translate russian ch4_exclusive_natsuki_548eadc3:
    n 1bh "А?"

translate russian ch4_exclusive_natsuki_035b8b94:
    mc "Я ценю, что ты пыталась быть повежливее."

translate russian ch4_exclusive_natsuki_87339ad0:
    mc "Мне тоже стоило быть чуть внимательнее."

translate russian ch4_exclusive_natsuki_b7ca89e4:
    mc "Но вот ещё что..."

translate russian ch4_exclusive_natsuki_c087ed18:
    mc "Если ты так думаешь, то знай: полно парней, которым нравятся как раз фигуры вроде твоей."

translate russian ch4_exclusive_natsuki_cf430c16:
    n 1bq "Ах..."

translate russian ch4_exclusive_natsuki_980d8e6f:
    n "А ты-то... откуда это знаешь?"

translate russian ch4_exclusive_natsuki_b28f1525:
    mc "Просто поверь мне на слово."

translate russian ch4_exclusive_natsuki_bb2cf764:
    n "..."

translate russian ch4_exclusive_natsuki_b19dc633:
    n 5bx "...Фу."

translate russian ch4_exclusive_natsuki_699878f6:
    mc "Эй!"

translate russian ch4_exclusive_natsuki_7a355051:
    mc "Это ты мне?"

translate russian ch4_exclusive_natsuki_273e265e:
    n 5bw "А кому ещё?"

translate russian ch4_exclusive_natsuki_3bb3965e:
    mc "Ну и ну..."

translate russian ch4_exclusive_natsuki_d9c485e9:
    mc "Давай уже начинать."

translate russian ch4_exclusive_natsuki_fac50087:
    n 2bl "А-ха-ха!"

translate russian ch4_exclusive_natsuki_a2ae14bd:
    n "Ты сразу скисаешь, когда девчонка говорит тебе «фу»."

translate russian ch4_exclusive_natsuki_43c527f1:
    n 2bd "Наконец-то я нашла твоё слабое место, [player]."

translate russian ch4_exclusive_natsuki_6f531a13:
    "Нацуки коварно улыбается."

translate russian ch4_exclusive_natsuki_488fc279:
    mc "Пощади..."

translate russian ch4_exclusive_natsuki_6178311a:
    "Что ж, если Нацуки решит и дальше так меня подкалывать, я в долгу не останусь."

translate russian ch4_exclusive_natsuki_c36c29ec:
    "Но пока что ей этого достаточно, и она наконец начинает доставать вещи из сумки, чтобы мы могли приступить."

translate russian ch4_exclusive_natsuki_a0bf5abf:
    "Вскоре на кухне царит полный бардак."

translate russian ch4_exclusive_natsuki_1484daec:
    "Ложки, грязные миски, мука, пролитая жидкость и пакеты разбросаны по всем столешницам."

translate russian ch4_exclusive_natsuki_aa72bfa4:
    "Миксер недостаточно большой, чтобы замесить всё тесто разом, так что приходится делать это несколько раз."

translate russian ch4_exclusive_natsuki_74c58494:
    "А Нацуки тем временем следит за каждым моим движением, чтобы я не испортил её драгоценную выпечку."

translate russian ch4_exclusive_natsuki_20607a5c:
    n "[player], куда ты дел пищевой краситель?"

translate russian ch4_exclusive_natsuki_aa6c698c:
    n "Тесто скоро пойдёт в духовку, так что мне надо заполнить формы."

translate russian ch4_exclusive_natsuki_25e0f256:
    mc "Кажется, он всё ещё в пакете возле стола."

translate russian ch4_exclusive_natsuki_e49ace96:
    mc "А зачем он тебе?"

translate russian ch4_exclusive_natsuki_2e67e7d1:
    n 4bl "Чтобы окрасить тесто, конечно!"

translate russian ch4_exclusive_natsuki_fb4e0e6a:
    n 4bj "Я делаю каждый противень разного цвета."

translate russian ch4_exclusive_natsuki_d3c0e264:
    n "Тогда, даже если вкусы одинаковые, каждый сможет выбрать свой любимый."

translate russian ch4_exclusive_natsuki_479c05cb:
    mc "А, милая идея."

translate russian ch4_exclusive_natsuki_df169c48:
    mc "А с глазурью будем делать что-нибудь такое?"

translate russian ch4_exclusive_natsuki_bd9c5ac8:
    n 4bk "А ты хочешь?"

translate russian ch4_exclusive_natsuki_93deaf69:
    mc "А..."

translate russian ch4_exclusive_natsuki_f7497de1:
    mc "Ты меня спрашиваешь?"

translate russian ch4_exclusive_natsuki_06d5350a:
    mc "Мне, в общем-то, всё равно, так что..."

translate russian ch4_exclusive_natsuki_0cf63e82:
    n 1bm "Ну ты чего..."

translate russian ch4_exclusive_natsuki_0802a95c:
    n "Ты совсем не вкладываешь в это душу!"

translate russian ch4_exclusive_natsuki_c50fa74d:
    n "Может, хотя бы попробуешь получить удовольствие?"

translate russian ch4_exclusive_natsuki_0a068810:
    mc "Да я получаю..."

translate russian ch4_exclusive_natsuki_330e2a1e:
    "Не очень понимаю, чего Нацуки пытается от меня добиться."

translate russian ch4_exclusive_natsuki_fa2ce4bf:
    "Тем временем я вижу, как она разделяет тесто на мисочки поменьше и капает в каждую по несколько капель красителя."

translate russian ch4_exclusive_natsuki_34c8fca9:
    mc "А, это и правда здорово выглядит."

translate russian ch4_exclusive_natsuki_54a47c3d:
    n 2bj "Вот видишь?"

translate russian ch4_exclusive_natsuki_11c0aecf:
    n "Выпечка — это не только следовать инструкциям."

translate russian ch4_exclusive_natsuki_8de3d406:
    n "Подача — вот где можно проявить фантазию и повеселиться больше всего."

translate russian ch4_exclusive_natsuki_40de2cf6:
    n "В итоге это в миллион раз ценнее, если от одного взгляда у всех загораются глаза."

translate russian ch4_exclusive_natsuki_15edc139:
    mc "Как те, что ты сделала в мой первый день, да?"

translate russian ch4_exclusive_natsuki_0656d64c:
    "Я вспоминаю, как Нацуки гордо показывала свои капкейки в виде котиков и как восторженно смотрели на них Сайори и Моника."

translate russian ch4_exclusive_natsuki_bfee687f:
    "Интересно, смогу ли и я сделать так, чтобы Нацуки мной гордилась."

translate russian ch4_exclusive_natsuki_69c25b65:
    mc "Да..."

translate russian ch4_exclusive_natsuki_d886bf01:
    mc "Тогда, пожалуй, я тоже возьму краситель."

translate russian ch4_exclusive_natsuki_b69e5738:
    n "Похоже, ты начинаешь понимать."

translate russian ch4_exclusive_natsuki_71795068:
    n "Только сначала как следует домешай глазурь, а потом уже возись с красителем."

translate russian ch4_exclusive_natsuki_0a06e60f:
    mc "Ага, почти готово."

translate russian ch4_exclusive_natsuki_59c32b6f:
    "Электрический миксер у нас был занят тестом, так что мне для глазури достались венчик и огромная миска."

translate russian ch4_exclusive_natsuki_ed00bc7f:
    n 4bc "А?"

translate russian ch4_exclusive_natsuki_ab61c1b3:
    n "Глазурь до сих пор вся в комках!"

translate russian ch4_exclusive_natsuki_b7dca70a:
    n "Ты вообще стараешься?"

translate russian ch4_exclusive_natsuki_06097ca0:
    mc "Ну, да..."

translate russian ch4_exclusive_natsuki_69eced86:
    mc "Просто это займёт чуть больше времени."

translate russian ch4_exclusive_natsuki_e079334e:
    n 4bg "Блин, если ты так будешь делать, я тут до ночи просижу."

translate russian ch4_exclusive_natsuki_c34670e5:
    n "Вот, смотри."

translate russian ch4_exclusive_natsuki_906b9348:
    "Нацуки забирает у меня венчик, а другой рукой наклоняет миску к себе."

translate russian ch4_exclusive_natsuki_27cbc539:
    n 4be "Её надо... взбивать... что есть мочи!"

translate russian ch4_exclusive_natsuki_588561d6:
    "Через несколько секунд консистенция глазури уже стала лучше."

translate russian ch4_exclusive_natsuki_f11f4e0d:
    n 4ba "Вот видишь?"

translate russian ch4_exclusive_natsuki_cae08608:
    "Словно для убедительности, Нацуки окунает палец в глазурь и отправляет его в рот."

translate russian ch4_exclusive_natsuki_d5da0856:
    "Я нерешительно собираюсь сделать то же самое."

translate russian ch4_exclusive_natsuki_1b8adaf7:
    n 1bh "Эй!"

translate russian ch4_exclusive_natsuki_d8ce8964:
    "Нацуки вдруг хватает меня за запястье."

translate russian ch4_exclusive_natsuki_09c60050:
    n 4bh "Не хочу, чтобы {i}твои{/i} противные пальцы лезли в мою глазурь."

translate russian ch4_exclusive_natsuki_0c8f7dd0:
    mc "В твою глазурь, значит?"

translate russian ch4_exclusive_natsuki_25019ce7:
    mc "Ты забыла, кто тут всю работу сделал?"

translate russian ch4_exclusive_natsuki_7f8c96f2:
    "Я начинаю сопротивляться, понемногу подбираясь пальцем к миске."

translate russian ch4_exclusive_natsuki_6766ddcd:
    n 4by "Не заставляй меня отлупить следующим тебя!"

translate russian ch4_exclusive_natsuki_a844a440:
    mc "Хотел бы я на это посмотреть!"

translate russian ch4_exclusive_natsuki_aa795219:
    "Я давлю сильнее — ровно настолько, чтобы палец дотянулся до глазури."

translate russian ch4_exclusive_natsuki_6a273d3e:
    "Я торжествующе зачерпываю немного пальцем, и в этот момент Нацуки изо всех сил тянет меня за руку."

translate russian ch4_exclusive_natsuki_557e43e2:
    mc "А—!"

translate russian ch4_exclusive_natsuki_90b98a6a:
    "Она тянет так сильно, что я спотыкаюсь, а следом спотыкается и она."

translate russian ch4_exclusive_natsuki_1638dc54:
    n 1bx "Фу!"

translate russian ch4_exclusive_natsuki_05237a5b:
    n "Ты мне на лицо попал!"

translate russian ch4_exclusive_natsuki_48245ab1:
    mc "А кто виноват?!"

translate russian ch4_exclusive_natsuki_ae8818cc:
    "На щеке у Нацуки большая капля глазури."

translate russian ch4_exclusive_natsuki_3a27a866:
    n 1bw "Н-н-н—"

translate russian ch4_exclusive_natsuki_f3de6fd1:
    "Она пытается дотянуться до неё языком, но слишком далеко."

translate russian ch4_exclusive_natsuki_86ad9693:
    n 1br "Блин..."

translate russian ch4_exclusive_natsuki_d574e730:
    n "Знаешь что?"

translate russian ch4_exclusive_natsuki_aa6844d3:
    n 4bd "Получай!"

translate russian ch4_exclusive_natsuki_6da18b6a:
    "Вместо этого Нацуки стирает глазурь пальцем и тычет им мне в лицо."

translate russian ch4_exclusive_natsuki_3b48697b:
    mc "Размечталась—!"

translate russian ch4_exclusive_natsuki_ff8bb9a7:
    "Я быстрее."

translate russian ch4_exclusive_natsuki_335fa0f9:
    "Я хватаю её за запястье прежде, чем палец доберётся до моего лица."

translate russian ch4_exclusive_natsuki_6370e929:
    "Нацуки пытается отбиться другой рукой, но я перехватываю и её."

translate russian ch4_exclusive_natsuki_c7195d04:
    n "А-ха-ха-ха! Хватит!"

translate russian ch4_exclusive_natsuki_e83d2664:
    mc "Не раньше, чем ты извинишься за «фу»!"

translate russian ch4_exclusive_natsuki_798d1a0a:
    n "Ладно, ладно!"

translate russian ch4_exclusive_natsuki_f421a613:
    n "Прости, что сказала тебе «фу»."

translate russian ch4_exclusive_natsuki_6f15ffd7:
    n "Ты же знаешь, что я не всерьёз."

translate russian ch4_exclusive_natsuki_5e35986d:
    n "Просто весело смотреть, как ты реагируешь."

translate russian ch4_exclusive_natsuki_b6dc0725:
    n "...Ты, между прочим, со мной всё время так делаешь!"

translate russian ch4_exclusive_natsuki_ae698bfa:
    n "Говоришь всякие глупости, только чтобы посмотреть на мою реакцию."

translate russian ch4_exclusive_natsuki_e1023c8a:
    n "Нельзя так дразнить девушек."

translate russian ch4_exclusive_natsuki_09f2de35:
    mc "Правда?"

translate russian ch4_exclusive_natsuki_33633399:
    mc "Тогда, наверное, и вот так делать не стоит..."

translate russian ch4_exclusive_natsuki_653a9beb:
    "Я беру палец Нацуки в рот и слизываю глазурь."

translate russian ch4_exclusive_natsuki_3d22480c:
    n "Ч-ч-что—?"

translate russian ch4_exclusive_natsuki_560f9eb4:
    n "Т-ты серьёзно только что—"

translate russian ch4_exclusive_natsuki_c3b64b42:
    n "А-ах—"

translate russian ch4_exclusive_natsuki_c6648740:
    "Нацуки так удивлена, что даже не может сообразить, как на меня разозлиться."

translate russian ch4_exclusive_natsuki_5fba981b:
    "Её лицо пунцовое."

translate russian ch4_exclusive_natsuki_a51de77b:
    n "[player]..."

translate russian ch4_exclusive_natsuki_e32c6238:
    n "Нельзя так делать с девушками... если только они тебе очень не нравятся..."

translate russian ch4_exclusive_natsuki_909d55b8:
    n "Ты ведь это знаешь... правда?"

translate russian ch4_exclusive_natsuki_2b35b6fe_1:
    mc "..."

translate russian ch4_exclusive_natsuki_7bc28d7b:
    "Что это вообще за вопрос, ни с того ни с сего?"

translate russian ch4_exclusive_natsuki_9a54372b:
    "Как обстановка так быстро стала такой?"

translate russian ch4_exclusive_natsuki_2485f494:
    mc "Я..."

translate russian ch4_exclusive_natsuki_4ca58c5b:
    "Нацуки молча смотрит на меня."

translate russian ch4_exclusive_natsuki_c95039fc:
    "Я замечаю, как часто и неглубоко она дышит."

translate russian ch4_exclusive_natsuki_950e2463:
    "Почему у меня начинает кружиться голова...?"

translate russian ch4_exclusive_natsuki_5422c19b:
    n "А?!"

translate russian ch4_exclusive_natsuki_ce979982:
    "Ни с того ни с сего срабатывает пожарная сигнализация."

translate russian ch4_exclusive_natsuki_eb46b5ed:
    "Нацуки бросается к духовке."

translate russian ch4_exclusive_natsuki_acfa92c5:
    mc "Что-то горит?"

translate russian ch4_exclusive_natsuki_16743c57:
    mc "Я думал, ты ещё не поставила капкейки."

translate russian ch4_exclusive_natsuki_104a21d2:
    n "{i}*Кхе-кхе*{/i}"

translate russian ch4_exclusive_natsuki_4fbb941a:
    n "Ещё бы..."

translate russian ch4_exclusive_natsuki_dd994157:
    n 1bb "Ты оставил тут грязный противень, дурак!"

translate russian ch4_exclusive_natsuki_0a2c42e8:
    n "Как можно было так ошибиться?"

translate russian ch4_exclusive_natsuki_c3cc419a:
    mc "Надо было проверить, прежде чем включать духовку!"

translate russian ch4_exclusive_natsuki_c9a7ce70:
    n 1bs "Не сваливай на меня свои ошибки!"

translate russian ch4_exclusive_natsuki_a8557d5c:
    n "Блин..."

translate russian ch4_exclusive_natsuki_0aae1803:
    "Нацуки прихваткой достаёт из духовки почерневший противень."

translate russian ch4_exclusive_natsuki_679f7251:
    "Она ставит его на плиту."

translate russian ch4_exclusive_natsuki_5c37080e:
    "Ещё через мгновение сигнализация замолкает."

translate russian ch4_exclusive_natsuki_d30e239a:
    n 1bq "В общем..."

translate russian ch4_exclusive_natsuki_160d12a8:
    n "Я... ставлю их в духовку."

translate russian ch4_exclusive_natsuki_69c25b65_1:
    mc "Да..."

translate russian ch4_exclusive_natsuki_2d0e864f:
    "Напряжение от того момента всё ещё висит в воздухе."

translate russian ch4_exclusive_natsuki_b5a9d6ef:
    "Но момент уже упущен."

translate russian ch4_exclusive_natsuki_02da55f4:
    "Я смотрю, как Нацуки задвигает формы с капкейками в духовку."

translate russian ch4_exclusive_natsuki_61989fb8:
    "Потом нехотя беру венчик и продолжаю возиться с глазурью, будто ничего и не было."

translate russian ch4_exclusive_natsuki_bf25631f:
    n "А-ах, как вкусно пахнет!"

translate russian ch4_exclusive_natsuki_ea0dd4c0:
    "Капкейки готовы, пора доставать их из духовки."

translate russian ch4_exclusive_natsuki_ef506997:
    "Стоит Нацуки открыть дверцу, как комнату наполняет волна тёплого сладкого воздуха."

translate russian ch4_exclusive_natsuki_15a3f3db:
    n 4bl "Посмотри, какие они все милые!"

translate russian ch4_exclusive_natsuki_4ddb17ec:
    "Она гордо показывает разноцветные капкейки на каждом противне."

translate russian ch4_exclusive_natsuki_c3e36f61:
    mc "С глазурью они будут выглядеть ещё лучше."

translate russian ch4_exclusive_natsuki_877713fd:
    n 2ba "Можно подумать, {i}мне{/i} нужно это говорить!"

translate russian ch4_exclusive_natsuki_f5971121:
    n "Я принесла всё для украшения, так что, надеюсь, ты проявишь фантазию."

translate russian ch4_exclusive_natsuki_07a6ed2d:
    n "Вот, накладывай глазурь в эти пакеты."

translate russian ch4_exclusive_natsuki_e4ee7df8:
    "Нацуки протягивает мне несколько пластиковых кондитерских мешков."

translate russian ch4_exclusive_natsuki_a55e0e4c:
    n 2bj "У меня есть насадки, с ними получится красиво и пышно."

translate russian ch4_exclusive_natsuki_5cf6a87d:
    n "А этой можно даже цветочки делать!"

translate russian ch4_exclusive_natsuki_313ffc55:
    n "Правда, в этот раз она нам, наверное, не понадобится."

translate russian ch4_exclusive_natsuki_b3e35c15:
    mc "А эта для чего?"

translate russian ch4_exclusive_natsuki_cccbea53:
    "Я беру одну из насадок, у которой кончик гораздо тоньше, чем у остальных."

translate russian ch4_exclusive_natsuki_a1983e5e:
    n 4bk "Она очень тонкая, ею можно делать полоски или другие узоры."

translate russian ch4_exclusive_natsuki_3970918a:
    n "А ещё можно писать что-нибудь на торте."

translate russian ch4_exclusive_natsuki_1685282e:
    n "Ну, „С днём рождения!“ или что там ещё."

translate russian ch4_exclusive_natsuki_c2722d72:
    mc "Хм, понятно..."

translate russian ch4_exclusive_natsuki_2385250d:
    mc "Вообще-то, у меня от этого появилась идея."

translate russian ch4_exclusive_natsuki_5adabccb:
    n "А?"

translate russian ch4_exclusive_natsuki_01f2e029:
    mc "Это ведь литературное мероприятие, так?"

translate russian ch4_exclusive_natsuki_768ebba6:
    mc "Можно сделать его ещё литературнее, если написать на каждом капкейке разное слово."

translate russian ch4_exclusive_natsuki_8699c01e:
    mc "Будет интересно посмотреть, как люди выбирают капкейк по слову, которое им нравится."

translate russian ch4_exclusive_natsuki_f44c40ad:
    n 1bq "У-у..."

translate russian ch4_exclusive_natsuki_582359ea:
    mc "Хм?"

translate russian ch4_exclusive_natsuki_16bd665d:
    n "Я вообще-то ждала, что ты скажешь какую-нибудь глупость..."

translate russian ch4_exclusive_natsuki_49111db5:
    n 1bs "Но это и правда... очень милая идея, так что..."

translate russian ch4_exclusive_natsuki_ee7d9dbd_1:
    mc "А-ха-ха."

translate russian ch4_exclusive_natsuki_7af16939:
    mc "Может, я этого от тебя набрался."

translate russian ch4_exclusive_natsuki_4bc12b95:
    n 5bh "Э-это ещё что значит?"

translate russian ch4_exclusive_natsuki_35bc861a:
    n "Я не милая!"

translate russian ch4_exclusive_natsuki_768f756d_1:
    mc "Да ладно тебе..."

translate russian ch4_exclusive_natsuki_d41b4265:
    mc "Мы не в школе, никто не осуждает."

translate russian ch4_exclusive_natsuki_ef1a2b87:
    mc "Нельзя так одеваться и так себя вести и не ожидать, что я сочту тебя милой."

translate russian ch4_exclusive_natsuki_451fa12f:
    n 5bs "Н-ну..."

translate russian ch4_exclusive_natsuki_b94e347c:
    "Голос Нацуки затихает."

translate russian ch4_exclusive_natsuki_e5eadc30:
    n "Ты тоже..."

translate russian ch4_exclusive_natsuki_fb2e5377:
    mc "А?"

translate russian ch4_exclusive_natsuki_8be7a0b3:
    mc "Ты что-то сказала?"

translate russian ch4_exclusive_natsuki_a4685fa5:
    n 1bw "Н-нет, ничего!"

translate russian ch4_exclusive_natsuki_251479be:
    n "Давай уже займёмся глазурью!"

translate russian ch4_exclusive_natsuki_fc1e895d:
    "Нацуки ускоряется и прикрепляет насадку к каждому мешку."

translate russian ch4_exclusive_natsuki_ff4da14f:
    n 1bh "Дел ещё много, так что нечего терять время!"

translate russian ch4_exclusive_natsuki_b1340538:
    n "Вот, я покажу тебе, как это делается."

translate russian ch4_exclusive_natsuki_5a7b1cc0:
    "Не давая мне времени подумать о том, что было раньше, Нацуки быстро переходит к делу."

translate russian ch4_exclusive_natsuki_099484f7:
    "Она показывает мне, как наносить глазурь, и мы оба принимаемся за работу."

translate russian ch4_exclusive_natsuki_36e0c7ae:
    "Когда мы наконец заканчиваем, Нацуки выставляет все капкейки рядом, чтобы полюбоваться нашей работой."

translate russian ch4_exclusive_natsuki_47bb6978:
    n "Посмотри, как красиво они смотрятся вместе!"

translate russian ch4_exclusive_natsuki_2e14ea6e:
    mc "Ага, правда красиво, да?"

translate russian ch4_exclusive_natsuki_ff581b84:
    n 1bm "У-у... Хочу один прямо сейчас!"

translate russian ch4_exclusive_natsuki_d403f6fb:
    mc "Ну, тебе ведь ничто не мешает, правда?"

translate russian ch4_exclusive_natsuki_8e8cfa03:
    mc "Не вижу в этом ничего плохого."

translate russian ch4_exclusive_natsuki_04c4a45e:
    n 1bc "Ну, да, но..."

translate russian ch4_exclusive_natsuki_27aafecd:
    n "Папа сегодня готовит ужин, так что мне надо сохранить аппетит."

translate russian ch4_exclusive_natsuki_ee7d9dbd_2:
    mc "А-ха-ха."

translate russian ch4_exclusive_natsuki_ac68524f:
    mc "Сайори в этом смысле полная противоположность."

translate russian ch4_exclusive_natsuki_f50b65ff:
    mc "Будь она здесь, мы бы уже недосчитались десятка капкейков."

translate russian ch4_exclusive_natsuki_bfd3cdaa:
    mc "И ужинать она бы всё равно стала."

translate russian ch4_exclusive_natsuki_588a5445:
    n 4bg "Да ну, это же вредно!"

translate russian ch4_exclusive_natsuki_d1ec6ede:
    n 4bs "К тому же, когда папа готовит, мне нужно съесть как можно больше..."

translate russian ch4_exclusive_natsuki_d77a0c40:
    n 4bq "...Ну, как бы то ни было!"

translate russian ch4_exclusive_natsuki_9e156483:
    n 4bc "Я надеялась, что у нас останется время на мангу, но мне нужно быть дома к ужину..."

translate russian ch4_exclusive_natsuki_aef079c7:
    mc "А, уже?"

translate russian ch4_exclusive_natsuki_b9ca631b:
    mc "Жаль."

translate russian ch4_exclusive_natsuki_28cdf998:
    n 1bg "Сам виноват, что так медленно работал!"

translate russian ch4_exclusive_natsuki_26a005bb:
    n "Надо было об этом подумать."

translate russian ch4_exclusive_natsuki_b07cb9d8:
    n "Такой шанс у тебя не всегда будет."

translate russian ch4_exclusive_natsuki_3bb3965e_1:
    mc "Ну и ну..."

translate russian ch4_exclusive_natsuki_e2ff1fee:
    "Нацуки, как обычно, сваливает вину на меня."

translate russian ch4_exclusive_natsuki_c0ae346b:
    n 2bk "Ты ведь сможешь завтра принести капкейки?"

translate russian ch4_exclusive_natsuki_6c24d03d:
    n "Если вы с Сайори понесёте их вдвоём, то, наверное, управитесь за один раз."

translate russian ch4_exclusive_natsuki_a0fa8927:
    mc "Да, смогу."

translate russian ch4_exclusive_natsuki_8af9aed2:
    mc "И не волнуйся, я не дам ей съесть ни одного."

translate russian ch4_exclusive_natsuki_3d04b304:
    n 2ba "А-ха-ха."

translate russian ch4_exclusive_natsuki_ed081af3:
    n "Вот бы она слушалась меня так же, как тебя."

translate russian ch4_exclusive_natsuki_93deaf69_1:
    mc "А..."

translate russian ch4_exclusive_natsuki_cf1adef2:
    mc "Ага."

translate russian ch4_exclusive_natsuki_3971d63c:
    "Я снова вспоминаю сегодняшний разговор с Сайори."

translate russian ch4_exclusive_natsuki_d5554afb:
    "Я чувствовал себя таким беспомощным."

translate russian ch4_exclusive_natsuki_ac4357a4:
    "Сайори всегда меня слушает, но в тот момент казалось, что она вообще не может меня услышать."

translate russian ch4_exclusive_natsuki_f74f5f5f:
    n "Так, я всё собрала."

translate russian ch4_exclusive_natsuki_ae2d053c:
    n "Хорошо сегодня поработали!"

translate russian ch4_exclusive_natsuki_0dfdcd09:
    mc "Ты тоже."

translate russian ch4_exclusive_natsuki_a19bfb12:
    mc "Я тебя провожу... наверное."

translate russian ch4_exclusive_natsuki_9596bafd:
    "Вот так просто Нацуки уже собирается уходить."

translate russian ch4_exclusive_natsuki_21adaaed:
    "Кажется, день пролетел в мгновение ока."

translate russian ch4_exclusive_natsuki_0a2f1618:
    "Более того..."

translate russian ch4_exclusive_natsuki_2c2fa4da:
    "Воспользовался ли я вообще возможностью сблизиться с ней, как хотел?"

translate russian ch4_exclusive_natsuki_228e3b68:
    n "Ну..."

translate russian ch4_exclusive_natsuki_7646e0cb:
    n "Ну, тогда я пойду..."

translate russian ch4_exclusive_natsuki_2613ee81:
    n 1bq "Спасибо за помощь и всё такое..."

translate russian ch4_exclusive_natsuki_07f48ce1:
    n "Увидимся завтра."

translate russian ch4_exclusive_natsuki_8a4103bc:
    mc "Подожди, Нацуки."

translate russian ch4_exclusive_natsuki_548eadc3_1:
    n 1bh "А?"

translate russian ch4_exclusive_natsuki_7e6f824c:
    mc "То, что ты сказала раньше... что такой шанс будет не всегда."

translate russian ch4_exclusive_natsuki_3f6cd4b1:
    mc "Это совсем не обязательно так!"

translate russian ch4_exclusive_natsuki_405c1d27:
    mc "Мне сегодня было весело."

translate russian ch4_exclusive_natsuki_6d9a97aa:
    mc "Ты показала мне, как здорово печь, как и хотела."

translate russian ch4_exclusive_natsuki_95ec073f:
    mc "Но кроме этого..."

translate russian ch4_exclusive_natsuki_83a4e9ac:
    mc "Приходи в любое время, ладно?"

translate russian ch4_exclusive_natsuki_0152a549:
    mc "По-моему, если получится, я бы хотел чаще проводить время вот так."

translate russian ch4_exclusive_natsuki_66925863:
    mc "Хочешь почитать мангу или сходить куда-нибудь—"

translate russian ch4_exclusive_natsuki_29362eb3:
    n 1bm "Э-э—"

translate russian ch4_exclusive_natsuki_434c12f4:
    n "Ты... правда так думаешь?"

translate russian ch4_exclusive_natsuki_8f33b5b6:
    "Нацуки напряжённо смотрит на меня, будто пытается скрыть выражение лица."

translate russian ch4_exclusive_natsuki_cf1adef2_1:
    mc "Ага."

translate russian ch4_exclusive_natsuki_ce366dd0:
    mc "Я хочу проводить с тобой больше времени."

translate russian ch4_exclusive_natsuki_578e1b37:
    n 1bq "[player]..."

translate russian ch4_exclusive_natsuki_e7f19355:
    n "Я думала, тебе важно только поскорее с этим разделаться..."

translate russian ch4_exclusive_natsuki_b2a0bf7e:
    n 1br "У-у..."

translate russian ch4_exclusive_natsuki_ba247806:
    n 1bn "Прости, что мне сегодня пришлось так рано уйти."

translate russian ch4_exclusive_natsuki_0c0c9508:
    n "Я правда не хотела!"

translate russian ch4_exclusive_natsuki_5b862643:
    n "Если бы могла... я бы правда осталась подольше."

translate russian ch4_exclusive_natsuki_31bb1625:
    n "Я чувствую то же, что и ты, так что..."

translate russian ch4_exclusive_natsuki_b5f4ef0c:
    "Нацуки вдруг подходит ко мне ближе."

translate russian ch4_exclusive_natsuki_b03b71a9:
    mc "Подожди, Нацуки—"

translate russian ch4_exclusive_natsuki_d2c5496d:
    "Стоя в нескольких сантиметрах от меня, Нацуки поднимает на меня взгляд."

translate russian ch4_exclusive_natsuki_94a82b0d:
    "Я чувствую, как её пальцы мягко сжимают края моей рубашки, словно она держится за меня."

translate russian ch4_exclusive_natsuki_8043eaf5:
    "Её розовые щёки, глаза в тон им и чуть приоткрытые губы заполняют всё поле зрения."

translate russian ch4_exclusive_natsuki_2d899e99:
    "Что происходит...?"

translate russian ch4_exclusive_natsuki_ed944824:
    "У меня начинает кружиться голова, когда я чувствую её мягкое дыхание."

translate russian ch4_exclusive_natsuki_341e4e51:
    n 1bh "Я это чувствую..."

translate russian ch4_exclusive_natsuki_b7304ef1:
    n "Уже какое-то время..."

translate russian ch4_exclusive_natsuki_6b055c45:
    n 1bo "—!!"

translate russian ch4_exclusive_natsuki_817ef322:
    "Нацуки вдруг отскакивает."

translate russian ch4_exclusive_natsuki_4f1c9b29:
    n "С-Сайори?!"

translate russian ch4_exclusive_natsuki_af40f385:
    mc "Что?!"

translate russian ch4_exclusive_natsuki_699ac020:
    s "Ах..."

translate russian ch4_exclusive_natsuki_072fe968:
    s "П-привет, [player]..."

translate russian ch4_exclusive_natsuki_48d5b9aa:
    mc "Сайори—!"

translate russian ch4_exclusive_natsuki_5f437551:
    mc "Мы только что не—"

translate russian ch4_exclusive_natsuki_67281b29:
    s 1bq "Э-хе-хе~"

translate russian ch4_exclusive_natsuki_9751c7af:
    s "Всё в порядке, [player]."

translate russian ch4_exclusive_natsuki_22ed0333:
    s 1ba "Я просто зашла поздороваться~"

translate russian ch4_exclusive_natsuki_8d2a55aa:
    n 5bq "А-ах..."

translate russian ch4_exclusive_natsuki_228e3b68_1:
    n "Ну..."

translate russian ch4_exclusive_natsuki_93fa748b:
    n 5bw "Т-тебе стоило прийти чуть пораньше!"

translate russian ch4_exclusive_natsuki_4a7cf3f5:
    n "Я уже ухожу, так что..."

translate russian ch4_exclusive_natsuki_2b79f5e2:
    s 1bh "Ой, правда?"

translate russian ch4_exclusive_natsuki_99f9ae0f:
    s "Жалко..."

translate russian ch4_exclusive_natsuki_18cb7261:
    n 2bq "Ну да, в общем..."

translate russian ch4_exclusive_natsuki_81f46482:
    n "Всё равно увидимся завтра на фестивале, так что ничего."

translate russian ch4_exclusive_natsuki_785a98dd:
    n 2bb "Только не ешь капкейки до завтра!"

translate russian ch4_exclusive_natsuki_fc835e31:
    n "В общем, пока!"

translate russian ch4_exclusive_natsuki_12421e5c:
    "Явно смутившись, Нацуки поспешно уходит, а Сайори машет ей на прощание."

translate russian ch4_exclusive_yuri_1a7f6292:
    "Подходя к дому, я вижу кое-что, от чего на мгновение впадаю в панику."

translate russian ch4_exclusive_yuri_638dc2fd:
    mc "Юри—?"

translate russian ch4_exclusive_yuri_728dcbc5:
    y "Ах..."

translate russian ch4_exclusive_yuri_aebfb27c:
    y "Слава богу..."

translate russian ch4_exclusive_yuri_7d3e503e:
    mc "Ты немного рано..."

translate russian ch4_exclusive_yuri_c2f0d2a5:
    mc "Прости, что меня ещё не было дома!"

translate russian ch4_exclusive_yuri_5bc7b00f:
    mc "Ты долго ждала?"

translate russian ch4_exclusive_yuri_41ee4e0d:
    y 1bf "Нет, я только что пришла."

translate russian ch4_exclusive_yuri_52db6abd:
    y 1bh "Но я начала сильно нервничать, когда никто не открыл на звонок..."

translate russian ch4_exclusive_yuri_c0ef2670:
    mc "Ты всегда могла написать мне."

translate russian ch4_exclusive_yuri_b7a0fdec:
    mc "Если бы я знал, то успокоил бы тебя и поспешил домой."

translate russian ch4_exclusive_yuri_18230f31:
    y 2bv "Ах... пожалуй, это правда..."

translate russian ch4_exclusive_yuri_fcc2b4c7:
    y "Почему-то... я об этом не подумала."

translate russian ch4_exclusive_yuri_2657ff20:
    "Это вроде бы само собой разумеется, но я решаю не обращать внимания."

translate russian ch4_exclusive_yuri_96b4e74a:
    mc "В общем... пойдём внутрь."

translate russian ch4_exclusive_yuri_a88731d1:
    mc "Смотрю, ты принесла с собой кучу всего."

translate russian ch4_exclusive_yuri_1d67f4b4:
    y 1ba "Верно."

translate russian ch4_exclusive_yuri_4867445e:
    y "А тебе удалось найти всё, что я просила купить?"

translate russian ch4_exclusive_yuri_f9aa3479:
    mc "Ага, почти."

translate russian ch4_exclusive_yuri_5b561522:
    mc "По крайней мере, надеюсь, что я всё купил правильно."

translate russian ch4_exclusive_yuri_b847bd64:
    y "Уверена, всё будет хорошо."

translate russian ch4_exclusive_yuri_77a91109:
    "Я веду Юри к себе в комнату."

translate russian ch4_exclusive_yuri_b849eb1c:
    "Первым делом она с любопытством оглядывается, и мне от этого становится неспокойно."

translate russian ch4_exclusive_yuri_4dee5cf9:
    y "Тут так чисто..."

translate russian ch4_exclusive_yuri_7a59b594:
    mc "А-ха-ха..."

translate russian ch4_exclusive_yuri_2bbeb240:
    mc "Я прибрался перед твоим приходом, так что..."

translate russian ch4_exclusive_yuri_269ab5bb:
    y 2ba "Это очень предупредительно с твоей стороны."

translate russian ch4_exclusive_yuri_ca87e370:
    mc "А, да нет..."

translate russian ch4_exclusive_yuri_a2e54355:
    mc "Мне было бы очень стыдно, если бы при тебе в комнате был бардак."

translate russian ch4_exclusive_yuri_de61ae76:
    y 1ba "Хм-м..."

translate russian ch4_exclusive_yuri_aca37334:
    y "Ну, я люблю убираться..."

translate russian ch4_exclusive_yuri_67a9042a:
    y "Я бы с радостью помогла тебе прибраться."

translate russian ch4_exclusive_yuri_f9d65918:
    mc "А—"

translate russian ch4_exclusive_yuri_ae619108:
    mc "Это было бы ещё стыднее!"

translate russian ch4_exclusive_yuri_5fe76988:
    mc "Стой, не заглядывай туда—!"

translate russian ch4_exclusive_yuri_0a264a44:
    "Я перехватываю запястье Юри, которая уже открывала ящик моего стола."

translate russian ch4_exclusive_yuri_443b546a:
    y 3bn "А-ах..."

translate russian ch4_exclusive_yuri_6e90d30a:
    y "Прости...!"

translate russian ch4_exclusive_yuri_051e7f8d:
    y 4bb "Почему-то я не подумала..."

translate russian ch4_exclusive_yuri_11ad06a4:
    y "Я просто задумалась!"

translate russian ch4_exclusive_yuri_b4c44733:
    mc "Ничего, ничего..."

translate russian ch4_exclusive_yuri_26bd586e:
    "Я отпускаю запястье Юри."

translate russian ch4_exclusive_yuri_133578e7:
    "Она крепко кладёт обе руки на колени, будто следит, чтобы они никуда не делись."

translate russian ch4_exclusive_yuri_b728bf55:
    mc "Так, э-э..."

translate russian ch4_exclusive_yuri_ad5f41a4:
    mc "Может... начнём?"

translate russian ch4_exclusive_yuri_b3a6c16d:
    y 2bu "Ах..."

translate russian ch4_exclusive_yuri_d55827f2:
    y "Да..."

translate russian ch4_exclusive_yuri_ab5c72af:
    y 2bf "Э-э, у меня запланировано несколько дел, с которыми ты можешь помочь..."

translate russian ch4_exclusive_yuri_75298410:
    y "Украшения и прочие улучшения атмосферы."

translate russian ch4_exclusive_yuri_e0f89db0:
    mc "Улучшения атмосферы...?"

translate russian ch4_exclusive_yuri_cbc5e4ad:
    y 1ba "Знаешь..."

translate russian ch4_exclusive_yuri_7e1e8777:
    y "Приглушённый свет, ароматические свечи..."

translate russian ch4_exclusive_yuri_013a6253:
    mc "Ого."

translate russian ch4_exclusive_yuri_779eaab5:
    mc "Я и не знал, что ты собираешься зайти так далеко."

translate russian ch4_exclusive_yuri_72353615:
    y 1bc "Конечно."

translate russian ch4_exclusive_yuri_ef02e8a8:
    y "Я хочу помочь нашим гостям перенестись в далёкое место."

translate russian ch4_exclusive_yuri_a5799c4f:
    y 1ba "Хоть многие и зайдут просто из любопытства..."

translate russian ch4_exclusive_yuri_6933d7a7:
    y 1bj "И ради... капкейков, наверное..."

translate russian ch4_exclusive_yuri_54c5caf2:
    y 1ba "Я полна решимости подарить им впечатления, после которых им захочется ещё."

translate russian ch4_exclusive_yuri_6c25f787:
    mc "Здорово."

translate russian ch4_exclusive_yuri_b9eea9fe:
    mc "Легко забыть, что ты довольно страстная натура."

translate russian ch4_exclusive_yuri_ab7d9b46:
    y 1bt "А—"

translate russian ch4_exclusive_yuri_b2f21f7b:
    y 2bt "Страстная...?"

translate russian ch4_exclusive_yuri_cbaeb1a4:
    mc "Пожалуй, лучше и не скажешь."

translate russian ch4_exclusive_yuri_49d2b152:
    y "Это... плохо?"

translate russian ch4_exclusive_yuri_4f671c67:
    mc "Нет, совсем нет."

translate russian ch4_exclusive_yuri_0137eca8:
    mc "Вообще-то, мне это в тебе нравится."

translate russian ch4_exclusive_yuri_f6874ccc:
    y 3bu "П-правда...?"

translate russian ch4_exclusive_yuri_af3e9355:
    y "Мне от этого спокойнее..."

translate russian ch4_exclusive_yuri_9854966a:
    y "И как-то радостно..."

translate russian ch4_exclusive_yuri_94800631:
    mc "Ага, так что не надо так волноваться."

translate russian ch4_exclusive_yuri_b7d344a1:
    mc "Можешь немного расслабиться."

translate russian ch4_exclusive_yuri_bf43dc27:
    y 3bl "Расслабиться..."

translate russian ch4_exclusive_yuri_d1d227e2:
    y 1bf "Я принесла кое-что для расслабления."

translate russian ch4_exclusive_yuri_6d7bbfcd:
    y "Я собиралась использовать это на поэтическом вечере..."

translate russian ch4_exclusive_yuri_66eaf3e1:
    mc "Да? Например?"

translate russian ch4_exclusive_yuri_4d80474c:
    y "Так-так..."

translate russian ch4_exclusive_yuri_ccdd61a2:
    "Юри роется в сумке."

translate russian ch4_exclusive_yuri_e00058c5:
    "Она достаёт несколько свечей и деревянный предмет в форме цилиндра."

translate russian ch4_exclusive_yuri_f5ca2c9a:
    y "По дороге сюда я заходила в магазин, так что они как раз оказались у меня в сумке."

translate russian ch4_exclusive_yuri_765dad15:
    y "Я собиралась закрыть окна чёрной бумагой и освещать комнату свечами."

translate russian ch4_exclusive_yuri_f943cc13:
    y 1ba "По-моему, будет потрясающе, а тебе так не кажется?"

translate russian ch4_exclusive_yuri_fbd5c4bc:
    mc "Да, будет очень здорово."

translate russian ch4_exclusive_yuri_773a7b7c:
    mc "А что это за деревянная штука?"

translate russian ch4_exclusive_yuri_84103177:
    y 1bf "А, это?"

translate russian ch4_exclusive_yuri_46615e83:
    y "Это диффузор для эфирных масел."

translate russian ch4_exclusive_yuri_c46fb0b4:
    y "Ты хорошо знаком с ароматерапией?"

translate russian ch4_exclusive_yuri_c4714615:
    mc "Совсем не знаком..."

translate russian ch4_exclusive_yuri_0ac10b23:
    y 1ba "Ах, вот как?"

translate russian ch4_exclusive_yuri_160fc237:
    y "Это одно из моих любимых средств для создания приятной атмосферы."

translate russian ch4_exclusive_yuri_7e0d9b6c:
    y "Смотря какие масла или травы выбрать, можно изменить само настроение воздуха."

translate russian ch4_exclusive_yuri_68bd94eb:
    y "Можно даже почувствовать, как оно растекается по телу."

translate russian ch4_exclusive_yuri_7a8bf27b:
    y 3bm "Расслабление, бодрость, романтика, задумчивость..."

translate russian ch4_exclusive_yuri_63fcc9ac:
    y "Это почти как волшебство."

translate russian ch4_exclusive_yuri_fb4f44e1:
    "Юри берёт цилиндр и нажимает переключатель на дне."

translate russian ch4_exclusive_yuri_7107b767:
    "Через мгновение из маленького отверстия наверху начинает струиться тонкая струйка пара."

translate russian ch4_exclusive_yuri_390de38c:
    mc "Ого, чудесный запах."

translate russian ch4_exclusive_yuri_4b18a6dc:
    mc "А это для какого настроения?"

translate russian ch4_exclusive_yuri_34d80b06:
    y 1ba "Это эфирное масло жасмина."

translate russian ch4_exclusive_yuri_24a8c22a:
    y "Пахнет немного сладко и цветочно, правда?"

translate russian ch4_exclusive_yuri_b87d6070:
    mc "Да, хорошее описание."

translate russian ch4_exclusive_yuri_d48abd3c:
    y 1bb "Я выбрала жасмин для мероприятия, потому что он не только расслабляет."

translate russian ch4_exclusive_yuri_885223a6:
    y "Жасмин усиливает эмоции и помогает почувствовать, как они разливаются по телу."

translate russian ch4_exclusive_yuri_edccefe6:
    y 1bu "Становится теплее, а сердце бьётся сильнее."

translate russian ch4_exclusive_yuri_68c0a0ec:
    y 1ba "Разве это не идеально подойдёт для чтения наших стихов?"

translate russian ch4_exclusive_yuri_dab38280:
    mc "Звучит подходяще..."

translate russian ch4_exclusive_yuri_8aa7202d:
    mc "Но ты, похоже, в этом хорошо разбираешься, так что я доверюсь тебе во всём."

translate russian ch4_exclusive_yuri_93d659fb:
    "Юри мягко улыбается — ей явно нравится происходящее."

translate russian ch4_exclusive_yuri_50fae775:
    "Она снова лезет в сумку и достаёт несколько катушек тонкой ленты."

translate russian ch4_exclusive_yuri_b62d580c:
    mc "А это для чего?"

translate russian ch4_exclusive_yuri_cc60637c:
    y 1bf "Ну..."

translate russian ch4_exclusive_yuri_e9e9de52:
    y "Ты купил бумагу для оригами, о которой я просила?"

translate russian ch4_exclusive_yuri_ffcd40a2:
    mc "Ага, вон она..."

translate russian ch4_exclusive_yuri_47353469:
    y "Складывать оригами мы из неё не будем."

translate russian ch4_exclusive_yuri_22eae3a4:
    y "Я хочу написать на каждом листке разное слово."

translate russian ch4_exclusive_yuri_22ab5158:
    y "Их понадобится около сотни."

translate russian ch4_exclusive_yuri_4f43e9fe:
    mc "Да?"

translate russian ch4_exclusive_yuri_2de638ab:
    mc "А для чего они?"

translate russian ch4_exclusive_yuri_43945948:
    y 2bf "Ну, я нарежу ленты, чтобы свесить их с дверного проёма класса."

translate russian ch4_exclusive_yuri_c3c62ae5:
    y "Потом мы прикрепим к лентам листки, и получится занавес на двери."

translate russian ch4_exclusive_yuri_91b54924:
    y 2bm "Разве это не будет красиво?"

translate russian ch4_exclusive_yuri_fc472a62:
    y "К тому же это привлечёт внимание тех, кто будет проходить мимо..."

translate russian ch4_exclusive_yuri_71e8f31c:
    y 2ba "Может, кто-то и заглянет внутрь."

translate russian ch4_exclusive_yuri_ce018b3a:
    mc "Как креативно!"

translate russian ch4_exclusive_yuri_d51182dd:
    mc "Я и не знал, что у тебя так здорово это получается, Юри."

translate russian ch4_exclusive_yuri_a9eb75bc:
    y 4ba "Правда...?"

translate russian ch4_exclusive_yuri_53203fa3:
    y "Что ж, пожалуй, я и правда бываю немного страстной... как ты выразился."

translate russian ch4_exclusive_yuri_e43fd5a9:
    y 3bu "У-фу-фу."

translate russian ch4_exclusive_yuri_cdc817ae:
    "Юри хихикает, покраснев."

translate russian ch4_exclusive_yuri_19e0a918:
    "Мне кажется или наедине со мной она спокойнее?"

translate russian ch4_exclusive_yuri_6ad7399d:
    "А может, это волнение оттого, что она делится тем, что ей нравится."

translate russian ch4_exclusive_yuri_ca3f9b5a:
    y 1ba "Вот маркер, [player]."

translate russian ch4_exclusive_yuri_3b16a249:
    y "Можешь писать любые иероглифы, какие захочешь."

translate russian ch4_exclusive_yuri_58cb4240:
    y "Я помогу, как только дорежу ленты."

translate russian ch4_exclusive_yuri_eeadee1b:
    mc "А, хорошо."

translate russian ch4_exclusive_yuri_3a9138bb:
    "Сидя вдвоём на полу, мы принимаемся за работу."

translate russian ch4_exclusive_yuri_52e58580:
    "Я старательно вывожу на каждом листке по иероглифу, изо всех сил борясь со своим плохим почерком."

translate russian ch4_exclusive_yuri_dd943745:
    "Юри разматывает длинную красную ленту до нужной длины."

translate russian ch4_exclusive_yuri_1cc8a003:
    "Потом снова лезет в сумку и достаёт складной нож."

translate russian ch4_exclusive_yuri_bbe4458e:
    mc "А...?"

translate russian ch4_exclusive_yuri_9588fb2b:
    "Нож странно красив."

translate russian ch4_exclusive_yuri_42062e86:
    "На серебряной рукояти выгравирован замысловатый узор из волн."

translate russian ch4_exclusive_yuri_dfd6bcd4:
    "Само лезвие отливает нежно-голубым."

translate russian ch4_exclusive_yuri_78f3868f:
    mc "Это не обычный складной нож..."

translate russian ch4_exclusive_yuri_93a46c5e:
    mc "Выглядит очень изысканно."

translate russian ch4_exclusive_yuri_9b47ae2d:
    y 4bb "А-ах..."

translate russian ch4_exclusive_yuri_ae7f22e8:
    y "Ну..."

translate russian ch4_exclusive_yuri_be7d4ca7:
    "Смутившись, Юри отводит взгляд."

translate russian ch4_exclusive_yuri_def0ad19:
    mc "А что там?"

translate russian ch4_exclusive_yuri_cbdd802c:
    y "Ты подумаешь, что это странно..."

translate russian ch4_exclusive_yuri_34c5d38d:
    mc "Юри, что бы это ни было, мне незачем тебя осуждать."

translate russian ch4_exclusive_yuri_5e0b9d41:
    mc "У каждого свои вкусы, понимаешь?"

translate russian ch4_exclusive_yuri_6901b8aa:
    y "Если пообещаешь, что не будешь считать это жутким..."

translate russian ch4_exclusive_yuri_5f1cf882:
    mc "Да, обещаю."

translate russian ch4_exclusive_yuri_a8fab8b1:
    y 2bi "Хорошо..."

translate russian ch4_exclusive_yuri_4791d5bf:
    y "Дело в том, что я вроде как увлекаюсь ножами..."

translate russian ch4_exclusive_yuri_4959c25f:
    y "Они просто... такие красивые..."

translate russian ch4_exclusive_yuri_ea47e2ed:
    y 2bv "Я-я ничего не могу с собой поделать!"

translate russian ch4_exclusive_yuri_ea5c6bb2:
    y "Не знаю, в чём дело..."

translate russian ch4_exclusive_yuri_585a09bb:
    y "Может, в сочетании мастерства и ощущения опасности..."

translate russian ch4_exclusive_yuri_1035f297:
    y 4bb "У-у, что я говорю...?"

translate russian ch4_exclusive_yuri_5053aa7a:
    y "Пожалуйста, не считай меня из-за этого странной..."

translate russian ch4_exclusive_yuri_ee7d9dbd:
    mc "А-ха-ха."

translate russian ch4_exclusive_yuri_4a73dfe6:
    y "Ты надо мной смеёшься..."

translate russian ch4_exclusive_yuri_ebf61b90:
    mc "Нет, я не смеюсь над тобой."

translate russian ch4_exclusive_yuri_8436c3fc:
    mc "Просто забавно, как ты разнервничалась, когда решила поделиться."

translate russian ch4_exclusive_yuri_98e5019e:
    mc "Это... ну, довольно интересное увлечение, наверное."

translate russian ch4_exclusive_yuri_2bdc4458:
    mc "Но, по-моему, тебе оно даже подходит."

translate russian ch4_exclusive_yuri_13cf2b15:
    y 2bt "Подходит...?"

translate russian ch4_exclusive_yuri_515d3ad5:
    mc "Ага... Оно такое же страстное. А-ха-ха."

translate russian ch4_exclusive_yuri_d53d688b:
    mc "К тому же нож и правда очень классный на вид, не могу не признать."

translate russian ch4_exclusive_yuri_26589eeb:
    y 2bu "Правда же...?"

translate russian ch4_exclusive_yuri_9ec1744f:
    "Выражение лица Юри снова смягчается."

translate russian ch4_exclusive_yuri_536b8e3f:
    y 1ba "Хочешь подержать?"

translate russian ch4_exclusive_yuri_2a490275:
    mc "Конечно, давай посмотрю."

translate russian ch4_exclusive_yuri_9cfef63c:
    "Юри аккуратно протягивает мне нож рукоятью вперёд."

translate russian ch4_exclusive_yuri_a5b6534a:
    "Я беру его и верчу в руках."

translate russian ch4_exclusive_yuri_b73b12fb:
    "Он тяжёлый и невероятно прочный."

translate russian ch4_exclusive_yuri_5e2013d8:
    "Где вообще берут такие ножи...?"

translate russian ch4_exclusive_yuri_b6c65002:
    "Из любопытства, насколько он острый, я трогаю кончик указательным пальцем."

translate russian ch4_exclusive_yuri_f8a85726:
    mc "Ай—!"

translate russian ch4_exclusive_yuri_656b9d8c:
    y 3bn "[player]—!!"

translate russian ch4_exclusive_yuri_5462fadf:
    y "Зачем ты это сделал?!"

translate russian ch4_exclusive_yuri_0978a0d2:
    mc "Я не ожидал, что он такой острый...!"

translate russian ch4_exclusive_yuri_94676cc9:
    mc "Я его еле коснулся."

translate russian ch4_exclusive_yuri_b3405a90:
    y "Э-это я виновата!"

translate russian ch4_exclusive_yuri_36b38d99:
    y 3bo "Надо было тебя предупредить..."

translate russian ch4_exclusive_yuri_4820b785:
    y "Этот нож невероятно острый..."

translate russian ch4_exclusive_yuri_f6c8abc2:
    y "Он режет кожу, как бумагу."

translate russian ch4_exclusive_yuri_5c76f169:
    y 2bv "О нет..."

translate russian ch4_exclusive_yuri_26ba740e:
    "По пальцу стекает маленькая капля крови."

translate russian ch4_exclusive_yuri_2e2eabd9:
    "Юри берёт меня за руку и рассматривает ранку поближе."

translate russian ch4_exclusive_yuri_a564ea90:
    y 2bt "Ах..."

translate russian ch4_exclusive_yuri_cb9ef4b0:
    "Она смотрит на неё и заметно ёрзает."

translate russian ch4_exclusive_yuri_e4611ef7:
    mc "Если тебе неприятно, я сейчас пойду промою—"

translate russian ch4_exclusive_yuri_01196e39:
    mc "А-ах!"

translate russian ch4_exclusive_yuri_92498935:
    "Без предупреждения Юри берёт мой палец в рот и слизывает кровь."

translate russian ch4_exclusive_yuri_d0486aa9:
    "Я чувствую, как её язык обвивает мой палец."

translate russian ch4_exclusive_yuri_89072020:
    "От неожиданности я инстинктивно отдёргиваю руку."

translate russian ch4_exclusive_yuri_1f41d1a2:
    y "О-ох..."

translate russian ch4_exclusive_yuri_2d11f2ab:
    y 3bo "П-пожалуйста, прости меня!"

translate russian ch4_exclusive_yuri_ad65b50e:
    y "Я не подумала!"

translate russian ch4_exclusive_yuri_7afcece9:
    y 4bc "Я..."

translate russian ch4_exclusive_yuri_0f644690:
    "Юри опускает голову, её лицо пылает."

translate russian ch4_exclusive_yuri_d90390e4:
    mc "Юри..."

translate russian ch4_exclusive_yuri_e43dbe5a:
    y "Это самое постыдное, что я когда-либо делала..."

translate russian ch4_exclusive_yuri_d68cfcd5:
    y "Как я могла такое сделать??"

translate russian ch4_exclusive_yuri_684804a5:
    y "Прости, прости..."

translate russian ch4_exclusive_yuri_93deaf69:
    mc "А..."

translate russian ch4_exclusive_yuri_5545b90b:
    "Конечно, это было немного странно и застало меня врасплох..."

translate russian ch4_exclusive_yuri_c4cc71cf:
    "Но она ведь просто хотела помочь, правда...?"

translate russian ch4_exclusive_yuri_0b0e5f5b:
    mc "Юри, по-моему, ты немного преувеличиваешь..."

translate russian ch4_exclusive_yuri_71fa57dd:
    y "У-у-ух..."

translate russian ch4_exclusive_yuri_73c62ed6:
    "Она не поднимает головы."

translate russian ch4_exclusive_yuri_93d8fc18:
    "Что, если она так и не оправится от этого до конца дня?"

translate russian ch4_exclusive_yuri_3d3ac541:
    mc "Ладно, знаешь что..."

translate russian ch4_exclusive_yuri_1d9a660b:
    "Может, это и глупо, но я всё равно это делаю."

translate russian ch4_exclusive_yuri_5795b8d6:
    "Я беру Юри за руку и в ответ облизываю её указательный палец."

translate russian ch4_exclusive_yuri_70468acb:
    y "[player]—!!"

translate russian ch4_exclusive_yuri_33afe2fb:
    y "Т-ты правда только что это сделал?"

translate russian ch4_exclusive_yuri_b952ccca:
    mc "Т-теперь мы квиты..."

translate russian ch4_exclusive_yuri_52a4ea86:
    y 3bv "..."

translate russian ch4_exclusive_yuri_f474f2b9:
    "Юри просто смотрит на меня так, будто я сделал что-то не то."

translate russian ch4_exclusive_yuri_7a59b594_1:
    mc "А-ха-ха..."

translate russian ch4_exclusive_yuri_c61d5d45:
    mc "Так и знал, что это плохая идея..."

translate russian ch4_exclusive_yuri_8e154315:
    "Если бы не сладкий аромат жасминового масла, воздух сейчас был бы невыносимо тяжёлым."

translate russian ch4_exclusive_yuri_93afc4bd:
    y 1bu "Какой же ты странный, [player]."

translate russian ch4_exclusive_yuri_d1f86faa:
    "Юри застенчиво хихикает."

translate russian ch4_exclusive_yuri_bbe4458e_1:
    mc "А...?"

translate russian ch4_exclusive_yuri_b21a4ab2:
    "Юри называет странным {i}меня{/i}?"

translate russian ch4_exclusive_yuri_4509d67c:
    "Мне нечего на это ответить..."

translate russian ch4_exclusive_yuri_f26759eb:
    y 1bf "Где у тебя пластыри?"

translate russian ch4_exclusive_yuri_93deaf69_1:
    mc "А..."

translate russian ch4_exclusive_yuri_1d482e7a:
    mc "Вообще-то, думаю, он мне не нужен."

translate russian ch4_exclusive_yuri_a13e7605:
    mc "Порез совсем крошечный."

translate russian ch4_exclusive_yuri_84cbbbab:
    mc "Смотри, кровь уже остановилась."

translate russian ch4_exclusive_yuri_02335ffd:
    y 1ba "Понятно..."

translate russian ch4_exclusive_yuri_e88d809b:
    y "Какое облегчение."

translate russian ch4_exclusive_yuri_d6c968ec:
    "Напряжение быстро рассеивается."

translate russian ch4_exclusive_yuri_8318b800:
    "Каждый из нас возвращается к своему делу."

translate russian ch4_exclusive_yuri_7b1ea838:
    "Я смотрю, как нож Юри режет ленту, будто это просто воздух."

translate russian ch4_exclusive_yuri_9915cc08:
    "А я тем временем продолжаю возиться с листками."

translate russian ch4_exclusive_yuri_5468995c:
    "Закончив прикреплять листки к лентам, мы раскладываем их все рядом."

translate russian ch4_exclusive_yuri_f65e23a4:
    "Выглядит лучше, чем я ожидал, и как занавес на двери будет смотреться очень эффектно."

translate russian ch4_exclusive_yuri_135a7724:
    mc "Выглядит отлично."

translate russian ch4_exclusive_yuri_6fd41911:
    mc "Здорово ты это придумала, Юри."

translate russian ch4_exclusive_yuri_672fb4b2:
    y "Ах, спасибо..."

translate russian ch4_exclusive_yuri_586312e0:
    y "Вообще-то, я просто увидела это в интернете."

translate russian ch4_exclusive_yuri_cebe4068:
    y 1ba "Готов перейти к следующему заданию?"

translate russian ch4_exclusive_yuri_39ef9b02:
    mc "Ага, давай."

translate russian ch4_exclusive_yuri_068582fd:
    mc "Что ты задумала?"

translate russian ch4_exclusive_yuri_6fb26d3d:
    y "Я бы хотела сделать растяжку."

translate russian ch4_exclusive_yuri_dfef5d98:
    y "Поэтому я и просила тебя купить акварель в таблетках."

translate russian ch4_exclusive_yuri_96a57d25:
    mc "А, точно."

translate russian ch4_exclusive_yuri_4d3528f0:
    "Среди прочего Юри просила купить набор акварельных красок в таблетках."

translate russian ch4_exclusive_yuri_623899fe:
    y 1bf "Нам понадобится около шести стаканов воды, чтобы растворить в каждом по таблетке."

translate russian ch4_exclusive_yuri_823c4f64:
    y "Ты не против принести их?"

translate russian ch4_exclusive_yuri_c2eb53da:
    mc "Конечно, нет."

translate russian ch4_exclusive_yuri_3da16ede:
    mc "Шесть стаканов воды..."

translate russian ch4_exclusive_yuri_bead7f72:
    mc "Я мигом."

translate russian ch4_exclusive_yuri_b5bd7011:
    y 1ba "Большое спасибо."

translate russian ch4_exclusive_yuri_1f653764:
    y 2bf "Ах да, воды нужно совсем немного."

translate russian ch4_exclusive_yuri_50bc645c:
    y "Если налить слишком много, краска будет слишком разбавленной."

translate russian ch4_exclusive_yuri_b093d7f5:
    "Следуя совету Юри, я решаю взять маленькие пластиковые стаканчики из ванной вместо обычных стаканов."

translate russian ch4_exclusive_yuri_b961b16f:
    "Я ставлю их на тарелку, чтобы краска не капала куда попало, и несу обратно в комнату."

translate russian ch4_exclusive_yuri_a09b77d5:
    mc "Юри?"

translate russian ch4_exclusive_yuri_b83ad773:
    y "Да?"

translate russian ch4_exclusive_yuri_efc7b6df:
    "Войдя, я вижу, как Юри торопливо раскатывает рукав, натягивая его обратно на руку."

translate russian ch4_exclusive_yuri_ef5f85f4:
    mc "А, ничего..."

translate russian ch4_exclusive_yuri_9fa41e43:
    mc "Ты немного покраснела."

translate russian ch4_exclusive_yuri_675d7d5c:
    mc "Тебе не жарко тут или что-нибудь такое?"

translate russian ch4_exclusive_yuri_2d1d7d7e:
    y 3bq "А—"

translate russian ch4_exclusive_yuri_7a464969:
    y "Нет, совсем нет!"

translate russian ch4_exclusive_yuri_a16ccc28:
    y "Всё в порядке, так что..."

translate russian ch4_exclusive_yuri_db4340a5:
    y "Давай смешаем краски."

translate russian ch4_exclusive_yuri_b0290512:
    "Юри поспешно отмахивается от меня и сама принимается разворачивать таблетки, бросая их в стаканчики."

translate russian ch4_exclusive_yuri_3e4bce89:
    y 1ba "Так что..."

translate russian ch4_exclusive_yuri_b644a548:
    y "Я подумала, что мы сделаем что-нибудь простое, но очень красивое."

translate russian ch4_exclusive_yuri_6b6d95e8:
    y "Я бы хотела нарисовать на растяжке плавный переход цветов..."

translate russian ch4_exclusive_yuri_3f3a93a3:
    y "Начиная с цветов рассвета, потом дня, а потом заката и ночи."

translate russian ch4_exclusive_yuri_7b6ef5bc:
    y "Когда высохнет, я напишу на растяжке вдохновляющую цитату."

translate russian ch4_exclusive_yuri_c969de9e:
    y "Мы повесим её на стену за кафедрой в передней части класса."

translate russian ch4_exclusive_yuri_0e82c4ee:
    mc "А, здорово."

translate russian ch4_exclusive_yuri_e7727079:
    mc "А что ты напишешь?"

translate russian ch4_exclusive_yuri_052e996f:
    y 2bm "Ну..."

translate russian ch4_exclusive_yuri_d95e4e0a:
    y "...Будет интереснее, если это станет для тебя сюрпризом."

translate russian ch4_exclusive_yuri_35fbb699:
    "Юри мне улыбается."

translate russian ch4_exclusive_yuri_0f240219:
    mc "Как скажешь..."

translate russian ch4_exclusive_yuri_197498ac:
    "Развернув растяжку, мы с Юри встаём на колени по разные стороны, чтобы не мешать друг другу."

translate russian ch4_exclusive_yuri_bd5f479c:
    "Юри кисточкой ставит на растяжке несколько точек разного цвета, чтобы мы ориентировались, где какой цвет."

translate russian ch4_exclusive_yuri_16905ab4:
    mc "Это мне немного напоминает начальную школу..."

translate russian ch4_exclusive_yuri_43b22982:
    "Рисовать акварелью на растяжке — очень похоже на поделки на уроках рисования в те времена."

translate russian ch4_exclusive_yuri_a8b0e464:
    "Это успокаивает."

translate russian ch4_exclusive_yuri_728dcbc5_1:
    y "Ах..."

translate russian ch4_exclusive_yuri_56217eb5:
    y "Прости, если это кажется слишком по-детски...!"

translate russian ch4_exclusive_yuri_be62e824:
    mc "Нет, я совсем не это имел в виду."

translate russian ch4_exclusive_yuri_636d9380:
    mc "Это даже весело, понимаешь?"

translate russian ch4_exclusive_yuri_e9a8b6f3:
    y 1bs "...Да."

translate russian ch4_exclusive_yuri_a022de23:
    y "Весело."

translate russian ch4_exclusive_yuri_1dd76b95:
    y "Я рада, что ты тоже так думаешь."

translate russian ch4_exclusive_yuri_d4ca8264:
    "Юри ненадолго перестаёт рисовать и о чём-то задумывается."

translate russian ch4_exclusive_yuri_c2c620fb:
    y 2bl "Мне..."

translate russian ch4_exclusive_yuri_76d4ffa1:
    y "Мне не нужно куда-то ходить и делать что-то безумное, чтобы повеселиться."

translate russian ch4_exclusive_yuri_33388526:
    y "Честно говоря, обычно мне этого даже не хочется."

translate russian ch4_exclusive_yuri_128efca8:
    y 2bf "Мне просто нравится проводить время с одним человеком..."

translate russian ch4_exclusive_yuri_005b197c:
    y "Даже если это что-то простое, вроде чтения, — и неважно, если мы почти не разговариваем."

translate russian ch4_exclusive_yuri_4ed83b82:
    y 2ba "Когда рядом просто есть друг, всё становится чуточку лучше."

translate russian ch4_exclusive_yuri_c3bb862b:
    y "Думаю, мне больше ничего и не нужно, чтобы быть счастливой."

translate russian ch4_exclusive_yuri_85d4ab1c:
    mc "Правда...?"

translate russian ch4_exclusive_yuri_b2a4a3d5:
    "Хоть мы с Юри и довольно разные, я понимаю, о чём она."

translate russian ch4_exclusive_yuri_750d2661:
    "У меня так бывает с аниме и играми: просто разделить их с кем-то — уже радость."

translate russian ch4_exclusive_yuri_d0c830b0:
    mc "Кажется, я чувствую то же самое."

translate russian ch4_exclusive_yuri_f1c99cd9:
    "Юри мягко улыбается."

translate russian ch4_exclusive_yuri_7bceb5ec:
    y 1bm "Я знала, что ты поймёшь..."

translate russian ch4_exclusive_yuri_af179c74:
    "Юри тянется через растяжку за свободной кисточкой."

translate russian ch4_exclusive_yuri_4a901502:
    "Но в этот же момент двигаюсь и я, и мы стукаемся головами."

translate russian ch4_exclusive_yuri_742c38fe:
    y 3bn "Кья—!"

translate russian ch4_exclusive_yuri_c817a551:
    mc "П-прости!"

translate russian ch4_exclusive_yuri_b5ff971c:
    "Юри отшатывается, а я от неожиданности вскидываю руки."

translate russian ch4_exclusive_yuri_a80d2f8a:
    mc "Тебе больно?"

translate russian ch4_exclusive_yuri_fb0e853e:
    y 2bv "Н-нет, не больно."

translate russian ch4_exclusive_yuri_5aa191a8:
    y "Просто испугалась... вот и всё."

translate russian ch4_exclusive_yuri_cb3ad9b3:
    y "Прости, надо было попросить тебя подать..."

translate russian ch4_exclusive_yuri_f2a32672:
    mc "Ты не виновата."

translate russian ch4_exclusive_yuri_25d60f82:
    mc "Ах, твоё лицо..."

translate russian ch4_exclusive_yuri_7127d05f:
    "На лице и шее Юри капли краски."

translate russian ch4_exclusive_yuri_7f5dd1f8:
    y 2bt "У меня что-то на лице?"

translate russian ch4_exclusive_yuri_3f00caef:
    mc "Ага, я случайно забрызгал тебя краской..."

translate russian ch4_exclusive_yuri_83e1a6f7:
    mc "Прости, это целиком моя вина!"

translate russian ch4_exclusive_yuri_cc6a4c18:
    mc "Сейчас принесу полотенце."

translate russian ch4_exclusive_yuri_25041c7e:
    "Я выбегаю за маленьким полотенцем и смачиваю его горячей водой."

translate russian ch4_exclusive_yuri_e1d00546:
    "Вернувшись в комнату, я снова опускаюсь перед ней на колени."

translate russian ch4_exclusive_yuri_c2b67b46:
    mc "Вот..."

translate russian ch4_exclusive_yuri_ee083efd:
    "Я промокаю полотенцем лицо и шею Юри."

translate russian ch4_exclusive_yuri_29a199f7:
    y "А—"

translate russian ch4_exclusive_yuri_34cec937:
    mc "Что-то не так?"

translate russian ch4_exclusive_yuri_1a60c448:
    y "Горячо... я просто не ожидала."

translate russian ch4_exclusive_yuri_4bbe5891:
    mc "Прости..."

translate russian ch4_exclusive_yuri_251373d4:
    mc "Не хотел брать холодную воду."

translate russian ch4_exclusive_yuri_433edcd4:
    "Закончив, я начинаю убирать руку."

translate russian ch4_exclusive_yuri_aacf7734:
    "Но Юри вдруг удерживает моё запястье."

translate russian ch4_exclusive_yuri_1899caaf:
    y "Подожди—"

translate russian ch4_exclusive_yuri_fb2e5377:
    mc "А?"

translate russian ch4_exclusive_yuri_15e02934:
    y "Ещё... совсем чуть-чуть."

translate russian ch4_exclusive_yuri_f820c100:
    y "Это так приятно..."

translate russian ch4_exclusive_yuri_93deaf69_2:
    mc "А..."

translate russian ch4_exclusive_yuri_54dc1c00:
    "Я не убираю руку с шеи Юри."

translate russian ch4_exclusive_yuri_a618dd3d:
    "Она смотрит мне в глаза."

translate russian ch4_exclusive_yuri_52e2ef25:
    "Это то самое напряжённое выражение, которое я узнаю по тому, как она читает свои книги..."

translate russian ch4_exclusive_yuri_ae3cc4b3:
    "Будто она в забытьи, окутанная собственными мыслями."

translate russian ch4_exclusive_yuri_6deb9809:
    "Она мягко дышит сквозь чуть приоткрытые губы."

translate russian ch4_exclusive_yuri_2d899e99:
    "Что происходит...?"

translate russian ch4_exclusive_yuri_45949426:
    "Это от аромата жасминового масла у меня так кружится голова?"

translate russian ch4_exclusive_yuri_3b6aae32:
    "Нежные пальцы Юри, обхватившие моё запястье, посылают по руке покалывание."

translate russian ch4_exclusive_yuri_5d16edad:
    "И вдруг её лицо будто оказывается гораздо ближе к моему, чем мгновение назад..."

translate russian ch4_exclusive_yuri_728dcbc5_2:
    y "Ах..."

translate russian ch4_exclusive_yuri_cda22c45:
    "Юри медленно отстраняется."

translate russian ch4_exclusive_yuri_485fb852:
    y "Прости..."

translate russian ch4_exclusive_yuri_02e9911c:
    y "У меня сегодня немного кружится голова."

translate russian ch4_exclusive_yuri_696c1815:
    y "Я не хотела так задуматься..."

translate russian ch4_exclusive_yuri_f7b2a944:
    mc "Н-ничего страшного..."

translate russian ch4_exclusive_yuri_a7cbdc20:
    "Момент заканчивается так же внезапно, как начался."

translate russian ch4_exclusive_yuri_959427da:
    "Юри снова берёт кисточку."

translate russian ch4_exclusive_yuri_7b6e91a0:
    "Но её движения кажутся неуклюжими, будто она никак не может сосредоточиться."

translate russian ch4_exclusive_yuri_f6454750:
    "Я молчу, вынужденный делать вид, что ничего не произошло."

translate russian ch4_exclusive_yuri_69cc8240:
    "Я нерешительно беру свою кисть и продолжаю следовать примеру Юри."

translate russian ch4_exclusive_yuri_583843dd:
    mc "Вот и всё..."

translate russian ch4_exclusive_yuri_3e5faaa7:
    "Я заканчиваю заполнять ночное небо белыми точками, похожими на звёзды."

translate russian ch4_exclusive_yuri_590b6e62:
    "Если посмотреть на растяжку целиком, она очень красивая и выглядит естественно."

translate russian ch4_exclusive_yuri_cef5aee6:
    y "По-моему, получилось лучше, чем я ожидала."

translate russian ch4_exclusive_yuri_d47ed027:
    y "Я очень довольна результатом."

translate russian ch4_exclusive_yuri_b805585e:
    mc "Ага, я тоже."

translate russian ch4_exclusive_yuri_d10cb133:
    mc "Теперь будешь добавлять надпись?"

translate russian ch4_exclusive_yuri_616184f4:
    y 1bf "Ах, ещё нет..."

translate russian ch4_exclusive_yuri_c9640c73:
    y "Сначала ей нужно высохнуть."

translate russian ch4_exclusive_yuri_af837fea:
    mc "Это правда, но разве это не займёт много времени?"

translate russian ch4_exclusive_yuri_be96fb6c:
    y 2bh "Ну..."

translate russian ch4_exclusive_yuri_58c476fe:
    y "Пожалуй, лучше оставить её здесь, а утром ты её принесёшь."

translate russian ch4_exclusive_yuri_7dcd70d3:
    y 2bf "Надпись я смогу сделать в классе перед началом мероприятия."

translate russian ch4_exclusive_yuri_4f2df90f:
    y "Так можно?"

translate russian ch4_exclusive_yuri_bb362cac:
    mc "Конечно, можно."

translate russian ch4_exclusive_yuri_75243184:
    y 1ba "Чудесно."

translate russian ch4_exclusive_yuri_2f957b61:
    y "В таком случае..."

translate russian ch4_exclusive_yuri_755f06ea:
    y "Думаю, больше нам здесь делать нечего."

translate russian ch4_exclusive_yuri_0c054906:
    mc "Фух."

translate russian ch4_exclusive_yuri_665032ee:
    y 1bc "А-ха-ха."

translate russian ch4_exclusive_yuri_59a18e38:
    y "Ты так говоришь, будто рад, что всё закончилось."

translate russian ch4_exclusive_yuri_a02df21f:
    y 1ba "Неужели я зря думала, что тебе хоть немного понравилось?"

translate russian ch4_exclusive_yuri_ecfaa6be:
    mc "А, нет, дело не в этом."

translate russian ch4_exclusive_yuri_81e8d9b0:
    mc "Я просто рад, что мы всё успели."

translate russian ch4_exclusive_yuri_f02be5f5:
    y 2ba "Понятно."

translate russian ch4_exclusive_yuri_5a91cda4:
    y "Я тоже."

translate russian ch4_exclusive_yuri_b61a45fa:
    y "Я немного беспокоилась насчёт времени..."

translate russian ch4_exclusive_yuri_744cb23b:
    y "Мне скоро нужно начинать готовить ужин."

translate russian ch4_exclusive_yuri_93deaf69_3:
    mc "А..."

translate russian ch4_exclusive_yuri_35d0e327:
    mc "Значит, времени у тебя совсем не осталось?"

translate russian ch4_exclusive_yuri_cf07af8c:
    "Я втайне надеялся, что после работы у нас останется время..."

translate russian ch4_exclusive_yuri_a0913b0a:
    y 2bl "Ну..."

translate russian ch4_exclusive_yuri_71a86863:
    y "..."

translate russian ch4_exclusive_yuri_9e1d344c:
    "Юри задумывается."

translate russian ch4_exclusive_yuri_374f5df8:
    y 3bv "Д-думаю, будет слишком безответственно с моей стороны задерживаться ещё..."

translate russian ch4_exclusive_yuri_6e8213df:
    y "Прости!"

translate russian ch4_exclusive_yuri_14634e1c:
    y "Я тоже надеялась, что времени будет больше..."

translate russian ch4_exclusive_yuri_0bcd6754:
    mc "Наверное, это я виноват."

translate russian ch4_exclusive_yuri_ec3b86ed:
    mc "Прости, что так медленно работаю."

translate russian ch4_exclusive_yuri_2d19a7fc:
    y 1bt "Нет, ты совсем не виноват."

translate russian ch4_exclusive_yuri_b720218b:
    y "И... главное ведь, что мы всё успели, правда?"

translate russian ch4_exclusive_yuri_69c25b65:
    mc "Да..."

translate russian ch4_exclusive_yuri_d6c08456:
    y 1bu "Так что..."

translate russian ch4_exclusive_yuri_86ced03c:
    y "Мне не стоит расстраиваться... или вроде того."

translate russian ch4_exclusive_yuri_8208851f:
    "Собирая вещи, Юри выглядит немного подавленной."

translate russian ch4_exclusive_yuri_de976283:
    "Я понимаю почему."

translate russian ch4_exclusive_yuri_1675b7da:
    "Похоже, ей редко выпадает возможность провести время с друзьями в спокойной обстановке."

translate russian ch4_exclusive_yuri_199cbd75:
    "Но это не значит, что больше такого не повторится..."

translate russian ch4_exclusive_yuri_1c6f46bc:
    "Когда Юри собирается, я провожаю её до двери."

translate russian ch4_exclusive_yuri_e25c257e:
    y "Большое спасибо, что пригласил меня сегодня."

translate russian ch4_exclusive_yuri_63623610:
    mc "Не за что, рад, что смог помочь."

translate russian ch4_exclusive_yuri_58c510ae:
    mc "Просто скажи, если завтра нужно будет принести что-нибудь ещё."

translate russian ch4_exclusive_yuri_2ad5f7b3:
    y "Скажу."

translate russian ch4_exclusive_yuri_4f72802e:
    y 1bu "Что ж, тогда..."

translate russian ch4_exclusive_yuri_b0923a1d:
    "Юри переминается с ноги на ногу."

translate russian ch4_exclusive_yuri_7c27ec04:
    y 2bu "Наверное... увидимся завтра."

translate russian ch4_exclusive_yuri_c67f99c5:
    mc "Подожди—"

translate russian ch4_exclusive_yuri_f08fa8ca:
    "Я говорю это, почти не подумав."

translate russian ch4_exclusive_yuri_2a3db547:
    mc "Насчёт сегодняшнего..."

translate russian ch4_exclusive_yuri_bbce3672:
    mc "Ничего страшного, что у нас было не так много времени, как хотелось."

translate russian ch4_exclusive_yuri_3cb990e3:
    mc "Потому что мы можем повторить."

translate russian ch4_exclusive_yuri_cb29463d:
    mc "Когда захочешь, можешь прийти ко мне, или сходим куда-нибудь—"

translate russian ch4_exclusive_yuri_a7d20c81:
    mc "А, я забыл, что ты не очень любишь куда-то ходить—"

translate russian ch4_exclusive_yuri_dc020e04:
    "Пока я путаюсь в словах, Юри просто смущённо улыбается."

translate russian ch4_exclusive_yuri_7e00e9ab:
    mc "Как бы то ни было..."

translate russian ch4_exclusive_yuri_91094ce1:
    mc "Ты понимаешь, что я пытаюсь сказать, так что..."

translate russian ch4_exclusive_yuri_9a0eedea:
    y 1bs "Ты очень заботливый, [player]."

translate russian ch4_exclusive_yuri_d2dbb876:
    "Юри делает шаг ко мне и ненадолго сжимает мою руку."

translate russian ch4_exclusive_yuri_c7ffdf05:
    y "Мне это в тебе вроде как нравится..."

translate russian ch4_exclusive_yuri_c14c584c:
    mc "Ну..."

translate russian ch4_exclusive_yuri_97034e8b:
    "И что мне на это ответить?"

translate russian ch4_exclusive_yuri_078f3436:
    "Но я не успеваю даже этого сделать — Юри вдруг отстраняется."

translate russian ch4_exclusive_yuri_d42c29c3:
    y "С-Сайори—?"

translate russian ch4_exclusive_yuri_af40f385:
    mc "Что?!"

translate russian ch4_exclusive_yuri_699ac020:
    s "Ах..."

translate russian ch4_exclusive_yuri_072fe968:
    s "П-привет, [player]..."

translate russian ch4_exclusive_yuri_48d5b9aa:
    mc "Сайори—!"

translate russian ch4_exclusive_yuri_5f437551:
    mc "Мы только что не—"

translate russian ch4_exclusive_yuri_67281b29:
    s 1bq "Э-хе-хе~"

translate russian ch4_exclusive_yuri_9751c7af:
    s "Всё в порядке, [player]."

translate russian ch4_exclusive_yuri_22ed0333:
    s 1ba "Я просто зашла поздороваться~"

translate russian ch4_exclusive_yuri_ce43ac16:
    y 3bq "Э-э..."

translate russian ch4_exclusive_yuri_15104c6c:
    y "Что ж, рада тебя видеть..."

translate russian ch4_exclusive_yuri_1c747780:
    y 3bv "Прости, но я уже ухожу!"

translate russian ch4_exclusive_yuri_2b79f5e2:
    s 1bh "Ой, правда?"

translate russian ch4_exclusive_yuri_99f9ae0f:
    s "Жалко..."

translate russian ch4_exclusive_yuri_8e9bd95d:
    y 2bt "Прости..."

translate russian ch4_exclusive_yuri_dc3a9a87:
    y "Но завтра на фестивале мы все будем вместе, так что..."

translate russian ch4_exclusive_yuri_2fc13e16:
    y "Так что всё хорошо, правда?"

translate russian ch4_exclusive_yuri_518ab1c0:
    s 4bq "Конечно!"

translate russian ch4_exclusive_yuri_d9a63191:
    "Сайори сияет."

translate russian ch4_exclusive_yuri_f91d45b5:
    y 4bc "Д-да, так что..."

translate russian ch4_exclusive_yuri_86e212e0:
    y "Увидимся завтра!"

translate russian ch4_exclusive_yuri_ee33e5eb:
    "Явно смутившись, Юри поспешно уходит."

translate russian ch4_exclusive_yuri_69c28b16:
    "Сайори машет ей вслед."

translate russian ch4_end_4de86fac:
    mc "Сайори—"

translate russian ch4_end_df916532:
    mc "Я думал, ты не хотела сегодня приходить!"

translate russian ch4_end_0bce81b2:
    s 2bl "А-ха-ха, ну..."

translate russian ch4_end_c25ef746:
    s "Я пыталась сидеть у себя в комнате..."

translate russian ch4_end_dbf79f14:
    s "Но моё воображение было ко мне очень жестоко..."

translate russian ch4_end_970496bc:
    s 1by "Так что мне пришлось прийти и увидеть всё своими глазами."

translate russian ch4_end_7b59bc97:
    mc "Увидеть что?"

translate russian ch4_end_3d996037:
    mc "О чём ты говоришь?"

translate russian ch4_end_f8ac1185:
    s "Знаешь..."

translate russian ch4_end_e9eaa5d7:
    s "Как тебе весело с [ch4_name!t]."

translate russian ch4_end_2ce2e237:
    s "И как ты с ней сблизился."

translate russian ch4_end_bcdea329:
    s 1bt "Это меня... очень радует..."

translate russian ch4_end_de92f417:
    s "Что у тебя появились такие хорошие друзья."

translate russian ch4_end_194142fb:
    s "Для меня только это и важно."

translate russian ch4_end_d97a01d7:
    "По лицу Сайори начинают катиться слёзы."

translate russian ch4_end_bedd3333:
    s 4bv "Только это для меня и важно—!"

translate russian ch4_end_cfa94369:
    s "Почему мне так плохо, [player]?"

translate russian ch4_end_c4296c1b:
    s "Я должна за тебя радоваться."

translate russian ch4_end_94ef81d5:
    s 4bw "Почему мне кажется, что моё сердце разрывается пополам?"

translate russian ch4_end_62fe0236:
    s "Мне так больно..."

translate russian ch4_end_f290081d:
    s "Всё так больно..."

translate russian ch4_end_a6de14fb:
    s "Было бы гораздо лучше, если бы я могла просто исчезнуть!"

translate russian ch4_end_9d6ea3d7:
    mc "Сайори, не говори так!"

translate russian ch4_end_024365d0:
    s 1bw "Это правда, [player]!"

translate russian ch4_end_4e3bfbbd:
    s "Если бы меня не было, тебе не пришлось бы тратить на меня своё сочувствие!"

translate russian ch4_end_e8ab76f3:
    s "Тебе не пришлось бы терпеть мой эгоизм!"

translate russian ch4_end_bb805239:
    s 1bv "Моника была права..."

translate russian ch4_end_427d4d4f:
    s "Мне стоит просто..."

translate russian ch4_end_bddde58a:
    mc "Моника...?"

translate russian ch4_end_c7aa397f:
    mc "В чём Моника была права?"

translate russian ch4_end_e1554201:
    s "..."

translate russian ch4_end_e87e0575:
    mc "Сайори..."

translate russian ch4_end_afb11ffe:
    mc "То, что я сказал раньше, — правда."

translate russian ch4_end_35fc502b:
    mc "Я не позволю этому продолжаться."

translate russian ch4_end_993d9b77:
    mc "Заботиться о тебе вот так — вовсе не бремя, как кажется твоему разуму."

translate russian ch4_end_adc9cfd4:
    mc "Это делает меня счастливым."

translate russian ch4_end_4516b61a:
    mc "Я бы ни на что это не променял."

translate russian ch4_end_900cd81d:
    mc "Так что, даже если на это уйдёт целая жизнь..."

translate russian ch4_end_ad66a1ec:
    mc "Я буду рядом с тобой, пока тебе не перестанет быть больно."

translate russian ch4_end_023a56fd:
    s 1bk "Н-но..."

translate russian ch4_end_6d934958:
    "Сайори отводит взгляд."

translate russian ch4_end_77065901:
    "Я кладу руку ей на плечо, чтобы успокоить."

translate russian ch4_end_603c500f:
    s "Мне страшно, [player]..."

translate russian ch4_end_16db0b05:
    s "Мне правда страшно..."

translate russian ch4_end_8409288d:
    mc "Чего ты боишься, Сайори?"

translate russian ch4_end_5dfc374d:
    s "Я боюсь, что..."

translate russian ch4_end_6c58de13:
    s "Что ты мне нравишься больше, чем я тебе..."

translate russian ch4_end_e47a0e88:
    mc "Сайори...?"

translate russian ch4_end_4ef04544:
    s 1bu "Это ведь правда, да?"

translate russian ch4_end_6b326e2a:
    s "Я была слабой, и ты начал мне слишком сильно нравиться..."

translate russian ch4_end_1ba21a6b:
    s "Я сама с собой это сделала."

translate russian ch4_end_23d81314:
    s "[player]..."

translate russian ch4_end_8572b749:
    s 4bw "Ты мне нравишься так сильно, что я хочу умереть!"

translate russian ch4_end_bf0be665:
    s "Вот что я чувствую!"

translate russian ch4_end_b87cca3d:
    s 2bv "И... и..."

translate russian ch4_end_383cba1a:
    mc "Хватит, Сайори..."

translate russian ch4_end_567e006f:
    mc "Я не хочу, чтобы тебе было больно."

translate russian ch4_end_d7bdc27f:
    "Я провожу рукой вниз по руке Сайори и крепко сжимаю её ладонь в своей."

translate russian ch4_end_f9dd9070:
    mc "Помнишь, я говорил, что всегда знаю, что для тебя лучше?"

translate russian ch4_end_defb8343:
    mc "Ты всё ещё мне веришь?"

translate russian ch4_end_0bd652ae:
    "Не говоря ни слова, Сайори кивает."

translate russian ch4_end_d2730f55:
    mc "Даже если ты не понимаешь всех своих чувств..."

translate russian ch4_end_da690006:
    mc "Я знаю, что тебе сейчас нужнее всего."

translate russian ch4_end_a5170f2a:
    mc "И именно это я тебе и дам."

translate russian ch4_end_de85ad1e:
    mc "Сайори..." nointeract

translate russian ch4_end_yes_83078e78:
    mc "Я люблю тебя."

translate russian ch4_end_yes_f9bfb0cf:
    s 1bv "А—?"

translate russian ch4_end_yes_3f6fa605:
    mc "Это мои настоящие чувства."

translate russian ch4_end_yes_84e0711b:
    mc "Так что... не может быть, чтобы я нравился тебе больше, чем ты мне."

translate russian ch4_end_yes_b11ca010:
    mc "Мне следовало понять это раньше."

translate russian ch4_end_yes_40679d50:
    mc "Но время со всеми в клубе..."

translate russian ch4_end_yes_67dbd20b:
    mc "Новые друзья..."

translate russian ch4_end_yes_1aaef2aa:
    mc "И то, как весело мне с тобой каждый день..."

translate russian ch4_end_yes_3754c335:
    mc "Всё это помогло мне понять, что ты по-настоящему самый важный для меня человек."

translate russian ch4_end_yes_508a8705:
    mc "Поэтому я приму на себя любое твоё бремя."

translate russian ch4_end_yes_f5a02ccd:
    mc "Если мы и дальше будем вот так, каждый день..."

translate russian ch4_end_yes_21a8946c:
    mc "Если ты будешь рядом..."

translate russian ch4_end_yes_0990f254:
    mc "Я знаю, что мы оба будем счастливы."

translate russian ch4_end_yes_23d81314:
    s "[player]..."

translate russian ch4_end_yes_7ba6830c:
    "Вдруг Сайори крепко обнимает меня."

translate russian ch4_end_yes_23d81314_1:
    s "[player]..."

translate russian ch4_end_yes_3b2bb07f:
    s "Это... правда можно?"

translate russian ch4_end_yes_cf1adef2:
    mc "Ага."

translate russian ch4_end_yes_d973c87e:
    "Я обнимаю Сайори и прижимаю её к себе."

translate russian ch4_end_yes_bf41ee51:
    mc "Тебе больше никогда не придётся меня отпускать."

translate russian ch4_end_yes_bba6c2d7:
    s "Я люблю тебя, [player]..."

translate russian ch4_end_yes_10e33d1c:
    s "Я хочу быть с тобой всегда."

translate russian ch4_end_yes_74fc6761:
    mc "Я тоже."

translate russian ch4_end_yes_e1554201:
    s "..."

translate russian ch4_end_yes_e67a2c76:
    "Я чувствую, как Сайори чуть ослабляет объятия."

translate russian ch4_end_yes_266d53d4:
    s "Что это такое...?"

translate russian ch4_end_yes_e47a0e88:
    mc "Сайори...?"

translate russian ch4_end_yes_109fac18:
    s "Я должна быть сейчас счастлива..."

translate russian ch4_end_yes_811b499c:
    s "Я всегда думала, что это будет самый счастливый момент в моей жизни."

translate russian ch4_end_yes_803e98ac:
    s "Но почему...?"

translate russian ch4_end_yes_3a2816bf:
    s "Даже сейчас..."

translate russian ch4_end_yes_09006ed7:
    s "Почему тучи никак не уходят?"

translate russian ch4_end_yes_5a1d692d:
    s "Они совсем не уходят, [player]..."

translate russian ch4_end_yes_36006ded:
    mc "Всё хорошо, Сайори..."

translate russian ch4_end_yes_79850a2c:
    mc "Может, пройдёт какое-то время, прежде чем станет лучше."

translate russian ch4_end_yes_2a878fb9:
    mc "Но сколько бы времени ни понадобилось, я буду рядом на каждом шагу."

translate russian ch4_end_yes_8b750c8d:
    mc "Сейчас только это и важно."

translate russian ch4_end_yes_7b5965f1:
    s "Л-ладно..."

translate russian ch4_end_yes_bc184ea0:
    s "Я... тебе доверяю..."

translate russian ch4_end_yes_ec058507:
    "Мы с Сайори медленно отпускаем друг друга."

translate russian ch4_end_yes_cb70afb1:
    mc "Так..."

translate russian ch4_end_yes_f058e20c:
    mc "Получается, завтрашний фестиваль... наше первое свидание, да?"

translate russian ch4_end_yes_b9a04fb1:
    s 1by "Э-хе-хе..."

translate russian ch4_end_yes_0f5823ae:
    s "Что ты такое говоришь?"

translate russian ch4_end_yes_52d72f09:
    s "Знаешь, я не хочу думать о таких вещах."

translate russian ch4_end_yes_40a16c23:
    s "Я хочу, чтобы всё было так же, как всегда."

translate russian ch4_end_yes_9822b35c:
    s "Даже если мы теперь правда... пара."

translate russian ch4_end_yes_3ce214b1:
    s 1bk "Не знаю, выдержу ли я сейчас что-то большее..."

translate russian ch4_end_yes_19ef9669:
    s "Для меня это так ново и страшно."

translate russian ch4_end_yes_83495ed0:
    mc "Понимаю."

translate russian ch4_end_yes_1492490d:
    mc "Мы будем двигаться в том темпе, который тебе удобнее."

translate russian ch4_end_yes_2e2ce76f:
    s 1bd "Эй, [player]..."

translate russian ch4_end_yes_0d32bf5f:
    "Сайори снова смотрит на меня с грустной улыбкой."

translate russian ch4_end_yes_0c1e31e7:
    s 4bd "Даже если мне станет очень-очень грустно..."

translate russian ch4_end_yes_8d244423:
    s "Для меня так будет лучше всего... правда?"

translate russian ch4_end_yes_bbe4458e:
    mc "А...?"

translate russian ch4_end_yes_fce3df4a:
    "Я не совсем понимаю, что Сайори имеет в виду."

translate russian ch4_end_yes_c0973791:
    mc "Ты хочешь сказать, что тебе от этого грустно, Сайори?"

translate russian ch4_end_yes_26ee72dd:
    s 4bk "Я-я не знаю..."

translate russian ch4_end_yes_287aec75:
    s "Я не понимаю, что чувствую."

translate russian ch4_end_yes_86c2ab05:
    s "Когда ты сказал, что любишь меня, это было как ворох шипов..."

translate russian ch4_end_yes_fe6c5884:
    s 4bd "Но поэтому я и хочу тебе доверять."

translate russian ch4_end_yes_ee4b3dd5:
    s "Ты знаешь, что для меня лучше..."

translate russian ch4_end_yes_c300082f:
    mc "...Да."

translate russian ch4_end_yes_2f068911:
    mc "Знаю."

translate russian ch4_end_yes_34b15363:
    mc "Обещаю."

translate russian ch4_end_yes_e0770fb6:
    "Я говорю это, но на самом деле никогда ещё не чувствовал себя таким неуверенным во всём, что касается Сайори."

translate russian ch4_end_yes_b6452473:
    "Я знаю, что люблю её, а она любит меня."

translate russian ch4_end_yes_99473e83:
    "Но мне так же трудно понять её чувства, как и ей самой."

translate russian ch4_end_yes_ffcb0f03:
    "Хоть я и могу её утешить..."

translate russian ch4_end_yes_bab55e01:
    "Я всё думаю, не нужно ли сделать что-то ещё или что-то иначе."

translate russian ch4_end_yes_b95f6d49:
    "Я знаю, что эти мысли будут терзать меня, пока всё не станет как прежде."

translate russian ch4_end_yes_9483036d:
    "Может, это и имела в виду Сайори, когда говорила, что не хочет перемен?"

translate russian ch4_end_yes_2293b91e:
    "Не знаю."

translate russian ch4_end_yes_86de2ac6:
    "Но я знаю, что отдам этому все силы."

translate russian ch4_end_yes_f49a39d3:
    "Сайори — самый важный для меня человек."

translate russian ch4_end_yes_ddcb853c:
    "И я сделаю всё, чтобы у нас с ней было счастливое будущее."

translate russian ch4_end_no_4c148b7a:
    mc "Ты всегда будешь моим самым дорогим другом."

translate russian ch4_end_no_cd67955e:
    mc "Больше всего тебе нужно, чтобы всё было так, как всегда."

translate russian ch4_end_no_6a30cffc:
    mc "Моника рассказала мне правду..."

translate russian ch4_end_no_0485d968:
    mc "Она рассказала, насколько счастливее ты стала, когда я вступил в клуб."

translate russian ch4_end_no_375b4bd3:
    mc "Я знаю, что сейчас ты борешься с очень тяжёлыми чувствами."

translate russian ch4_end_no_fc896afd:
    mc "Но..."

translate russian ch4_end_no_d5019172:
    mc "Пожалуйста, поверь, что я знаю, как будет лучше... и что в итоге сделает тебя счастливой."

translate russian ch4_end_no_25a0a921:
    mc "Обещаю, я помогу всё вернуть на свои места."

translate russian ch4_end_no_3a34a450:
    s 1bt "Я..."

translate russian ch4_end_no_4fdffb7a:
    s "Я... понимаю..."

translate russian ch4_end_no_b6ee3cde:
    "Сайори через силу улыбается, хотя на её лице написана невыносимая боль."

translate russian ch4_end_no_81d59952:
    s "А-ха-ха..."

translate russian ch4_end_no_42c2abdb:
    s "Вот, значит, каково это... когда тебя пронзают в грудь?"

translate russian ch4_end_no_1086f675:
    s "Надо написать об этом стихотворение..."

translate russian ch4_end_no_4de86fac:
    mc "Сайори—"

translate russian ch4_end_no_61c2e6b9:
    s "Всё хорошо."

translate russian ch4_end_no_e2ef34df:
    s "Это ведь просто моё наказание... помнишь?"

translate russian ch4_end_no_8d07612f:
    s "За то, что я такая эгоистка..."

translate russian ch4_end_no_0e428635:
    s "Так что, пожалуйста..."

translate russian ch4_end_no_669dcae2:
    s "Пожалуйста, не переживай из-за этих глупых чувств."

translate russian ch4_end_no_401919cf:
    s "Я знаю, что ты прав."

translate russian ch4_end_no_180b42cc:
    s "Я всё это время знала, что на этом пути нет счастья."

translate russian ch4_end_no_481e25e6:
    s "Поэтому я и пришла сюда..."

translate russian ch4_end_no_dc07545e:
    s "Только чтобы услышать ответ, который мне нужно было услышать."

translate russian ch4_end_no_cd91ef23:
    s "И ещё..."

translate russian ch4_end_no_994ef067:
    s "Ты прав и в том, что я просто хочу, чтобы всё стало как раньше."

translate russian ch4_end_no_8b6ae30d:
    s "Теперь я это понимаю."

translate russian ch4_end_no_b2660ed8:
    s "Ты и правда знаешь меня лучше всех, [player]."

translate russian ch4_end_no_983d37bf:
    s 4bv "Я доверю тебе что угодно..."

translate russian ch4_end_no_798f1447:
    s "Абсолютно что угодно..."

translate russian ch4_end_no_87038562:
    s "Так что..."

translate russian ch4_end_no_f7da56a2:
    "Улыбка Сайори наконец ломается."

translate russian ch4_end_no_5cfbaaf6:
    "Вдруг она отворачивается и падает на колени."

translate russian ch4_end_no_afb35a0b:
    s "{i}А-А-А-А-А-а-а-а-А-А-А-А-А-А-А-А-Х!!!!{/i}"

translate russian ch4_end_no_8de5cc24:
    "Схватившись обеими руками за голову, она кричит изо всех сил."

translate russian ch4_end_no_d91df51b:
    "Я так потрясён, что не знаю, как реагировать."

translate russian ch4_end_no_e1554201:
    s "..."

translate russian ch4_end_no_94733a37:
    "Сайори оглядывается через плечо, ещё раз слабо мне улыбается, а потом разворачивается и убегает."

translate russian ch4_end_no_ce62c226:
    mc "Сайори!"

translate russian ch4_end_no_a20cefa7:
    "..."

translate russian ch4_end_no_283d82a4:
    "Я остаюсь беспомощно стоять перед своим домом."

translate russian ch4_end_no_a725921f:
    "Почему мне от этого так паршиво?"

translate russian ch4_end_no_62f60545:
    "Больше я ничего не мог сделать."

translate russian ch4_end_no_ff0adde9:
    "Самое большее, что я могу, — поддерживать Сайори в её чувствах и помогать ей на правильном пути."

translate russian ch4_end_no_99473e83:
    "Но мне так же трудно понять её чувства, как и ей самой."

translate russian ch4_end_no_ffcb0f03:
    "Хоть я и могу её утешить..."

translate russian ch4_end_no_bab55e01:
    "Я всё думаю, не нужно ли сделать что-то ещё или что-то иначе."

translate russian ch4_end_no_b95f6d49:
    "Я знаю, что эти мысли будут терзать меня, пока всё не станет как прежде."

translate russian ch4_end_no_465abfd3:
    "Я отдам этому все силы."

translate russian ch4_end_no_da44e641:
    "Сайори всегда будет моим самым дорогим другом."

translate russian ch4_end_no_fbc6196a:
    "И я сделаю всё, чтобы она улыбалась каждый день."
