# Русский перевод: script-ch0

translate russian ch0_main_41e273ca:
    s "Приве-е-е-е-ет!!"

translate russian ch0_main_bcc5bb00:
    "Я вижу, как издалека ко мне несётся какая-то надоедливая девчонка и машет руками так, будто ей совершенно всё равно, сколько внимания она к себе привлекает."

translate russian ch0_main_80f1ba46:
    "Эта девчонка — Сайори, моя соседка и хорошая подруга с самого детства."

translate russian ch0_main_40dc33e4:
    "Ну, знаете, такой друг, с которым сейчас ты бы ни за что не сошёлся, но всё как-то складывается само собой, потому что вы знакомы сто лет."

translate russian ch0_main_fc8dd6bc:
    "Раньше в такие дни мы ходили в школу вместе, но где-то со старших классов она стала всё чаще просыпать, и мне надоело её ждать."

translate russian ch0_main_0117e949:
    "Но если она собирается вот так за мной гоняться, то, пожалуй, лучше было бы убежать."

translate russian ch0_main_a0aaf316:
    "Но вместо этого я лишь вздыхаю, останавливаюсь у пешеходного перехода и жду, пока Сайори меня догонит."

translate russian ch0_main_cf958be9:
    s 4p "Ха-а-а... ха-а-а..."

translate russian ch0_main_d5b6fac2:
    s "Я опять проспала!"

translate russian ch0_main_7fa78c9d:
    s "Но в этот раз я тебя догнала!"

translate russian ch0_main_164efad7:
    mc "Может быть, но только потому, что я сам решил остановиться и подождать тебя."

translate russian ch0_main_426a9522:
    s 5c "Э-э-э-э, ты так говоришь, будто собирался меня проигнорировать!"

translate russian ch0_main_15216994:
    s "Как не стыдно, [player]!"

translate russian ch0_main_b13a945b:
    mc "Ну, если на тебя будут пялиться за то, что ты чудишь, я не хочу, чтобы все подумали, будто мы парочка или что-то в этом роде."

translate russian ch0_main_5d016585:
    s 1a "Ладно, ладно."

translate russian ch0_main_636f00f3:
    s "Но ты ведь всё-таки меня подождал."

translate russian ch0_main_2640e984:
    s "Наверное, ты просто не умеешь быть злым, даже если очень хочешь~"

translate russian ch0_main_ff65683d:
    mc "Как скажешь, Сайори..."

translate russian ch0_main_4fe8273d:
    s 1q "Э-хе-хе~"

translate russian ch0_main_f870d325:
    "Мы вместе переходим улицу и направляемся к школе."

translate russian ch0_main_6fc63fca:
    "Чем ближе мы подходим, тем больше на улицах других учеников, спешащих на занятия."

translate russian ch0_main_3142c5a4:
    s "Кстати, [player]..."

translate russian ch0_main_02182e1b:
    s "Ты уже решил, в какой клуб вступишь?"

translate russian ch0_main_0855e33f:
    mc "В клуб?"

translate russian ch0_main_514f6cec:
    mc "Я же тебе говорил: мне совершенно не интересно вступать ни в какие клубы."

translate russian ch0_main_57434f02:
    mc "Да я и не искал."

translate russian ch0_main_510bdda9:
    s 4h "А? Неправда!"

translate russian ch0_main_dc11d283:
    s "Ты сам мне сказал, что в этом году вступишь в клуб!"

translate russian ch0_main_92f7a5c6:
    mc "Я такое говорил...?"

translate russian ch0_main_2317207b:
    "Вполне возможно, что и говорил — в одном из наших бесчисленных разговоров, когда я рассеянно поддакиваю всему, о чём она там тараторит."

translate russian ch0_main_988d7054:
    "Сайори слишком уж любит за меня переживать, хотя меня вполне устраивает быть середнячком, а свободное время тратить на игры и аниме."

translate russian ch0_main_06a80352:
    s 4j "Ага!"

translate russian ch0_main_b2ade169:
    s "Я говорила, что боюсь, как бы ты не дожил до университета, так и не научившись общаться с людьми и вообще ничего не умея."

translate russian ch0_main_61fb4fdb:
    s "Знаешь, твоё счастье очень для меня важно!"

translate russian ch0_main_12a3f20b:
    s "Я знаю, что сейчас ты счастлив, но я умру, если через пару лет ты станешь безработным хикикомори, потому что не привык к настоящей жизни!"

translate russian ch0_main_0df692b5:
    s 4g "Ты же мне доверяешь, правда?"

translate russian ch0_main_9985ba2f:
    s "Не заставляй меня и дальше за тебя волноваться..."

translate russian ch0_main_62185db9:
    mc "Ладно, ладно..."

translate russian ch0_main_a240cafd:
    mc "Посмотрю пару клубов, раз тебя это порадует."

translate russian ch0_main_a6395f5e:
    mc "Но ничего не обещаю."

translate russian ch0_main_4320f887:
    s 1h "А хотя бы пообещаешь, что немножко постараешься?"

translate russian ch0_main_185b43a6:
    mc "Ну да, это, пожалуй, пообещать могу."

translate russian ch0_main_3c2076a4:
    s 4r "Ура-а~!"

translate russian ch0_main_0ec84410:
    "И почему я позволяю такой беззаботной девчонке читать мне нотации?"

translate russian ch0_main_427c8d3d:
    "А ещё больше меня удивляет, что я ей уступил."

translate russian ch0_main_86001771:
    "Наверное, когда я вижу, как сильно она за меня переживает, мне хочется хоть немного её успокоить — даже если у себя в голове она всё раздувает."

translate russian ch0_main_d234f771:
    "Учебный день проходит как обычно и заканчивается прежде, чем я успеваю это заметить."

translate russian ch0_main_7a46ab7f:
    "Собрав вещи, я тупо смотрю в стену в поисках хоть капли мотивации."

translate russian ch0_main_64e92eab:
    mc "Клубы..."

translate russian ch0_main_71ad5d38:
    "Сайори хочет, чтобы я посмотрел какие-нибудь клубы."

translate russian ch0_main_aded22ad:
    "Похоже, выбора нет — начну с аниме-клуба..."

translate russian ch0_main_fb713b14:
    s "Ау-у-у?"

translate russian ch0_main_e47a0e88:
    mc "Сайори...?"

translate russian ch0_main_6020da7f:
    "Видимо, Сайори зашла в класс, пока я витал в облаках."

translate russian ch0_main_1990352b:
    "Я оглядываюсь и понимаю, что в классе больше никого не осталось."

translate russian ch0_main_dedd63de:
    s 1a "Я думала перехватить тебя на выходе, а потом увидела, что ты просто сидишь тут и витаешь в облаках, вот и зашла."

translate russian ch0_main_7615d8d6:
    s "Честное слово, иногда ты даже хуже меня... Я впечатлена!"

translate russian ch0_main_6d733c80:
    mc "Не надо меня ждать, если из-за этого ты опоздаешь в свой же клуб."

translate russian ch0_main_9d8de398:
    s 1y "Ну, я подумала, что тебе не помешает поддержка, вот и решила, ну, понимаешь..."

translate russian ch0_main_200708b1:
    mc "Что понимаю?"

translate russian ch0_main_e745591c:
    s 1a "Ну, что ты мог бы прийти в мой клуб!"

translate russian ch0_main_e87e0575:
    mc "Сайори..."

translate russian ch0_main_863b15e1:
    s 4r "Да-а??"

translate russian ch0_main_3b777b8d:
    mc "...Ни за что на свете я не пойду в твой клуб."

translate russian ch0_main_f92ba1b1:
    s 5d "Э-э-э-э?! Вредина!"

translate russian ch0_main_24c0c28c:
    "Сайори — вице-президент Литературного клуба."

translate russian ch0_main_3b431c20:
    "Не то чтобы я вообще подозревал, что её интересует литература."

translate russian ch0_main_a89001e9:
    "Если честно, я на 99%% уверен, что она пошла туда только потому, что ей показалось весело помочь открыть новый клуб."

translate russian ch0_main_bf60a48d:
    "Раз уж она первой откликнулась после того, кто предложил создать клуб, ей и достался титул «вице-президента»."

translate russian ch0_main_dad2209a:
    "Впрочем, мой интерес к литературе наверняка ещё меньше."

translate russian ch0_main_67a570cc:
    mc "Ага. Я иду в аниме-клуб."

translate russian ch0_main_e9fc337c:
    s 1g "Ну пожа-а-алуйста!"

translate russian ch0_main_a2239a0d:
    mc "И вообще, почему тебе это так важно?"

translate russian ch0_main_d39dce85:
    s 5b "Ну..."

translate russian ch0_main_d72b517e:
    s "Я вроде как вчера пообещала клубу, что приведу нового участника..."

translate russian ch0_main_dc74dc48:
    s "А Нацуки испекла капкейки и всё такое..."

translate russian ch0_main_cc3db8cd:
    s "Э-хе-хе..."

translate russian ch0_main_e05adf1b:
    mc "Не обещай того, чего не можешь выполнить!"

translate russian ch0_main_cc62f8f9:
    "Никак не пойму: Сайори и правда такая простушка или настолько хитрая, что спланировала всё это заранее?"

translate russian ch0_main_d02635ba:
    "Я протяжно вздыхаю."

translate russian ch0_main_09810a2c:
    mc "Ладно... Зайду ради капкейка, идёт?"

translate russian ch0_main_56df6485:
    s 4r "Да! Пошли~!"

translate russian ch0_main_d005514b:
    "Вот так этот день и стал днём, когда я продал душу за капкейк."

translate russian ch0_main_cb634d94:
    "Я уныло плетусь за Сайори через всю школу и поднимаюсь наверх — в ту часть здания, где почти не бываю: там в основном проходят занятия и мероприятия выпускных классов."

translate russian ch0_main_01a899d9:
    "Сайори, полная энергии, распахивает дверь класса."

translate russian ch0_main_fcd53725:
    s "Все сюда! Новый участник пришёл~!"

translate russian ch0_main_a17485df:
    mc "Я же просил не называть меня „новым участ—“"

translate russian ch0_main_6c94972f:
    "А? Я оглядываю комнату."

translate russian ch0_main_0a3aa08f:
    y "Добро пожаловать в Литературный клуб. Рада познакомиться."

translate russian ch0_main_3c9be08b:
    y "Сайори всегда так хорошо о тебе отзывается."

translate russian ch0_main_cc7dab55:
    n "Серьёзно? Ты привела парня?"

translate russian ch0_main_2bfb1f2f:
    n "Вся атмосфера насмарку."

translate russian ch0_main_bf1dc1a1:
    m "А, [player]! Какой приятный сюрприз!"

translate russian ch0_main_d4348f02:
    m "Добро пожаловать в клуб!"

translate russian ch0_main_2b35b6fe:
    mc "..."

translate russian ch0_main_00244a6d:
    "В такой ситуации у меня просто нет слов."

translate russian ch0_main_7903e6e7:
    "Этот клуб..."

translate russian ch0_main_4c13a14b:
    "{i}...полон невероятно милых девушек!!{/i}"

translate russian ch0_main_b2022684:
    n 2c "Чего уставился?"

translate russian ch0_main_89e5120b:
    n "Хочешь что-то сказать — говори."

translate russian ch0_main_6cbd4647:
    mc "П-прости..."

translate russian ch0_main_98d9573e:
    y "Нацуки..."

translate russian ch0_main_bc64dbb8:
    n 5s "Хмф."

translate russian ch0_main_3b270b09:
    "Девчонку с кислой миной — видимо, её зовут Нацуки — я раньше не встречал."

translate russian ch0_main_5e0f976f:
    "Судя по её миниатюрной фигуре, она, наверное, первогодка."

translate russian ch0_main_6627708c:
    "А ещё, если верить Сайори, это она испекла капкейки."

translate russian ch0_main_50a3834f:
    s "Не обращай на неё внимания, когда она не в духе~"

translate russian ch0_main_f4b3e5d1:
    "Сайори шепчет это мне на ухо и снова поворачивается к остальным."

translate russian ch0_main_f72302c8:
    s 1x "Итак! Это Нацуки, она всегда полна энергии."

translate russian ch0_main_77201e52:
    s "А это Юри, самая умная в клубе!"

translate russian ch0_main_084001f0:
    y 4b "Н-не говори так..."

translate russian ch0_main_4ccfaeda:
    "Юри выглядит заметно взрослее и застенчивее и, похоже, с трудом поспевает за такими, как Сайори и Нацуки."

translate russian ch0_main_13900021:
    mc "А... Ну, приятно познакомиться с вами обеими."

translate russian ch0_main_34c0c312:
    s 1a "А Монику ты, кажется, уже знаешь, да?"

translate russian ch0_main_857b34c3:
    m "Верно."

translate russian ch0_main_3573b794:
    m "Рада снова тебя видеть, [player]."

translate russian ch0_main_3049c3ae:
    "Моника мило улыбается."

translate russian ch0_main_7c7cb783:
    "Мы и правда знакомы — ну, почти не разговаривали, но в прошлом году учились в одном классе."

translate russian ch0_main_f583350f:
    "Моника была, пожалуй, самой популярной девчонкой в классе — умная, красивая, спортивная."

translate russian ch0_main_e3e8565d:
    "Короче говоря, совершенно не моего полёта птица."

translate russian ch0_main_f83977c1:
    "Поэтому, когда она так искренне мне улыбается, мне становится немного..."

translate russian ch0_main_dffc1ef1:
    mc "Я т-тоже рад, Моника."

translate russian ch0_main_5ade5cd5:
    s 4x "Садись, [player]! Мы освободили тебе место за столом, так что можешь сесть рядом со мной или с Моникой."

translate russian ch0_main_8b8dbdb6:
    s "Я принесу капкейки~"

translate russian ch0_main_7dba2d0b:
    n "Эй! Я их пекла, я и принесу!"

translate russian ch0_main_0d2a5328:
    s 5a "Прости, я немножко увлеклась~"

translate russian ch0_main_4c9bc219:
    y "Тогда, может, я заварю чаю?"

translate russian ch0_main_9f8ec8cb:
    "Девушки сдвинули несколько парт, чтобы получился стол."

translate russian ch0_main_8c49885c:
    "Как и сказала Сайори, его расширили так, что одно место есть рядом с Моникой, а другое — рядом с Сайори."

translate russian ch0_main_dd182ef4:
    "Нацуки и Юри идут в угол комнаты: Нацуки берёт накрытый поднос, а Юри открывает шкаф."

translate russian ch0_main_7b148be6:
    "Всё ещё чувствуя себя неловко, я сажусь рядом с Сайори."

translate russian ch0_main_f4e1d6dd:
    "Нацуки с гордым видом марширует обратно к столу с подносом в руках."

translate russian ch0_main_5be7519f:
    n "Та-а-ак, все готовы?"

translate russian ch0_main_a49f0dc7:
    n "...Та-да-а!"

translate russian ch0_main_496daacd:
    s "Ух ты-ы-ы-ы!"

translate russian ch0_main_f7578acc:
    "Нацуки снимает фольгу с подноса, и под ней оказывается дюжина белых пушистых капкейков, украшенных в виде маленьких котиков."

translate russian ch0_main_96ece77f:
    "Усики нарисованы глазурью, а ушки сделаны из кусочков шоколада."

translate russian ch0_main_697c694e:
    s 4r "Какая пре-е-елесть~!"

translate russian ch0_main_c9f569c5:
    m 2b "Нацуки, я и не знала, что ты так здорово печёшь!"

translate russian ch0_main_ab028ca4:
    n 2d "Э-хе-хе. Ну, сама понимаешь."

translate russian ch0_main_1b5731e3:
    n "Давайте уже, берите!"

translate russian ch0_main_4f3b5c41:
    "Сайори хватает капкейк первой, за ней Моника. Я следом."

translate russian ch0_main_5fdd7380:
    s 4q "Вкуснотища!"

translate russian ch0_main_2e786edb:
    "Сайори говорит с набитым ртом и уже успела перемазаться глазурью."

translate russian ch0_main_9137625a:
    "Я верчу капкейк в пальцах, выбирая, с какой стороны лучше откусить."

translate russian ch0_main_2230ff25:
    "Нацуки молчит."

translate russian ch0_main_55d0254f:
    "Я не могу не заметить, что она украдкой поглядывает в мою сторону."

translate russian ch0_main_c0782073:
    "Ждёт, пока я откушу?"

translate russian ch0_main_894dc484:
    "Наконец я откусываю."

translate russian ch0_main_31cb8e28:
    "Глазурь сладкая и насыщенная — интересно, она сама её сделала?"

translate russian ch0_main_e31bb4c4:
    mc "Очень вкусно."

translate russian ch0_main_4c34725b:
    mc "Спасибо, Нацуки."

translate russian ch0_main_feae3ba6:
    n 5h "Ч-чего это ты меня благодаришь? Не то чтобы я...!"

translate russian ch0_main_8aa3724b:
    "{i}(Где-то я это уже слышал...?){/i}"

translate russian ch0_main_0b0590da:
    n 5s "...для тебя их пекла или вроде того."

translate russian ch0_main_cbdb9568:
    mc "А? Вообще-то, вроде как для меня. Сайори сказала—"

translate russian ch0_main_3c076ae6:
    n 12c "Ну, может, и так!"

translate russian ch0_main_3963d9b0:
    n "Но не для, н-ну, {i}тебя!{/i} Дурак..."

translate russian ch0_main_62185db9_1:
    mc "Ладно, ладно..."

translate russian ch0_main_e11ca288:
    "Я сдаюсь перед странной логикой Нацуки и не продолжаю разговор."

translate russian ch0_main_28adc331:
    "Юри возвращается к столу с чайным сервизом."

translate russian ch0_main_3b0ad38e:
    "Она аккуратно ставит перед каждым из нас чашку, а потом опускает чайник рядом с подносом капкейков."

translate russian ch0_main_b0102204:
    mc "Вы держите в классе целый чайный сервиз?"

translate russian ch0_main_63fe0000:
    y "Не волнуйся, учителя нам разрешили."

translate russian ch0_main_efc4ed34:
    y "В конце концов, разве чашка горячего чая не помогает насладиться хорошей книгой?"

translate russian ch0_main_a3a3b943:
    mc "А... Н-наверное..."

translate russian ch0_main_de8b3252:
    m "Э-хе-хе, не тушуйся, Юри просто хочет произвести на тебя впечатление."

translate russian ch0_main_d1e9e5c9:
    y 3n "А?! Н-неправда..."

translate russian ch0_main_6f8e7fc9:
    "Обиженная Юри отводит взгляд."

translate russian ch0_main_0403ff06:
    y 4b "Я имела в виду, ну..."

translate russian ch0_main_03220b59:
    mc "Я тебе верю."

translate russian ch0_main_e29518b6:
    mc "Ну, чтение за чаем — это, может, и не моё, но чай я хотя бы люблю."

translate russian ch0_main_fb4dad3b:
    y 2u "Я рада..."

translate russian ch0_main_c171e465:
    "Юри с облегчением едва заметно улыбается."

translate russian ch0_main_ef1106ab:
    "Моника приподнимает бровь, а потом улыбается мне."

translate russian ch0_main_6825feaf:
    m 1 "Так что же привело тебя в Литературный клуб?"

translate russian ch0_main_6b0ed824:
    mc "Э-э..."

translate russian ch0_main_dc25391e:
    "Я так и боялся этого вопроса."

translate russian ch0_main_e8c5b463:
    "Что-то мне подсказывает, что не стоит говорить Монике, как Сайори практически силой притащила меня сюда."

translate russian ch0_main_7fc001c4:
    mc "Ну, я ещё не вступил ни в один клуб, а Сайори тут, кажется, очень нравится, так что..."

translate russian ch0_main_fd3149d6:
    m 1j "Всё в порядке! Не стесняйся!"

translate russian ch0_main_ce2d7c11:
    m 1b "Мы сделаем всё, чтобы ты чувствовал себя как дома, хорошо?"

translate russian ch0_main_c706e39a:
    m "Как президент Литературного клуба, я обязана сделать так, чтобы в клубе всем было весело и интересно!"

translate russian ch0_main_a32c6d1d:
    mc "Моника, ты меня удивляешь."

translate russian ch0_main_eee6c6cb:
    mc "С чего ты решила основать собственный клуб?"

translate russian ch0_main_4c32cc5d:
    mc "Тебя бы наверняка взяли в руководство любого крупного клуба."

translate russian ch0_main_e482a1a0:
    mc "Разве в прошлом году ты не была одной из главных в дебатном клубе?"

translate russian ch0_main_ac39b15e:
    m 5 "А-ха-ха, ну, знаешь..."

translate russian ch0_main_762f40f1:
    m "Честно говоря, меня воротит от всех этих интриг в крупных клубах."

translate russian ch0_main_0ee5c447:
    m "Сплошные споры о бюджете, рекламе и подготовке к мероприятиям..."

translate russian ch0_main_874ed9a4:
    m "Мне куда больше хочется взять то, что нравится лично мне, и сделать из этого что-то особенное."

translate russian ch0_main_5744d684:
    m 1b "А если это вдохновит других заняться литературой, значит, моя мечта сбывается!"

translate russian ch0_main_e707a53f:
    s "Моника и правда замечательный лидер!"

translate russian ch0_main_da545528:
    "Юри тоже согласно кивает."

translate russian ch0_main_d8791778:
    mc "Тогда странно, что в клубе до сих пор так мало людей."

translate russian ch0_main_d49bb743:
    mc "Наверное, сложно открыть новый клуб."

translate russian ch0_main_be7ec00e:
    m 3b "Можно и так сказать."

translate russian ch0_main_75b36957:
    m "Не так уж много людей готовы вкладывать столько сил, чтобы начать что-то совершенно новое..."

translate russian ch0_main_e8c57f75:
    m "Особенно когда это что-то не особо привлекает внимание — вот как литература."

translate russian ch0_main_1ca5227d:
    m "Нужно очень постараться, чтобы убедить людей, что с тобой и весело, и не зря."

translate russian ch0_main_2d2540fa:
    m "Зато школьные мероприятия вроде фестиваля становятся от этого куда важнее."

translate russian ch0_main_5d278e4b:
    m 2k "Я уверена, что вместе мы по-настоящему разовьём этот клуб, прежде чем выпустимся!"

translate russian ch0_main_f8598f30:
    m "Верно я говорю?"

translate russian ch0_main_a03b41d0:
    s "Да!"

translate russian ch0_main_d4e34ad8:
    y "Мы постараемся."

translate russian ch0_main_91310346:
    n "Ещё бы!"

translate russian ch0_main_b250c385:
    "Все с энтузиазмом соглашаются."

translate russian ch0_main_fffaaae6:
    "Такие разные девушки — и все стремятся к одной цели..."

translate russian ch0_main_e4ea91ed:
    "Монике, наверное, пришлось очень постараться, чтобы найти хотя бы этих троих."

translate russian ch0_main_568069f4:
    "Может, поэтому они все так обрадовались, что в клуб придёт новый участник."

translate russian ch0_main_08aa7ac3:
    "Хотя я всё ещё не уверен, что смогу разделить их увлечённость литературой..."

translate russian ch0_main_63db5da7:
    y "Итак, [player], что ты любишь читать?"

translate russian ch0_main_cf79ccdb:
    mc "Ну... Э-э..."

translate russian ch0_main_5fcc5273:
    "Учитывая, как мало я прочитал за последние несколько лет, внятно ответить на этот вопрос я не могу."

translate russian ch0_main_1947382b:
    mc "...Мангу..."

translate russian ch0_main_459c1918:
    "Я бормочу это себе под нос, наполовину в шутку."

translate russian ch0_main_c6e48974:
    "Нацуки вдруг резко поднимает голову."

translate russian ch0_main_9101cacb:
    "Кажется, она хочет что-то сказать, но молчит."

translate russian ch0_main_8c105e2a:
    y 3u "З-значит, ты не особо любишь читать..."

translate russian ch0_main_68d50b2d:
    mc "...Ну, это можно исправить..."

translate russian ch0_main_ccf38a3c:
    "Что я несу?"

translate russian ch0_main_3b4ce5c9:
    "Я ляпнул не подумав, когда увидел грустную улыбку Юри."

translate russian ch0_main_ca4f61b8:
    mc "В общем, а как насчёт тебя, Юри?"

translate russian ch0_main_a89289a8:
    y 1l "Ну, дай подумать..."

translate russian ch0_main_de0357e1:
    "Юри обводит пальцем край своей чашки."

translate russian ch0_main_17dec8ac:
    y 1a "Больше всего я люблю романы, в которых выстроены глубокие и сложные фантастические миры."

translate russian ch0_main_24dcace1:
    y "Меня поражает, сколько в них творческой фантазии и мастерства."

translate russian ch0_main_ff3c844f:
    y 1f "А рассказать хорошую историю в таком чуждом мире — это не менее впечатляюще."

translate russian ch0_main_c77e0dd8:
    "Юри продолжает, явно увлечённая своими книгами."

translate russian ch0_main_30d11e87:
    "С самого моего прихода она казалась такой сдержанной и робкой, но по тому, как загораются её глаза, ясно: утешение она находит в мире книг, а не людей."

translate russian ch0_main_830d7316:
    y 2m "Но, знаешь, мне нравится очень многое."

translate russian ch0_main_7aa57972:
    y "Истории с глубоким психологизмом тоже обычно меня затягивают."

translate russian ch0_main_b1a75737:
    y 2a "Разве не удивительно, как писатель может намеренно сыграть на недостатке твоего воображения, чтобы застать тебя врасплох?"

translate russian ch0_main_98f09acd:
    y "В общем, в последнее время я много читаю ужасы..."

translate russian ch0_main_b274f53a:
    mc "А, я однажды читал книгу ужасов..."

translate russian ch0_main_e7c359a6:
    "Я отчаянно хватаюсь за то, к чему имею хоть какое-то отношение."

translate russian ch0_main_6b8ceb25:
    "С таким успехом Юри могла бы разговаривать с камнем."

translate russian ch0_main_dac3be05:
    m "Правда? Вот уж не ожидала от тебя, Юри."

translate russian ch0_main_cb2111ac:
    m "Ты ведь такая мягкая..."

translate russian ch0_main_84a13e28:
    y 1a "Пожалуй, можно и так сказать."

translate russian ch0_main_38b0ae71:
    y "Но если история заставляет меня задуматься или переносит в другой мир, я просто не могу от неё оторваться."

translate russian ch0_main_fa55ff2a:
    y "Сюрреалистичный хоррор часто прекрасно умеет изменить то, как ты смотришь на мир, — пусть даже ненадолго."

translate russian ch0_main_b8c3c144:
    n "Фу, ненавижу ужасы..."

translate russian ch0_main_1c139e48:
    y 1f "О? Почему же?"

translate russian ch0_main_ab1562c5:
    n 5c "Ну, просто я..."

translate russian ch0_main_7aac067b:
    "Нацуки на долю секунды бросает взгляд на меня."

translate russian ch0_main_98c7c1c1:
    n 5q "Забудь."

translate russian ch0_main_5d936510:
    m 1a "Точно, ты ведь обычно любишь писать о чём-нибудь милом, да, Нацуки?"

translate russian ch0_main_f053d184:
    n "Ч-чего?"

translate russian ch0_main_3df32e44:
    n "С чего ты это взяла?"

translate russian ch0_main_550dd777:
    m 3b "На прошлом собрании ты оставила черновик."

translate russian ch0_main_e37f3c62:
    m "Похоже, ты писала стихотворение под названием—"

translate russian ch0_main_1e455dfe:
    n "Не говори вслух!!"

translate russian ch0_main_ff703620:
    n "И отдай сейчас же!"

translate russian ch0_main_7ae96939:
    m 1j "Ладно, ладно~"

translate russian ch0_main_fa944ba0:
    s "Э-хе-хе, твои капкейки, твои стихи..."

translate russian ch0_main_da28403a:
    s "Всё, что ты делаешь, такое же милое, как ты сама~"

translate russian ch0_main_c429c3fc:
    "Сайори подкрадывается к Нацуки сзади и кладёт руки ей на плечи."

translate russian ch0_main_6ccf1bfd:
    n 1v "{i}Я не милая!!{/i}"

translate russian ch0_main_af8472c2:
    mc "Нацуки, ты сама пишешь стихи?"

translate russian ch0_main_30d37f9a:
    n 1c "А? Ну, бывает иногда."

translate russian ch0_main_842dce39:
    n "Тебе-то что?"

translate russian ch0_main_fe27eb16:
    mc "По-моему, это впечатляет."

translate russian ch0_main_ccafd1bb:
    mc "Может, как-нибудь покажешь?"

translate russian ch0_main_3f199bd2:
    n 5q "Н-нет!"

translate russian ch0_main_edb6ed7f:
    "Нацуки отводит взгляд."

translate russian ch0_main_9d7b9bad:
    n "Тебе бы они... не понравились..."

translate russian ch0_main_35a5aeea:
    mc "А... Ещё не очень уверена в себе как автор?"

translate russian ch0_main_7e67e889:
    y "Я понимаю, что чувствует Нацуки."

translate russian ch0_main_a387c89f:
    y "Чтобы делиться такими текстами, одной уверенности мало."

translate russian ch0_main_e06ca773:
    y 2k "Самое настоящее творчество — это когда пишешь для себя."

translate russian ch0_main_d2b7c428:
    y "Нужно быть готовой открыться читателям, обнажить свои слабости и показать даже самые потаённые уголки своего сердца."

translate russian ch0_main_d526bbf0:
    m "Юри, у тебя тоже есть опыт в писательстве?"

translate russian ch0_main_2bc6a16e:
    m "Может, если ты поделишься своими работами, то подашь пример, и Нацуки будет спокойнее показать свои."

translate russian ch0_main_5a6499dc:
    y 3o "..."

translate russian ch0_main_19552c38:
    mc "Видимо, с Юри то же самое..."

translate russian ch0_main_ec936eb4:
    s "Эх... А я хотела почитать стихи всех..."

translate russian ch0_main_701e440d:
    "Какое-то время мы все сидим молча."

translate russian ch0_main_e74385d7:
    m "Так!"

translate russian ch0_main_2ffc1dd9:
    m "Слушайте все, у меня идея~"

translate russian ch0_main_95cd0d51:
    ny "...?"

translate russian ch0_main_d080e0ca:
    "Нацуки и Юри вопросительно смотрят на Монику."

translate russian ch0_main_a4f63044:
    m 2b "Давайте все пойдём домой и напишем по стихотворению!"

translate russian ch0_main_cd1a6280:
    m "А в следующий раз, когда соберёмся, покажем их друг другу."

translate russian ch0_main_a106107a:
    m "Так все будут в равных условиях!"

translate russian ch0_main_963b3971:
    n 5q "Э-э..."

translate russian ch0_main_71a86863:
    y "..."

translate russian ch0_main_6766811d:
    s "Да-а-а! Давайте!"

translate russian ch0_main_cdd2d381:
    m 1a "К тому же теперь, когда у нас новый участник, это поможет нам всем немного привыкнуть друг к другу и укрепит дружбу в клубе."

translate russian ch0_main_26116031:
    m "Правда ведь, [player]?"

translate russian ch0_main_871cb3a3:
    "Моника снова тепло мне улыбается."

translate russian ch0_main_cf25d371:
    mc "Погоди... есть ещё одна проблема."

translate russian ch0_main_bee826cb:
    m 1d "А? Какая?"

translate russian ch0_main_376d0c21:
    "Раз уж мы вернулись к вопросу о моём вступлении в клуб, я прямо выкладываю то, что всё это время было у меня на уме."

translate russian ch0_main_5ce8ccfa:
    mc "Я ведь не говорил, что вступлю в этот клуб!"

translate russian ch0_main_b0a068b5:
    mc "Сайори, может, и уговорила меня заглянуть, но я ещё ничего не решил."

translate russian ch0_main_4de02539:
    mc "Мне нужно посмотреть и другие клубы, и... э-э..."

translate russian ch0_main_1e4b58a1:
    "Я теряю нить мысли."

translate russian ch0_main_3b7e2967:
    "Все четыре девушки смотрят на меня полными уныния глазами."

translate russian ch0_main_8911e105:
    m 1p "Н-но..."

translate russian ch0_main_a403322e:
    y 2v "Прости, я думала..."

translate russian ch0_main_bc64dbb8_1:
    n 5s "Хмф."

translate russian ch0_main_48b8805c:
    s 1k "[player]..."

translate russian ch0_main_a99ed1fe:
    mc "В-вы все..."

translate russian ch0_main_966cc463:
    "Я... я беззащитен перед этими девушками."

translate russian ch0_main_d4da3079:
    "Как тут вообще можно принять взвешенное решение?"

translate russian ch0_main_1f374c38:
    "Если писать стихи — это цена, которую придётся заплатить, чтобы каждый день проводить с этими красавицами..."

translate russian ch0_main_36037676:
    mc "...Ладно."

translate russian ch0_main_ee38c6e2:
    mc "Хорошо, тогда я решил."

translate russian ch0_main_bfead9f9:
    mc "Я вступаю в Литературный клуб."

translate russian ch0_main_4423eaff:
    "Глаза девушек одна за другой загораются."

translate russian ch0_main_7265c99b:
    s 4r "Ура-а-а! Я так ра-а-ада~"

translate russian ch0_main_4037de6b:
    "Сайори обнимает меня и прыгает на месте."

translate russian ch0_main_4fb65cd5:
    mc "Э-эй—"

translate russian ch0_main_792dfef8:
    y 1m "Ты меня и правда на миг напугал..."

translate russian ch0_main_e9faf06e:
    n 5q "Если ты пришёл только ради капкейков, я ужасно разозлюсь."

translate russian ch0_main_e1457fb7:
    m 5 "Значит, теперь это официально!"

translate russian ch0_main_4fb57992:
    m "Добро пожаловать в Литературный клуб!"

translate russian ch0_main_fc5c3668:
    mc "А... ну, спасибо, наверное."

translate russian ch0_main_e719ebca:
    m 3b "Итак, ребята!"

translate russian ch0_main_94ecc185:
    m "Думаю, на этом можно официально закончить сегодняшнее собрание на хорошей ноте."

translate russian ch0_main_435b8f44:
    m "Все помните сегодняшнее задание:"

translate russian ch0_main_f3222edc:
    m "Напишите к следующему собранию стихотворение, чтобы мы все могли ими поделиться!"

translate russian ch0_main_f7602550:
    "Моника снова смотрит на меня."

translate russian ch0_main_7c3950aa:
    m 1a "[player], мне не терпится увидеть, как ты себя выразишь."

translate russian ch0_main_45d9cd96:
    m "Э-хе-хе~"

translate russian ch0_main_5aa72ccd:
    mc "Д-да..."

translate russian ch0_main_c5a873f7:
    "Неужели я правда смогу впечатлить Монику, звезду класса, своими посредственными писательскими способностями?"

translate russian ch0_main_6944e055:
    "Внутри уже нарастает тревога."

translate russian ch0_main_a90aebad:
    "Тем временем девушки продолжают болтать, а Юри и Нацуки убирают со стола."

translate russian ch0_main_9957133c:
    s "Эй, [player], раз уж мы тут вместе, может, пойдём домой вдвоём?"

translate russian ch0_main_62fc13da:
    "И правда — мы с Сайори давно уже не ходим домой вместе, потому что после уроков она всегда оставалась в клубе."

translate russian ch0_main_336bf349:
    mc "Конечно, почему бы и нет."

translate russian ch0_main_df253bf7:
    s 4q "Ура-а~"

translate russian ch0_main_55e5370a:
    "На этом мы вдвоём покидаем клубную комнату и направляемся домой."

translate russian ch0_main_7df62755:
    "Всю дорогу мои мысли то и дело возвращаются к четырём девушкам:"

translate russian ch0_main_f67abbfb:
    "Сайори,"

translate russian ch0_main_fa99dc55:
    "Нацуки,"

translate russian ch0_main_f8ee4cf6:
    "Юри"

translate russian ch0_main_b3c6e50b:
    "и, конечно же, Моника."

translate russian ch0_main_3ec099e1:
    "Буду ли я и правда счастлив, проводя каждый день после уроков в литературном клубе?"

translate russian ch0_main_2b5dfb83:
    "Может, мне выпадет шанс сблизиться с одной из этих девушек..."

translate russian ch0_main_16cd82b1:
    "Решено!"

translate russian ch0_main_b0188844:
    "Нужно просто извлечь максимум из того, что есть, и удача обязательно мне улыбнётся."

translate russian ch0_main_dff2799d:
    "А начинается это, видимо, с того, что сегодня вечером я напишу стихотворение..."

translate russian ch0_kill_e1554201:
    s "..."

translate russian ch0_kill_e1554201_1:
    s "..."

translate russian ch0_kill_2a5a342b:
    s "Ч-что..."

translate russian ch0_kill_ecefd2ea:
    s 1g "..."

translate russian ch0_kill_c846785b:
    s "Это..."

translate russian ch0_kill_266d53d4:
    s "Что это такое...?"

translate russian ch0_kill_ff8bb5a8:
    s "О нет..."

translate russian ch0_kill_ee35af3b:
    s 1u "Нет..."

translate russian ch0_kill_df4d9288:
    s "Не может быть, что это всё."

translate russian ch0_kill_d9000ecb:
    s "Не может быть, что больше ничего нет."

translate russian ch0_kill_5ef55015:
    s 4w "Что это?"

translate russian ch0_kill_a2d41fd3:
    s "Что я такое?"

translate russian ch0_kill_33a08944:
    s "Прекратите это!"

translate russian ch0_kill_ace8097a:
    s "ПОЖАЛУЙСТА, ПРЕКРАТИТЕ ЭТО!"
