# Русский перевод: script-ch3

translate russian ch3_main_9f4a56c4:
    m "Ну вот..."

translate russian ch3_main_055e03b2:
    m "Я опять пришла последней!"

translate russian ch3_main_b7e281fe:
    mc "Не волнуйся, я тоже только что зашёл."

translate russian ch3_main_c3ef2d3c:
    y "Ты опять занималась на пианино?"

translate russian ch3_main_45b8967d:
    m 1l "Ну вот..."

translate russian ch3_main_f6daf90a:
    m "А-ха-ха..."

translate russian ch3_main_f6674ca2:
    y 1m "У тебя, должно быть, огромная целеустремлённость."

translate russian ch3_main_b3742316:
    y "Основать этот клуб, а теперь ещё и взяться за пианино..."

translate russian ch3_main_d085cf7d:
    m 1a "Ну, может, и не целеустремлённость..."

translate russian ch3_main_3107ecc8:
    m "Скорее страсть."

translate russian ch3_main_2a81fef4:
    m "Помните, что без всех вас этого клуба бы не было."

translate russian ch3_main_c98c2ef3:
    m 1b "И я ужасно рада, что вы все готовы помочь и с фестивалем!"

translate russian ch3_main_c579b59a:
    n "А-а-ах, скорее бы фестиваль!"

translate russian ch3_main_0622f046:
    n "Будет здорово!"

translate russian ch3_main_8ce7a8ef:
    m 1d "А?"

translate russian ch3_main_ab7ae29e:
    m "Разве не ты вчера на него жаловалась, Нацуки?"

translate russian ch3_main_37f7579e:
    n "Ну да."

translate russian ch3_main_f68bca32:
    n "Я не про {i}нашу{/i} часть фестиваля."

translate russian ch3_main_0f6cfdeb:
    n 4l "Это же целый школьный день, когда можно развлекаться и есть всякие вкусности!"

translate russian ch3_main_54b06106:
    mc "Ты вдруг заговорила прямо как Сайори..."

translate russian ch3_main_cfe933b2:
    n 4a "Моника! А там обычно бывает жареный кальмар?"

translate russian ch3_main_a6e88b1f:
    m "Кальмар...?"

translate russian ch3_main_6c34f853:
    m "Довольно конкретное ожидание..."

translate russian ch3_main_a4c7577e:
    n "Ой, да ладно."

translate russian ch3_main_9440d258:
    n "Ты хочешь сказать, что не любишь кальмаров?"

translate russian ch3_main_1f8fa284:
    n "Кто-кто, а ты?"

translate russian ch3_main_6eb6bfe0:
    m "А? Я не говорила, что не люблю."

translate russian ch3_main_d8ec5ced:
    m "И вообще, что значит «кто-кто, а ты»?"

translate russian ch3_main_a0fd7848:
    n "Потому что!"

translate russian ch3_main_07187167:
    n "Это же прямо в твоём имени!"

translate russian ch3_main_8f497507:
    n 4z "Мон-ИКА!"

translate russian ch3_main_5ddfdfed:
    m "А?!"

translate russian ch3_main_6132dc6f:
    m "Моё имя вообще не так произносится!"

translate russian ch3_main_69ab772f:
    m "К тому же в переводе эта шутка теряет всякий смысл!"

translate russian ch3_main_a5a5ad3d:
    n 4m "...?"

translate russian ch3_main_23054d2c:
    m "Ах... неважно!"

translate russian ch3_main_bcac77c0:
    m "Давайте пока сосредоточимся на нашем мероприятии, хорошо?"

translate russian ch3_main_290c4793:
    n "Э-хе-хе."

translate russian ch3_main_bb28cd81:
    n "Ладно, ладно."

translate russian ch3_main_b2acf4f8:
    n "Всё равно ты реагируешь не так забавно, как Юри или Сайори."

translate russian ch3_main_d07bdb0a:
    y "Прошу прощения..."

translate russian ch3_main_bf3989ea:
    mc "А где, кстати, Сайори...?"

translate russian ch3_main_e0642a0e:
    mc "А, вот ты где."

translate russian ch3_main_7a772057:
    "Сайори сидит за партой в углу комнаты и смотрит в пустоту."

translate russian ch3_main_45a1d633:
    "Я подхожу к ней."

translate russian ch3_main_64ca4d29:
    mc "Эй, Сайори."

translate russian ch3_main_34620dff:
    "Я машу рукой у неё перед лицом."

translate russian ch3_main_d19b9137:
    s 1n "А—?"

translate russian ch3_main_290df0ce:
    mc "Ты опять витаешь в облаках."

translate russian ch3_main_82cca4a1:
    s "А-ах..."

translate russian ch3_main_3bfb671b:
    s 4l "Э-хе-хе, прости..."

translate russian ch3_main_5caa9a43:
    s "Не обращай на меня внимания."

translate russian ch3_main_636b7bc7:
    s 4y "Можешь пойти поговорить с остальными."

translate russian ch3_main_5693a819:
    mc "Хм..."

translate russian ch3_main_86bcc222:
    mc "Всё в порядке?"

translate russian ch3_main_d6ab89ea:
    s 1h "К-конечно!"

translate russian ch3_main_c72e5106:
    s "А почему должно быть иначе?"

translate russian ch3_main_9136ec5d:
    mc "Просто кажется, что ты какая-то не такая..."

translate russian ch3_main_a16a7353:
    mc "Прости, что напридумывал."

translate russian ch3_main_c904bbeb:
    s "Боже, ты слишком за меня переживаешь."

translate russian ch3_main_afbc6df5:
    s 4r "Я в порядке, видишь?"

translate russian ch3_main_fb603655:
    "Сайори широко мне улыбается."

translate russian ch3_main_599d33ee:
    s 1a "Не давай мне отвлекать тебя от веселья с остальными."

translate russian ch3_main_970c9c1e:
    mc "Ну... ладно."

translate russian ch3_main_f16c798b:
    mc "Раз ты так говоришь."

translate russian ch3_main_1dbe8bfc:
    "Я встревоженно смотрю на Сайори, прежде чем повернуться к остальным."

translate russian ch3_main_b6502fc6:
    "Но разговор уже распался, и все вернулись к своим обычным занятиям."

translate russian ch3_main_8a136d4b:
    "Может, спросить Монику, не замечала ли она чего-нибудь за Сайори в последнее время..."

translate russian ch3_main_c1385105:
    "Раз они готовятся к фестивалю, то наверняка проводят много времени вместе."

translate russian ch3_main_4bfa6536:
    "Я робко подхожу к Монике, которая перебирает бумаги у себя на парте."

translate russian ch3_main_2a6e770a:
    m "[player]! Что такое?"

translate russian ch3_main_e22411e9:
    mc "Слушай, может, это прозвучит немного странно, но..."

translate russian ch3_main_7d89c66d:
    mc "Ты не замечала в последнее время ничего необычного за Сайори?"

translate russian ch3_main_2f38f7c6:
    m 1d "Необычного...?"

translate russian ch3_main_6d065c32:
    m "В каком смысле?"

translate russian ch3_main_4af445be:
    mc "Может, я слишком много себе надумываю, но сегодня она кажется какой-то подавленной..."

translate russian ch3_main_3d2f1e4f:
    m "О? Ты так думаешь?"

translate russian ch3_main_e65999e3:
    m "Не могу сказать, что я что-то заметила..."

translate russian ch3_main_b0f2d760:
    "Моника смотрит через всю комнату на Сайори, которая рассеянно водит ластиком туда-сюда по парте."

translate russian ch3_main_20f10b9d:
    m "Может, её что-то и тревожит..."

translate russian ch3_main_f53d8414:
    m 2a "Но удивительно, что это не я тебя спрашиваю, [player]."

translate russian ch3_main_4f1d9fcf:
    m "Ты ведь знаешь её гораздо лучше меня."

translate russian ch3_main_5d1a8e6e:
    mc "Да, но она никогда такой не бывает..."

translate russian ch3_main_8e93da88:
    mc "Она всегда рассказывала мне о том, что её беспокоит."

translate russian ch3_main_41a46d4e:
    mc "А в этот раз, когда я спросил, она просто отмахнулась."

translate russian ch3_main_7806befb:
    mc "...Прости, я знаю, что это не твоя проблема!"

translate russian ch3_main_e84794f0:
    mc "Я просто хотел спросить, не знаешь ли ты чего-нибудь, так что больше не буду..."

translate russian ch3_main_9a81ed2c:
    m 1g "Нет-нет..."

translate russian ch3_main_1203b368:
    m "Для меня это тоже важно."

translate russian ch3_main_a44abe16:
    m 1e "В смысле, я ведь тоже с ней дружу..."

translate russian ch3_main_4ed92bda:
    m "И мне не всё равно, как себя чувствуют члены моего клуба, понимаешь?"

translate russian ch3_main_19a357cd:
    m 1i "Может, я сама попробую с ней поговорить..."

translate russian ch3_main_86450641:
    mc "А? Ты уверена...?"

translate russian ch3_main_8b5282dc:
    mc "Мне показалось, она хотела, чтобы её оставили в покое..."

translate russian ch3_main_eeff158c:
    m "Ты уверен?"

translate russian ch3_main_d06144a2:
    m "Может, ей просто трудно заговорить об этом с тем, кого это касается..."

translate russian ch3_main_af2414ed:
    mc "С тем, кого это касается...?"

translate russian ch3_main_721d4483:
    mc "Что ты имеешь в виду?"

translate russian ch3_main_a8802558:
    m 2e "Я хочу сказать, что, может быть, у неё на уме именно ты, [player]."

translate russian ch3_main_55dcaef8:
    mc "Я...?"

translate russian ch3_main_f21ed1cb:
    mc "С чего ты вообще так решила?"

translate russian ch3_main_3597eef0:
    m 1j "Ну..."

translate russian ch3_main_70cf461c:
    m "Мне, наверное, не стоит много говорить, но..."

translate russian ch3_main_5171073b:
    m 1a "Знаешь, Сайори говорит о тебе больше, чем о чём-либо другом."

translate russian ch3_main_bbe4458e:
    mc "А...?"

translate russian ch3_main_35841dde:
    m "С тех пор как ты вступил в клуб, она стала гораздо счастливее."

translate russian ch3_main_d6ca5954:
    m "Будто у неё внутри зажёгся ещё один огонёк."

translate russian ch3_main_11455b53:
    mc "Что?"

translate russian ch3_main_84b7a515:
    mc "Быть не может..."

translate russian ch3_main_f6072126:
    mc "Сайори... она всегда такая."

translate russian ch3_main_25b78605:
    mc "Она всегда была как солнышко."

translate russian ch3_main_7a6772a0:
    mc "Сейчас она ничем не отличается от того, какой была всегда."

translate russian ch3_main_0ccc6dfb:
    m 5 "Э-хе-хе."

translate russian ch3_main_6fa5c5c5:
    m "Какой же ты забавный, [player]."

translate russian ch3_main_ab217aeb:
    m "А ты не думал, что, может, ты всегда видел её такой жизнерадостной..."

translate russian ch3_main_44e6e308:
    m "...потому что такой она бывает именно рядом с тобой?"

translate russian ch3_main_2b35b6fe:
    mc "..."

translate russian ch3_main_f1680e8f:
    m 1n "Ах... я сказала лишнее."

translate russian ch3_main_9cd47824:
    m "Прости... да и что я вообще знаю?"

translate russian ch3_main_f2ea8b79:
    m 1a "Я не хотела делать поспешных выводов, так что лучше забудь, что я сказала."

translate russian ch3_main_537af382:
    m "Я попробую с ней поговорить, так что постарайся пока об этом не думать."

translate russian ch3_main_93deaf69:
    mc "А..."

translate russian ch3_main_b12907fb:
    mc "Ладно..."

translate russian ch3_main_43c1f1cb:
    "Моника многозначительно улыбается."

translate russian ch3_main_4fe59b5e:
    "Знаю, она сказала забыть об этом..."

translate russian ch3_main_fffb9c28:
    "Но я уже понимаю, что её слова не выйдут у меня из головы."

translate russian ch3_main_b789063e:
    "Моника встаёт из-за парты и идёт через всю комнату туда, где сидит Сайори."

translate russian ch3_main_7b6cf640:
    "Я смотрю, как она опускается на колени рядом с Сайори и мягко с ней разговаривает."

translate russian ch3_main_e970c9da:
    "Но говорит она так тихо, что отсюда мне ничего не слышно."

translate russian ch3_main_28bcbf2a:
    "Я вздыхаю и сажусь."

translate russian ch3_main_69bc17e9:
    "Знаю, Сайори сказала мне не волноваться за неё и веселиться с остальными..."

translate russian ch3_main_4890308f:
    "Но это невозможно, когда она так себя ведёт."

translate russian ch3_main_fae0adaf:
    "Насколько же она мне дорога, раз меня это так гнетёт?"

translate russian ch3_main_15fb5d0a:
    "Теперь такое ощущение, что это я веду себя странно..."

translate russian ch3_main_9fca3f68:
    "Но мне ничего не остаётся, кроме как ждать Монику."

translate russian ch3_start_natsuki_902551ba:
    n "Эй, ты."

translate russian ch3_start_natsuki_fb2e5377:
    mc "А?"

translate russian ch3_start_natsuki_e73b3f96:
    "Я поднимаю голову и вижу рядом Нацуки."

translate russian ch3_start_natsuki_f4523236:
    n "Так и будешь сидеть и пялиться в пустоту?"

translate russian ch3_start_natsuki_8fba89af:
    n "Времени не так уж много, так что..."

translate russian ch3_start_natsuki_ad9d747e:
    mc "А, прости."

translate russian ch3_start_natsuki_f930e5b1:
    mc "Я не хотел, чтобы ты волновалась."

translate russian ch3_start_natsuki_030f9150:
    n 1q "Я-я вовсе не волнуюсь!"

translate russian ch3_start_natsuki_9aff6292:
    n "Я просто..."

translate russian ch3_start_natsuki_a41a98d6:
    "Нацуки опускает взгляд."

translate russian ch3_start_natsuki_212a86e2:
    "В руке у неё том манги."

translate russian ch3_start_natsuki_dad7a8db:
    mc "Точно..."

translate russian ch3_start_natsuki_d24ec9fb:
    mc "Тут кое-что ненадолго всплыло, но теперь можем начинать."

translate russian ch3_start_natsuki_96ad46f7:
    mc "Больше не заставлю тебя ждать."

translate russian ch3_start_natsuki_8a80dfb5:
    n 5n "Блин..."

translate russian ch3_start_natsuki_3550bb95:
    n "Теперь я чувствую себя какой-то стервой."

translate russian ch3_start_natsuki_607cf66c:
    n "Если тебя что-то беспокоит, просто скажи, чтобы я от тебя отстала, и я отстану."

translate russian ch3_start_natsuki_9a59920b:
    n 5u "Ну..."

translate russian ch3_start_natsuki_f42f6ca7:
    n "Ну, если тебе не хочется об этом говорить или вроде того..."

translate russian ch3_start_natsuki_eb708455:
    "Последнее она практически бормочет."

translate russian ch3_start_natsuki_82c21d4c:
    mc "Да не... я, наверное, раздуваю из этого больше, чем оно того стоит."

translate russian ch3_start_natsuki_39a60b69:
    mc "Я просто думал о Сайори, вот и всё."

translate russian ch3_start_natsuki_3d513601:
    n 1p "О С-Сайори...?"

translate russian ch3_start_natsuki_cddb30dc:
    n "Думал о ней...?"

translate russian ch3_start_natsuki_f7dbd999:
    mc "Ага, она сегодня какая-то подавленная."

translate russian ch3_start_natsuki_588008e2:
    mc "Но не захотела мне в этом признаваться."

translate russian ch3_start_natsuki_5ccf3d8c:
    mc "Вот я и не могу не думать, не случилось ли с ней чего."

translate russian ch3_start_natsuki_76502d6d:
    n 1q "Ох..."

translate russian ch3_start_natsuki_8fefafe4:
    "Нацуки выдыхает."

translate russian ch3_start_natsuki_187134d9:
    n 4w "Ну, во-первых..."

translate russian ch3_start_natsuki_31a4f59e:
    n "Тебе стоит поработать над формулировками!"

translate russian ch3_start_natsuki_e7374d30:
    n 4c "Но в общем..."

translate russian ch3_start_natsuki_2916b1ec:
    n "Ты ведь её лучший друг, да?"

translate russian ch3_start_natsuki_8e64bc71:
    mc "Да, наверное..."

translate russian ch3_start_natsuki_2fe1bf98:
    n "Ага."

translate russian ch3_start_natsuki_09f83c65:
    n 3k "Тогда, по-моему, тебе стоит ей больше доверять."

translate russian ch3_start_natsuki_9b164341:
    n "Если бы ты был ей нужен, она бы первым делом пошла к тебе, разве нет?"

translate russian ch3_start_natsuki_bae81423:
    mc "Ну... пожалуй, это правда."

translate russian ch3_start_natsuki_16331171:
    n 3c "Ну, у некоторых просто бывают такие дни."

translate russian ch3_start_natsuki_587e4a4f:
    n "Этого не всегда можно избежать."

translate russian ch3_start_natsuki_66712f45:
    n "Скорее всего, она не хочет, чтобы ты за неё волновался, потому что это неважно."

translate russian ch3_start_natsuki_77c6db72:
    mc "Да, она мне примерно так и сказала..."

translate russian ch3_start_natsuki_4191d571:
    mc "Может, и правда не стоит идти против её желания."

translate russian ch3_start_natsuki_37577bf9:
    n 3a "Вот именно."

translate russian ch3_start_natsuki_0599259f:
    n "Если ей понадобится, чтобы ты за неё волновался, это будет куда заметнее."

translate russian ch3_start_natsuki_69c25b65:
    mc "Да..."

translate russian ch3_start_natsuki_ab0430cd:
    mc "Надо было с самого начала так на это посмотреть."

translate russian ch3_start_natsuki_de5759f8:
    "Нацуки вертит в руках книгу."

translate russian ch3_start_natsuki_4e52d9cd:
    n 1q "Она..."

translate russian ch3_start_natsuki_82eebb9c:
    n "Она ведь очень много для тебя значит, да...?"

translate russian ch3_start_natsuki_f9d65918:
    mc "А—"

translate russian ch3_start_natsuki_6e3a63d0:
    mc "Только не пойми неправильно...!"

translate russian ch3_start_natsuki_d7b4cc75:
    mc "Мы просто давно дружим."

translate russian ch3_start_natsuki_ea513c23:
    mc "Нормально волноваться за друзей."

translate russian ch3_start_natsuki_74e8c8a1:
    mc "Ты ведь вот за меня волновалась, так что—"

translate russian ch3_start_natsuki_01eaeb75:
    n 4w "Вовсе нет!!"

translate russian ch3_start_natsuki_1011a1fe:
    n "Блин... если ты в порядке, давай уже скорее начинать!"

translate russian ch3_start_natsuki_e9ea92f3:
    mc "Да-да..."

translate russian ch3_start_yuri_b046af93:
    "Почему мне кажется, что за мной наблюдают...?"

translate russian ch3_start_yuri_58e4d71b:
    "Я оглядываю комнату."

translate russian ch3_start_yuri_f5b959b9:
    "Вдруг я замечаю, что Юри поглядывает на меня поверх книги."

translate russian ch3_start_yuri_f6654335:
    "Но она тут же смущённо отводит взгляд."

translate russian ch3_start_yuri_2d0373af:
    "Я понимаю, что так она ничего не добьётся."

translate russian ch3_start_yuri_2963f68b:
    "Я ни разу не видел, чтобы Юри сама к кому-то подошла или начала разговор."

translate russian ch3_start_yuri_5080c5c5:
    "Так что мне ничего не остаётся, кроме как подойти самому."

translate russian ch3_start_yuri_ac24567b:
    "Теперь мне это даётся уже немного легче."

translate russian ch3_start_yuri_624fe589:
    "Я встаю из-за своей парты и сажусь за соседнюю с ней."

translate russian ch3_start_yuri_a3dfe221:
    y 2v "..."

translate russian ch3_start_yuri_e34fd7aa:
    y "Я... не хотела тебя беспокоить..."

translate russian ch3_start_yuri_adb501d9:
    mc "Расслабься, ты же ничего не сделала."

translate russian ch3_start_yuri_e45b137d:
    y "Но..."

translate russian ch3_start_yuri_5fc73f2b:
    y "Я видела, что тебе хочется побыть наедине со своими мыслями..."

translate russian ch3_start_yuri_f936a2cb:
    mc "Наедине со своими мыслями...?"

translate russian ch3_start_yuri_de9a347a:
    mc "Как ты вообще поняла, что я о чём-то таком думаю?"

translate russian ch3_start_yuri_c7dbab07:
    y 1t "Ну..."

translate russian ch3_start_yuri_a893f40a:
    y "Со мной такое часто бывает..."

translate russian ch3_start_yuri_5a61ff15:
    y "Так что по позе и выражению лица мне было нетрудно это заметить."

translate russian ch3_start_yuri_191b9255:
    y 3o "Н-не то чтобы я пялилась или что-то такое...!"

translate russian ch3_start_yuri_d9991a92:
    y "Я не делала ничего такого жуткого...!"

translate russian ch3_start_yuri_ff234481:
    mc "В любом случае, похоже, ты была права."

translate russian ch3_start_yuri_541c5376:
    mc "Прости, если заставил тебя волноваться."

translate russian ch3_start_yuri_faa74039:
    y 1s "Не извиняйся..."

translate russian ch3_start_yuri_d0e854ff:
    y "Твои тревоги касаются лишь тех, кто сам готов их разделить."

translate russian ch3_start_yuri_64808ee1:
    y "Конечно, есть и те, кому легче всего держать всё в себе..."

translate russian ch3_start_yuri_e41ba113:
    y "Но если тебе хочется поделиться тем, что у тебя на уме, я с радостью выслушаю."

translate russian ch3_start_yuri_3f26c11b:
    mc "А, да ничего особенного..."

translate russian ch3_start_yuri_2c386bc7:
    mc "Просто мне было немного неспокойно из-за Сайори."

translate russian ch3_start_yuri_0f4247ac:
    y 2t "Из-за Сайори...?"

translate russian ch3_start_yuri_1a7b9fae:
    mc "Ага... она сегодня какая-то не такая, но когда я спросил, она не захотела мне признаваться."

translate russian ch3_start_yuri_5ccf3d8c:
    mc "Вот я и не могу не думать, не случилось ли с ней чего."

translate russian ch3_start_yuri_c15e0eaa:
    y 3u "Да ну?"

translate russian ch3_start_yuri_61283316:
    y "Как это романтично..."

translate russian ch3_start_yuri_bbe4458e:
    mc "А...?"

translate russian ch3_start_yuri_a272b51c:
    y 4c "П-прости!"

translate russian ch3_start_yuri_cb06f6f8:
    y "Я не хотела сказать ничего глупого...!"

translate russian ch3_start_yuri_f39335e9:
    mc "Дело не в этом, просто я не хотел, чтобы ты неправильно поняла."

translate russian ch3_start_yuri_df68ee98:
    mc "Мы с Сайори просто давно дружим, вот и всё."

translate russian ch3_start_yuri_139c99f2:
    y 2l "Ах... понятно..."

translate russian ch3_start_yuri_fe36a679:
    y 2f "Тогда, возможно, это и правда необычно, что она отмахивается, когда ты спрашиваешь о её чувствах..."

translate russian ch3_start_yuri_a137bb32:
    mc "А может, я просто слишком много себе надумываю..."

translate russian ch3_start_yuri_d98e9a0c:
    y 1u "[player]..."

translate russian ch3_start_yuri_ab280eb6:
    y "Мир полон смысла, который часто скрыт глубоко под тем, что лежит на поверхности."

translate russian ch3_start_yuri_b63c2d1d:
    y 1s "И за каждым человеком таится множество неразгаданных тайн — как бы хорошо ты его ни знал."

translate russian ch3_start_yuri_93deaf69:
    mc "А..."

translate russian ch3_start_yuri_718361da:
    mc "То есть ты думаешь, что за этим всё-таки может что-то стоять?"

translate russian ch3_start_yuri_9ceea5ad:
    y 1l "М-м..."

translate russian ch3_start_yuri_b6ef9812:
    y "Я думаю, что Сайори очень сложный человек."

translate russian ch3_start_yuri_0c505c13:
    y 1h "То, как она ведёт себя внешне, не всегда совпадает с тем, что творится у неё в голове..."

translate russian ch3_start_yuri_3cdc6d8c:
    y "И она не всегда знает, чего хочет."

translate russian ch3_start_yuri_2c978512:
    y "Я тоже заметила сегодня её странное поведение..."

translate russian ch3_start_yuri_9016fb99:
    y "И тоже за неё немного волнуюсь."

translate russian ch3_start_yuri_dddc1645:
    y 1f "Но, судя по тебе, она полностью занимала твои мысли, правда?"

translate russian ch3_start_yuri_c14c584c:
    mc "Ну..."

translate russian ch3_start_yuri_53686c03:
    mc "Пожалуй, так и было."

translate russian ch3_start_yuri_9fe5ba9f:
    y 3u "Сайори..."

translate russian ch3_start_yuri_da2ff30c:
    y "Она ведь правда... много для тебя значит?"

translate russian ch3_start_yuri_c25ffd48:
    mc "А— Я... н-наверное..."

translate russian ch3_start_yuri_425a7bc2:
    mc "Но не нужно так это формулировать!"

translate russian ch3_start_yuri_e6e65f33:
    mc "Мы просто хорошие друзья, вот и всё..."

translate russian ch3_start_yuri_53949ad8:
    y 2t "..."

translate russian ch3_start_yuri_b2c046ce:
    "Юри вдруг пристально смотрит мне в глаза."

translate russian ch3_start_yuri_ac02031e:
    "У неё мягкий и любопытный взгляд, будто она что-то ищет."

translate russian ch3_start_yuri_d72b8be5:
    "Смутившись, я отвожу глаза."

translate russian ch3_start_yuri_15b6e7d4:
    y 2m "Иногда..."

translate russian ch3_start_yuri_1e08d0e4:
    y "Тайны человека неведомы даже ему самому."

translate russian ch3_start_yuri_9e67dd5b:
    y 2a "А ты, такой честный и заботливый..."

translate russian ch3_start_yuri_31c1263b:
    y "Можешь открыть в себе чувства, о которых и не подозревал."

translate russian ch3_start_yuri_bb28d76b:
    y 4b "Т-то есть..."

translate russian ch3_start_yuri_e18ac8ca:
    y "Я думаю..."

translate russian ch3_start_yuri_c9253009:
    y "Ей бы очень повезло..."

translate russian ch3_start_yuri_1e1d3da7:
    y "Если бы ты... так к ней относился."

translate russian ch3_start_yuri_d90390e4:
    mc "Юри..."

translate russian ch3_start_yuri_d343240b:
    mc "Ты меня переоцениваешь."

translate russian ch3_start_yuri_3cd75302:
    mc "Я довольно простой парень."

translate russian ch3_start_yuri_6f75c5e2:
    mc "Так что, по-моему, в своих чувствах я разбираюсь неплохо."

translate russian ch3_start_yuri_da278827:
    mc "Я и близко не такой утончённый, как ты."

translate russian ch3_start_yuri_4003d0d4:
    y 2t "А-ах..."

translate russian ch3_start_yuri_9f821789:
    y "Это ведь... не комплимент, да?"

translate russian ch3_start_yuri_a4130810:
    mc "Как есть, так есть."

translate russian ch3_start_yuri_592bafde:
    mc "Ладно, раз уж мы тут, может, почитаем?"

translate russian ch3_start_yuri_9a41bed3:
    y 2s "Ну..."

translate russian ch3_start_yuri_22f80716:
    y "Если ты не против."

translate russian ch3_start_yuri_cf1adef2:
    mc "Ага."

translate russian ch3_start_yuri_5a750791:
    mc "Мне в любом случае стоит отвлечься от всего этого."

translate russian ch3_start_none_a20cefa7:
    "..."

translate russian ch3_start_none_90de9c4d:
    m "Итак, ребята!"

translate russian ch3_start_none_47502d00:
    "Через какое-то время Моника обращается ко всем в клубной комнате."

translate russian ch3_start_none_738e5e9f:
    m "Может, теперь поделимся стихами?"

translate russian ch3_start_none_bcc79eb8:
    "Не успеваю оглянуться, как всё возвращается в норму."

translate russian ch3_start_none_3f31fddb:
    "Все идут за своими стихами, и я тоже."

translate russian ch3_start_none_4cd498e1:
    "Я встречаюсь взглядом с Моникой, и она мне улыбается."

translate russian ch3_start_none_22f0f11e:
    "Интересно, о чём она говорила с Сайори..."

translate russian ch3_end_84df1cfa:
    m "...Итак, вы трое!"

translate russian ch3_end_0795937b:
    m "Мы ведь все закончили делиться стихами, да?"

translate russian ch3_end_3f9ab9c8:
    m "Давайте начнём решать—"

translate russian ch3_end_6ed1568a:
    n "Секундочку!"

translate russian ch3_end_ddcdae43:
    n "Мне кажется или ты только что сказала что-то странное?"

translate russian ch3_end_b74e685b:
    m 4d "А...?"

translate russian ch3_end_d6e4920b:
    y "Что-то и правда прозвучало необычно..."

translate russian ch3_end_d8b24c61:
    y "Верно."

translate russian ch3_end_4d8740f5:
    y 1f "Ты отступила от своей обычной коронной фразы, когда обращалась к клубу."

translate russian ch3_end_1c52c004:
    m "К-коронной фразы?"

translate russian ch3_end_aa1e6f7a:
    m "Нет у меня никакой коронной фразы..."

translate russian ch3_end_a8557d5c:
    n "Блин..."

translate russian ch3_end_2035e967:
    n "Почему сегодня такая странная атмосфера?"

translate russian ch3_end_42c8edbf:
    n "Смотри, даже Юри не устояла."

translate russian ch3_end_6559e79e:
    y "У-у..."

translate russian ch3_end_3d9092ae:
    y "Застоявшийся воздух — частое предзнаменование того, что вот-вот случится что-то ужасное..."

translate russian ch3_end_a4addc33:
    mc "Может, в {i}твоих{/i} книгах!"

translate russian ch3_end_e0420b13:
    mc "Слушайте, единственное отличие — что здесь нет Сайори."

translate russian ch3_end_728dcbc5:
    y "Ах..."

translate russian ch3_end_24e93c44:
    y "...Похоже, ты прав."

translate russian ch3_end_2a255601:
    m "Эх..."

translate russian ch3_end_6e2840f0:
    m 2d "Сайори ведь всегда помогает немного разрядить обстановку, правда?"

translate russian ch3_end_1991d387:
    m "Будто без неё у всех немного сбивается равновесие..."

translate russian ch3_end_5bb895ac:
    n "И куда она вообще умотала?"

translate russian ch3_end_badc8c5a:
    n "Я думала, она просто пописать вышла."

translate russian ch3_end_c171bf14:
    y "Нацуки, пожалуйста, имей приличие..."

translate russian ch3_end_a4c7577e:
    n "Ой, да ладно."

translate russian ch3_end_ccde1656:
    mc "А, вообще-то, ей было нехорошо, и она ушла домой пораньше..."

translate russian ch3_end_a8420f91:
    y "Правда...?"

translate russian ch3_end_6e3d4ad3:
    y "Надеюсь, с ней всё в порядке..."

translate russian ch3_end_1a9d476d:
    n "Серьёзно?"

translate russian ch3_end_27827478:
    n "Из всех дней, чтобы не пойти с ней домой, ты выбрал тот, когда ей плохо?"

translate russian ch3_end_02ca53a6:
    n "Вот тебе и все ваши нежности."

translate russian ch3_end_9b806679:
    mc "А— нет!"

translate russian ch3_end_6c0b543e:
    mc "Во-первых, хватит неправильно понимать мою дружбу с Сайори!"

translate russian ch3_end_c5e9a51b:
    mc "А во-вторых..."

translate russian ch3_end_ef83d2cf:
    mc "Она сегодня как будто избегала меня, так что я не хотел навязываться..."

translate russian ch3_end_f825c637:
    y "Хо-хо-о?"

translate russian ch3_end_c1dcd516:
    mc "{i}И это любопытное выражение — у Юри, из всех людей??{/i}"

translate russian ch3_end_23adc179:
    m "Успокойтесь, ребята...!"

translate russian ch3_end_9681b087:
    m 1d "Я с ней поговорила, и всё в порядке."

translate russian ch3_end_3c0d093e:
    mc "И что она сказала...?"

translate russian ch3_end_f71b2aa3:
    m 1a "В общем, нам нужно решить, что осталось подготовить к фестивалю, так что..."

translate russian ch3_end_4e27f33a:
    m "Давайте определимся, кто чем займётся на выходных."

translate russian ch3_end_4e7e7ba9:
    n "Я уже знаю, чем займусь {i}я{/i}!"

translate russian ch3_end_857b34c3:
    m "Верно."

translate russian ch3_end_517de665:
    m "Нацуки будет печь капкейки."

translate russian ch3_end_bf54fe4b:
    m "Но их может понадобиться много, и разных вкусов..."

translate russian ch3_end_40bd1ea9:
    m "Ты справишься с этим одна, Нацуки?"

translate russian ch3_end_cb4f44ae:
    n 4z "Вызов принят!"

translate russian ch3_end_bcecd721:
    m 1a "А что до меня..."

translate russian ch3_end_3e6b0e64:
    m "Я буду печатать и собирать все поэтические буклеты."

translate russian ch3_end_2b382450:
    m "Сайори поможет мне с оформлением."

translate russian ch3_end_61a14a34:
    m "А Юри..."

translate russian ch3_end_85faf29d:
    m 1d "..."

translate russian ch3_end_584fd974:
    m 3n "Юри, ты можешь..."

translate russian ch3_end_6ab3b3e0:
    m "Ах... Э-э..."

translate russian ch3_end_913a614e:
    n "...?"

translate russian ch3_end_8164653e:
    m "Девочки..."

translate russian ch3_end_87ace600:
    m "Поможешь мне придумать что-нибудь для Юри...?"

translate russian ch3_end_507dcdd3:
    y "Я..."

translate russian ch3_end_9f89b1eb:
    y "Я бесполезна..."

translate russian ch3_end_393eeed6:
    m "Н-нет!"

translate russian ch3_end_a7cf08f9:
    m "Вовсе нет!"

translate russian ch3_end_f0f62567:
    m "Ты ведь самая талантливая из нас, знаешь!"

translate russian ch3_end_bb2cf764:
    n "..."

translate russian ch3_end_b199ecd4:
    m 1g "Т-теперь и Нацуки дуется??"

translate russian ch3_end_b978ddfb:
    mc "Ну и ну, даже я теперь вижу..."

translate russian ch3_end_a013c0b5:
    mc "Наверное, я никогда не отдавал Сайори должного, но видно, что без неё тебе ещё тяжелее."

translate russian ch3_end_f0139694:
    m "Ах..."

translate russian ch3_end_c505dd66:
    m "Может, и так..."

translate russian ch3_end_28087115:
    m 1i "Но если я не научусь быть лидером сама по себе, то не вырасту как человек."

translate russian ch3_end_24d5fcdf:
    m 2i "Итак, Юри...!"

translate russian ch3_end_a1dda444:
    m 2a "У тебя ведь красивый почерк, знаешь?"

translate russian ch3_end_c7cb7c95:
    m "Так что тебе стоит сделать растяжки и украшения, чтобы создать атмосферу."

translate russian ch3_end_1dec6dd6:
    y "Атмосферу...?"

translate russian ch3_end_f34c48c6:
    y "Э-э, насчёт этого..."

translate russian ch3_end_507dcdd3_1:
    y "Я..."

translate russian ch3_end_1d085594:
    y 2r "Я обожаю атмосферу!"

translate russian ch3_end_46322d3e:
    "Выражение лица Юри вдруг меняется: она сосредоточенно смотрит в парту и начинает кивать сама себе."

translate russian ch3_end_7c92f7b8:
    mc "Вижу, у тебя уже голова вовсю работает..."

translate russian ch3_end_bdb3e427:
    m "Отлично!"

translate russian ch3_end_1c28d742:
    m "Ты очень поможешь, Юри."

translate russian ch3_end_7ec87b07:
    m 2a "Но в общем..."

translate russian ch3_end_c81e9fcd:
    m "Остался только ты, [player]."

translate russian ch3_end_8170e98d:
    mc "Тот, кто воистину бесполезен."

translate russian ch3_end_17695396:
    m "А-ха-ха! Не говори так."

translate russian ch3_end_f880bf6d:
    m 1b "Вообще..."

translate russian ch3_end_c8d0f130:
    m "У Нацуки и Юри довольно серьёзные задачи."

translate russian ch3_end_baa41005:
    m "Если помочь одной из них, это будет очень кстати."

translate russian ch3_end_2cab0f7d:
    m 1m "А ещё ты всегда можешь помочь мне..."

translate russian ch3_end_66cb881c:
    m 1a "Я была бы тебе очень благодарна."

translate russian ch3_end_f9d65918:
    mc "А—"

translate russian ch3_end_b7f7559b:
    mc "Это..."

translate russian ch3_end_790c6cbc:
    "Моника что, предлагает мне провести выходные с одной из участниц клуба?"

translate russian ch3_end_fa8ddbb9:
    "И как они вообще отреагируют на такое предложение...?"

translate russian ch3_end_728dcbc5_1:
    y "Ах..."

translate russian ch3_end_cb62efbe:
    y "Я... пожалуй, не откажусь от небольшой помощи..."

translate russian ch3_end_64cf539e:
    n "Ну, даже если ты не умеешь печь, для тебя всегда найдётся какая-нибудь грязная работа."

translate russian ch3_end_c42e0713:
    n 3q "Моника всё равно не оставит мне выбора, да и тебе нечего сидеть на попе ровно..."

translate russian ch3_end_16c45c35:
    "Нацуки бормочет кучу подобных отговорок."

translate russian ch3_end_a1300026:
    y "Э-э..."

translate russian ch3_end_554c5a10:
    y "Если я правильно помню, Нацуки..."

translate russian ch3_end_91c9e13d:
    y 2f "Ты говорила, что хочешь сама заняться выпечкой."

translate russian ch3_end_c75c53b7:
    y "[player], возможно, не захочет быть рядом, если ты выставляешь его помехой..."

translate russian ch3_end_61551706:
    y 2i "А следовательно..."

translate russian ch3_end_091ad47d:
    y "Он, возможно, больше подойдёт для помощи с украшениями."

translate russian ch3_end_745af0aa:
    n "Стоп! Ничего такого я не говорила!"

translate russian ch3_end_10705a29:
    n 4h "И вообще, что сложного в том, чтобы сделать пару украшений?"

translate russian ch3_end_a62fb946:
    n "По-моему, ты просто ищешь предлог, чтобы [player]—"

translate russian ch3_end_61efbc65:
    y "Ч-что ты такое говоришь?!"

translate russian ch3_end_2482de44:
    y "Это будет крайне кропотливая работа..."

translate russian ch3_end_51a03886:
    n "А выпечка, что ли, нет?"

translate russian ch3_end_e341b6f5:
    n "Ты вообще кем себя—"

translate russian ch3_end_560fd063:
    m "Девочки, девочки!"

translate russian ch3_end_b6eb34a3:
    m "Давайте немного успокоимся..."

translate russian ch3_end_594b9380:
    m 2d "В конце концов, думаю, [player] сам решит, чем хочет помочь."

translate russian ch3_end_85cbc2fa:
    m "К тому же..."

translate russian ch3_end_cce2d5ec:
    m 5 "Он ведь ещё толком не проводил время со мной, понимаете?"

translate russian ch3_end_3f602671:
    m "Так что, уверена, ему интересно—"

translate russian ch3_end_8b0b965e:
    n 4f "Ты {i}буквально{/i} только что сказала—"

translate russian ch3_end_34eb91a2:
    y "Я-я тоже удивлена!"

translate russian ch3_end_b396bff6:
    m "Простите, простите!"

translate russian ch3_end_a0ab1942:
    m "Я просто к слову..."

translate russian ch3_end_a8557d5c_1:
    n "Блин..."

translate russian ch3_end_6e7afd40:
    n "Может, уже решим?"

translate russian ch3_end_7e7f246d:
    m "Ну вот..."

translate russian ch3_end_96cefd3a:
    m "[player], ты ведь не против?"

translate russian ch3_end_210829fa:
    m 1a "В конце концов, решать тебе."

translate russian ch3_end_93deaf69:
    mc "А..."

translate russian ch3_end_1bf60051:
    mc "Конечно."

translate russian ch3_end_ffa2b290:
    n "Хмф."

translate russian ch3_end_51500451:
    y "Очень хорошо..."

translate russian ch3_end_148978dd:
    m "В таком случае..."

translate russian ch3_end_64979231:
    "Все смотрят прямо на меня."

translate russian ch3_end_8cbb49b3:
    "Поверить не могу!"

translate russian ch3_end_7bb2e7af:
    "[ch4_name!t] придёт ко мне домой в воскресенье...?"

translate russian ch3_end_f8f05de5:
    "Хоть я бы и предпочёл заняться этим с Сайори..."

translate russian ch3_end_62355466:
    "Тревога всё равно зашкаливает."

translate russian ch3_end_8b2d6fd7:
    "Пожалуй, я уже неплохо научился с ней ладить..."

translate russian ch3_end_9c64daec:
    "Но кто знает, что может случиться, когда мы окажемся за пределами школы?"

translate russian ch3_end_7447ffc7:
    "Она даже сказала, что ждёт этого с нетерпением..."

translate russian ch3_end_6a20a80d:
    "Я качаю головой."

translate russian ch3_end_e3832ce7:
    "Почему я так нервничаю, что об этом узнает Сайори?"

translate russian ch3_end_c22a5730:
    "Мы ведь не испытываем друг к другу {i}таких{/i} чувств..."

translate russian ch3_end_d1f0fb38:
    "К тому же, как сказала Моника, это ради клуба."

translate russian ch3_end_ae7e6de4:
    "Мне не о чем беспокоиться."

translate russian ch3_end_03715df7:
    "Если просто плыть по течению, я хорошо проведу время."

translate russian ch3_end_ad9ae7c8:
    "Тревога зашкаливает."

translate russian ch3_end_f05401bb:
    "Хоть я уже неплохо научился с ней ладить..."

translate russian ch3_end_c9299d7f:
    "Неизвестно, что может случиться, когда мы окажемся за пределами школы."

translate russian ch3_end_451ce4bc:
    "Более того... она сказала, что ждёт этого с нетерпением."

translate russian ch3_end_b6bc376f:
    "Может, это мой шанс, чтобы между нами что-то произошло?"

translate russian ch3_end_df118cce:
    "...Или для этого ещё рано?"

translate russian ch3_end_972e47a7:
    "Время покажет..."

translate russian ch3_end_e7f8ae2a:
    "Но до тех пор я не смогу думать ни о чём другом."

translate russian ch3_end_788cbacd:
    "Жду не дождусь!"

translate russian ch3_end_sayori_7136c946:
    mc "Ну..."

translate russian ch3_end_sayori_6cb4c996:
    mc "Если уж кому-то помогать, то я бы предпочёл Сайори."

translate russian ch3_end_sayori_b9e57242:
    mc "В смысле, мы и так соседи, и—"

translate russian ch3_end_sayori_3e76ae79:
    y "Но Моника сказала—"

translate russian ch3_end_sayori_a92bec08:
    n "Моника же сказала, что Сайори помогает ей!"

translate russian ch3_end_sayori_a8557d5c:
    n "Блин..."

translate russian ch3_end_sayori_0808ca59:
    n 4h "Ты нас что, так сильно ненавидишь?"

translate russian ch3_end_sayori_8acab5fb:
    mc "Н-нет!"

translate russian ch3_end_sayori_be22acf9:
    m "Простите, я не хотела, чтобы всё так усложнилось..."

translate russian ch3_end_sayori_dd9616f1:
    m "Просто подумай о клубе, хорошо?" nointeract

translate russian ch3_end_monika_eddfdb9f:
    mc "Ну, наверное, мне стоит помочь Монике..."

translate russian ch3_end_monika_c0f988c6:
    m "Ура, ты выбрал меня!"

translate russian ch3_end_monika_49aff3fd:
    n "Секундочку!"

translate russian ch3_end_monika_e0ae7e85:
    y "Д-да!"

translate russian ch3_end_monika_14815f7c:
    n "Моника, тебе помощь нужна меньше всех нас!"

translate russian ch3_end_monika_d7f49d58:
    m "А? Но..."

translate russian ch3_end_monika_025912d2:
    y "Я согласна с Нацуки."

translate russian ch3_end_monika_89c337b8:
    y 1l "Мало того что с твоей работой лучше всего справится один человек..."

translate russian ch3_end_monika_44d7e401:
    y "Так у тебя ещё и Сайори есть."

translate russian ch3_end_monika_f953990a:
    m 1p "Но ведь [player] сам..."

translate russian ch3_end_monika_f0139694:
    m "Ах..."

translate russian ch3_end_monika_e052c63e:
    n "Неважно."

translate russian ch3_end_monika_f4ab89bc:
    n "Это ты его запугала, чтобы он выбрал тебя."

translate russian ch3_end_monika_58de77c3:
    n 3e "Ты президент клуба, Моника."

translate russian ch3_end_monika_908fcc8b:
    n "Ты должна принимать ответственные решения ради клуба!"

translate russian ch3_end_monika_b5b5f310:
    y "Моника, не позволяй скрытым мотивам влиять на это решение."

translate russian ch3_end_monika_7137b361:
    m "Скрытым мотивам?"

translate russian ch3_end_monika_c89eb112:
    m "Ч-что ты такое говоришь, Юри?"

translate russian ch3_end_monika_537b0f2d:
    m "Вообще-то, похоже, это у вас скрытые мотивы!"

translate russian ch3_end_monika_42241b7e:
    n "{i}Прошу{/i} прощения?"

translate russian ch3_end_monika_391272cd:
    m "Иначе... никто бы не стал раздувать из этого такую проблему!"

translate russian ch3_end_monika_1ea45023:
    y "Это... совершенно неправда, Моника!"

translate russian ch3_end_monika_6a9ed22c:
    n "Да!"

translate russian ch3_end_monika_9b61eb34:
    n "У нас, между прочим, куча работы!"

translate russian ch3_end_monika_32392805:
    n "Если заставишь нас работать в одиночку, у нас выйдет хуже."

translate russian ch3_end_monika_72f25f1f:
    m "Ах... может... это и правда..."

translate russian ch3_end_monika_90309088:
    y "Подумай о клубе, Моника..."

translate russian ch3_end_monika_099d37d8:
    y "Если мы хотим, чтобы мероприятие удалось, нужно разумно распределить силы."

translate russian ch3_end_monika_619a4637:
    m "Э-э..."

translate russian ch3_end_monika_f0139694_1:
    m "Ах..."

translate russian ch3_end_monika_79ddc100:
    n "Так ты поступишь правильно, {i}госпожа президент{/i}?"

translate russian ch3_end_monika_a5c16eef:
    m "Ладно, ладно!"

translate russian ch3_end_monika_98dba970:
    m "Я поняла!"

translate russian ch3_end_monika_628ac17d:
    m 1r "Эх..."

translate russian ch3_end_monika_8cc24be7:
    m 1g "Формально... логичнее всего, чтобы [player] помог одной из вас двоих."

translate russian ch3_end_monika_252f3573:
    m "Так что..."

translate russian ch3_end_monika_a5a47c09:
    m 1c "Наверное... так и сделаем."

translate russian ch3_end_monika_8c85a419:
    m "У тебя есть предпочтения, [player]?" nointeract

translate russian ch3_end_natsuki_72753329:
    mc "Ну, печь вроде бы может быть весело..."

translate russian ch3_end_natsuki_8b428605:
    mc "И вы так описали, будто там куча работы, так что двое людей не помешают."

translate russian ch3_end_natsuki_be578dde:
    n "Не волнуйся!"

translate russian ch3_end_natsuki_ee4402d4:
    n "Печь — это ужасно весело!"

translate russian ch3_end_natsuki_2cb40953:
    n "Ты точно согласишься!"

translate russian ch3_end_natsuki_03a0fb4c:
    m "А?"

translate russian ch3_end_natsuki_349883c9:
    m "Ещё минуту назад ты говорила, что—"

translate russian ch3_end_natsuki_3849d692:
    n "Э-это потому что—!"

translate russian ch3_end_natsuki_bb2cf764:
    n "..."

translate russian ch3_end_natsuki_9416e03b:
    n "...Неважно, ясно?"

translate russian ch3_end_natsuki_fbf91cb8:
    m "Ну, в общем..."

translate russian ch3_end_natsuki_3511be36:
    m "Ты ведь справишься одна, правда, Юри?"

translate russian ch3_end_natsuki_d32f8ecc:
    y "Конечно."

translate russian ch3_end_natsuki_6b9c95e6:
    y "Мне не привыкать..."

translate russian ch3_end_natsuki_e612037c:
    m "..."

translate russian ch3_end_natsuki_2b35b6fe:
    mc "..."

translate russian ch3_end_natsuki_fab0e3be:
    m 1n "Это... хорошо..."

translate russian ch3_end_natsuki_0eca6f62:
    "Хоть Юри и драматизирует, трудно не почувствовать себя виноватым..."

translate russian ch3_end_natsuki_4e35f922:
    n "Так, значит, это всё, да?"

translate russian ch3_end_natsuki_215b38f4:
    n "Ещё что-нибудь нужно обсудить?"

translate russian ch3_end_natsuki_19cab300:
    m "Нет, думаю, это всё..."

translate russian ch3_end_natsuki_6013423a:
    m "Вы рады?"

translate russian ch3_end_natsuki_92cd0883:
    n "Да!"

translate russian ch3_end_natsuki_6fae5d5f:
    n "Всё, кроме выступления, будет офигенно!"

translate russian ch3_end_natsuki_7ff50c81:
    mc "По-моему, это не считается..."

translate russian ch3_end_natsuki_55b1fcf7:
    m "А ты, [player]?"

translate russian ch3_end_natsuki_9e6f11df:
    mc "Я?"

translate russian ch3_end_natsuki_ecb451a0:
    mc "А, ну, можно сказать, мне интересно, что из этого выйдет..."

translate russian ch3_end_natsuki_6c2e08ac:
    m "Меня это устраивает!"

translate russian ch3_end_natsuki_87e6cdc1:
    m "А ты, Юри?"

translate russian ch3_end_natsuki_5be9dd62:
    m 2d "...Юри?"

translate russian ch3_end_natsuki_2d301cc4:
    n "Она всё ещё дуется."

translate russian ch3_end_natsuki_71a86863:
    y "..."

translate russian ch3_end_natsuki_bb2cf764_1:
    n "..."

translate russian ch3_end_natsuki_1620f6e8:
    "Нацуки тоже начинает дуться."

translate russian ch3_end_natsuki_a5f2d4ba:
    n "Это не..."

translate russian ch3_end_natsuki_b4060d3b:
    n 5m "В смысле, это не такая уж большая проблема..."

translate russian ch3_end_natsuki_2dc04eee:
    mc "Ну, может, дело не только в этом..."

translate russian ch3_end_natsuki_913a614e:
    n "...?"

translate russian ch3_end_natsuki_8fbf7e6f:
    mc "Мне кажется, Юри просто в целом чувствует, что её недооценивают."

translate russian ch3_end_natsuki_6201ebd1:
    mc "Сначала для неё пришлось придумывать занятие, а потом никто не вызвался помочь."

translate russian ch3_end_natsuki_b968cef9:
    n 5q "Это ещё не значит..."

translate russian ch3_end_natsuki_bb2cf764_2:
    n "..."

translate russian ch3_end_natsuki_a51ccf38:
    n 5r "У-у..."

translate russian ch3_end_natsuki_8d78cf34:
    "Нацуки с тревогой переводит взгляд с одного на другого."

translate russian ch3_end_natsuki_10625f38:
    n 1u "Слушай..."

translate russian ch3_end_natsuki_1f6447c7:
    "Нацуки подходит и кладёт руки Юри на плечи."

translate russian ch3_end_natsuki_70537bc0:
    n 1h "Юри."

translate russian ch3_end_natsuki_1d910180:
    n "Ты правда самая талантливая из нас."

translate russian ch3_end_natsuki_7b96d186:
    n "И..."

translate russian ch3_end_natsuki_46f94ca7:
    n "И ты поможешь сделать мероприятие гораздо веселее и уютнее."

translate russian ch3_end_natsuki_744003af:
    n 1q "Ну, капкейки, наверное, тоже очень помогут..."

translate russian ch3_end_natsuki_557aaf44:
    n 3h "Но особую атмосферу создашь именно ты."

translate russian ch3_end_natsuki_91138a49:
    n "Это будет очень важно для того, что люди будут чувствовать во время выступлений."

translate russian ch3_end_natsuki_e2d9bd71:
    n "Так что..."

translate russian ch3_end_natsuki_b577b7cc:
    n 4w "Хватит тупить, цени себя хоть немного больше!"

translate russian ch3_end_natsuki_043aacda:
    "Нацуки убирает руки и отворачивается."

translate russian ch3_end_natsuki_1588679c:
    y 4a "..."

translate russian ch3_end_natsuki_0d80d29a:
    y "Ты ведь... не всерьёз это сказала?"

translate russian ch3_end_natsuki_2889c693:
    n "Э-э..."

translate russian ch3_end_natsuki_1de64ad5:
    n "Н-не совсем, но..."

translate russian ch3_end_natsuki_0d7060c4:
    "Удивлена не только Юри."

translate russian ch3_end_natsuki_73903abe:
    "Мы с Моникой тоже опешили от слов Нацуки."

translate russian ch3_end_natsuki_c7f10162:
    "Кто бы мог подумать, что именно Нацуки скажет что-то настолько ободряющее."

translate russian ch3_end_natsuki_877ff267:
    "Но я начинаю понимать."

translate russian ch3_end_natsuki_0af7d7c6:
    "Нацуки пыталась говорить как Сайори."

translate russian ch3_end_natsuki_f6652a81:
    "Пусть получилось не идеально, но видно, что она постаралась сказать то, что сказала бы в такой момент Сайори."

translate russian ch3_end_natsuki_c95f033e:
    "Потому что Сайори всегда помогает всем улыбаться и чувствовать себя хорошо."

translate russian ch3_end_natsuki_79221067:
    y "Прости... что тупила."

translate russian ch3_end_natsuki_415aa198:
    y 2i "Я буду стараться изо всех сил."

translate russian ch3_end_natsuki_797f7e12:
    y "И все вместе мы сделаем по-настоящему замечательное мероприятие."

translate russian ch3_end_natsuki_ed0b911f:
    n 5j "Ага."

translate russian ch3_end_natsuki_61ad1bd4:
    m "Да!"

translate russian ch3_end_natsuki_1367ad2e:
    m 2b "Надеюсь, все постараются изо всех сил."

translate russian ch3_end_natsuki_55fc6d3f:
    m "Но на этом..."

translate russian ch3_end_natsuki_14aa76e5:
    m "На сегодня всё."

translate russian ch3_end_natsuki_14049ddb:
    m "Так что, пожалуй, пора расходиться."

translate russian ch3_end_natsuki_0632b24f:
    n "Ладно, но я ещё немного здесь посижу."

translate russian ch3_end_natsuki_b9da110d:
    n "Сегодня я почти ничего не почитала, так что..."

translate russian ch3_end_natsuki_09e8a520:
    m "Справедливо, в этом нет ничего плохого."

translate russian ch3_end_natsuki_0e0522dd:
    "Все собирают вещи."

translate russian ch3_end_natsuki_0d216df6:
    "Я иду к двери следом за Моникой и Юри, которые о чём-то болтают между собой."

translate russian ch3_end_natsuki_fca049ae:
    n "Э-э, а ты куда?"

translate russian ch3_end_natsuki_bbe4458e:
    mc "А...?"

translate russian ch3_end_natsuki_f0a49c47:
    n 4c "Нам ещё нужно обсудить планы на выходные."

translate russian ch3_end_natsuki_98f75d12:
    n "Ты бы буквально пришёл домой и понял, что тебе даже не связаться со мной."

translate russian ch3_end_natsuki_8aea1b74:
    mc "А, точно..."

translate russian ch3_end_natsuki_e2645e57:
    mc "Понятия не имею, как это вылетело у меня из головы."

translate russian ch3_end_natsuki_a36684ce:
    n 2c "Блин, хорошо, что я тебя остановила."

translate russian ch3_end_natsuki_2f22555e:
    n "Я дам тебе свой номер, ясно?"

translate russian ch3_end_natsuki_0d6ba8de:
    n 2q "Только не вздумай делать из этого что-то странное!"

translate russian ch3_end_natsuki_12de3eea:
    mc "С чего бы мне...?"

translate russian ch3_end_natsuki_f36f981d:
    n 1s "Хмф..."

translate russian ch3_end_natsuki_a6837a06:
    "Нацуки даёт мне свой номер."

translate russian ch3_end_natsuki_d8e92e63:
    n 1c "Хорошо..."

translate russian ch3_end_natsuki_44fedd10:
    n "Я приду в воскресенье."

translate russian ch3_end_natsuki_6210fd19:
    n "Принесу все продукты."

translate russian ch3_end_natsuki_8b5e620a:
    mc "Подожди!"

translate russian ch3_end_natsuki_dec324fa:
    mc "Ты придёшь ко {i}мне{/i} домой?"

translate russian ch3_end_natsuki_b5970c82:
    n 2c "Ну да."

translate russian ch3_end_natsuki_8ec69281:
    n "А что такого?"

translate russian ch3_end_natsuki_7136c946:
    mc "Ну..."

translate russian ch3_end_natsuki_b895cfd8:
    mc "Я просто подумал, раз помогаю я, то и идти к тебе мне..."

translate russian ch3_end_natsuki_21d9dc91:
    n "Ага, как же."

translate russian ch3_end_natsuki_5d7ebee2:
    n 5x "Как будто я могу привести домой парня..."

translate russian ch3_end_natsuki_d252f728:
    n "Папа меня убьёт."

translate russian ch3_end_natsuki_a31340dd:
    mc "Правда?"

translate russian ch3_end_natsuki_f8234537:
    mc "Как-то строго, по-моему."

translate russian ch3_end_natsuki_8a847cea:
    n 5r "Ага, а мне каково, думаешь?"

translate russian ch3_end_natsuki_89629f09:
    n "Я ничего не могу делать, когда папа дома..."

translate russian ch3_end_natsuki_27706dbc:
    n 2q "Ладно... мне просто надо было на секунду пожаловаться."

translate russian ch3_end_natsuki_b8d6e764:
    n 2c "Теперь у нас есть номера друг друга."

translate russian ch3_end_natsuki_abfdd3e9:
    n "Это всё, что мне от тебя было нужно."

translate russian ch3_end_natsuki_fff1cebf:
    n "Наверное, напишу тебе, когда буду выходить."

translate russian ch3_end_natsuki_116b7f4e:
    mc "Хорошо, меня устраивает."

translate russian ch3_end_natsuki_2fe1bf98:
    n "Ага."

translate russian ch3_end_natsuki_bf607dbe:
    n 4a "Я тебе по-настоящему покажу, почему так люблю печь."

translate russian ch3_end_natsuki_bba9be11:
    n "Так что жди с нетерпением."

translate russian ch3_end_natsuki_ee87e6f3:
    mc "О?"

translate russian ch3_end_natsuki_17c480a1:
    mc "Ты же вроде говорила, что дашь мне только грязную работу?"

translate russian ch3_end_natsuki_52e841b5:
    n 1r "Ну—!"

translate russian ch3_end_natsuki_150b5684:
    n "Я... просто так сказала."

translate russian ch3_end_natsuki_45c46c46:
    n 1q "Не могла же я при всех показать..."

translate russian ch3_end_natsuki_e33d864d:
    n "Что жду этого."

translate russian ch3_end_natsuki_ad06b27f:
    mc "Стоп, правда??"

translate russian ch3_end_natsuki_a25aae4f:
    n 5w "Ну, вроде того!"

translate russian ch3_end_natsuki_efd79c0a:
    n "Просто потому что... я ещё никогда ни с кем не пекла вместе."

translate russian ch3_end_natsuki_0a3e6a2d:
    n 5h "Только поэтому, так что..."

translate russian ch3_end_natsuki_fd88a0aa:
    mc "Ладно, понял."

translate russian ch3_end_natsuki_bf85d064:
    mc "Прости, что так бурно отреагировал."

translate russian ch3_end_natsuki_fd09eb55:
    mc "В общем, я пойду."

translate russian ch3_end_natsuki_0ae1f5e7:
    mc "Увидимся в воскресенье."

translate russian ch3_end_natsuki_8209a018:
    n 5m "А—"

translate russian ch3_end_natsuki_bb2cf764_3:
    n "..."

translate russian ch3_end_natsuki_959a3ff3:
    n 5u "...Проехали."

translate russian ch3_end_yuri_749a08a8:
    mc "Ну, наверное, полезнее всего я буду, если помогу Юри..."

translate russian ch3_end_yuri_42ff488e:
    y 2n "М-мне...?"

translate russian ch3_end_yuri_cf30115f:
    n 4e "Ты серьёзно?"

translate russian ch3_end_yuri_75323e75:
    n "Зачем тебе—"

translate russian ch3_end_yuri_2abec0d2:
    m 1i "Нацуки."

translate russian ch3_end_yuri_83ee1800:
    m "Я уже вижу, что ты собираешься сказать какую-то гадость."

translate russian ch3_end_yuri_1ec86408:
    n 5r "Н-нет..."

translate russian ch3_end_yuri_ce56d35b:
    n "Я просто говорю—"

translate russian ch3_end_yuri_9ddd1f08:
    n "Фу..."

translate russian ch3_end_yuri_d363c92e:
    m 2a "Значит, ты будешь помогать Юри, [player]?"

translate russian ch3_end_yuri_cf1adef2:
    mc "Ага."

translate russian ch3_end_yuri_3016c490:
    mc "Так и сделаю."

translate russian ch3_end_yuri_6bac830a:
    y 1u "Я рада."

translate russian ch3_end_yuri_2c128542:
    y "У меня дурная привычка слишком много думать о таких вещах..."

translate russian ch3_end_yuri_ae1442df:
    y "Так что, думаю, твоя помощь будет очень кстати."

translate russian ch3_end_yuri_19af08d2:
    m "Здорово это слышать."

translate russian ch3_end_yuri_c5783589:
    m "Нацуки, ты справишься с выпечкой сама?"

translate russian ch3_end_yuri_9f5901b3:
    n 3w "Ну, да."

translate russian ch3_end_yuri_c13c493e:
    n "Я же уже сказала, что справлюсь."

translate russian ch3_end_yuri_4d36e93e:
    m 1i "Ладно, ладно..."

translate russian ch3_end_yuri_ddea86e0:
    "Всем видно, что Нацуки немного не в духе."

translate russian ch3_end_yuri_ec3ce0b9:
    mc "Так... это всё, что нужно было обсудить?"

translate russian ch3_end_yuri_df58724c:
    m 1a "Да, кажется, всё."

translate russian ch3_end_yuri_b79a4270:
    m 2a "Вы рады?"

translate russian ch3_end_yuri_c235eb7d:
    y 1i "Ну, «рада», может, и не то слово..."

translate russian ch3_end_yuri_b9b9a65b:
    y "Но, пожалуй, я немного жду этого."

translate russian ch3_end_yuri_ea26fc68:
    m "А ты что чувствуешь, [player]?"

translate russian ch3_end_yuri_9e6f11df:
    mc "Я?"

translate russian ch3_end_yuri_ecb451a0:
    mc "А, ну, можно сказать, мне интересно, что из этого выйдет..."

translate russian ch3_end_yuri_54f038f3:
    m 2b "Меня это устраивает!"

translate russian ch3_end_yuri_75d79227:
    m 2a "А ты, Нацуки?"

translate russian ch3_end_yuri_9977936e:
    n 5s "..."

translate russian ch3_end_yuri_d1b9b370:
    y 2h "Нацуки!"

translate russian ch3_end_yuri_25925cae:
    n 1o "Что??"

translate russian ch3_end_yuri_fa91afb8:
    n 1m "Чего все на меня кричат?"

translate russian ch3_end_yuri_53a1b496:
    n "Я же ничего не сделала...!"

translate russian ch3_end_yuri_07b50ad2:
    y 3n "Н-нет—!"

translate russian ch3_end_yuri_80300763:
    y "Я совсем не это имела в виду!"

translate russian ch3_end_yuri_ac74122e:
    y 3o "А-ах..."

translate russian ch3_end_yuri_6ce9125b:
    "Юри тревожно переводит взгляд с одного на другого."

translate russian ch3_end_yuri_62a736ae:
    y 2w "П-простите меня!"

translate russian ch3_end_yuri_066d8e4a:
    y 2v "Я не знаю, почему [player] выбрал меня..."

translate russian ch3_end_yuri_54029fe6:
    y "И ещё..."

translate russian ch3_end_yuri_6826bd26:
    y 2t "Твои капкейки — самые лучшие, какие я когда-либо пробовала!"

translate russian ch3_end_yuri_332616e3:
    y "Они так хорошо подходят к моему чаю!"

translate russian ch3_end_yuri_e1ba5a31:
    y "И ничто из того, что я сделаю для мероприятия, с ними не сравнится, так что..."

translate russian ch3_end_yuri_245c9079:
    y 4b "Так что..."

translate russian ch3_end_yuri_ddbc93f8:
    n 3q "Поняла я, поняла."

translate russian ch3_end_yuri_eadf5990:
    n 3h "Хотя я как-то удивлена..."

translate russian ch3_end_yuri_98704825:
    y "П-почему?"

translate russian ch3_end_yuri_12dbf8c7:
    n 3q "Э-э..."

translate russian ch3_end_yuri_787b8590:
    n "Ну, это я веду себя по-детски..."

translate russian ch3_end_yuri_504e7e29:
    n "Это я и так знаю."

translate russian ch3_end_yuri_65397568:
    n 5h "Но ты вдруг пытаешься меня подбодрить..."

translate russian ch3_end_yuri_63157d8c:
    y "Я-я знаю, что у меня это не очень получается..."

translate russian ch3_end_yuri_ec389ee1:
    y 2v "Прости, если сказала что-то не то!"

translate russian ch3_end_yuri_fa5aee3c:
    "Удивлена не только Нацуки."

translate russian ch3_end_yuri_e84d2e49:
    "Мы с Моникой тоже опешили от слов Юри."

translate russian ch3_end_yuri_88649469:
    "Ей и так трудно подбирать слова, а пытаться кого-то подбодрить — это, должно быть, далеко за пределами её зоны комфорта."

translate russian ch3_end_yuri_877ff267:
    "Но я начинаю понимать."

translate russian ch3_end_yuri_a4253212:
    "Юри пыталась говорить как Сайори."

translate russian ch3_end_yuri_f6652a81:
    "Пусть получилось не идеально, но видно, что она постаралась сказать то, что сказала бы в такой момент Сайори."

translate russian ch3_end_yuri_c95f033e:
    "Потому что Сайори всегда помогает всем улыбаться и чувствовать себя хорошо."

translate russian ch3_end_yuri_a5e020aa:
    n 1h "Нет..."

translate russian ch3_end_yuri_aeb8c782:
    n "Мне вроде как было приятно."

translate russian ch3_end_yuri_8efa0b11:
    n 1u "Прости... что раздула из ничего."

translate russian ch3_end_yuri_8f79c918:
    n 1m "Но вот что я скажу."

translate russian ch3_end_yuri_a430f515:
    y 2e "...?"

translate russian ch3_end_yuri_5629add4:
    n 4e "Можешь не сомневаться: мои капкейки будут лучшей частью всего мероприятия!"

translate russian ch3_end_yuri_dbf88eaa:
    y 2f "Ах..."

translate russian ch3_end_yuri_e0a588bf:
    y 1s "...Я тебе верю."

translate russian ch3_end_yuri_0af37af4:
    m 2b "Да!"

translate russian ch3_end_yuri_1d3f095c:
    m "Надеюсь, все постараются изо всех сил."

translate russian ch3_end_yuri_55fc6d3f:
    m "Но на этом..."

translate russian ch3_end_yuri_14aa76e5:
    m "На сегодня всё."

translate russian ch3_end_yuri_14049ddb:
    m "Так что, пожалуй, пора расходиться."

translate russian ch3_end_yuri_240402ee:
    n "Ладно, тогда пошли отсюда."

translate russian ch3_end_yuri_0e0522dd:
    "Все собирают вещи."

translate russian ch3_end_yuri_3f8dbcfe:
    "Я иду к двери следом за Моникой и Нацуки, которые о чём-то болтают между собой."

translate russian ch3_end_yuri_f951bfc8:
    y "Э-э-эм—!"

translate russian ch3_end_yuri_fb2e5377:
    mc "А?"

translate russian ch3_end_yuri_5986887c:
    "Я оборачиваюсь."

translate russian ch3_end_yuri_485fb852:
    y "Прости..."

translate russian ch3_end_yuri_521971d9:
    y 2s "Я поняла, что мне никак с тобой не связаться на выходных..."

translate russian ch3_end_yuri_3c370cbd:
    mc "А, ты права."

translate russian ch3_end_yuri_ca8651f2:
    mc "Не могу поверить, что это вылетело у меня из головы."

translate russian ch3_end_yuri_a96b1a5e:
    mc "Дать тебе мой номер телефона?"

translate russian ch3_end_yuri_7dd56a53:
    y 1a "Думаю... так будет лучше всего, да."

translate russian ch3_end_yuri_5059f8b1:
    mc "Хорошо, тогда..."

translate russian ch3_end_yuri_39c4f646:
    "Мы с Юри обмениваемся номерами."

translate russian ch3_end_yuri_0b77dadf:
    y "Хорошо."

translate russian ch3_end_yuri_7155d252:
    y "Тогда я зайду к тебе в воскресенье..."

translate russian ch3_end_yuri_fb2e5377_1:
    mc "А?"

translate russian ch3_end_yuri_31d3a4d0:
    mc "Ко мне домой?"

translate russian ch3_end_yuri_cfe43053:
    y 2t "Э-это проблема...?"

translate russian ch3_end_yuri_7ecf4f7c:
    mc "Нет, вовсе нет..."

translate russian ch3_end_yuri_0ff253ab:
    mc "Я просто подумал, что это я приду к тебе, раз уж помогаю я."

translate russian ch3_end_yuri_3b4d5a18:
    y "Ах, пожалуй, это логично..."

translate russian ch3_end_yuri_1e746cc8:
    y "Но если ты не против..."

translate russian ch3_end_yuri_281d3cd6:
    y 1u "Думаю, я бы предпочла прийти к тебе."

translate russian ch3_end_yuri_6651ab87:
    mc "Хорошо."

translate russian ch3_end_yuri_3dfd3780:
    mc "Тогда никаких проблем."

translate russian ch3_end_yuri_b05831e9:
    "Я решаю не выпытывать у Юри причину."

translate russian ch3_end_yuri_aff2603d:
    "В любом случае это не так уж важно, просто нужно будет прибраться в комнате."

translate russian ch3_end_yuri_f1c58b21:
    mc "Надеюсь, я хоть чем-то смогу быть полезен..."

translate russian ch3_end_yuri_d4598b2f:
    mc "У меня и близко нет твоей фантазии."

translate russian ch3_end_yuri_c76ca90d:
    y 1a "Не недооценивай себя, [player]."

translate russian ch3_end_yuri_a22f1a9b:
    y "Думаю, мы станем очень продуктивной командой."

translate russian ch3_end_yuri_54114af3:
    y 1u "Даже если ты выбрал меня только из жалости или вроде того..."

translate russian ch3_end_yuri_5973a68a:
    mc "Подожди...!"

translate russian ch3_end_yuri_247501df:
    mc "Ты ведь на самом деле так не думаешь?"

translate russian ch3_end_yuri_0dbaabdd:
    y 4b "..."

translate russian ch3_end_yuri_48f5cc95:
    y "Я... не знаю."

translate russian ch3_end_yuri_924431d9:
    y "Мне трудно придумать какую-то другую причину, по которой ты мог меня выбрать..."

translate russian ch3_end_yuri_d8a3a07b:
    mc "Ты забываешь самую очевидную причину!"

translate russian ch3_end_yuri_0c409d3f:
    mc "Я решил помогать тебе, потому что сам этого хочу."

translate russian ch3_end_yuri_4568f8ee:
    y 2v "Н-но..."

translate russian ch3_end_yuri_84bc3d23:
    "Юри с крайне напряжённым лицом о чём-то думает."

translate russian ch3_end_yuri_0b42cf34:
    mc "Юри... ты слишком много об этом думаешь."

translate russian ch3_end_yuri_40033046:
    mc "Ты ведь хотела, чтобы я говорил тебе, когда ты слишком много думаешь?"

translate russian ch3_end_yuri_d1820aca:
    y "А...?"

translate russian ch3_end_yuri_3d2e38f5:
    y 4 "Я... не заметила..."

translate russian ch3_end_yuri_3158a610:
    mc "Я тебе говорю: я сам хочу."

translate russian ch3_end_yuri_7584c8de:
    mc "Вот и всё."

translate russian ch3_end_yuri_cfe6e6b7:
    mc "Ты мне веришь?"

translate russian ch3_end_yuri_b4a282c8:
    y 1t "Я..."

translate russian ch3_end_yuri_c1b1352a:
    "Юри снова напряжённо думает."

translate russian ch3_end_yuri_91d334e6:
    "Она долго смотрит мне прямо в глаза."

translate russian ch3_end_yuri_7f627e4a:
    y 3l "...Я тебе верю!"

translate russian ch3_end_yuri_0ace9a63:
    "Будто это стоило ей огромных усилий, Юри наконец произносит это, и выражение её лица смягчается."

translate russian ch3_end_yuri_83916e61:
    y 3s "И я очень жду воскресенья."

translate russian ch3_end_yuri_69c25b65:
    mc "Да..."

translate russian ch3_end_yuri_1c6fc136:
    mc "Я тоже."

translate russian ch3_end_yuri_330007c6:
    "После этого я выхожу за дверь, и Юри идёт следом."
