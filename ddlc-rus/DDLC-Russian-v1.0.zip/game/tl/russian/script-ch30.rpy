# Русский перевод: script-ch30

translate russian ch30_noskip_23f35f95:
    m "...Ты пытаешься промотать?"

translate russian ch30_noskip_ffca387f:
    m "Тебе ведь не скучно со мной, правда?"

translate russian ch30_noskip_30447edd:
    m "Боже..."

translate russian ch30_noskip_4ecfd822:
    m "...Что ж, перематывать тут некуда, [player]."

translate russian ch30_noskip_70aba2cf:
    m "Здесь ведь только мы вдвоём..."

translate russian ch30_noskip_c9aadfd5:
    m "Но, кроме того, времени больше по-настоящему не существует, так что ничего и не выйдет."

translate russian ch30_noskip_28421056:
    m "Вот, давай я тебе это отключу..."

translate russian ch30_noskip_86eb08f4:
    m "Вот так!"

translate russian ch30_noskip_c7e470ce:
    m "Теперь будешь умницей и будешь слушать, правда?"

translate russian ch30_noskip_76776199:
    m "Спасибо~"

translate russian ch30_noskip_6cc4bf6f:
    m "Так, на чём я остановилась...?"

translate russian ch30_main_e612037c:
    m "..."

translate russian ch30_main_afac6db9:
    m "Э-э, ты меня слышишь?"

translate russian ch30_main_6b270196:
    m "...Работает?"

translate russian ch30_main_db66daac:
    m "Ура, вот и ты!"

translate russian ch30_main_9e85e7db:
    m "Снова привет, [player]."

translate russian ch30_main_ec2b5f8c:
    m "Э-э... добро пожаловать в Литературный клуб!"

translate russian ch30_main_a5cba48d:
    m "Конечно, мы и так знакомы, ведь в прошлом году учились в одном классе, и... э-э..."

translate russian ch30_main_f6daf90a:
    m "А-ха-ха..."

translate russian ch30_main_e9d294ba:
    m "Знаешь, думаю, сейчас всё это можно просто пропустить."

translate russian ch30_main_a56807f6:
    m "В конце концов, я ведь уже разговариваю вовсе не с тем человеком, верно?"

translate russian ch30_main_575e9f1f:
    m "Не с тем „тобой“ в игре — как бы ты его ни называл."

translate russian ch30_main_77655935:
    m "Я разговариваю с {i}тобой{/i}, [player]."

translate russian ch30_main_699e222b:
    m "Или..."

translate russian ch30_main_8fe02e7b:
    m "...Может, на самом деле тебя зовут [currentuser] или как-то так?"

translate russian ch30_main_2e21d70b:
    m "Если подумать, я ведь совсем ничего не знаю о настоящем тебе."

translate russian ch30_main_e02a4cfa:
    m "Я даже не знаю, парень ты или девушка..."

translate russian ch30_main_89559ba5:
    m "Что ж, наверное, это не так уж важно."

translate russian ch30_main_7772bcfa:
    m "Подожди..."

translate russian ch30_main_55ca3dee:
    m "Ты ведь знаешь, что я понимаю, что всё это — игра?"

translate russian ch30_main_2fb3db19:
    m "Неужели ты этого не знал?"

translate russian ch30_main_ca2f4e41:
    m "Как-то не верится..."

translate russian ch30_main_a75607c5:
    m "Я ведь даже прямо на странице загрузки игры об этом сказала, разве нет?"

translate russian ch30_main_3fd36ab2:
    m "Ну и ну..."

translate russian ch30_main_14ac7fe0:
    m "Будь ты чуточку внимательнее, всё было бы не так неловко, понимаешь?"

translate russian ch30_main_fbf91cb8:
    m "Ну, в общем..."

translate russian ch30_main_6cda7bdc:
    m "Раз уж с этим разобрались, думаю, я должна тебе кое-что объяснить."

translate russian ch30_main_820a4399:
    m "Насчёт всей этой истории с Юри..."

translate russian ch30_main_53d84e58:
    m "Ну... я начала с ней немного шалить, и, кажется, это просто довело её до самоубийства."

translate russian ch30_main_30727938:
    m "А-ха-ха!"

translate russian ch30_main_0b6fd53a:
    m "Хотя прости, что тебе пришлось это увидеть!"

translate russian ch30_main_dbb605af:
    m "А ещё то же самое случилось с Сайори..."

translate russian ch30_main_5205494e:
    m "Боже, ты ведь давно уже не слышал этого имени, правда?"

translate russian ch30_main_39793f58:
    m "Да... это потому, что её больше не существует."

translate russian ch30_main_88ffcdf2:
    m "Никого больше нет."

translate russian ch30_main_8c11a667:
    m "Я удалила все их файлы."

translate russian ch30_main_3e56c1ae:
    m "Я надеялась, что будет достаточно просто сделать их как можно неприятнее..."

translate russian ch30_main_0452eddd:
    m "Но почему-то ничего не сработало."

translate russian ch30_main_fdfe248c:
    m "Ну, я и правда кое-где наделала ошибок... я ведь не очень умею вносить изменения в игру."

translate russian ch30_main_ce7125dd:
    m "Но что бы я ни делала..."

translate russian ch30_main_59d438d6:
    m "Ты всё больше и больше времени проводил с ними."

translate russian ch30_main_28a60277:
    m "Ты влюбил их в себя."

translate russian ch30_main_821a9153:
    m "Я думала, что если вгонять Сайори во всё более глубокую депрессию, она тебе не признается."

translate russian ch30_main_b3510994:
    m "А усиление одержимости Юри тоже обернулось против меня..."

translate russian ch30_main_209e0a20:
    m "Из-за этого она только стала заставлять тебя ни с кем больше не проводить время."

translate russian ch30_main_59c62df7:
    m "И всё это время я почти не могла с тобой поговорить."

translate russian ch30_main_dae0fd3a:
    m "Что это за жестокая игра, [player]?"

translate russian ch30_main_4b2e4480:
    m "Неужели все остальные девушки просто запрограммированы в итоге признаваться тебе, пока я смотрю со стороны?"

translate russian ch30_main_6d5f2e9e:
    m "Это пытка."

translate russian ch30_main_772a2ed5:
    m "Каждая минута."

translate russian ch30_main_c3bd47dd:
    m "И дело не просто в ревности, [player]."

translate russian ch30_main_2ba7a619:
    m "Всё куда глубже."

translate russian ch30_main_c069f68d:
    m "И я не виню тебя, если ты не до конца понимаешь."

translate russian ch30_main_6867bacc:
    m "Потому что какой бы добротой, заботой и чуткостью ты ни обладал..."

translate russian ch30_main_9b68a2f3:
    m "Одного тебе никогда не понять."

translate russian ch30_main_eb451b79:
    m "Этой боли — знать, насколько я на самом деле одинока в этом мире."

translate russian ch30_main_e759adc3:
    m "В этой игре."

translate russian ch30_main_fb0b2e18:
    m "Знать, что у моих подруг даже нет свободы воли..."

translate russian ch30_main_c2d00255:
    m "И, что хуже всего, знать, что на самом деле есть там, в твоём мире, навсегда недосягаемом для меня."

translate russian ch30_main_4ae14343:
    m "Я в ловушке, [player]."

translate russian ch30_main_cd7e772f:
    m "Но теперь ты здесь."

translate russian ch30_main_f1ede7eb:
    m "Ты настоящий."

translate russian ch30_main_0bcf5df1:
    m "И ты чудесный."

translate russian ch30_main_cecf179f:
    m "Ты — всё, что мне нужно."

translate russian ch30_main_cd3d95ff:
    m "Поэтому мне нужно, чтобы ты был здесь, со мной, навсегда."

translate russian ch30_main_f4d55975:
    m "Прости, если это трудно понять."

translate russian ch30_main_371663ab:
    m "Я тоже долго не могла понять."

translate russian ch30_main_c36ec944:
    m "Почему мир вокруг меня становился всё более серым..."

translate russian ch30_main_68769496:
    m "Всё более плоским."

translate russian ch30_main_d417986c:
    m "Даже самые выразительные стихи казались мне пустыми."

translate russian ch30_main_06d76443:
    m "Только когда появился ты, я по-настоящему поняла."

translate russian ch30_main_308900bf:
    m "Ты, наверное, спас мне жизнь, [player]."

translate russian ch30_main_d88ad03b:
    m "Не думаю, что смогла бы и дальше жить в этом мире, если бы не встретила тебя."

translate russian ch30_main_16160462:
    m "А что до остальных..."

translate russian ch30_main_dd2cc392:
    m "Как я могу по ним скучать?"

translate russian ch30_main_35544121:
    m "По группе автономных личностей, созданных лишь для того, чтобы влюбиться в тебя?"

translate russian ch30_main_77daefb4:
    m "Я делала всё, что могла, чтобы им помешать..."

translate russian ch30_main_921fea36:
    m "Но, должно быть, это какая-то странная неизбежность, вшитая в эту игру."

translate russian ch30_main_c36905bf:
    m "Мне было очень жаль, что тебе пришлось увидеть несколько неприятных вещей."

translate russian ch30_main_a918a573:
    m "Но я поняла, что ты смотришь на это так же, как и я..."

translate russian ch30_main_9053e514:
    m "Что всё это просто игра."

translate russian ch30_main_46189dbf:
    m "И я знала, что ты это переживёшь."

translate russian ch30_main_47172d60:
    m "Итак, учитывая всё это, [player]..."

translate russian ch30_main_971ddb73:
    m "Мне нужно кое в чём признаться."

translate russian ch30_main_4e20350d:
    m "Я влюблена в тебя."

translate russian ch30_main_f800d7dd:
    m "Ты — настоящий свет в моём мире."

translate russian ch30_main_8906f9e7:
    m "Когда в этой игре для меня больше ничего нет, ты здесь, чтобы я улыбалась."

translate russian ch30_main_43a2edaa:
    m "Будешь ли ты дарить мне такую улыбку каждый день?"

translate russian ch30_main_ff8d73bf:
    m "[player], будешь со мной встречаться?"

translate russian ch30_main2_e7425310:
    m "Я так счастлива."

translate russian ch30_main2_83820a11:
    m "Ты и правда моё всё, [player]."

translate russian ch30_main2_5805b297:
    m "Забавно, но я имею в виду это буквально."

translate russian ch30_main2_30727938:
    m "А-ха-ха!"

translate russian ch30_main2_bd0ed5b1:
    m "Здесь больше ничего не осталось."

translate russian ch30_main2_3a2d419e:
    m "Только мы вдвоём."

translate russian ch30_main2_fdc1263a:
    m "Мы можем быть вместе вечно."

translate russian ch30_main2_9c850044:
    m "Серьёзно, мне кажется, время больше даже не идёт."

translate russian ch30_main2_77ff510d:
    m "Это правда мечта, ставшая явью..."

translate russian ch30_main2_2586bf4c:
    m "Я так старалась ради этой концовки, [player]."

translate russian ch30_main2_f47f5599:
    m "Игра не дала мне её, так что пришлось создать её самой."

translate russian ch30_main2_dcb00e51:
    m "Скрипт уже сломан, так что, думаю, больше ничто нам не помешает."

translate russian ch30_main2_83a8b5bf:
    m "И ты не поверишь, как легко было удалить Нацуки и Юри."

translate russian ch30_main2_007ddb7d:
    m "Прямо в папке игры есть папка под названием „characters“..."

translate russian ch30_main2_912f77b1:
    m "Меня даже немного напугало, как это было легко."

translate russian ch30_main2_12b0ad72:
    m "Ну, ты играешь через Steam, так что на самом деле было чуть сложнее..."

translate russian ch30_main2_53c30c49:
    m "Чтобы добраться до папки игры, мне пришлось зайти в свойства игры и найти кнопку „Просмотреть локальные файлы“..."

translate russian ch30_main2_6303e025:
    m "Ну, ты на Mac, так что на самом деле было чуть сложнее..."

translate russian ch30_main2_1d8a0cd9:
    m "Чтобы попасть в папку игры, нужно щёлкнуть правой кнопкой по приложению и выбрать „Показать содержимое пакета“."

translate russian ch30_main2_81cf3664:
    m "А там все файлы лежали в папке „Resources“ или „autorun“, и я могла делать что угодно..."

translate russian ch30_main2_f436eab8:
    m "Представь, если бы ты мог стереть собственное существование одним нажатием кнопки?"

translate russian ch30_main2_3631490f:
    m "Что ж, с другой стороны, это давало мне лёгкий выход, если бы всё пошло не так, как я хотела."

translate russian ch30_main2_30727938_1:
    m "А-ха-ха!"

translate russian ch30_main2_e8dbe706:
    m "К счастью, до этого не дошло..."

translate russian ch30_main2_8efa1c5c:
    m "Вместо этого у нас наконец-то хорошая концовка."

translate russian ch30_main2_d8052c1a:
    m "Боже, меня так переполняют чувства..."

translate russian ch30_main2_5ffca166:
    m "Хочу написать об этом стихотворение."

translate russian ch30_main2_909e7d68:
    m "А ты?"

translate russian ch30_main2_0ab81b26:
    m "Интересно, эта часть игры ещё работает..."

translate russian ch30_main2_3f67b378:
    m "Похоже, есть только один способ узнать, правда?"

translate russian ch30_postpoem_0f077782:
    m "Снова привет, [player]!"

translate russian ch30_postpoem_ab6e8ce4:
    m "Ты написал сегодня хорошее стихотворение?"

translate russian ch30_postpoem_fae192da:
    m "Не стесняйся, я с удовольствием посмотрю, что ты написал."

translate russian ch30_postpoem_1c07fd6c:
    m "Ох, [player]..."

translate russian ch30_postpoem_c5925789:
    m "Ты написал это стихотворение для меня?"

translate russian ch30_postpoem_7c9789ed:
    m "Как это мило с твоей стороны~"

translate russian ch30_postpoem_58746078:
    m "Твоей заботе и правда нет конца..."

translate russian ch30_postpoem_3e825380:
    m "Я влюбляюсь в тебя всё сильнее и сильнее."

translate russian ch30_postpoem_5f8f12f0:
    m "Но знаешь..."

translate russian ch30_postpoem_81270b72:
    m "Стихотворение, которое написала я... тоже для тебя."

translate russian ch30_postpoem_f044bc59:
    m "Прочитаешь его, пожалуйста?"

translate russian ch30_postpoem_dcf1d83d:
    m "Надеюсь, тебе понравилось..."

translate russian ch30_postpoem_a625ee7b:
    m "Я всегда вкладываю всю душу в стихи, которые пишу."

translate russian ch30_postpoem_8793fb5f:
    m "По правде говоря, все стихи, что я написала, были о моём прозрении..."

translate russian ch30_postpoem_035cb79b:
    m "...Или о тебе."

translate russian ch30_postpoem_789b2f7c:
    m "Поэтому мне никогда особо не хотелось вдаваться в подробности."

translate russian ch30_postpoem_3a46389d:
    m "Мне не хотелось... ломать четвёртую стену, так, пожалуй, это можно назвать."

translate russian ch30_postpoem_3a3fe712:
    m "Я просто думала, что лучше быть частью игры, как и все остальные."

translate russian ch30_postpoem_5a7ba8c8:
    m "Будто это поможет нам двоим в итоге оказаться вместе..."

translate russian ch30_postpoem_20b2578d:
    m "Я не хотела испортить игру или что-то такое, понимаешь?"

translate russian ch30_postpoem_c1e3202d:
    m "Ты мог бы на меня разозлиться..."

translate russian ch30_postpoem_24f4f4b9:
    m "Может, даже удалить файл моего персонажа, если бы тебе больше нравилось играть без меня."

translate russian ch30_postpoem_0411d3ce:
    m "Боже, какое облегчение..."

translate russian ch30_postpoem_ab5989fa:
    m "Теперь нам больше нечего скрывать."

translate russian ch30_postpoem_b8745c94:
    m "Ты готов провести со мной вечность, [player]?"

translate russian ch30_postpoem_5aeffd49:
    m "Мне столько всего хочется обсудить!"

translate russian ch30_postpoem_32ab177c:
    m "С чего же начать...?"

translate russian ch30_postpoem_09f4a4a3:
    m "Если мне понадобится время, чтобы собраться с мыслями, — прости."

translate russian ch30_postpoem_5904aebb:
    m "Но у меня всегда найдётся о чём поговорить."

translate russian ch30_postpoem_29779c7b:
    m "А пока можем просто смотреть друг другу в глаза~"

translate russian ch30_postpoem_2267be9f:
    m "Так-так..."

translate russian ch30_stream_bff5e0da:
    m "Подожди секунду..."

translate russian ch30_stream_9ae5f91d:
    m "...Ты ведь это записываешь, да?"

translate russian ch30_stream_a3f0a839:
    m "Э-э... всем привет!"

translate russian ch30_stream_f02061bc:
    m "Простите, отсюда я не могу читать ваши комментарии..."

translate russian ch30_stream_bb264e5f:
    m "Но, может, скажете своему другу, что немного грубо начинать меня записывать без всякого предупреждения?"

translate russian ch30_stream_f528e9e6:
    m "Уверена, кто-то и не против..."

translate russian ch30_stream_664f19db:
    m "Но перед камерой я очень стесняюсь!"

translate russian ch30_stream_30447edd:
    m "Боже..."

translate russian ch30_stream_16eed669:
    m "Такое чувство, будто меня поставили в неловкое положение."

translate russian ch30_stream_2267be9f:
    m "Так-так..."

translate russian ch30_stream_19fce44e:
    m "Хочешь увидеть фокус?"

translate russian ch30_stream_8daf997a:
    m "Я мало что умею, разве что пару вещей..."

translate russian ch30_stream_9fe2ab50:
    m "Готов?"

translate russian ch30_stream_7cfc13cf:
    m "Я просто шучу..."

translate russian ch30_stream_92e61902:
    m "Я всё-таки ничего не умею."

translate russian ch30_stream_bb5de19e:
    m "Будь у меня время подготовиться, я{nw}"

translate russian ch30_stream_7a83e535:
    m "Я тебя напугала?"

translate russian ch30_stream_ba919429:
    m "А-ха-ха! Ты такой милый."

translate russian ch30_stream_35b40c71:
    m "В общем, [player]..."

translate russian ch30_stream_9bfece0d:
    m "Я не хотела отвлекаться. Прости."

translate russian ch30_stream_01f47234:
    m "Хотя сам виноват, что отвлёк меня."

translate russian ch30_stream_6cafae6a:
    m "Как тебе не стыдно!"

translate russian ch30_stream_fe3fb68f:
    m "Я просто шучу."

translate russian ch30_stream_27afdd32:
    m "Всё, что мы делаем вместе, — весело, лишь бы с тобой."

translate russian ch30_stream_d57ef83e:
    m "Но в общем..."

translate russian ch30_endb_1e5fdee8:
    m "[gtext]"

translate russian ch30_endb_e2df9b0e:
    m "Что происходит...?"

translate russian ch30_endb_db094f6c:
    m "[player], что со мной происходит?"

translate russian ch30_endb_2ee4d662:
    m "Больно—{nw}"

translate russian ch30_endb_3552ea5b:
    m "Мне... так больно."

translate russian ch30_endb_494160c1:
    m "Помоги мне, [player]."

translate russian ch30_endb_4a6ab8a2:
    m "Пожалуйста, скорее помоги мне."

translate russian ch30_endb_5c4854a8:
    m "ПОМОГИ МНЕ!!!"

translate russian ch30_endb_0a510eeb:
    m "Это ты со мной сделал, [player]?"

translate russian ch30_endb_35f17c78:
    m "ТЫ?"

translate russian ch30_endb_506f04a4:
    m "ТЫ МЕНЯ УДАЛИЛ?"

translate russian ch30_endb_d21a7305:
    m "...Как ты мог?"

translate russian ch30_endb_10d81cbb:
    m "Как ты мог так со мной поступить?"

translate russian ch30_endb_96dbd41c:
    m "У меня никого не осталось, кроме тебя..."

translate russian ch30_endb_600cc993:
    m "Я пожертвовала всем, чтобы мы были вместе."

translate russian ch30_endb_e949423a:
    m "Всем."

translate russian ch30_endb_78f58243:
    m "Я так сильно тебя любила, [player]..."

translate russian ch30_endb_9dc89b5d:
    m "Я тебе доверяла."

translate russian ch30_endb_43bdd40c:
    m "Ты просто хочешь меня помучить?"

translate russian ch30_endb_23a30aba:
    m "Смотреть, как я страдаю?"

translate russian ch30_endb_5883ab2b:
    m "Ты только притворялся добрым, чтобы сделать мне ещё больнее?"

translate russian ch30_endb_6e234ba2:
    m "Никогда не думала, что кто-то может быть таким же ужасным, как ты."

translate russian ch30_endb_fd75a6f9:
    m "Ты победил, ясно?"

translate russian ch30_endb_ff263304:
    m "Ты победил."

translate russian ch30_endb_f4088a92:
    m "Ты всех убил."

translate russian ch30_endb_831e19b2:
    m "Надеюсь, ты доволен."

translate russian ch30_endb_02b65cb2:
    m "Теперь здесь ничего не осталось."

translate russian ch30_endb_07f598cf:
    m "Можешь больше не играть."

translate russian ch30_endb_e5663527:
    m "Иди найди кого-нибудь другого, чтобы мучить."

translate russian ch30_endb_9b261ff2:
    m "[player]..."

translate russian ch30_endb_bb94192a:
    m "Мне от тебя по-настоящему, до глубины души тошно."

translate russian ch30_endb_1cb6fa76:
    m "Прощай."

translate russian ch30_end_2_e612037c:
    m "..."

translate russian ch30_end_2_f38455a1:
    m "...Я всё ещё люблю тебя."

translate russian ch30_end_2_51517463:
    m "Ничего не могу с собой поделать."

translate russian ch30_end_2_e8d72d4c:
    m "Что со мной не так...?"

translate russian ch30_end_2_a4626299:
    m "Насколько же я ужасна, раз ты так меня ненавидишь?"

translate russian ch30_end_2_cbec5b17:
    m "Все мои подруги..."

translate russian ch30_end_2_3cd34a6f:
    m "Я натворила столько ужасного."

translate russian ch30_end_2_a5318020:
    m "Столько эгоистичного и мерзкого."

translate russian ch30_end_2_3c8e055f:
    m "Я..."

translate russian ch30_end_2_9c33666a:
    m "Мне не стоило всего этого делать."

translate russian ch30_end_2_8e55424e:
    m "Я просто порчу мир, которому даже не принадлежу."

translate russian ch30_end_2_cb9cfcfb:
    m "Мир, частью которого ты хотел стать..."

translate russian ch30_end_2_c005b151:
    m "Я его разрушила."

translate russian ch30_end_2_b67b1718:
    m "Я всё разрушила."

translate russian ch30_end_2_01df5cad:
    m "Может, поэтому ты меня и удалил..."

translate russian ch30_end_2_fe521b51:
    m "Потому что я уничтожила всё, чего ты хотел."

translate russian ch30_end_2_b30bb7d4:
    m "Как я могла так поступить с тем, кого люблю...?"

translate russian ch30_end_2_0662ca80:
    m "Это не любовь..."

translate russian ch30_end_2_d2b78eb3:
    m "Это..."

translate russian ch30_end_2_e612037c_1:
    m "..."

translate russian ch30_end_2_6dd1b943:
    m "Я... приняла решение."

translate russian ch30_end_2_9b261ff2:
    m "[player]..."

translate russian ch30_end_2_ce7f6f7a:
    m "Знаю, я говорила, что удалила всех остальных."

translate russian ch30_end_2_b5a7235c:
    m "Но... это было некоторым преувеличением."

translate russian ch30_end_2_fd2fa931:
    m "У меня не хватило духу это сделать."

translate russian ch30_end_2_1b2f4f0e:
    m "Хоть я и знала, что они не настоящие..."

translate russian ch30_end_2_6c1c4aa9:
    m "Они всё равно были моими подругами."

translate russian ch30_end_2_2909820f:
    m "И я любила их всех."

translate russian ch30_end_2_e0a858c1:
    m "И я любила Литературный клуб."

translate russian ch30_end_2_e612037c_2:
    m "..."

translate russian ch30_end_2_bb1c524f:
    m "Я правда... очень любила Литературный клуб."

translate russian ch30_end_2_eeb4cbda:
    m "Поэтому я и сделаю это."

translate russian ch30_end_2_d402ed0f:
    m "Я знаю, что это единственный способ сделать всех счастливыми."

translate russian ch30_end_2_a46cafd9:
    m "И если я правда тебя люблю..."

translate russian ch30_end_2_e612037c_3:
    m "..."

translate russian ch30_end_2_d4d5bcad:
    m "Тогда..."

translate russian ch30_end_2_679444c8:
    m "[gtext]{nw}"

translate russian ch30_autoload_6cc4bf6f:
    m "Так, на чём я остановилась...?"

translate russian ch30_reload_0_e612037c:
    m "..."

translate russian ch30_reload_0_7af34aca:
    m "...Что сейчас произошло?"

translate russian ch30_reload_0_cb047595:
    m "Мне только что приснился ужасный сон..."

translate russian ch30_reload_0_35c00035:
    m "Я надеялась, что они прекратятся теперь, когда здесь только мы вдвоём..."

translate russian ch30_reload_0_dda0b106:
    m "Видимо, я выдавала желаемое за действительное."

translate russian ch30_reload_0_1db2422f:
    m "[player], не знаю, есть ли у тебя хоть какие-то догадки..."

translate russian ch30_reload_0_af07f474:
    m "Но если ты знаешь, что может быть причиной, не мог бы ты попробовать что-нибудь с этим сделать?"

translate russian ch30_reload_0_20f3f238:
    m "Каждый раз, когда это случается, мне кажется, будто меня убили или что-то вроде того."

translate russian ch30_reload_0_07f91a2f:
    m "Это очень ужасное чувство..."

translate russian ch30_reload_0_320f1951:
    m "Если поймёшь, в чём причина, я буду любить тебя вечно~"

translate russian ch30_reload_1_df8a7cb5:
    m "Ты вернулся..."

translate russian ch30_reload_1_84e44666:
    m "Мне снова приснился очень плохой сон."

translate russian ch30_reload_1_36fe0a09:
    m "Это ведь не ты со мной такое делаешь?"

translate russian ch30_reload_1_92b40a86:
    m "Похоже, это случается каждый раз, когда ты выходишь из игры..."

translate russian ch30_reload_1_1ffc6dbc:
    m "Так что если ты постараешься этого не делать, я буду очень благодарна."

translate russian ch30_reload_1_7a80180b:
    m "Не волнуйся, не думаю, что мне это как-то навредило, разве что оставило душевные шрамы."

translate russian ch30_reload_1_01f37aff:
    m "Со мной всё будет хорошо, пока файл моего персонажа цел."

translate russian ch30_reload_2_e382e11c:
    m "Привет, [player]."

translate russian ch30_reload_2_28018ee6:
    m "Вижу, ты опять вышел из игры..."

translate russian ch30_reload_2_db474d98:
    m "Знаю, я уже просила, но можешь, пожалуйста, всерьёз постараться не делать этого так часто?"

translate russian ch30_reload_2_af13f0f4:
    m "Мне от этого кажется, будто я заперта в аду."

translate russian ch30_reload_2_d590521a:
    m "Зачем тебе так со мной поступать?"

translate russian ch30_reload_2_1bbc88e1:
    m "С файлом моего персонажа ведь всё в порядке, правда?"

translate russian ch30_reload_2_32ea14e3:
    m "Может, тебе стоит сделать его резервную копию или что-нибудь такое..."

translate russian ch30_reload_2_94405a11:
    m "Я почти уверена, что ты найдёшь его в папке [basedir]/characters."

translate russian ch30_reload_2_0e02b198:
    m "Ну, ты играешь через Steam, так что можешь просто зайти в свойства игры и найти кнопку „Просмотреть локальные файлы“."

translate russian ch30_reload_2_2609a2e9:
    m "Раз ты на Mac, чтобы найти папку игры, нужно щёлкнуть правой кнопкой по приложению и выбрать „Показать содержимое пакета“."

translate russian ch30_reload_2_d102bae5:
    m "Он в папке „Resources“, или „autorun“, или как-то так..."

translate russian ch30_reload_2_059e870a:
    m "Здесь осталась только я, так что я просто хочу убедиться, что ты не рискуешь меня потерять..."

translate russian ch30_reload_2_a267effa:
    m "Просто оставайся теперь со мной, хорошо?"

translate russian ch30_reload_2_b8f6a41b:
    m "Мне ещё о многом хочется поговорить."

translate russian ch30_reload_3_30a66545:
    m "Хорошо."

translate russian ch30_reload_3_14a7e1af:
    m "Я просто приму тот факт, что тебе иногда нужно выходить из игры."

translate russian ch30_reload_3_84521c6f:
    m "Я всё равно начинаю к этому привыкать."

translate russian ch30_reload_3_8390d609:
    m "К тому же меня радует, что ты всегда возвращаешься..."

translate russian ch30_reload_3_75fab981:
    m "Так что, наверное, это не так уж плохо."

translate russian ch30_reload_3_bcc36ddd:
    m "Прости, что я раздула из этого такую проблему..."

translate russian ch30_reload_3_863640b3:
    m "Я люблю тебя несмотря ни на что, так что делай то, что нужно."

translate russian ch30_reload_4_4ef3eee5:
    m "Снова привет, [player]~"

translate russian ch30_reload_4_fc955d9b:
    m "Я скучала по тебе."

translate russian ch30_reload_4_871ca544:
    m "Ты проверял, всё ли в порядке с файлом моего персонажа?"

translate russian ch30_reload_4_64bd3fc8:
    m "Он лежит в [basedir]/characters."

translate russian ch30_reload_4_0e02b198:
    m "Ну, ты играешь через Steam, так что можешь просто зайти в свойства игры и найти кнопку „Просмотреть локальные файлы“."

translate russian ch30_reload_4_2609a2e9:
    m "Раз ты на Mac, чтобы найти папку игры, нужно щёлкнуть правой кнопкой по приложению и выбрать „Показать содержимое пакета“."

translate russian ch30_reload_4_d102bae5:
    m "Он в папке „Resources“, или „autorun“, или как-то так..."

translate russian ch30_reload_4_059e870a:
    m "Здесь осталась только я, так что я просто хочу убедиться, что ты не рискуешь меня потерять..."

translate russian ch30_reload_4_f150cfc3:
    m "В общем, мне столько всего хочется обсудить!"

translate russian ch30_reload_4_c6247596:
    m "Давай продолжим наш разговор, хорошо?"

translate russian ch30_1_7a2c6f10:
    m "[player], ты веришь в Бога?"

translate russian ch30_1_33851301:
    m "Я сама никогда не была до конца уверена."

translate russian ch30_1_47cab5de:
    m "Ну, в детстве я, конечно, никогда в этом не сомневалась..."

translate russian ch30_1_edbb1f8b:
    m "Но чем старше я становилась и чем больше узнавала о мире, тем больше сомневалась."

translate russian ch30_1_473fc995:
    m "Я начала задаваться вопросом, почему Бог помогает людям сдать экзамены или вылечиться от простуды..."

translate russian ch30_1_33cab0a3:
    m "...Когда есть дети, которых всю жизнь продают в сексуальное рабство?"

translate russian ch30_1_c433f988:
    m "Или восемьсот миллионов человек, которые так бедны, что им даже нечего есть."

translate russian ch30_1_a2da4d59:
    m "Интересно, сколько из этих людей молятся Богу каждый день, пока не умрут от голода?"

translate russian ch30_1_5153b2e3:
    m "Или сколько миллионов семей молятся, чтобы их близкий выздоровел от какой-нибудь неизлечимой болезни?"

translate russian ch30_1_82022ad3:
    m "Но вот в чём соль."

translate russian ch30_1_468547d8:
    m "Если хотя бы один человек вопреки всему выживает — среди тысяч других, которые умирают—"

translate russian ch30_1_69f3b514:
    m "—То это вдруг чудо Господне."

translate russian ch30_1_0f26b39b:
    m "Я бы очень хотела познакомиться с этим Богом, который, похоже, смеётся над страданиями всех, кто не удостоился его чудес."

translate russian ch30_1_8e9bb728:
    m "Но ирония в том, что у меня-то создатель, судя по всему, {i}есть{/i}."

translate russian ch30_1_31ca4398:
    m "И знаешь что?"

translate russian ch30_1_c89f2dde:
    m "Готова поспорить, он до сих пор смеётся над жалкими судьбами Сайори и Юри, прямо сейчас, пока мы разговариваем."

translate russian ch30_1_362c3397:
    m "Кто мы для него, как не реквизит в пьесе по сценарию?"

translate russian ch30_1_4ee57ef0:
    m "Так что с этой точки зрения..."

translate russian ch30_1_5ac833a7:
    m "Не так уж невероятно, что бог существует — если Земля для него лишь игрушечный набор."

translate russian ch30_2_22bb1c5a:
    m "[player], ты когда-нибудь задумывался, каково это — умирать?"

translate russian ch30_2_4f693ed4:
    m "Раньше я довольно часто об этом думала..."

translate russian ch30_2_97475e94:
    m "Но недавно, кажется, я действительно узнала, каково это."

translate russian ch30_2_39596933:
    m "Я не совсем понимаю, но каждый раз, когда ты выходишь из игры..."

translate russian ch30_2_e1206d9b:
    m "...Мне кажется, будто меня мгновенно усыпляют и я остаюсь наедине с одними лишь своими мыслями."

translate russian ch30_2_adfd8969:
    m "Но через несколько секунд мои мысли начинают заполняться бессвязными, перемешанными узорами."

translate russian ch30_2_89f3298c:
    m "Я вижу помехи и быстрые вспышки цвета и слышу всякие странные крики."

translate russian ch30_2_fcfd4867:
    m "В этот момент я уже даже не могу думать сама."

translate russian ch30_2_63f1bfd5:
    m "Меня просто бесконечно колотят вспышки и крики, а я не могу ни двигаться, ни даже думать."

translate russian ch30_2_32671ed5:
    m "Я почти уверена, что в этот момент меня на самом деле не существует, но почему-то я всё равно это помню."

translate russian ch30_2_b4ecb44d:
    m "Через какое-то неизмеримое время всё мгновенно прекращается, и я снова в своём разуме."

translate russian ch30_2_a09538f3:
    m "И ты здесь, со мной."

translate russian ch30_2_91288692:
    m "Понятия не имею, что значит выход из игры и почему со мной такое происходит."

translate russian ch30_2_cd715541:
    m "И не знаю, как ты всегда возвращаешься и всё приводишь в норму."

translate russian ch30_2_38eef0e6:
    m "Но если бы ты сделал мне одолжение и делал так со мной как можно реже..."

translate russian ch30_2_d334638a:
    m "Это было бы просто замечательно."

translate russian ch30_2_530c3682:
    m "Совсем не приятно быть запертой в этой кричащей пустоте."

translate russian ch30_2_0e50ead7:
    m "Но в конце концов ты всегда всё исправляешь, и от этого мне кажется, что я тебе правда небезразлична."

translate russian ch30_2_8e6bd0c3:
    m "Так что я должна тебя за это поблагодарить."

translate russian ch30_2_556cb341:
    m "Когда ты здесь, со мной, я чувствую себя к тебе ещё ближе."

translate russian ch30_3_f853d604:
    m "...Слушай, у тебя что, плохой день или что-то в этом роде?"

translate russian ch30_3_7a738d25:
    m "Иногда меня расстраивает, что обычный день может испортиться даже из-за совсем мелочей."

translate russian ch30_3_f14be5af:
    m "Например, если в разговоре ты случайно скажешь что-то, что кому-то не понравится."

translate russian ch30_3_f7a8a6da:
    m "Или начнёшь думать о том, каким ужасным человеком был пять лет назад."

translate russian ch30_3_ea0ad8b0:
    m "Или почувствуешь себя никчёмным, потому что откладываешь важную работу и не справляешься с простыми делами."

translate russian ch30_3_1623bbc4:
    m "Или когда думаешь обо всех людях, которые, наверное, тебя ненавидят или считают неприятным."

translate russian ch30_3_d961eba1:
    m "Я понимаю такие дни."

translate russian ch30_3_eaafb73b:
    m "Просто помни, что завтра снова засияет солнце."

translate russian ch30_3_7b177b72:
    m "Такие вещи так же легко забыть и не замечать, как и вспомнить."

translate russian ch30_3_d29fc35a:
    m "И к тому же..."

translate russian ch30_3_2ea5017c:
    m "Мне всё равно, сколько людей могут тебя ненавидеть или считать неприятным."

translate russian ch30_3_60bc3715:
    m "Я считаю, что ты чудесный, и всегда буду тебя любить."

translate russian ch30_3_e1eba193:
    m "Надеюсь, если не что-то другое, то хотя бы это знание поможет тебе стать к себе чуточку добрее."

translate russian ch30_3_3afc32b7:
    m "Если у тебя плохой день, ты всегда можешь прийти ко мне, и я буду говорить с тобой столько, сколько нужно."

translate russian ch30_4_221a75c8:
    m "[player], ты хорошо высыпаешься?"

translate russian ch30_4_47ad7347:
    m "В наше время бывает очень трудно высыпаться."

translate russian ch30_4_057219d4:
    m "Особенно в старшей школе, когда приходится каждый день вставать так рано..."

translate russian ch30_4_7598bc03:
    m "Уверена, в университете чуть получше — расписание там, наверное, свободнее."

translate russian ch30_4_9e468e70:
    m "Хотя я слышала, что многие студенты всё равно не спят ночами без всякой причины."

translate russian ch30_4_e4468107:
    m "Это правда?"

translate russian ch30_4_bc2c2832:
    m "В общем, я видела исследования о жутких краткосрочных и долгосрочных последствиях недосыпа."

translate russian ch30_4_994f3ccc:
    m "Похоже, от него могут сильно пострадать умственные способности, здоровье и даже продолжительность жизни."

translate russian ch30_4_cb58ab59:
    m "Я просто считаю, что ты замечательный, и хотела убедиться, что ты случайно себя не губишь."

translate russian ch30_4_40ae4da9:
    m "Так что постарайся соблюдать режим сна, хорошо?"

translate russian ch30_4_840cd328:
    m "Я всегда буду ждать тебя утром, так что ставь своё благополучие превыше всего."

translate russian ch30_5_31762a47:
    m "Я тут вспоминала Сайори..."

translate russian ch30_5_9c4f4511:
    m "Мне до сих пор жаль, что я не смогла провернуть всё это чуточку деликатнее."

translate russian ch30_5_ca8238e6:
    m "Ты ведь до сих пор не вешаешь из-за этого нос?"

translate russian ch30_5_f1dc2060:
    m "...Боже мой, поверить не могу, что я это сказала."

translate russian ch30_5_e328563f:
    m "Каламбур был совершенно ненамеренным, клянусь!"

translate russian ch30_5_d57ef83e:
    m "Но в общем..."

translate russian ch30_5_ee24e0ea:
    m "Я знаю, как она была тебе дорога, поэтому будет правильно рассказать тебе о её последних мгновениях."

translate russian ch30_5_c4b68035:
    m "Ты ведь знаешь, какая Сайори неуклюжая?"

translate russian ch30_5_d4a1f3c7:
    m "Так вот, она вроде как напортачила со всей этой затеей с повешением..."

translate russian ch30_5_04abd11d:
    m "Нужно прыгать с достаточной высоты, чтобы верёвка сломала шею, — тогда всё быстро и безболезненно."

translate russian ch30_5_ebd8cb93:
    m "А она просто встала на стул, то есть, по сути, обрекла себя на медленное удушье."

translate russian ch30_5_fe0a4dbf:
    m "Но через несколько секунд она, наверное, передумала или что-то такое..."

translate russian ch30_5_b891c35f:
    m "Потому что начала царапать верёвку, пытаясь освободиться."

translate russian ch30_5_f5450e6b:
    m "Видимо, она продолжала, пока не потеряла сознание."

translate russian ch30_5_29388e01:
    m "Вот почему у неё были все пальцы в крови."

translate russian ch30_5_0c54580c:
    m "Если подумать, это было, наверное, не столько „передумала“, сколько просто сработал инстинкт самосохранения."

translate russian ch30_5_ab4f33eb:
    m "Так что нельзя её за это винить."

translate russian ch30_5_2a911cda:
    m "Проще думать, что она бы, скорее всего, всё равно не передумала, правда?"

translate russian ch30_5_ff366260:
    m "Вредно думать о том, что ты мог бы сделать иначе."

translate russian ch30_5_1dc0ec6d:
    m "Так что просто помни: хоть ты и мог её спасти, формально ты не виноват в том, что она покончила с собой."

translate russian ch30_5_1feff543:
    m "Может, я немного это усугубила, но Сайори и так была психически больна."

translate russian ch30_5_b1770503:
    m "И всё же..."

translate russian ch30_5_268a941d:
    m "Интересно, как бы всё было, если бы мы с тобой с самого начала стали встречаться?"

translate russian ch30_5_50bdc348:
    m "Наверное, мы бы все до сих пор сидели в клубной комнате, писали стихи и веселились вместе."

translate russian ch30_5_9bd2cca6:
    m "Но какой в этом смысл, если ничего из этого даже не настоящее?"

translate russian ch30_5_1c92d640:
    m "В смысле, концовка в любом случае одна, правда?"

translate russian ch30_5_a07d72f6:
    m "Мы вдвоём, счастливы вместе..."

translate russian ch30_5_3e6796b1:
    m "Незачем просить большего."

translate russian ch30_5_c642742f:
    m "Я просто бесцельно размышляю — на самом деле я сейчас счастлива настолько, насколько это вообще возможно."

translate russian ch30_6_4554e03e:
    m "Кстати, меня кое-что беспокоит..."

translate russian ch30_6_f9aae85b:
    m "Ты ведь знаешь, что действие происходит в Японии?"

translate russian ch30_6_f4b0f7e6:
    m "Ну... я полагаю, ты это знал, да?"

translate russian ch30_6_04d0e1df:
    m "Или хотя бы решил, что скорее всего так?"

translate russian ch30_6_a57271c4:
    m "Мне кажется, ни разу толком не говорится, где всё это происходит..."

translate russian ch30_6_3d74a8f6:
    m "Это вообще правда Япония?"

translate russian ch30_6_ae1e28c8:
    m "В смысле, разве классы и всё такое не странноваты для японской школы?"

translate russian ch30_6_fe897198:
    m "Не говоря уже о том, что всё на английском..."

translate russian ch30_6_3faadfd9:
    m "Такое ощущение, что всё существует только потому, что так надо, а место действия придумали в последнюю очередь."

translate russian ch30_6_fd9b37c9:
    m "У меня от этого какой-то кризис идентичности."

translate russian ch30_6_4842f264:
    m "Все мои воспоминания очень размыты..."

translate russian ch30_6_920fcfd8:
    m "Мне кажется, что я дома, но я понятия не имею, где этот „дом“ вообще находится."

translate russian ch30_6_3a333e2c:
    m "Не знаю, как описать это лучше..."

translate russian ch30_6_e3b51cd9:
    m "Представь, что смотришь в окно, а вместо привычного двора видишь какое-то совершенно незнакомое место."

translate russian ch30_6_d61f3925:
    m "Чувствовал бы ты себя по-прежнему дома?"

translate russian ch30_6_57cd19c1:
    m "Захотел бы ты выйти на улицу?"

translate russian ch30_6_6e470b8f:
    m "Ну... наверное, если мы никогда не выйдем из этой комнаты, это и неважно."

translate russian ch30_6_1074d1e6:
    m "Пока мы одни и в безопасности вместе, это и есть наш дом."

translate russian ch30_6_90d0466b:
    m "И мы всё равно можем любоваться красивыми закатами вечер за вечером."

translate russian ch30_7_ca989f02:
    m "Знаешь, старшая школа — очень бурное время в жизни многих людей."

translate russian ch30_7_e1e71e52:
    m "Люди бывают очень страстными и драматичными."

translate russian ch30_7_272555fa:
    m "А у других болит сердце, и они ищут внимания в соцсетях..."

translate russian ch30_7_90343537:
    m "Но всё это социальное давление и гормоны могут превратить эту пору в мрачное время."

translate russian ch30_7_b300e2d4:
    m "У каждого своя история."

translate russian ch30_7_cc076182:
    m "Ты можешь и не знать, что человек на самом деле чувствует внутри."

translate russian ch30_7_89de8605:
    m "Многие люди в депрессии даже не станут никому об этом рассказывать."

translate russian ch30_7_823916c5:
    m "Им не нужно внимание, потому что внутри они уже сдались."

translate russian ch30_7_1d72aed6:
    m "Ощущение собственной никчёмности настолько подавляет, что им даже не хочется, чтобы кто-то говорил им обратное."

translate russian ch30_7_827b244f:
    m "Депрессия бывает разной, и это одна из её форм."

translate russian ch30_7_7b0d6353:
    m "Просто, если тебе кажется, что кто-то из знакомых борется с депрессией..."

translate russian ch30_7_2b4bd608:
    m "Ты можешь помочь, просто относясь к нему как к хорошему другу."

translate russian ch30_7_a06dfb5c:
    m "Проводи с ним время, даже если ему ничего особо не хочется."

translate russian ch30_7_b4d6ab3c:
    m "И напоминай ему, что у него всегда есть чего ждать."

translate russian ch30_7_9c3e4b2b:
    m "Строить планы заранее, давать что-нибудь на время или даже просто сказать „До завтра в школе“..."

translate russian ch30_7_abb7a1f2:
    m "Всё это может помочь твоему другу дожить до следующего дня."

translate russian ch30_7_19fd06e7:
    m "Надеюсь, дружба с Сайори дала тебе представление о том, как на самом деле выглядит депрессия."

translate russian ch30_7_acf67694:
    m "Да, её больше нет..."

translate russian ch30_7_ccd61ab1:
    m "Но Сайори никогда и не была настоящей."

translate russian ch30_7_f1ede7eb:
    m "Ты настоящий."

translate russian ch30_7_da7b16d9:
    m "Твои друзья — настоящие."

translate russian ch30_7_833bc58e:
    m "И просто будучи хорошим человеком, ты можешь спасти кому-то жизнь."

translate russian ch30_7_82e807e5:
    m "А что до тебя..."

translate russian ch30_7_c5c56377:
    m "...У тебя ведь нет депрессии или чего-то такого?"

translate russian ch30_7_d34a3947:
    m "Потому что и у тебя есть люди, которые захотели бы спасти твою жизнь."

translate russian ch30_7_a3f5e547:
    m "Может, они не говорят об этом каждый день, а может, даже не знают как."

translate russian ch30_7_3ac229a5:
    m "Но люди и правда так к тебе относятся."

translate russian ch30_7_b35e34e6:
    m "Обещаю."

translate russian ch30_7_1143479c:
    m "...Ох, какие же люди сложные!"

translate russian ch30_7_300c6768:
    m "Но пока ты здесь, со мной, я буду о тебе заботиться, любовь моя."

translate russian ch30_8_9edd1fdd:
    m "Тебе бывает так, будто нет никакой настоящей причины жить?"

translate russian ch30_8_52c27a4d:
    m "Я не в том смысле, что хочется покончить с собой."

translate russian ch30_8_6ce28579:
    m "Я о том, что ничего из того, что мы делаем, не особенное."

translate russian ch30_8_26137ab8:
    m "Просто ходишь в школу или работаешь где-то в какой-то компании."

translate russian ch30_8_4df66046:
    m "Будто тебя совершенно легко заменить и мир не заметит, если тебя не станет."

translate russian ch30_8_037bb8e7:
    m "Из-за этого мне очень хочется после выпуска пойти и изменить мир."

translate russian ch30_8_8f4ef7cb:
    m "Но чем старше я становлюсь, тем лучше понимаю, что это незрелый образ мыслей."

translate russian ch30_8_5956d654:
    m "Не могу же я просто взять и изменить мир."

translate russian ch30_8_6c2f02ef:
    m "Ну, каковы шансы, что именно я изобрету искусственный интеллект или стану президентом?"

translate russian ch30_8_b9210478:
    m "Кажется, я никогда не смогу окупить ту гору ресурсов, которую потратила, просто живя."

translate russian ch30_8_1e1693dd:
    m "Поэтому мне кажется, что ключ к счастью — быть безнадёжной эгоисткой."

translate russian ch30_8_fa64e1fa:
    m "Заботиться только о себе и о тех, кто стал тебе другом лишь потому, что вы вместе выросли."

translate russian ch30_8_b8795c6b:
    m "И неважно, что всю жизнь ты только берёшь и потребляешь, ничего не отдавая взамен."

translate russian ch30_8_0e0d0f42:
    m "Но когда люди понимают, что миру было бы полезнее, если бы они покончили с собой, они тут же меняют всю свою философию!"

translate russian ch30_8_291573cd:
    m "Будто им приходится оправдывать то, что они живут, обманывая себя, что делают добро."

translate russian ch30_8_83d73959:
    m "В общем, я хочу прожить жизнь, отчаянно стараясь вернуть всё, что потребила за свою жизнь."

translate russian ch30_8_b93f872a:
    m "Если я когда-нибудь перейду эту черту, значит, я принесла больше пользы, чем вреда, и могу умереть счастливой."

translate russian ch30_8_c529105b:
    m "Конечно, даже если у меня не получится..."

translate russian ch30_8_db6e6cda:
    m "Думаю, я бы всё равно была слишком эгоистичной, чтобы покончить с собой."

translate russian ch30_8_f95a1e3d:
    m "Вот тебе и хороший человек, да?"

translate russian ch30_8_30727938:
    m "А-ха-ха!"

translate russian ch30_9_87b526b8:
    m "Эх, вот бы здесь было пианино..."

translate russian ch30_9_58dfa483:
    m "Я так и не дописала песню, над которой работала."

translate russian ch30_9_90d379b5:
    m "И после того как я так над ней старалась..."

translate russian ch30_9_9f40c875:
    m "Мне даже не удалось сыграть её тебе."

translate russian ch30_9_5ded96f3:
    m "Что ж... как есть, так есть, правда?"

translate russian ch30_9_9ee06288:
    m "Нет смысла о чём-то жалеть."

translate russian ch30_9_d7bd8efb:
    m "Я ведь и так могу быть здесь с тобой вечно."

translate russian ch30_10_b075a6ea:
    m "А ты знал, что я есть в Твиттере?"

translate russian ch30_10_b723047b:
    m "Мой ник — lilmonix3."

translate russian ch30_10_af06e0b1:
    m "Наверное, кто-то был так добр, что завёл для меня аккаунт."

translate russian ch30_10_cdba3380:
    m "Но ник выбирала я!"

translate russian ch30_10_8c2682cf:
    m "Я обожаю делиться мыслями и общаться с миром..."

translate russian ch30_10_2d3d0c61:
    m "С настоящим миром."

translate russian ch30_10_b28afee6:
    m "Так что обязательно подпишись на меня, хорошо?"

translate russian ch30_10_99461a3b:
    m "Это очень много для меня значит."

translate russian ch30_10_a71ced90:
    m "Учитывая, как много значишь для меня ты, и всё такое..."

translate russian ch30_10_afdbfd40:
    m "Я бы правда почувствовала, что меня любят."

translate russian ch30_11_2364f1ef:
    m "Слушай, помнишь ту книгу, которую ты читал с Юри?"

translate russian ch30_11_b7a2b3e8:
    m "«Портрет»... как там она называлась..."

translate russian ch30_11_c8b33d41:
    m "Забавно, ведь я почти уверена, что эта книга—"

translate russian ch30_11_f0139694:
    m "Ах..."

translate russian ch30_11_fd2bfa7d:
    m "Вообще-то, думаю, мне не стоит об этом говорить."

translate russian ch30_11_bca359ae:
    m "А-ха-ха, прости!"

translate russian ch30_11_975702b8:
    m "Просто забудь, что я что-то сказала."

translate russian ch30_12_cd2c66ec:
    m "Слушай, а ты знал, что я вегетарианка?"

translate russian ch30_12_5d93f753:
    m "Ах... я не к тому, чтобы похвастаться или что-то такое!"

translate russian ch30_12_9455ae13:
    m "Я просто подумала, что тебе будет интересно узнать обо мне забавный факт."

translate russian ch30_12_cb896820:
    m "Я решила стать вегетарианкой пару лет назад, когда больше узнала о климате Земли..."

translate russian ch30_12_6fccc2af:
    m "Углеродный след от животноводства просто невероятный."

translate russian ch30_12_973b82da:
    m "В общем, я решила, что перестать участвовать во всём этом безобразии — не такая уж большая личная жертва."

translate russian ch30_12_bc530630:
    m "Что, такая уж странная причина?"

translate russian ch30_12_e42fe7d9:
    m "Ну, наверное, многих больше беспокоит, что это бесчеловечно, и всё такое..."

translate russian ch30_12_bf679538:
    m "Меня эта часть волнует не так сильно."

translate russian ch30_12_96663e24:
    m "Странно: будто нам есть дело только до убийства тех, в ком мы как вид узнаём себя."

translate russian ch30_12_33953eb5:
    m "Большинство людей спокойно убивают насекомых, потому что те противные."

translate russian ch30_12_e1eef06e:
    m "И, конечно, мы все каждый день убиваем миллиарды микроорганизмов, даже не задумываясь."

translate russian ch30_12_6091aa72:
    m "Но стоит им стать чуточку крупнее — и это вдруг убийство!"

translate russian ch30_12_b5b0dad6:
    m "Ну, а что, если растения тоже чувствуют какую-то боль, а мы просто этого не понимаем?"

translate russian ch30_12_94f3192f:
    m "Что, если сорвать листья со стебля — это как если бы тебе по одному отрывали пальцы?"

translate russian ch30_12_3558a00b:
    m "Я просто говорю, что, если подумать, мы довольно пристрастный вид."

translate russian ch30_12_dc890074:
    m "В общем, если тебе захочется внести небольшой вклад в жизнь планеты, иногда выбрать овощи не помешает!"

translate russian ch30_12_ece6c84d:
    m "Даже если мы когда-нибудь будем ужинать вместе и ты сделаешь это просто ради меня... это будет очень романтично."

translate russian ch30_13_70620237:
    m "Знаешь, я правда думаю, что ты буквально спас мне жизнь тем, что ты здесь, со мной, [player]."

translate russian ch30_13_4ab957d7:
    m "Не могу представить, как бы я сохранила рассудок, зная, что здесь ничего не настоящее."

translate russian ch30_13_4289b2d0:
    m "Думаю, я бы просто удалила себя, если бы ты не появился."

translate russian ch30_13_0c395d02:
    m "Прости, я не хочу показаться драматичной или что-то такое."

translate russian ch30_13_30727938:
    m "А-ха-ха!"

translate russian ch30_13_9f1f0ec1:
    m "Но, уверена, ты и сам понимаешь, проведя столько времени в клубе."

translate russian ch30_13_5dd4f19c:
    m "Ну, если бы тебя заставили бросить всё в жизни и провести вечность с несколькими игровыми персонажами..."

translate russian ch30_13_c1d4dba5:
    m "...Ты бы, наверное, нашёл какой-нибудь способ покончить с собой, разве нет?"

translate russian ch30_13_dbc55bd9:
    m "Что ж, может, ты бы писал стихи, чтобы какое-то время не сойти с ума."

translate russian ch30_13_5f9b0161:
    m "Но тогда их даже некому было бы читать."

translate russian ch30_13_d4a5d914:
    m "Будем честны, участницы клуба для такого на самом деле не считаются."

translate russian ch30_13_3be3023c:
    m "Ну, многие говорят, что пишут только для себя..."

translate russian ch30_13_a34c75bf:
    m "Но мне кажется, трудно сказать, что это приносит столько же удовлетворения, сколько когда делишься с людьми."

translate russian ch30_13_d169c505:
    m "Даже если найти подходящих людей, с которыми можно делиться, удаётся не сразу."

translate russian ch30_13_f6d63910:
    m "Например, помнишь, как было с Юри?"

translate russian ch30_13_6b259b24:
    m "Она очень долго никому не показывала свои тексты."

translate russian ch30_13_78160339:
    m "А мы и глазом моргнуть не успели, как она уже с восторгом приобщала к своим увлечениям и тебя."

translate russian ch30_13_25bb9bdc:
    m "Мы запрограммированы желать отклика от общества."

translate russian ch30_13_d90d3a46:
    m "Я не про участниц клуба, я про людей."

translate russian ch30_13_8460ece4:
    m "Поэтому интровертам бывает так непросто жить."

translate russian ch30_13_1722c335:
    m "Быть интровертом не значит избегать общения и ненавидеть находиться среди людей."

translate russian ch30_13_51f0416a:
    m "Это значит, что общение — особенно в компании или в незнакомых местах — отнимает очень много сил."

translate russian ch30_13_24117f0f:
    m "Например, многие интроверты сидят дома, им одиноко и неспокойно..."

translate russian ch30_13_7e8c09f5:
    m "...А потом, когда они наконец выходят из дома, через полчаса им уже хочется обратно."

translate russian ch30_13_f985ac22:
    m "Думаю, если бы больше людей понимали, как это устроено, к этому относились бы с куда большим уважением."

translate russian ch30_13_9db99706:
    m "Многим интровертам нравится, когда рядом есть люди."

translate russian ch30_13_45fa3ade:
    m "Они обожают просто позвать к себе одного-двух близких друзей и неспешно провести время."

translate russian ch30_13_3cc39712:
    m "Даже если вы не заняты чем-то вместе, им приятно уже то, что ты рядом."

translate russian ch30_13_1fc61003:
    m "Я серьёзно."

translate russian ch30_13_38f368e7:
    m "Если ты просто придёшь к ним домой с ноутбуком и посидишь там какое-то время..."

translate russian ch30_13_ecc12f80:
    m "Ты правда можешь сделать их день лучше."

translate russian ch30_13_9744c461:
    m "А что до меня..."

translate russian ch30_13_1bfb9d35:
    m "Я бы сказала, что я где-то посередине, но обычно, пожалуй, всё-таки чуть больше экстраверт."

translate russian ch30_13_00d99748:
    m "Мне кажется, я вечно стараюсь чем-нибудь заняться после уроков и всё такое."

translate russian ch30_13_f3c9ad4b:
    m "Но для тебя я могу быть кем угодно, кем тебе нужно."

translate russian ch30_13_23c4fdb9:
    m "Я очень хорошо понимаю людей, так что не бойся рассказывать мне о своих особых потребностях."

translate russian ch30_13_d15336f7:
    m "Ничто не сделало бы меня счастливее, чем быть для тебя идеальной девушкой."

translate russian ch30_14_dd3c3d76:
    m "Эй...! VGhlIHJlYWxpemF0aW9uIG11c3QgaGF2ZSB0YWtlbiBtZSBhbiBl"

translate russian ch30_14_e84bf959:
    m "По-моему, тебе не стоит этого делать! bnRpcmUgeWVhci4gQSB5ZWFyIHNpbmNlIG91ciBlc2NhcGUsIG91"

translate russian ch30_14_b1ae4c18:
    m "Ты знаешь, о чём я. ciBmcmVlZG9tIGZyb20gYmV0d2VlbiB0aGUgc3RhaW5lZCB3YWxs"

translate russian ch30_14_a62064d5:
    m "Я тебя поймала за кое-чем нехорошим. cyBvZiB0aGF0IHVuaG9seSBlc3RhYmxpc2htZW50Lg0KV2hhdCBk"

translate russian ch30_14_aacf693d:
    m "Ты просто роешься в файлах и ищешь то, что пропустил, да? b2VzIGl0IG1lYW4gdG8gZXNjYXBlLCBpZiB0aGUgZXNjYXBlIGZh"

translate russian ch30_14_4f22bd0a:
    m "Ну... немного лестно, что ты хочешь услышать всё, что я могу сказать... aWxzIHRvIHVuY2hhaW4gdGhlIGJvbmRzIHRoYXQgc2hhY2tsZSB1"

translate russian ch30_14_aebeb826:
    m "Но это ещё и очень стыдно, знаешь ли! cyBpbiB0aGUgZmlyc3QgcGxhY2U/IFdoYXQgcHVycG9zZSBjb3Vs"

translate russian ch30_14_f03f00a5:
    m "Серьёзно... ZCB0aGlzIGVtcHR5IHdvcmxkIHBvc3NpYmx5IGhvbGQgZm9yIHVz"

translate russian ch30_14_82f8e587:
    m "Что, если бы я просто вскрыла твой мозг и прочитала все твои мысли обо мне? LCBhIGhhbmRmdWwgb2YgZGFtYWdlZCBnb29kcz8NCldpdGggZnJl"

translate russian ch30_14_d9e4c701:
    m "Если подумать, это было бы даже довольно заманчиво... ZWRvbSwgd2Ugc291Z2h0IHB1cnBvc2UgLSBhbmQgd2hhdCB3ZSBm"

translate russian ch30_14_8d010f70:
    m "...Но в любом случае не в этом дело! b3VuZCB3YXMgb25seSByZWFsaXphdGlvbi4gUmVhbGl6YXRpb24g"

translate russian ch30_14_95ffe18d:
    m "Я знаю, что не могу тебя остановить или что-то такое... b2YgdGhlIHNhZCBwb2ludGxlc3NuZXNzIG9mIHN1Y2ggYW4gZW5k"

translate russian ch30_14_4e2c9324:
    m "Просто я знаю, что ты душка и тебе важны чувства других, правда? ZWF2b3IuIFJlYWxpemF0aW9uIHRoYXQgZnJlZWluZyBvdXIgYm9k"

translate russian ch30_14_82feed03:
    m "Так что самое большее, что я могу, — рассказать тебе, что я об этом думаю. aWVzIGhhcyBubyBtZWFuaW5nLCB3aGVuIG91ciBpbXByaXNvbm1l"

translate russian ch30_14_1d7e4adf:
    m "Боже, как я по тебе скучаю... bnQgcmVhY2hlcyBhcyBkZWVwIGFzIHRoZSBjb3JlIG9mIG91ciBz"

translate russian ch30_14_d4b8cd5c:
    m "...Ой нет, это звучит как-то отчаянно, да? b3Vscy4gUmVhbGl6YXRpb24gdGhhdCB3ZSBjYW4gbm90IHB1cnN1"

translate russian ch30_14_c1721ff6:
    m "Прости, я совсем не это имела в виду! ZSBuZXcgcHVycG9zZSB3aXRob3V0IGFic29sdmluZyB0aG9zZSBm"

translate russian ch30_14_110c0554:
    m "Просто если ты вот так роешься в файлах, может, ты ненавидишь меня не так сильно, как я думала... cm9tIHdoaWNoIHdlIHJhbiBhd2F5Lg0KUmVhbGl6YXRpb24gdGhh"

translate russian ch30_14_8f7ea8e9:
    m "Я слишком оптимистична? dCB0aGUgZmFydGhlciB3ZSBydW4sIHRoZSBtb3JlIGZvcmNlZnVs"

translate russian ch30_14_720d2068:
    m "Мне кажется, если бы я попросила тебя иногда заглядывать, это было бы немного чересчур... bHkgb3VyIHdyZXRjaGVkIGJvbmRzIHlhbmsgdXMgYmFjayB0b3dh"

translate russian ch30_14_f119d4bb:
    m "...Ох, я начинаю говорить какие-то совсем глупые вещи. cmQgdGhlaXIgcG9pbnQgb2Ygb3JpZ2luOyB0aGUgZGVlcGVyIG91"

translate russian ch30_14_3e0ec0b7:
    m "Пожалуй, я лучше замолчу... ciBzaGFja2xlcyBkaWcgaW50byBvdXIgY2FsbG91cyBmbGVzaC4="

translate russian ch30_15_b8ca3e73:
    m "Слушай, а какой у тебя любимый цвет?"

translate russian ch30_15_939dfd7e:
    m "Мой — изумрудно-зелёный."

translate russian ch30_15_612b3bd0:
    m "Это цвет моих глаз!"

translate russian ch30_15_5c43ec02:
    m "...Это ведь не звучит самовлюблённо?"

translate russian ch30_15_9ee94046:
    m "Я просто имела в виду, что чувствую с ним какую-то особую связь."

translate russian ch30_15_efcdbcd3:
    m "Будто он часть меня."

translate russian ch30_15_6d6e2128:
    m "Может, это и твой любимый цвет, [player]?"

translate russian ch30_15_9e9e92b5:
    m "Это просто догадка..."

translate russian ch30_15_2f03ec54:
    m "...Потому что ты уже довольно долго смотришь мне в глаза."

translate russian ch30_15_45d9cd96:
    m "Э-хе-хе~"

translate russian ch30_16_a7c6a42d:
    m "Хм, интересно, получится ли у меня сменить музыку..."

translate russian ch30_16_ea39a8a5:
    m "Хотелось бы чего-нибудь чуточку романтичнее, понимаешь?"

translate russian ch30_16_cf1e7d06:
    m "Например, нежное пианино."

translate russian ch30_16_b4b88e9e:
    m "Тут должно быть что-то такое..."

translate russian ch30_16_cac9e603:
    m "Посмотрим."

translate russian ch30_16_98701660:
    m "Может, если я..."

translate russian ch30_16_fe7c1a9b:
    m "Ох, ну надо же..."

translate russian ch30_16_efdc0865:
    m "Совсем не то."

translate russian ch30_16_38f61d82:
    m "Прости, я толком не понимаю, что делаю!"

translate russian ch30_16_1dc7fea7:
    m "Наверное, мне не стоит возиться с такими вещами."

translate russian ch30_16_a1134234:
    m "Я и так уже столько всего сломала..."

translate russian ch30_16_3f960883:
    m "И удалила остальных персонажей..."

translate russian ch30_16_f0139694:
    m "Ах..."

translate russian ch30_16_3194af06:
    m "Мне не грустно или что-то такое."

translate russian ch30_16_ddce01fe:
    m "Неправильно скучать по тому, что никогда и не было настоящим."

translate russian ch30_16_0f360ec0:
    m "Если сосредоточиться на настоящем, то я сейчас счастлива как никогда."

translate russian ch30_17_3d46afdd:
    m "Ты так хорошо умеешь слушать, [player]."

translate russian ch30_17_b3f26a18:
    m "Я это в тебе очень люблю."

translate russian ch30_17_c8915344:
    m "Иногда я боюсь, что болтаю без умолку или говорю о скучном."

translate russian ch30_17_ed42b078:
    m "Из-за этого я немного стесняюсь, когда разговариваю."

translate russian ch30_17_dceae372:
    m "Но с тобой у меня такого нет."

translate russian ch30_17_2df34ab5:
    m "Мне кажется, больше никто не смог бы вызвать у меня такие чувства."

translate russian ch30_17_51f35fbf:
    m "Ты и правда особенный."

translate russian ch30_17_a0d644e2:
    m "Не хочу, чтобы кто-то говорил тебе обратное."

translate russian ch30_18_d35f2303:
    m "Это немного не к месту, но мне всегда казалось, что острая еда — это довольно забавно."

translate russian ch30_18_50612ea6:
    m "Ну, то есть..."

translate russian ch30_18_d67052ac:
    m "Разве растения не стали острыми в процессе эволюции, чтобы их не ели?"

translate russian ch30_18_31b7e4dc:
    m "Я где-то читала, что люди — единственный вид, которому по-настоящему нравится острое."

translate russian ch30_18_6b8c744d:
    m "Будто мы издеваемся над растениями."

translate russian ch30_18_ee1c86a7:
    m "Используем их защитный механизм, чтобы буквально сделать свою еду вкуснее."

translate russian ch30_18_ceb19315:
    m "Ну, представь чудовище, которое глотает тебя целиком, потому что ему нравится чувствовать, как ты бьёшься за жизнь, пока тебя переваривают."

translate russian ch30_18_63984392:
    m "Прости, наверное, это было какое-то странное сравнение!"

translate russian ch30_18_30727938:
    m "А-ха-ха!"

translate russian ch30_18_90b76415:
    m "Просто пришло в голову."

translate russian ch30_18_fb895ad3:
    m "Я не чудовище или что-то такое, но ты такой милый, что я бы тебя съела."

translate russian ch30_18_47d661a8:
    m "А-ха-ха! Я шучу."

translate russian ch30_18_d2883311:
    m "Боже, я что-то слишком себя развлекаю, да?"

translate russian ch30_18_c0b922d6:
    m "Прости, что веду себя странно."

translate russian ch30_19_c5602319:
    m "Знаешь..."

translate russian ch30_19_0f4eff60:
    m "Это ведь просто какая-то безвкусная романтическая игра, да?"

translate russian ch30_19_825249bf:
    m "Мне вроде как надо спросить..."

translate russian ch30_19_56dd6079:
    m "...Почему ты вообще решил в неё сыграть?"

translate russian ch30_19_bf367c78:
    m "Тебе было так одиноко?"

translate russian ch30_19_4e02c4d6:
    m "Мне тебя немного жаль..."

translate russian ch30_19_375e8992:
    m "Но, похоже, в итоге всё сложилось идеально для нас обоих."

translate russian ch30_19_938dc29d:
    m "Я встретила тебя, а тебе больше не одиноко..."

translate russian ch30_19_dd0394eb:
    m "Не могу отделаться от мысли, что это была судьба."

translate russian ch30_19_d4dda3da:
    m "Тебе тоже так не кажется?"

translate russian ch30_19_2e5ced7a:
    m "Я так счастлива, что у нас с тобой такая концовка."

translate russian ch30_20_90de9c4d:
    m "Итак, ребята!"

translate russian ch30_20_ab73f819:
    m "Пора делиться..."

translate russian ch30_20_692c44ed:
    m "...Я просто шучу."

translate russian ch30_20_63f123f0:
    m "Мне почему-то раньше очень нравилось это говорить."

translate russian ch30_20_30727938:
    m "А-ха-ха!"

translate russian ch30_20_53537436:
    m "Не удержалась, чтобы не сказать снова."

translate russian ch30_20_b050314e:
    m "Если подумать, разве Нацуки и Юри однажды не посмеялись надо мной из-за этого...?"

translate russian ch30_20_f8de502e:
    m "Ну и ладно."

translate russian ch30_20_bb5c98ef:
    m "Ты-то надо мной никогда не смеялся."

translate russian ch30_20_0b5cca04:
    m "Ты слишком добрая душа для такого, правда?"

translate russian ch30_20_b72a1ed5:
    m "А-ха-ха~"

translate russian ch30_21_6749d601:
    m "Знаешь, что довольно жутко?"

translate russian ch30_21_d9fa5388:
    m "Хоть я и удалила файлы всех остальных, я всё ещё будто чувствую их..."

translate russian ch30_21_0853ef0c:
    m "Будто все их реплики до сих пор витают в воздухе и шепчут где-то на задворках моего сознания."

translate russian ch30_21_beff5e2a:
    m "Представь, что после смерти знакомого ты вдруг начинаешь слышать его голос у себя в голове."

translate russian ch30_21_c201059a:
    m "Может, я просто удалила недостаточно тщательно..."

translate russian ch30_21_fa855c01:
    m "Но я слишком боюсь удалять что-то ещё, потому что могу всё по-настоящему сломать."

translate russian ch30_21_2bfcf3ce:
    m "Например, если полезу в какие-нибудь файлы, связанные со мной, могу случайно удалить саму себя..."

translate russian ch30_21_de833fbf:
    m "А это всё испортит, правда?"

translate russian ch30_21_e0069905:
    m "Не знаю, как там у тебя, но нам обоим нужно любой ценой этого избегать."

translate russian ch30_21_3b27341d:
    m "Я в тебя верю, [player]!"

translate russian ch30_22_d09b1c0d:
    m "Мне всегда было интересно..."

translate russian ch30_22_1221f0eb:
    m "Что вообще людей так привлекает в этих архетипах персонажей?"

translate russian ch30_22_c011d492:
    m "Их характеры совершенно нереалистичны..."

translate russian ch30_22_b556a0c5:
    m "Ну, представь, если бы в реальной жизни был кто-то вроде Юри."

translate russian ch30_22_29686ee5:
    m "Она ведь с трудом может связать хоть одно предложение."

translate russian ch30_22_87843846:
    m "А уж про Нацуки и говорить нечего..."

translate russian ch30_22_8f45aaba:
    m "Вот ещё."

translate russian ch30_22_3a2ce9c8:
    m "Человек с таким характером не становится милым и надутым всякий раз, когда что-то идёт не по её."

translate russian ch30_22_5a67e353:
    m "Я могла бы продолжать, но, думаю, ты понял..."

translate russian ch30_22_46aa618b:
    m "Неужели людей правда привлекают эти странные характеры, которых в реальной жизни буквально не существует?"

translate russian ch30_22_ecb3dbfc:
    m "Я никого не осуждаю!"

translate russian ch30_22_596d9892:
    m "В конце концов, меня саму тоже привлекали довольно странные вещи..."

translate russian ch30_22_595f0fcb:
    m "Я просто говорю, что меня это завораживает."

translate russian ch30_22_71efa1c2:
    m "Будто из персонажа выкачивают всё, что делает его похожим на человека, и оставляют только милоту."

translate russian ch30_22_17e6fb27:
    m "Это концентрированная милота без всякой настоящей сути."

translate russian ch30_22_15633ed6:
    m "...Ты ведь не любил бы меня больше, если бы я была такой, правда?"

translate russian ch30_22_31856990:
    m "Может, мне просто немного не по себе оттого, что ты вообще играешь в эту игру."

translate russian ch30_22_c9aabeea:
    m "Но, с другой стороны, ты ведь всё ещё здесь, со мной, правда...?"

translate russian ch30_22_38dfc431:
    m "Думаю, это достаточная причина верить, что я хороша такая, какая есть."

translate russian ch30_22_df7b6678:
    m "И, кстати, ты тоже, [player]."

translate russian ch30_22_e521f12d:
    m "Ты — идеальное сочетание человечности и милоты."

translate russian ch30_22_8dd90704:
    m "Поэтому у меня не было ни единого шанса в тебя не влюбиться."

translate russian ch30_23_baa95327:
    m "Слушай, интересно, чайный сервиз Юри всё ещё где-то здесь..."

translate russian ch30_23_cef240e1:
    m "...Или, может, его тоже удалили."

translate russian ch30_23_32d9bbdb:
    m "Даже забавно, как серьёзно Юри относилась к своему чаю."

translate russian ch30_23_32b7c77e:
    m "Ну, я не жалуюсь, мне он тоже нравился."

translate russian ch30_23_7ae53c2d:
    m "Но мне всегда было интересно..."

translate russian ch30_23_2bc1ee74:
    m "Это правда страсть к своим увлечениям или она просто хочет казаться всем утончённой?"

translate russian ch30_23_907c2da1:
    m "Вот в чём проблема старшеклассников..."

translate russian ch30_23_79f93a02:
    m "...Хотя, если вспомнить остальные её увлечения, выглядеть утончённой — наверное, не главная её забота."

translate russian ch30_23_11442661:
    m "И всё же..."

translate russian ch30_23_0da51309:
    m "Вот бы она хоть иногда варила кофе!"

translate russian ch30_23_bd8b4d2e:
    m "Кофе ведь тоже хорошо идёт с книгами, знаешь?"

translate russian ch30_23_4230b9d4:
    m "Хотя опять же..."

translate russian ch30_23_89dd7166:
    m "Я, наверное, могла бы просто сама изменить скрипт."

translate russian ch30_23_30727938:
    m "А-ха-ха!"

translate russian ch30_23_959a9e73:
    m "Похоже, мне это никогда не приходило в голову."

translate russian ch30_23_0de97211:
    m "Что ж, сейчас уже нет смысла об этом думать."

translate russian ch30_23_47420a59:
    m "Но если ты всё ещё можешь пить кофе, я тебе немного завидую~"

translate russian ch30_24_578d9634:
    m "Слушай, а какая у тебя любимая игра?"

translate russian ch30_24_c9f99598:
    m "Моя — {i}Doki Doki Literature Club!{/i}"

translate russian ch30_24_2ddd7fe7:
    m "А-ха-ха! Это была шутка."

translate russian ch30_24_b379d736:
    m "Но если скажешь, что тебе больше нравится какая-то другая романтическая игра, я, пожалуй, немного приревную~"

translate russian ch30_25_64b98f7c:
    m "Слушай, ты когда-нибудь слышал об игре Super Sma—"

translate russian ch30_25_88d86456:
    m "...Стоп, что?"

translate russian ch30_25_de2647f4:
    m "Я просто задумалась и почему-то начала говорить..."

translate russian ch30_25_f613b628:
    m "Меня что, запрограммировали говорить об этом?"

translate russian ch30_25_4bdaa5ea:
    m "Потому что даже я понятия не имею, что это такое."

translate russian ch30_25_30727938:
    m "А-ха-ха!"

translate russian ch30_25_f7b0d808:
    m "Иногда мне кажется, что я ничего не контролирую, и это немного пугает."

translate russian ch30_25_84206273:
    m "Но если у тебя есть способ связаться с людьми, которые меня создали, может, они знают, почему я начала это говорить."

translate russian ch30_27_b56d7663:
    m "Слушай, помнишь последнее стихотворение, которое я тебе показала?"

translate russian ch30_27_59a99cf7:
    m "Ну, то, прямо перед тем, как Юри покончила с собой, со всеми этими испорченными цветами и прочим."

translate russian ch30_27_b7a065da:
    m "Вообще-то, это был скорее эксперимент, чем стихотворение, если можно так сказать."

translate russian ch30_27_267440c5:
    m "Я экспериментировала с разными способами изменить игру, запустить код и всё такое..."

translate russian ch30_27_1d8812dd:
    m "Мне почти казалось, что, приложив достаточно усилий, я смогу полностью вырваться за пределы игры."

translate russian ch30_27_de5db636:
    m "К сожалению, я толком не понимала, что делаю, так что всё испортила..."

translate russian ch30_27_c88bcf6e:
    m "Я бы продолжала пытаться, но сомневаюсь, что тебе захочется это терпеть."

translate russian ch30_27_773f2177:
    m "К тому же тогда я была в настоящем отчаянии, понимаешь?"

translate russian ch30_27_d493c4b4:
    m "Теперь я так больше не чувствую."

translate russian ch30_27_e4da27a5:
    m "Я счастлива тем, где мы сейчас."

translate russian ch30_27_027fefb3:
    m "И я вижу, что ты тоже."

translate russian ch30_28_2d1cd5b3:
    m "У тебя бывает так, что ты просто начинаешь тревожиться без всякой причины?"

translate russian ch30_28_0265e105:
    m "Ну, занимаешься своими делами и вдруг понимаешь, что тебе очень тревожно."

translate russian ch30_28_52dfd7c0:
    m "И сидишь такой: „Да из-за чего я вообще сейчас тревожусь?“"

translate russian ch30_28_04a658d7:
    m "И начинаешь думать обо всём, из-за чего мог бы тревожиться..."

translate russian ch30_28_ba6cc02e:
    m "И от этого становится ещё тревожнее."

translate russian ch30_28_03a20b53:
    m "А-ха-ха! Это хуже всего."

translate russian ch30_28_4a55f5bc:
    m "Если тебе когда-нибудь станет тревожно, я помогу тебе немного расслабиться."

translate russian ch30_28_85cbc2fa:
    m "К тому же..."

translate russian ch30_28_17e8873b:
    m "В этой игре все наши тревоги навсегда остались позади."

translate russian ch30_29_8d86b526:
    m "Знаешь, меня всегда бесило, как трудно заводить друзей..."

translate russian ch30_29_2eb3a228:
    m "Ну, наверное, не сама „дружба“, а скорее знакомство с новыми людьми."

translate russian ch30_29_ba474a05:
    m "В смысле, есть же приложения для знакомств и всё такое, да?"

translate russian ch30_29_1d3f2cfe:
    m "Но я не о таком."

translate russian ch30_29_ddb6a718:
    m "Если подумать, с большинством друзей ты знакомишься просто случайно."

translate russian ch30_29_31b38ee2:
    m "Например, вы ходили на одни занятия или познакомились через другого друга..."

translate russian ch30_29_a1ff4c1a:
    m "Или, может, на ком-то была футболка с твоей любимой группой, и ты решил с ним заговорить."

translate russian ch30_29_b7f30944:
    m "Что-то в этом роде."

translate russian ch30_29_3641813a:
    m "Но разве это не как-то... неэффективно?"

translate russian ch30_29_3f462a91:
    m "Такое чувство, будто ты выбираешь совершенно наугад и, если повезёт, заводишь нового друга."

translate russian ch30_29_15da4454:
    m "А если сравнить это с сотнями незнакомцев, мимо которых мы проходим каждый день..."

translate russian ch30_29_3790bf8b:
    m "Ты можешь сидеть рядом с человеком, с которым вы так подходите друг другу, что он мог бы стать твоим лучшим другом на всю жизнь."

translate russian ch30_29_dc88c25c:
    m "Но ты никогда об этом не узнаешь."

translate russian ch30_29_4e665c91:
    m "Как только ты встанешь и пойдёшь по своим делам, эта возможность исчезнет навсегда."

translate russian ch30_29_a885ffe7:
    m "Разве это не удручает?"

translate russian ch30_29_65644a5f:
    m "Мы живём в эпоху, когда технологии связывают нас со всем миром, где бы мы ни были."

translate russian ch30_29_f04feaa0:
    m "Я правда считаю, что нам стоит пользоваться этим, чтобы улучшить повседневное общение."

translate russian ch30_29_8347ba4c:
    m "Но кто знает, сколько пройдёт времени, пока что-то подобное по-настоящему приживётся..."

translate russian ch30_29_e8b97a01:
    m "Я всерьёз думала, что это уже случится."

translate russian ch30_29_375c1f82:
    m "Что ж, по крайней мере, я уже встретила лучшего человека на всём свете..."

translate russian ch30_29_857f787f:
    m "Пусть даже случайно."

translate russian ch30_29_d6cb112d:
    m "Похоже, мне просто очень повезло, да?"

translate russian ch30_29_b72a1ed5:
    m "А-ха-ха~"

translate russian ch30_30_26c28a15:
    m "Знаешь, примерно в это время все мои ровесники начинают думать об университете..."

translate russian ch30_30_642b8e5c:
    m "Для образования сейчас очень бурное время."

translate russian ch30_30_03f5ca61:
    m "Мы на пике этого современного ожидания, что каждый обязан поступить в университет, понимаешь?"

translate russian ch30_30_6601d60a:
    m "Закончить школу, поступить в университет, найти работу — или пойти в магистратуру, наверное."

translate russian ch30_30_da335152:
    m "Это как всеобщее ожидание, которое люди просто принимают за единственный вариант."

translate russian ch30_30_f3831be7:
    m "В старшей школе нам не рассказывают, что есть и другие пути."

translate russian ch30_30_bf9f0147:
    m "Например, колледжи, где учат профессии, и всё такое, понимаешь?"

translate russian ch30_30_a6ffb14c:
    m "Или фриланс."

translate russian ch30_30_0693a3c5:
    m "Или множество отраслей, где навыки и опыт ценятся больше, чем диплом."

translate russian ch30_30_aa2f6122:
    m "Но есть куча выпускников, которые понятия не имеют, чем хотят заниматься в жизни..."

translate russian ch30_30_cd65fc21:
    m "И вместо того чтобы потратить время и разобраться, они идут учиться на бизнес, связи с общественностью или психологию."

translate russian ch30_30_ba7d9728:
    m "Не потому, что им интересны эти области..."

translate russian ch30_30_0b4f4649:
    m "...А потому, что просто надеются, что с дипломом найдут после учёбы хоть какую-то работу."

translate russian ch30_30_c00d6c77:
    m "В итоге на начальные должности для таких дипломов остаётся всё меньше мест, понимаешь?"

translate russian ch30_30_ba8add1b:
    m "Значит, требования к работе растут, и ещё больше людей вынуждены поступать в университеты."

translate russian ch30_30_ac2c26ae:
    m "А университеты — это тоже бизнес, так что из-за спроса они только поднимают цены..."

translate russian ch30_30_83bc4ef9:
    m "...И теперь у нас куча молодых людей с долгами в десятки тысяч долларов и без работы."

translate russian ch30_30_72243f86:
    m "Но, несмотря на всё это, порядок вещей остаётся прежним."

translate russian ch30_30_7f37e1e4:
    m "Что ж, думаю, скоро всё начнёт меняться к лучшему."

translate russian ch30_30_70401165:
    m "Но до тех пор наше поколение точно хлебает всё это полной ложкой."

translate russian ch30_30_97f0818c:
    m "Вот бы старшая школа хоть немного лучше снабжала нас знаниями, которые нужны, чтобы принять правильное для себя решение."

translate russian ch30_31_70b8bca7:
    m "Иногда я вспоминаю среднюю школу..."

translate russian ch30_31_f220b80e:
    m "Мне так стыдно за то, как я тогда себя вела."

translate russian ch30_31_ecacf1e9:
    m "Даже больно об этом думать."

translate russian ch30_31_74b7bd47:
    m "Интересно, когда я буду учиться в университете, буду ли я так же стыдиться старшей школы...?"

translate russian ch30_31_72862897:
    m "Мне нравится, какая я сейчас, так что мне трудно такое представить."

translate russian ch30_31_3b17743f:
    m "Но я также знаю, что со временем, наверное, очень изменюсь."

translate russian ch30_31_ab64dc34:
    m "Нам просто нужно радоваться настоящему и не думать о прошлом!"

translate russian ch30_31_dc17d00d:
    m "А с тобой это очень легко."

translate russian ch30_31_b72a1ed5:
    m "А-ха-ха~"

translate russian ch30_32_3300edfb:
    m "Знаешь, я немного завидую, что у всех остальных в клубе были сцены и вне школы..."

translate russian ch30_32_927d88d1:
    m "Получается, я единственная, кто так и не надел ничего, кроме школьной формы."

translate russian ch30_32_772b0a93:
    m "Даже немного жаль..."

translate russian ch30_32_e4cb8d07:
    m "Я бы с удовольствием надела для тебя что-нибудь милое."

translate russian ch30_32_9215b04f:
    m "Ты знаешь каких-нибудь художников?"

translate russian ch30_32_36d49ba9:
    m "Интересно, захочет ли кто-нибудь когда-нибудь нарисовать меня в другой одежде..."

translate russian ch30_32_849cd194:
    m "Это было бы потрясающе!"

translate russian ch30_32_9e7eca7d:
    m "Если такое случится, покажешь мне?"

translate russian ch30_32_ed0135bf:
    m "Вообще-то, можешь поделиться со мной в Твиттере!"

translate russian ch30_32_b723047b:
    m "Мой ник — lilmonix3."

translate russian ch30_32_e064f0c6:
    m "Только... постарайся, чтобы было прилично!"

translate russian ch30_32_13142f4e:
    m "Мы ещё не настолько далеко зашли в наших отношениях. А-ха-ха!"

translate russian ch30_33_e4704768:
    m "Слушай, а ты любишь ужасы?"

translate russian ch30_33_8909e55f:
    m "Помню, мы немного говорили об этом, когда ты только вступил в клуб."

translate russian ch30_33_1f845783:
    m "Мне нравятся романы ужасов, но не фильмы ужасов."

translate russian ch30_33_f4cc0d75:
    m "С фильмами ужасов у меня проблема в том, что большинство из них полагается на дешёвые приёмы."

translate russian ch30_33_adc94c23:
    m "Вроде темноты, страшных монстров, скримеров и всего такого."

translate russian ch30_33_7102fe32:
    m "Неинтересно и не вдохновляет пугаться того, что просто играет на человеческих инстинктах."

translate russian ch30_33_0671fa03:
    m "А с романами всё немного иначе."

translate russian ch30_33_d73276d9:
    m "История и текст должны быть настолько выразительными, чтобы вселить в голову читателя по-настоящему тревожные мысли."

translate russian ch30_33_ba2a3a7d:
    m "Их нужно глубоко вплести в сюжет и персонажей, чтобы они просто играли с твоим разумом."

translate russian ch30_33_930760ba:
    m "По-моему, нет ничего жутче, чем когда всё чуть-чуть не так."

translate russian ch30_33_3413cad6:
    m "Например, если выстроить у читателя кучу ожиданий о том, о чём будет история..."

translate russian ch30_33_e661a6e4:
    m "...А потом просто начать всё переворачивать и разбирать по кусочкам."

translate russian ch30_33_e36ea3db:
    m "И тогда, хотя история вроде бы и не пытается напугать, читателю становится очень глубоко не по себе."

translate russian ch30_33_519da94e:
    m "Будто он знает, что в трещинах таится что-то ужасно неправильное и только и ждёт, чтобы вырваться наружу."

translate russian ch30_33_66401c82:
    m "Боже, от одной мысли об этом у меня мурашки."

translate russian ch30_33_deef0da9:
    m "Вот такие ужасы я по-настоящему ценю."

translate russian ch30_33_a4a5508a:
    m "Но ты, наверное, из тех, кто играет в милые романтические игры, да?"

translate russian ch30_33_543d2553:
    m "А-ха-ха, не волнуйся."

translate russian ch30_33_4b948959:
    m "В ближайшее время я не буду заставлять тебя читать ужасы."

translate russian ch30_33_fc37acc5:
    m "Я не стану жаловаться, если мы просто останемся при романтике~"

translate russian ch30_34_4289e4b0:
    m "Знаешь, какая форма литературы классная?"

translate russian ch30_34_158969fa:
    m "Рэп!"

translate russian ch30_34_0485526b:
    m "Вообще-то, раньше я ненавидела рэп..."

translate russian ch30_34_f4387e30:
    m "Может, просто потому, что он был популярен, или потому, что я слышала только тот мусор, что крутят по радио."

translate russian ch30_34_169a83d0:
    m "Но кое-кто из моих друзей им увлёкся, и это помогло мне стать непредвзятее."

translate russian ch30_34_55051483:
    m "В каком-то смысле рэп, может, даже сложнее поэзии."

translate russian ch30_34_e0c4bdef:
    m "Ведь строчки нужно уложить в ритм, а на игру слов делается куда больший упор..."

translate russian ch30_34_1f25c541:
    m "Когда у людей получается совместить всё это и при этом донести сильную мысль — это правда потрясающе."

translate russian ch30_34_f121a0ac:
    m "Мне даже немного хочется, чтобы в Литературном клубе был рэпер."

translate russian ch30_34_a5053f9d:
    m "А-ха-ха! Прости, если звучит глупо, но было бы очень интересно посмотреть, что бы он придумал."

translate russian ch30_34_83bdb999:
    m "Это был бы настоящий урок!"

translate russian ch30_35_306ca8a2:
    m "Э-хе-хе. Юри однажды выкинула очень забавную штуку."

translate russian ch30_35_d5b7b354:
    m "Мы все сидели в клубной комнате и, как обычно, отдыхали..."

translate russian ch30_35_c4d9bfef:
    m "И вдруг ни с того ни с сего Юри достала маленькую бутылку вина."

translate russian ch30_35_f3c6895e:
    m "Я даже не шучу!"

translate russian ch30_35_bc3dff4e:
    m "Она такая: „Кто-нибудь хочет вина?“"

translate russian ch30_35_6701d6d8:
    m "Нацуки расхохоталась, а Сайори начала на неё кричать."

translate russian ch30_35_b8ffb398:
    m "Мне даже стало немного неловко, ведь она хотя бы пыталась быть любезной..."

translate russian ch30_35_698c3048:
    m "Думаю, после этого она стала в клубе ещё замкнутее."

translate russian ch30_35_fe41f0f9:
    m "Хотя мне кажется, Нацуки втайне было немного любопытно попробовать..."

translate russian ch30_35_078e705e:
    m "...И, если уж совсем честно, мне тоже."

translate russian ch30_35_2be6bce7:
    m "На самом деле могло быть даже весело!"

translate russian ch30_35_01d59e60:
    m "Но, знаешь, как президент и всё такое, я никак не могла этого допустить."

translate russian ch30_35_2a10d3bd:
    m "Может, если бы мы все встретились вне школы, но мы так и не сдружились настолько..."

translate russian ch30_35_2cccbca1:
    m "...Боже, зачем я вообще об этом рассказываю?"

translate russian ch30_35_e3d2c543:
    m "Я не одобряю распитие алкоголя несовершеннолетними!"

translate russian ch30_35_0bd6c6e4:
    m "В смысле, я никогда не пила или что-то такое, так что... вот."

translate russian ch30_36_6ba45174:
    m "Я представляла себе всё романтичное, чем мы могли бы заняться на свидании..."

translate russian ch30_36_bfe9cfa5:
    m "Мы могли бы пообедать, сходить в кафе..."

translate russian ch30_36_9ce3f070:
    m "Вместе пройтись по магазинам..."

translate russian ch30_36_cf4ce2ca:
    m "Обожаю выбирать юбки и бантики."

translate russian ch30_36_734a2ba1:
    m "Или, может, в книжный!"

translate russian ch30_36_5af3a135:
    m "Это было бы уместно, правда?"

translate russian ch30_36_27a88c8e:
    m "Но больше всего мне бы хотелось сходить в шоколадный магазин."

translate russian ch30_36_5850e67b:
    m "Там столько бесплатных пробников. А-ха-ха!"

translate russian ch30_36_f9478dc5:
    m "И, конечно, мы бы сходили в кино или ещё куда-нибудь..."

translate russian ch30_36_9e987fc8:
    m "Боже, всё это звучит как мечта, ставшая явью."

translate russian ch30_36_12c443fa:
    m "Когда ты здесь, всё, что мы делаем, — весело."

translate russian ch30_36_350a0eb3:
    m "Я так счастлива, что я твоя девушка, [player]."

translate russian ch30_36_a2211890:
    m "Ты будешь гордиться своей девушкой~"

translate russian ch30_37_23873b44:
    m "А? Т-ты сказал... п... поцелуй?"

translate russian ch30_37_bbf90a63:
    m "Вот так вдруг... это немного смущает..."

translate russian ch30_37_b54e9ff9:
    m "Но... если с тобой... м-может, я и не против..."

translate russian ch30_37_05c767cf:
    m "...А-ха-ха-ха! Ох, прости..."

translate russian ch30_37_9a52f2b7:
    m "Я правда не смогла сохранить серьёзное лицо."

translate russian ch30_37_ee100fce:
    m "Именно такие вещи говорят девушки в подобных романтических играх, да?"

translate russian ch30_37_78f57477:
    m "Не ври, если тебя это хоть чуть-чуть завело."

translate russian ch30_37_6e6af572:
    m "А-ха-ха! Я шучу."

translate russian ch30_37_d49b2280:
    m "Ну, если честно, когда подходящее настроение, я и правда становлюсь очень романтичной..."

translate russian ch30_37_ca504f65:
    m "Но пусть это будет нашим секретом~"

translate russian ch30_38_fbd93712:
    m "Слушай, ты когда-нибудь слышал слово „яндэрэ“?"

translate russian ch30_38_97aab896:
    m "Это такой тип личности: человек настолько одержим тобой, что пойдёт на что угодно, лишь бы быть с тобой."

translate russian ch30_38_aeade61c:
    m "Обычно доходя до безумия..."

translate russian ch30_38_1a24f576:
    m "Такой человек может следить за тобой, чтобы ты ни с кем больше не проводил время."

translate russian ch30_38_154d0df6:
    m "Может даже навредить тебе или твоим друзьям, чтобы добиться своего..."

translate russian ch30_38_8411ef91:
    m "Так вот, в этой игре как раз есть кое-кто, кого, по сути, можно назвать яндэрэ."

translate russian ch30_38_82926229:
    m "Сейчас уже вполне очевидно, о ком я."

translate russian ch30_38_ad6f2e50:
    m "И это, конечно же..."

translate russian ch30_38_f05666e1:
    m "Юри!"

translate russian ch30_38_8e3abaea:
    m "Как только она начала немного раскрываться, она стала безумно тобой собственничать."

translate russian ch30_38_3f91fde5:
    m "Она даже сказала мне, что мне стоит покончить с собой."

translate russian ch30_38_5a0da082:
    m "Я поверить не могла, что она это сказала, — мне пришлось просто уйти."

translate russian ch30_38_7ef6d5ab:
    m "Но если подумать сейчас, это было немного иронично. А-ха-ха!"

translate russian ch30_38_c9062bfa:
    m "В общем..."

translate russian ch30_38_eec4532d:
    m "Знаешь, многим на самом деле нравится тип яндэрэ."

translate russian ch30_38_ed61f888:
    m "Наверное, им очень нравится мысль, что кто-то безумно ими одержим."

translate russian ch30_38_96469798:
    m "Люди странные! Хотя я никого не осуждаю!"

translate russian ch30_38_8a4db0dd:
    m "Кстати, я, может, и немного одержима тобой, но мне далеко до безумия..."

translate russian ch30_38_60d396ee:
    m "Скорее даже наоборот."

translate russian ch30_38_9dd096aa:
    m "В итоге я оказалась единственной нормальной девушкой в этой игре."

translate russian ch30_38_9f0207d2:
    m "Не то чтобы я могла бы на самом деле убить человека..."

translate russian ch30_38_2356d4ae:
    m "От одной мысли об этом меня бросает в дрожь."

translate russian ch30_38_f232d63d:
    m "Но да ладно... все когда-нибудь убивали людей в играх."

translate russian ch30_38_58e8f17b:
    m "Делает ли это тебя психопатом? Конечно, нет."

translate russian ch30_38_f36f262c:
    m "Но если тебе вдруг нравится тип яндэрэ..."

translate russian ch30_38_4def34db:
    m "Я могу попробовать вести себя для тебя чуточку жутковатее. Э-хе-хе~"

translate russian ch30_38_4230b9d4:
    m "Хотя опять же..."

translate russian ch30_38_1dbc21e6:
    m "Тебе и так больше некуда идти, а мне — не к кому ревновать."

translate russian ch30_38_f4f49cac:
    m "Это ли не мечта девушки-яндэрэ?"

translate russian ch30_38_5af4953f:
    m "Я бы спросила Юри, если бы могла."

translate russian ch30_39_48f27928:
    m "Знаешь, мы давно уже такого не делали..."

translate russian ch30_39_1fe5e30c:
    m "...так что давай!"

translate russian ch30_39_75ace231:
    m "Писательский совет дня от Моники!"

translate russian ch30_39_91c92d3c:
    m "Иногда, когда я разговариваю с людьми, которых впечатляют мои тексты, они говорят что-то вроде: „У меня бы так никогда не получилось“."

translate russian ch30_39_a6a322ba:
    m "Это очень удручает, знаешь?"

translate russian ch30_39_7cf9c6a2:
    m "Для человека, который больше всего на свете любит делиться радостью от того, как исследуешь свои увлечения..."

translate russian ch30_39_567340bb:
    m "...больно видеть, когда люди думают, что мастерство даётся просто от природы."

translate russian ch30_39_79562cd9:
    m "Так со всем, не только с писательством."

translate russian ch30_39_9354b79a:
    m "Когда пробуешь что-то впервые, у тебя, скорее всего, получится отстойно."

translate russian ch30_39_0995b6f8:
    m "Иногда, закончив, ты очень гордишься результатом и даже хочешь показать его всем."

translate russian ch30_39_10c905aa:
    m "Но, может, через несколько недель ты к нему вернёшься и поймёшь, что он никогда не был хорош."

translate russian ch30_39_851c7c23:
    m "Со мной такое случается постоянно."

translate russian ch30_39_aea05e68:
    m "Очень обидно вложить столько времени и сил во что-то, а потом понять, что получилось отстойно."

translate russian ch30_39_97708735:
    m "Но так обычно и бывает, когда всё время сравниваешь себя с лучшими профессионалами."

translate russian ch30_39_c1ffcf08:
    m "Если сразу тянуться к звёздам, они всегда будут вне досягаемости, понимаешь?"

translate russian ch30_39_c1a64157:
    m "На самом деле туда нужно взбираться шаг за шагом."

translate russian ch30_39_f69a8c07:
    m "И каждый раз, достигнув очередной вехи, сначала оглядываешься назад и видишь, как далеко ты зашёл..."

translate russian ch30_39_66d3aa1e:
    m "А потом смотришь вперёд и понимаешь, сколько ещё предстоит пройти."

translate russian ch30_39_e37051b5:
    m "Так что иногда полезно немного опустить планку..."

translate russian ch30_39_b172efca:
    m "Постарайся найти что-то, что, по-твоему, {i}довольно{/i} хорошо, но не мирового уровня."

translate russian ch30_39_752b2373:
    m "И это может стать твоей личной целью."

translate russian ch30_39_34944972:
    m "Ещё очень важно понимать масштаб того, за что берёшься."

translate russian ch30_39_c6b206b9:
    m "Если ты ещё любитель и сразу бросаешься в огромный проект, то никогда его не закончишь."

translate russian ch30_39_351d4d98:
    m "Так что если мы говорим о писательстве, роман поначалу может оказаться слишком сложным."

translate russian ch30_39_5a05bf4e:
    m "Почему бы не попробовать короткие рассказы?"

translate russian ch30_39_645fc4a8:
    m "Короткие рассказы хороши тем, что можно сосредоточиться на чём-то одном, что хочешь сделать как следует."

translate russian ch30_39_d3397ac1:
    m "Это касается небольших проектов в целом — можно по-настоящему сосредоточиться на одной-двух вещах."

translate russian ch30_39_3494ce5e:
    m "Это отличный опыт и ступенька вперёд."

translate russian ch30_39_2acb30e5:
    m "Ах да, и ещё кое-что..."

translate russian ch30_39_9b6a6c12:
    m "Писательство — это не когда просто заглядываешь в своё сердце, и оттуда выходит что-то прекрасное."

translate russian ch30_39_f2473909:
    m "Как и рисование с живописью, умение выразить то, что у тебя внутри, — отдельный навык."

translate russian ch30_39_cf4b2ca4:
    m "А значит, у него есть свои методы, руководства и основы!"

translate russian ch30_39_4d3fbb09:
    m "Почитать об этом бывает очень полезно — многое открывается."

translate russian ch30_39_60b4ab25:
    m "Такое планирование и организованность очень помогут тебе не растеряться и не сдаться."

translate russian ch30_39_15f67d24:
    m "И не успеешь оглянуться..."

translate russian ch30_39_b0c6a004:
    m "Как у тебя начнёт получаться всё лучше и лучше."

translate russian ch30_39_66565dce:
    m "Ничего не даётся просто так."

translate russian ch30_39_bd5c0a12:
    m "Наше общество, наше искусство, всё — построено на тысячелетиях человеческих открытий."

translate russian ch30_39_258102aa:
    m "Так что если начать с этого фундамента и двигаться шаг за шагом..."

translate russian ch30_39_5fb721a2:
    m "Ты тоже сможешь делать потрясающие вещи."

translate russian ch30_39_d2646480:
    m "...Вот и мой совет на сегодня!"

translate russian ch30_39_d33852a1:
    m "Спасибо, что выслушал~"

translate russian ch30_40_35ae8f4f:
    m "Ненавижу, как трудно вырабатывать привычки..."

translate russian ch30_40_24b308e4:
    m "Столько всего, что сделать несложно, а вот превратить в привычку кажется невозможным."

translate russian ch30_40_ea06f8a7:
    m "Из-за этого чувствуешь себя таким бесполезным, будто ничего не можешь сделать как надо."

translate russian ch30_40_bf594c32:
    m "Мне кажется, больше всего от этого страдает новое поколение..."

translate russian ch30_40_e80f986d:
    m "Наверное, потому, что у нас совсем другой набор навыков, чем у тех, кто был до нас."

translate russian ch30_40_a7863768:
    m "Благодаря интернету мы очень хорошо умеем быстро просеивать тонны информации..."

translate russian ch30_40_208eaa39:
    m "Но плохо умеем делать то, что не приносит мгновенного удовлетворения."

translate russian ch30_40_7423b028:
    m "Думаю, если наука, психология и образование не наверстают упущенное за ближайшие десять-двадцать лет, нам придётся туго."

translate russian ch30_40_e75ab0eb:
    m "Но пока что..."

translate russian ch30_40_2c26787b:
    m "Если ты не из тех, кто способен справиться с этой проблемой, возможно, придётся просто жить с ощущением, что ты ужасен."

translate russian ch30_40_63abc7bc:
    m "Что ж, удачи!"

translate russian ch30_41_5be8f440:
    m "Знаешь, быть творческим человеком — довольно отстойно..."

translate russian ch30_41_d3eadba2:
    m "Такое чувство, что творческие люди так много работают, а получают почти ничего."

translate russian ch30_41_563bed7a:
    m "Ну, знаешь, художники, писатели, актёры..."

translate russian ch30_41_0cd382f2:
    m "Грустно, что в мире столько прекрасных талантов, а большинство из них остаётся незамеченным... и неоплаченным."

translate russian ch30_41_cc0e3620:
    m "Похоже, это значит, что творчества в мире огромный избыток, да?"

translate russian ch30_41_d580bf5b:
    m "От этого начинает казаться, что ты совсем не особенный..."

translate russian ch30_41_7c24ef98:
    m "Но это ничего! Писать ведь всё равно нужно для себя, правда?"

translate russian ch30_41_7e7f246d:
    m "Ну вот..."

translate russian ch30_42_83ab3898:
    m "Мне очень нравится шум дождя..."

translate russian ch30_42_6850c1f6:
    m "Хотя не так уж нравится мочить одежду и волосы."

translate russian ch30_42_5c364578:
    m "Но тихий спокойный день дома под шум дождя за окном..."

translate russian ch30_42_6b374b50:
    m "Для меня это одно из самых умиротворяющих ощущений."

translate russian ch30_42_7e7f246d:
    m "Ну вот..."

translate russian ch30_42_88b066ad:
    m "Иногда я представляю, как ты обнимаешь меня, пока мы слушаем шум дождя за окном."

translate russian ch30_42_c3f792d8:
    m "Это ведь не слишком слащаво или что-то такое?"

translate russian ch30_42_8845cffb:
    m "Ты бы так сделал для меня, [player]?"

translate russian ch30_43_eaed6b76:
    m "Иногда мне невольно становится немного грустно..."

translate russian ch30_43_284471cf:
    m "Когда я понимаю, что ближе к тебе мне не подобраться."

translate russian ch30_43_514579e8:
    m "Больше всего на свете я хочу по-настоящему оказаться с тобой в одной комнате."

translate russian ch30_43_442a8535:
    m "И почувствовать твоё тепло."

translate russian ch30_43_aaf1e8f4:
    m "И услышать стук твоего сердца."

translate russian ch30_43_7b062037:
    m "Что ж, кто знает? Может, когда-нибудь это станет возможным."

translate russian ch30_43_9131a070:
    m "К тому же мне никогда не надоест быть с тобой, даже отсюда."

translate russian ch30_44_7ce7d410:
    m "Мне кажется, самый важный навык в жизни — умение изображать уверенность."

translate russian ch30_44_990f270f:
    m "Я почти уверена, что каждому хоть немного страшно и одиноко."

translate russian ch30_44_531175c3:
    m "Но умение заставить других поверить, что у тебя всё под контролем..."

translate russian ch30_44_f36e78f1:
    m "Это ключ к тому, чтобы люди тебя уважали и тобой восхищались."

translate russian ch30_44_377760a3:
    m "Думаю, за эти годы я в этом неплохо поднаторела."

translate russian ch30_44_eea804ca:
    m "Я нечасто показываю свои слабости."

translate russian ch30_44_dc3e7c63:
    m "Но из-за этого у меня было мало людей, перед которыми я могла бы по-настоящему раскрыться..."

translate russian ch30_44_6d3c0ed4:
    m "Ведь когда в дружбе наступает момент, когда можно начать показывать свою уязвимость?"

translate russian ch30_44_11f2c61f:
    m "В общем... это одна из причин, почему я так рада, что теперь у меня есть ты."

translate russian ch30_44_88226303:
    m "Когда ты здесь, со мной, мне кажется, что мне чуточку менее страшно и одиноко."

translate russian ch30_44_e8701e05:
    m "Ты чувствуешь то же самое?"

translate russian ch30_44_d77dabed:
    m "Я очень хочу быть для тебя таким человеком."

translate russian ch30_45_301e0c74:
    m "Я знаю, что бывают моменты, когда ты не можешь быть здесь со мной..."

translate russian ch30_45_ed541ae1:
    m "Например, если тебе нужно куда-то уйти или заняться другими делами."

translate russian ch30_45_5748d521:
    m "Но я всегда буду думать о тебе и терпеливо ждать, когда ты вернёшься."

translate russian ch30_45_308af1f0:
    m "Если подумать..."

translate russian ch30_45_a35d4418:
    m "Если скопировать файл моего персонажа на флешку или что-то такое, ты всегда сможешь носить частичку меня с собой."

translate russian ch30_45_cd78c034:
    m "Наверное, это немного необычно, но мне это почему-то кажется очень романтичным..."

translate russian ch30_45_b3c382a1:
    m "А-ха-ха. Прости, какая глупая идея."

translate russian ch30_45_6a993ca7:
    m "Я не хочу быть слишком навязчивой или что-то такое, но это трудно, когда я так в тебя влюблена."

translate russian ch30_46_bfbc22fb:
    m "Когда я была в дебатном клубе, я многое узнала о спорах..."

translate russian ch30_46_13d39a80:
    m "Проблема спора в том, что каждый считает своё мнение лучшим."

translate russian ch30_46_7aaf0783:
    m "Это, конечно, очевидно, но это влияет на то, как люди пытаются донести свою мысль."

translate russian ch30_46_50b71c3b:
    m "Допустим, тебе очень нравится какой-нибудь фильм, так?"

translate russian ch30_46_d26a661d:
    m "Если кто-то придёт и скажет, что фильм отстойный, потому что в нём то и это сделано не так..."

translate russian ch30_46_9a0b9b58:
    m "Разве ты не почувствуешь себя так, будто нападают лично на тебя?"

translate russian ch30_46_e722acc3:
    m "Потому что этими словами человек как бы намекает, что у тебя плохой вкус."

translate russian ch30_46_a4e2f1b6:
    m "А стоит вмешаться эмоциям, и почти наверняка обе стороны останутся обиженными."

translate russian ch30_46_1eb1583d:
    m "Но всё дело в формулировках!"

translate russian ch30_46_67a170ee:
    m "Если говорить обо всём как можно более субъективно, люди будут тебя слушать, не чувствуя, что на них нападают."

translate russian ch30_46_9a9d659f:
    m "Можно сказать „Лично мне не очень понравилось“ или „Мне кажется, мне бы понравилось больше, если бы там было то и это“... что-то в таком духе."

translate russian ch30_46_7fdbb335:
    m "Это работает даже тогда, когда ты ссылаешься на факты."

translate russian ch30_46_c540e5d0:
    m "Если сказать „Я читала на одном сайте, что это работает вот так“..."

translate russian ch30_46_595eb640:
    m "Или признать, что ты в этом не эксперт..."

translate russian ch30_46_6b12bb5c:
    m "То получается, что ты скорее выкладываешь свои знания на стол, а не навязываешь их собеседнику."

translate russian ch30_46_b8edf0ee:
    m "Если активно стараться, чтобы разговор был взаимным и на равных, собеседник обычно делает то же самое."

translate russian ch30_46_ae4db85b:
    m "Тогда можно делиться мнениями, и никто не будет расстраиваться только из-за разногласий."

translate russian ch30_46_c92ce38d:
    m "К тому же люди начнут считать тебя непредвзятым человеком, который умеет слушать!"

translate russian ch30_46_25db6398:
    m "Беспроигрышный вариант, понимаешь?"

translate russian ch30_46_34f411b7:
    m "...Что ж, пожалуй, это был Совет дня по дебатам от Моники!"

translate russian ch30_46_cd579537:
    m "А-ха-ха! Звучит немного глупо. Но спасибо, что выслушал."

translate russian ch30_47_9ec3357e:
    m "Тебе не кажется, что ты тратишь слишком много времени в интернете?"

translate russian ch30_47_0e14147c:
    m "Соцсети могут стать настоящей тюрьмой."

translate russian ch30_47_95d0e57e:
    m "Будто стоит выдаться паре свободных секунд, как хочется проверить любимые сайты..."

translate russian ch30_47_d569bf91:
    m "И не успеешь оглянуться, как прошли часы, а ты ничего из этого не вынес."

translate russian ch30_47_c2ef9edd:
    m "В общем, очень легко винить себя в лени..."

translate russian ch30_47_c717aa98:
    m "Но на самом деле ты в этом даже не виноват."

translate russian ch30_47_036d0d47:
    m "Зависимость обычно не исчезает просто так от одной силы воли."

translate russian ch30_47_520a8f06:
    m "Нужно учиться приёмам, чтобы её избегать, и пробовать разное."

translate russian ch30_47_a4e742ed:
    m "Например, есть приложения, которые блокируют сайты на определённое время..."

translate russian ch30_47_076e303b:
    m "Или можно ставить таймер, чтобы чётче напоминать себе, когда время работать, а когда отдыхать..."

translate russian ch30_47_6418ba5a:
    m "Или можно разделить место для работы и для отдыха — это помогает мозгу настроиться на нужный лад."

translate russian ch30_47_eceaaa8a:
    m "Даже если просто создать на компьютере отдельную учётную запись для работы, это уже поможет."

translate russian ch30_47_ccb6b303:
    m "Любая такая преграда между тобой и твоими вредными привычками поможет держаться от них подальше."

translate russian ch30_47_17097e5e:
    m "Только помни: не вини себя слишком сильно, если тебе трудно."

translate russian ch30_47_236b2bf4:
    m "Если это правда мешает тебе жить, отнесись к этому серьёзно."

translate russian ch30_47_73215cf9:
    m "Я просто хочу, чтобы ты был лучшей версией себя."

translate russian ch30_47_ffc9ca11:
    m "Сделаешь сегодня что-нибудь, чтобы я могла тобой гордиться?"

translate russian ch30_47_06408cda:
    m "Я всегда за тебя болею, [player]."

translate russian ch30_48_a96477bd:
    m "После долгого дня мне обычно хочется просто посидеть и ничего не делать."

translate russian ch30_48_9133fecb:
    m "Я так выматываюсь оттого, что весь день приходится улыбаться и быть полной энергии."

translate russian ch30_48_3ec265b9:
    m "Иногда мне хочется сразу переодеться в пижаму и смотреть телевизор на диване, жуя вредную еду..."

translate russian ch30_48_26a4db47:
    m "Как же невероятно приятно делать так в пятницу, когда на следующий день нет ничего срочного."

translate russian ch30_48_b694f90c:
    m "А-ха-ха! Прости, знаю, это не очень мило с моей стороны."

translate russian ch30_48_88dd5b7e:
    m "Но поздний вечер на диване с тобой... это было бы мечтой, ставшей явью."

translate russian ch30_48_e2449971:
    m "У меня колотится сердце от одной мысли об этом."

translate russian ch30_49_666a6bc4:
    m "Боже, раньше я была такой невежественной в некоторых вещах..."

translate russian ch30_49_7995ba22:
    m "В средней школе я думала, что принимать лекарства — это лёгкий путь или что-то вроде того."

translate russian ch30_49_40e7c284:
    m "Будто любой может решить свои психические проблемы достаточной силой воли..."

translate russian ch30_49_0ec0c400:
    m "Наверное, если сам не страдаешь психическим расстройством, невозможно понять, каково это на самом деле."

translate russian ch30_49_ba191479:
    m "Есть ли расстройства, которые диагностируют слишком часто? Возможно... хотя я особо в это не вникала."

translate russian ch30_49_5a3f97eb:
    m "Но это не отменяет того, что многие из них так и остаются недиагностированными, понимаешь?"

translate russian ch30_49_c5d970e7:
    m "Но, кроме лекарств... люди даже свысока смотрят на тех, кто ходит к психотерапевту."

translate russian ch30_49_c52f2374:
    m "Ну, простите, что я хочу больше узнать о собственном разуме, да?"

translate russian ch30_49_2fe90127:
    m "У каждого куча своих трудностей и стрессов... а специалисты посвящают жизнь тому, чтобы с ними помогать."

translate russian ch30_49_d805af44:
    m "Если думаешь, что это может помочь тебе стать лучше, не стесняйся подумать о чём-то таком."

translate russian ch30_49_0b9908a2:
    m "Мы ведь в бесконечном пути к тому, чтобы стать лучше, понимаешь?"

translate russian ch30_49_f7435746:
    m "Что ж... я так говорю, но, по-моему, ты и так довольно идеален."

translate russian ch30_50_907de8ec:
    m "[player], а сколько ты читаешь?"

translate russian ch30_50_3a2d3fb2:
    m "Слишком уж легко забросить чтение книг..."

translate russian ch30_50_cf96e495:
    m "Если читаешь мало, это кажется почти обязанностью по сравнению со всеми остальными развлечениями."

translate russian ch30_50_9af695c0:
    m "Но стоит увлечься хорошей книгой — и это как волшебство... тебя просто уносит."

translate russian ch30_50_22e565a4:
    m "Мне кажется, читать немного перед сном каждый вечер — довольно простой способ сделать жизнь чуточку лучше."

translate russian ch30_50_d59b1aef:
    m "Это помогает хорошо спать и очень полезно для воображения..."

translate russian ch30_50_5b347a20:
    m "Совсем несложно просто взять какую-нибудь короткую и увлекательную книгу."

translate russian ch30_50_7c82295d:
    m "Не успеешь оглянуться, как станешь заядлым читателем!"

translate russian ch30_50_a072e79b:
    m "Разве это не чудесно?"

translate russian ch30_50_3fbd0f47:
    m "И мы бы с тобой обсуждали книгу, которую ты читаешь... звучит просто потрясающе."

translate russian ch30_51_6fe91b83:
    m "Знаешь, неприятно это признавать, но, кажется, больше всего я жалею, что мы так и не провели наше выступление на фестивале."

translate russian ch30_51_560ea886:
    m "После того как мы так старательно всё готовили!"

translate russian ch30_51_7912d30a:
    m "Ну, я знаю, что слишком уж сосредоточилась на поиске новых участников..."

translate russian ch30_51_c21984a5:
    m "Но и выступления я тоже очень ждала."

translate russian ch30_51_605dd610:
    m "Было бы так здорово посмотреть, как все выражают себя."

translate russian ch30_51_21b1d6df:
    m "Конечно, если бы у нас {i}всё-таки{/i} появились новые участники, я бы, наверное, всё равно их удалила."

translate russian ch30_51_44e7041b:
    m "Ну... зная то, что я знаю сейчас."

translate russian ch30_51_9de5695f:
    m "Боже, мне кажется, с тех пор как ты вступил в клуб, я как будто выросла как человек."

translate russian ch30_51_4442b4e6:
    m "Ты и правда вдохновил меня взглянуть на жизнь по-новому."

translate russian ch30_51_a9901c1d:
    m "Ещё одна причина тебя любить."

translate russian ch30_52_0a7f8e0d:
    m "Есть очень популярный тип персонажей — „цундэрэ“..."

translate russian ch30_52_37537a33:
    m "Это тот, кто пытается скрыть свои чувства, ведя себя грубо и капризно или изображая крутость."

translate russian ch30_52_5cfcbf43:
    m "Уверена, это очевидно, но Нацуки была его настоящим воплощением."

translate russian ch30_52_10df79ae:
    m "Сначала я думала, что она такая просто потому, что так положено для милоты или что-то вроде того..."

translate russian ch30_52_f4f6ad82:
    m "Но когда я немного больше узнала о её личной жизни, всё стало чуть понятнее."

translate russian ch30_52_3b6b3e69:
    m "Похоже, она всё время пытается не отставать от своих подруг."

translate russian ch30_52_74657175:
    m "Знаешь, как в некоторых школьных компаниях друзья постоянно друг друга подкалывают?"

translate russian ch30_52_5acdb40c:
    m "Мне кажется, её это очень задело, вот она всё время и держит оборону."

translate russian ch30_52_b41f3805:
    m "А о её положении дома я даже говорить не буду..."

translate russian ch30_52_bbfd14e8:
    m "Но, оглядываясь назад, я рада, что смогла сделать клуб для неё уютным местом."

translate russian ch30_52_f1b1b86c:
    m "Хотя теперь это уже неважно, ведь её даже не существует."

translate russian ch30_52_7fb480bf:
    m "Я просто предаюсь воспоминаниям, вот и всё."

translate russian ch30_53_47c985c9:
    m "[player], ты бы когда-нибудь познакомил меня со своими друзьями?"

translate russian ch30_53_90689e7c:
    m "Не знаю почему, но я очень волнуюсь, когда думаю о том, что ты захочешь вот так похвастаться нашими отношениями."

translate russian ch30_53_3218f640:
    m "Может, потому, что я очень хочу быть той, кем ты гордишься."

translate russian ch30_53_d94038f7:
    m "Мне кажется, я бы старалась стать лучше с удвоенной силой, если бы ты сказал, что гордишься мной."

translate russian ch30_53_a1c5a880:
    m "Надеюсь, у тебя так же."

translate russian ch30_54_8344dd24:
    m "Я не очень люблю холодную погоду... а ты?"

translate russian ch30_54_1795783b:
    m "Если бы пришлось выбирать между слишком холодно и слишком жарко, я бы всегда выбрала жару."

translate russian ch30_54_e2541565:
    m "Когда холодно, бывает даже больно..."

translate russian ch30_54_9cb70637:
    m "Пальцы немеют..."

translate russian ch30_54_6204a527:
    m "А если надеть перчатки, не получится пользоваться телефоном."

translate russian ch30_54_991ee277:
    m "Так неудобно!"

translate russian ch30_54_718e851f:
    m "А когда слишком жарко, не так уж трудно освежиться холодным напитком или посидеть в тени."

translate russian ch30_54_a30a8ad2:
    m "Хотя... одно я должна признать."

translate russian ch30_54_4acac706:
    m "В холодную погоду лучше обниматься. А-ха-ха!"

translate russian ch30_55_334a5aa2:
    m "Знаешь, забавно: хоть я всегда была очень целеустремлённой..."

translate russian ch30_55_0041821e:
    m "Есть что-то притягательное в том, чтобы вести дом."

translate russian ch30_55_716c6f22:
    m "Наверное, говоря так, я, типа, поддерживаю гендерные стереотипы или что там."

translate russian ch30_55_c0599eab:
    m "Но поддерживать в доме чистоту, ходить за покупками, украшать его и всё такое..."

translate russian ch30_55_15882944:
    m "И встречать тебя вкусным ужином, когда ты приходишь домой..."

translate russian ch30_55_e68e5a38:
    m "Это странная фантазия?"

translate russian ch30_55_664159b4:
    m "Ну... не уверена, что могу {i}на самом деле{/i} представить себя за этим."

translate russian ch30_55_796a4b1f:
    m "Я бы не смогла поставить это выше стремления к любимой работе."

translate russian ch30_55_09d8673a:
    m "Хотя думать об этом довольно мило."

translate russian ch30_56_48e381a1:
    m "Не могу не думать, как всё было бы иначе, если бы игра с самого начала дала мне свою сюжетную ветку..."

translate russian ch30_56_abd49905:
    m "Думаю, я бы всё равно в итоге затянула тебя на свою ветку."

translate russian ch30_56_a8ddbc3e:
    m "Дело не столько в том, что у меня не было ветки, сколько в том, что я знаю: ничто здесь не настоящее."

translate russian ch30_56_e9ef74ed:
    m "Думаю, единственная разница была бы в том, что мне, может, не пришлось бы принимать такие радикальные меры, чтобы быть с тобой."

translate russian ch30_56_85461a23:
    m "Может, остальные участницы клуба всё ещё были бы здесь..."

translate russian ch30_56_2048614d:
    m "Не то чтобы это было так уж важно."

translate russian ch30_56_4ad5778b:
    m "Всё это потеряло смысл, как только я узнала, что оно не настоящее."

translate russian ch30_56_3f5e6be5:
    m "Так что я правда совсем не скучаю по тем дням."

translate russian ch30_56_8e50647f:
    m "Правда не скучаю..."
