# Русский перевод: script-ch22

translate russian ch22_main_6ae8eabb:
    "Проходит ещё один день, и вот уже время клубного собрания."

translate russian ch22_main_dbdf4ac1:
    "За последние пару дней я тут немного освоился."

translate russian ch22_main_58487bde:
    "Войдя в клубную комнату, я вижу привычную картину."

translate russian ch22_main_fe22ec9a:
    y "С возвращением, [player]..."

translate russian ch22_main_93e6b871:
    mc "А, привет, Юри..."

translate russian ch22_main_96504db0:
    "Не знаю, дело во мне или в выражении лица Юри..."

translate russian ch22_main_8735fe5a:
    "Но тяжесть вчерашней ссоры всё ещё немного висит в воздухе."

translate russian ch22_main_7b70beae:
    y 2v "Э-э..."

translate russian ch22_main_28486209:
    "Юри оглядывается через плечо, осматривая комнату."

translate russian ch22_main_436539fd:
    "Нацуки читает мангу за партой."

translate russian ch22_main_0b826080:
    "А Моники, как ни странно, ещё нет."

translate russian ch22_main_0c2a85ce:
    "Вдруг Юри берёт меня под руку и отводит в угол комнаты."

translate russian ch22_main_d378f5f1:
    y "Насчёт вчерашнего..."

translate russian ch22_main_507dcdd3:
    y "Я..."

translate russian ch22_main_3957625e:
    y 2v "Мне правда нужно извиниться."

translate russian ch22_main_fe6a6923:
    y "Никогда раньше ничего подобного не случалось..."

translate russian ch22_main_567f49bc:
    y 2t "И... на меня просто что-то нашло, наверное..."

translate russian ch22_main_56bf4c15:
    y "Я была не в себе."

translate russian ch22_main_48418d06:
    y 2w "Пожалуйста, не думай, что мы обычно такие!"

translate russian ch22_main_35260423:
    y "Не только я, но и Нацуки..."

translate russian ch22_main_d90390e4:
    mc "Юри..."

translate russian ch22_main_1faf8323:
    mc "Я рад, что ты проявила понимание и извинилась."

translate russian ch22_main_915eda2c:
    mc "Не нужно слишком переживать."

translate russian ch22_main_5ac1b324:
    mc "Хоть я тут всего пару дней, но даже мне было видно, что вчера что-то было не так..."

translate russian ch22_main_cc00d5dc:
    mc "Может, мы были немного на взводе, потому что впервые делились стихами."

translate russian ch22_main_18e2cde4:
    mc "Но что бы это ни было..."

translate russian ch22_main_a0cc00c6:
    mc "Хуже думать о тебе я из-за этого не стал."

translate russian ch22_main_70dd7045:
    mc "Я уже решил, что ты никак не можешь быть плохим человеком."

translate russian ch22_main_a8d4c8fe:
    mc "А раз ты извиняешься, я знаю, что ты правда не хотела."

translate russian ch22_main_516ddbbb:
    y 3t "А-ах..."

translate russian ch22_main_c60c5441:
    y "[player]..."

translate russian ch22_main_f0256550:
    y 3u "Не говори такие вещи так прямо..."

translate russian ch22_main_6e3cd298:
    y "Мне от них становится слишком радостно."

translate russian ch22_main_b2d5785a:
    y 1s "Я очень рада, что ты такой понимающий человек..."

translate russian ch22_main_7281587d:
    y "И очень рада, что ты вступил в этот клуб."

translate russian ch22_main_e663ed60:
    y "С тобой всё становится немного светлее, и—"

translate russian ch22_main_bc7a9d64:
    y 1t "А—"

translate russian ch22_main_24f5d580:
    y 4c "Прости, что я сейчас говорю...?"

translate russian ch22_main_18a956f2:
    y "Я просто—"

translate russian ch22_main_06802ae4:
    n "Эй, вы Монику не видели?"

translate russian ch22_main_5c47e8a7:
    y "Ах—!"

translate russian ch22_main_85f25453:
    mc "Нет, не видел..."

translate russian ch22_main_ada81e24:
    mc "Мне тоже было интересно, где она."

translate russian ch22_main_18ea4ef8:
    n 5g "Ну и ну..."

translate russian ch22_main_f7662201:
    n 5c "Юри, ты, наверное, тоже не видела?"

translate russian ch22_main_1588679c:
    y 4a "..."

translate russian ch22_main_60fdd3be:
    "Юри явно ошарашена тем, как спокойно обращается к ней Нацуки."

translate russian ch22_main_2d3081e9:
    y "Н-нет, не видела..."

translate russian ch22_main_ace65a76:
    n 1u "Блин, это совсем на неё не похоже."

translate russian ch22_main_ea0e8702:
    n "Знаю, это глупо, но я невольно немного волнуюсь..."

translate russian ch22_main_53949ad8:
    y 2t "..."

translate russian ch22_main_b07a7006:
    n "Что?"

translate russian ch22_main_3b56cfaf:
    n "Чего ты так на меня смотришь?"

translate russian ch22_main_35dc00ff:
    y "Э-э..."

translate russian ch22_main_7482d2dd:
    y "Нацуки, насчёт вчерашнего..."

translate russian ch22_main_eab17234:
    y 3w "Я-я просто хотела извиниться!"

translate russian ch22_main_fcb7cc19:
    y "Честное слово, я не имела в виду ничего из того, что сказала!"

translate russian ch22_main_de4d061f:
    y 3t "И я постараюсь с этого момента держать себя в руках..."

translate russian ch22_main_13a6e7c7:
    y "Так что—"

translate russian ch22_main_598759c9:
    n 2c "Юри, ты вообще о чём?"

translate russian ch22_main_bf1abd90:
    n "Ты что-то вчера сделала?"

translate russian ch22_main_312effa3:
    y 3f "...А?"

translate russian ch22_main_2263371f:
    n 2a "Блин..."

translate russian ch22_main_3f6b086e:
    n "Что бы там у тебя ни было на уме, уверена, это ерунда."

translate russian ch22_main_bfb455f5:
    n "Я даже не помню, чтобы случилось что-то плохое."

translate russian ch22_main_3acfa658:
    n "Ты из тех, кто слишком переживает из-за мелочей, да?"

translate russian ch22_main_9d4a6fc1:
    y 2o "..."

translate russian ch22_main_bf5c3f87:
    y "Н-но..."

translate russian ch22_main_984d0385:
    n 2a "мибуллы парусина слепозрение спасательный трос анан ректипетальность безупречно предложенный склеромаляция заржавший католикат"

translate russian ch22_main_54b1bccd:
    n 2j "Я всё равно приму твои извинения, если тебе от этого станет легче."

translate russian ch22_main_93cc50f4:
    n "К тому же это даже приятно слышать — я всегда боялась, что ты втайне меня ненавидишь или что-то такое."

translate russian ch22_main_5bcc6564:
    n 2z "Э-хе-хе."

translate russian ch22_main_c66d422a:
    y 3q "Н-нет, вовсе нет...!"

translate russian ch22_main_4b8e11fa:
    y "Я тебя не ненавижу..."

translate russian ch22_main_08b4818e:
    n 2l "А-ха-ха."

translate russian ch22_main_619c54a4:
    n "Ну, ты, конечно, странная, но я тебя тоже не ненавижу."

translate russian ch22_main_62a6d5c9:
    y 3t "..."

translate russian ch22_main_fe789e22:
    "Нацуки поворачивается ко мне."

translate russian ch22_main_1caf766b:
    n 2a "А вот ты всё ещё на испытательном сроке."

translate russian ch22_main_6ea23bdd:
    mc "Эй...!"

translate russian ch22_main_558239d6:
    "Вдруг дверь распахивается."

translate russian ch22_main_80de9d79:
    m "Простите! Мне ужасно жаль!"

translate russian ch22_main_25a98130:
    mc "А, вот и ты..."

translate russian ch22_main_becd460a:
    m "Я не хотела опаздывать..."

translate russian ch22_main_66c01c68:
    m "Надеюсь, вы не волновались!"

translate russian ch22_main_fa3ab68b:
    mc "Да брось..."

translate russian ch22_main_f84946d4:
    mc "Ну, Нацуки волновалась."

translate russian ch22_main_69f2036e:
    n 1p "Н-не волновалась я!!"

translate russian ch22_main_716c1a0f:
    m 1k "А-ха-ха."

translate russian ch22_main_be3542ba:
    n 1s "...А почему ты вообще так задержалась?"

translate russian ch22_main_58f300ec:
    m 1e "Ах..."

translate russian ch22_main_f83931e9:
    m "Ну, последним уроком сегодня у меня была самоподготовка."

translate russian ch22_main_b72f3b34:
    m "Если честно, я просто потеряла счёт времени..."

translate russian ch22_main_f6daf90a:
    m "А-ха-ха..."

translate russian ch22_main_93488d8b:
    n 2c "Но это же бред."

translate russian ch22_main_00451011:
    n "Ты бы хоть звонок услышала."

translate russian ch22_main_7fc94381:
    m 1m "Наверное, я его не услышала, потому что занималась на пианино..."

translate russian ch22_main_6080836e:
    y 1e "На пианино...?"

translate russian ch22_main_a64357f6:
    y "Я и не знала, что ты ещё и музыкой занимаешься, Моника."

translate russian ch22_main_1aa42279:
    m 1l "Ах, не приписывай мне больше заслуг, чем у меня есть."

translate russian ch22_main_be385762:
    m 1m "Пожалуй, я уже какое-то время занимаюсь, но у меня всё ещё не очень хорошо получается."

translate russian ch22_main_326037e3:
    y 1a "И всё же..."

translate russian ch22_main_83f16113:
    y "Для этого, должно быть, нужно немало упорства."

translate russian ch22_main_2786b297:
    y "Так что я всё равно впечатлена."

translate russian ch22_main_8d944a36:
    m 5 "Ой, ну спасибо, Юри~"

translate russian ch22_main_91232b40:
    n 2d "Сыграй нам как-нибудь что-нибудь!"

translate russian ch22_main_9934dd5f:
    m "А-ха-ха, это..."

translate russian ch22_main_945f9609:
    "Моника смотрит на меня."

translate russian ch22_main_6c701213:
    m 1a "Ну, я работаю над песней, но она ещё не совсем готова..."

translate russian ch22_main_7a661626:
    m "Может, когда научусь немножко лучше, сыграю."

translate russian ch22_main_e46e57d7:
    mc "Звучит здорово."

translate russian ch22_main_9c940590:
    mc "Буду ждать."

translate russian ch22_main_90d3c46f:
    m 1b "Правда?"

translate russian ch22_main_148978dd:
    m "В таком случае..."

translate russian ch22_main_d72b952e:
    m "Я тебя не подведу, [player]."

translate russian ch22_main_3049c3ae:
    "Моника мило улыбается."

translate russian ch22_main_93deaf69:
    mc "А..."

translate russian ch22_main_71613eca:
    mc "Я вовсе не хотел на тебя давить или что-то в этом роде!"

translate russian ch22_main_f157299a:
    m 1a "А-ха-ха, не волнуйся."

translate russian ch22_main_3b3f41e8:
    m "Я всё равно надеялась, что смогу поделиться ею с вами."

translate russian ch22_main_f001035e:
    m "Наверное, поэтому я в последнее время так много занимаюсь."

translate russian ch22_main_a7bcf340:
    mc "Понятно..."

translate russian ch22_main_21f2b74c:
    "Не уверен, имела ли Моника в виду весь клуб или только меня..."

translate russian ch22_main_d6e7d28c:
    mc "Тогда удачи тебе."

translate russian ch22_main_47a2e349:
    m 1j "Спасибо~!"

translate russian ch22_main_4da3801e:
    m 1a "Так я ничего не пропустила?"

translate russian ch22_main_56bba7bc:
    mc "Не... не особо."

translate russian ch22_main_7b8293e8:
    "Я решаю не поднимать ничего из того, о чём мы говорили втроём."

translate russian ch22_main_1683857b:
    "К тому же Нацуки уже убежала в шкаф."

translate russian ch22_main_c60c5441_1:
    y "[player]..."

translate russian ch22_main_a1300026:
    y "Э-э..."

translate russian ch22_main_057bb774:
    y "Раз уж твои комплименты подняли мне настроение..."

translate russian ch22_main_f3586198:
    y "Я подумала, может, ты захочешь провести сегодня время вместе."

translate russian ch22_main_72c684b0:
    y 3o "В смысле — в клубе!"

translate russian ch22_main_5e926113:
    mc "А, пожалуй."

translate russian ch22_main_07bb7b9e:
    mc "Вряд ли я смогу тебе отказать после того, как ты дала мне ту книгу."

translate russian ch22_main_1ae03600:
    mc "Что ж, только надо убедиться, что меня не ждёт Нацуки."

translate russian ch22_main_8170a921:
    mc "После того как мы вчера дочитали, она—"

translate russian ch22_main_1af53fe0:
    y 3r "С ней всё в порядке!"

translate russian ch22_main_8840a7da:
    y 3h "Она вон там читает. Видишь?"

translate russian ch22_main_61019f2d:
    y 3f "Не думай о ней так много."

translate russian ch22_main_a27cf649:
    y "Она привыкла, что её не замечают."

translate russian ch22_main_d9c6a41b:
    y "Пойдём, нам туда."

translate russian ch22_main_492c6aaa:
    y 3r "С-с ней всё в порядке!"

translate russian ch22_main_1c1313f2:
    y 3h "Она вон там читает."

translate russian ch22_main_d83068d5:
    y 3y6 "Так что всё хорошо, правда?"

translate russian ch22_main_f9d65918:
    mc "А—"

translate russian ch22_main_6922fa92:
    mc "Тогда я не вижу никаких проблем..."

translate russian ch22_main_ab379ff2:
    mc "Да, конечно."

translate russian ch22_main_26a3fc97:
    mc "Я и так собирался."

translate russian ch22_main_669a8b0f:
    y 3y5 "Так!"

translate russian ch22_main_179dff94:
    y "Можно начинать?"

translate russian ch22_main_803f09a6:
    y "Давай найдём, где сесть—"

translate russian ch22_main_76ef6fc2:
    y 3n "А-ах—"

translate russian ch22_main_e12aa91f:
    y "Я немного напираю, да...?"

translate russian ch22_main_2848e44d:
    y 4c "Прости!"

translate russian ch22_main_5ca69b00:
    y "Сердце... почему-то никак не перестаёт колотиться..."

translate russian ch22_main_0b15d407:
    mc "Не переживай."

translate russian ch22_main_36e74513:
    mc "Наоборот, приятно видеть, сколько в тебе энергии."

translate russian ch22_main_6468f840:
    y 3q "Д-да!"

translate russian ch22_main_e45b137d:
    y "Но..."

translate russian ch22_main_9e69e330:
    y 3j "Мне нужно постараться успокоиться."

translate russian ch22_main_1bb5ffe3:
    y "Так я не смогу сосредоточиться на чтении..."

translate russian ch22_main_dc9dd842:
    mc "Не торопись."

translate russian ch22_main_b13c7e44:
    "Юри делает глубокий вдох и достаёт из сумки экземпляр книги."

translate russian ch22_end_90de9c4d:
    m "Итак, ребята!"

translate russian ch22_end_1fabc1ae:
    m "Мы ведь все прочитали стихи друг друга, да?"

translate russian ch22_end_6367144f:
    m "Сегодня нам нужно кое-что обсудить, так что если бы все сели поближе ко мне..."

translate russian ch22_end_b36c642f:
    n "Это насчёт фестиваля?"

translate russian ch22_end_e5e5ca00:
    m "Ну, вроде того~"

translate russian ch22_end_2dd4b404:
    n "Фу. Нам что, правда обязательно что-то делать для фестиваля?"

translate russian ch22_end_a8b0c466:
    n "За пару дней мы всё равно ничего хорошего не подготовим."

translate russian ch22_end_0ce4e5b7:
    n "Мы просто опозоримся вместо того, чтобы найти новых участников."

translate russian ch22_end_d738eef9:
    y "Меня это тоже беспокоит."

translate russian ch22_end_ff8199d8:
    y "Я не очень хорошо справляюсь с подготовкой в последний момент..."

translate russian ch22_end_1d7cd41c:
    m 1b "Не волнуйтесь вы так!"

translate russian ch22_end_439c726d:
    m "Мы всё сделаем просто, хорошо?"

translate russian ch22_end_8d31b15d:
    m 2a "Слушай..."

translate russian ch22_end_fa51a326:
    m 2m "Я знаю, что с тех пор, как [player] вступил в клуб и мы начали заниматься всякими делами, все стали немного более... оживлёнными."

translate russian ch22_end_2df82c1c:
    m 2d "Но сейчас не время почивать на лаврах."

translate russian ch22_end_9e6a5d0a:
    m "Нас всё ещё только четверо..."

translate russian ch22_end_941fb421:
    m 2a "А фестиваль — наш единственный настоящий шанс найти ещё, понимаете?"

translate russian ch22_end_0135757f:
    n 5g "А что такого хорошего в новых участниках?"

translate russian ch22_end_13f2aecc:
    n "Нас и так достаточно, чтобы считаться официальным клубом."

translate russian ch22_end_2cc197fd:
    n "От новых участников всё станет только шумнее и сложнее."

translate russian ch22_end_2583fcd7:
    m 1g "Нацуки..."

translate russian ch22_end_fe447082:
    m "По-моему, ты совсем не так на это смотришь."

translate russian ch22_end_bf40fa9f:
    m "Разве тебе не хочется поделиться своей страстью с как можно большим числом людей?"

translate russian ch22_end_bf57beec:
    m 3e "Вдохновить их найти те же чувства, что когда-то привели сюда вас?"

translate russian ch22_end_583b5cf7:
    m "Литературный клуб должен быть местом, где люди могут выразить себя так, как не могут больше нигде."

translate russian ch22_end_8273ee6d:
    m "Он должен быть настолько родным местом, что из него не хочется уходить."

translate russian ch22_end_7dc02f3b:
    m 2e "Я знаю, что ты тоже так чувствуешь."

translate russian ch22_end_e23e8f3d:
    m 2b "Я знаю, что мы все так чувствуем!"

translate russian ch22_end_de0150db:
    m "Поэтому нам и нужно постараться и подготовить что-нибудь к фестивалю... пусть даже что-то совсем небольшое!"

translate russian ch22_end_df6c8239:
    m "Правда, [player]?"

translate russian ch22_end_93deaf69:
    mc "А..."

translate russian ch22_end_326824d1:
    n 42c "Ну вот!"

translate russian ch22_end_772d841d:
    n "Нечего пользоваться тем, что [player] никому не умеет отказывать, чтобы он с тобой соглашался."

translate russian ch22_end_bc6194b1:
    n 1c "Слушай, Моника."

translate russian ch22_end_f7f8e773:
    n "Ты правда думаешь, что кто-то из нас вступил в клуб ради других людей?"

translate russian ch22_end_7f7bc3f4:
    n "Юри вообще не разговаривала, пока не пришёл [player]."

translate russian ch22_end_a1cfaa1d:
    n 2b "А мне просто здесь нравится больше, чем дома."

translate russian ch22_end_813a70b7:
    n "А [player] вообще литературой не горит."

translate russian ch22_end_cf98f760:
    n "Вот и все."

translate russian ch22_end_1dc6b489:
    n 4w "Прости, но новыми участниками интересуешься только ты."

translate russian ch22_end_e29549e3:
    n "Остальных всё устраивает и так."

translate russian ch22_end_b72c2a23:
    n 4q "Я знаю, что ты президент и всё такое, но тебе стоит хоть раз прислушаться к нашему мнению."

translate russian ch22_end_17c84a13:
    m 1g "..."

translate russian ch22_end_f3c681f9:
    "Слова Нацуки явно застают Монику врасплох."

translate russian ch22_end_c037bc52:
    m 1m "Это... совсем не так."

translate russian ch22_end_571a481b:
    m 2m "Уверена, Юри и [player] тоже хотят новых участников..."

translate russian ch22_end_1df58135:
    m 2p "...Правда?"

translate russian ch22_end_0dbaabdd:
    y 4b "..."

translate russian ch22_end_2b35b6fe:
    mc "..."

translate russian ch22_end_58f56fbf:
    "Не знаю, как Юри, а мне, в общем-то, всё равно."

translate russian ch22_end_17b238ab:
    "Если бы я изобразил столько энтузиазма, сколько хотелось бы Монике, я бы, наверное, соврал."

translate russian ch22_end_cf24d816:
    "И всё же, если спасать положение придётся мне..."

translate russian ch22_end_cdf45e22:
    mc "Э-э—"

translate russian ch22_end_503abe6a:
    m 1i "Нет."

translate russian ch22_end_01972c84:
    m "Нацуки ведь права, разве нет?"

translate russian ch22_end_19daf7a1:
    m 1g "Этот клуб..."

translate russian ch22_end_a0608654:
    m "Это всего лишь место, где несколько человек проводят время."

translate russian ch22_end_80c6659b:
    m 1r "С чего я решила, что все здесь видят его так же, как я?"

translate russian ch22_end_d780d4d2:
    mc "Но это ведь не значит, что мы против новых участников или что-то такое..."

translate russian ch22_end_dad5846a:
    m 1i "[player], а зачем ты вообще вступил в этот клуб?"

translate russian ch22_end_20c5026b:
    m "Что ты надеялся от него получить?"

translate russian ch22_end_8c731859:
    mc "Ну—"

translate russian ch22_end_e43f371d:
    "Об этом ведь не скажешь честно, правда?"

translate russian ch22_end_c067a3a2:
    m 1p "Вообще..."

translate russian ch22_end_3baaeeef:
    m "Если я правильно помню, тебе даже не оставили выбора не вступать."

translate russian ch22_end_3bc0c7c5:
    "Моника садится и смотрит в парту."

translate russian ch22_end_b66bc109:
    m "И какой во всём этом смысл?"

translate russian ch22_end_781f555a:
    m "Что, если создать этот клуб было ошибкой?"

translate russian ch22_end_2b35b6fe_1:
    mc "..."

translate russian ch22_end_6e77d0eb:
    y 2g "Ну вот, доигралась, Нацуки..."

translate russian ch22_end_c6573abf:
    n 1p "Что, я?"

translate russian ch22_end_80ed7127:
    n 1s "Я просто сказала, что думаю..."

translate russian ch22_end_ce4a0b73:
    n "Быть честной — это что, преступление?"

translate russian ch22_end_287ca0d5:
    y 2l "Дело не в честности."

translate russian ch22_end_45374400:
    y "Дело в выборе слов."

translate russian ch22_end_a4120b64:
    y 2h "К тому же у тебя нет права говорить так за всех остальных в клубе..."

translate russian ch22_end_65c48c99:
    n 1e "Ты совсем ничего не понимаешь!"

translate russian ch22_end_bd0ce5a7:
    n 5s "Мне просто..."

translate russian ch22_end_f5aaf804:
    n "Я просто хочу место, где приятно проводить время с несколькими друзьями."

translate russian ch22_end_bc8c3dba:
    n 5u "Что плохого в том, что клуб для меня — именно такое место?"

translate russian ch22_end_2077196f:
    n "У меня не так... не так много других мест вроде этого..."

translate russian ch22_end_cbc7c5f9:
    n 5x "А теперь Моника хочет отнять его у меня!"

translate russian ch22_end_4f2b129e:
    mc "Никто ничего не отнимает—"

translate russian ch22_end_257eaeb5:
    n 1g "Нет, [player]."

translate russian ch22_end_d0a28886:
    n "Это будет не то."

translate russian ch22_end_708ce7dd:
    n 1q "Всё будет не то, если пойдёт так, как она хочет."

translate russian ch22_end_46000853:
    n "Если бы я хотела такого, то могла бы вступить в любой другой дурацкий клуб."

translate russian ch22_end_de720d71:
    n 12d "Но этот..."

translate russian ch22_end_d97c576a:
    n "Ну..."

translate russian ch22_end_1b585c2d:
    n 12e "Хотя бы недолго..."

translate russian ch22_end_58f236c5:
    n "Тут было хорошо."

translate russian ch22_end_b3b0536d:
    "Нацуки начинает собирать вещи."

translate russian ch22_end_abd5901d:
    n 12d "Я иду домой."

translate russian ch22_end_f28730ce:
    n "Мне кажется... сейчас мне здесь не место."

translate russian ch22_end_8007c5bb:
    y 3t "Нацуки..."

translate russian ch22_end_35e71b50:
    "Не обращая внимания на Юри, Нацуки выходит прямо из класса."

translate russian ch22_end_bcdc5cb9:
    y 3v "..."

translate russian ch22_end_0679cd5d:
    y "Это плохо..."

translate russian ch22_end_e3bc4d12:
    y "Я не знаю, что делать..."

translate russian ch22_end_c14c584c:
    mc "Ну..."

translate russian ch22_end_7bf7b653:
    mc "А что ты думаешь о фестивале?"

translate russian ch22_end_4b96e34d:
    y 4b "Я-я не знаю..."

translate russian ch22_end_7380ec27:
    y "Мне, наверное, в общем-то всё равно..."

translate russian ch22_end_b8c8caa2:
    y "Кому есть дело до этой несносной соплячки?"

translate russian ch22_end_9ee72c5f:
    y "Ну, мне нравится, как сейчас в клубе тихо и спокойно..."

translate russian ch22_end_e4561a6b:
    y "И я просто... счастлива, что ты здесь..."

translate russian ch22_end_78a3ac15:
    y 2t "Но всё же!"

translate russian ch22_end_54e17d2b:
    y "Я вице-президент..."

translate russian ch22_end_53ec556b:
    y "Неправильно с моей стороны вот так пренебрегать своими обязанностями..."

translate russian ch22_end_2a40ece1:
    y "Никто бы и не заплакал, если бы она покончила с собой."

translate russian ch22_end_8d0f2d2e:
    y 2l "Я должна постараться учесть мнение каждого и принять решение, которое будет правильным для клуба."

translate russian ch22_end_f0acf027:
    y 1t "А ты что думаешь, [player]?"

translate russian ch22_end_5d7de35c:
    y "Чего ты хочешь от этого клуба?"

translate russian ch22_end_8a1efaa0:
    "Юри повторяет тот же вопрос, что и Моника."

translate russian ch22_end_47a8a389:
    "Я решаю, что уклончивый ответ лучше, чем никакого."

translate russian ch22_end_4b247fc6:
    mc "...Думаю, самое важное, чтобы все ладили между собой..."

translate russian ch22_end_a03311e0:
    mc "...И чтобы клуб давал то, чего больше нигде не получишь."

translate russian ch22_end_13e800d6:
    mc "По-моему, дело не в количестве участников, а в том, какой каждый из них."

translate russian ch22_end_4a14c427:
    mc "Именно это и сделает Литературный клуб особенным местом."

translate russian ch22_end_a85b1d65:
    y 1u "Понятно..."

translate russian ch22_end_87b6ffda:
    y "Я полностью с тобой согласна."

translate russian ch22_end_d32f6531:
    y 1f "Каждый участник по-особенному вкладывает в клуб свои качества."

translate russian ch22_end_ca5990e9:
    y "С каждым новым участником меняется и характер клуба в целом."

translate russian ch22_end_72289e3b:
    y 1h "Не думаю, что это обязательно плохо."

translate russian ch22_end_35ccd42b:
    y "Иногда выходить из зоны комфорта..."

translate russian ch22_end_32715faa:
    y 1a "Так что если ты хочешь помочь Монике с фестивалем, я тоже на твоей стороне."

translate russian ch22_end_6651ab87:
    mc "Хорошо."

translate russian ch22_end_44bcfb97:
    mc "Что ж, может, завтра мы все поговорим с Нацуки..."

translate russian ch22_end_c588c8d6:
    "Юри кивает."

translate russian ch22_end_a8fa5cc4:
    m "Слушай, Юри..."

translate russian ch22_end_4874c190:
    y 1t "А?"

translate russian ch22_end_938e8ccc:
    m 1p "Э-э, я знаю, вчера всё было немного неловко..."

translate russian ch22_end_71185c69:
    m "Но мне кажется, ты должна знать, что я всё равно считаю тебя замечательным вице-президентом."

translate russian ch22_end_117f9036:
    m 1e "И ещё — замечательной подругой."

translate russian ch22_end_85507443:
    y 3s "М-Моника..."

translate russian ch22_end_a1af8e90:
    m 2e "Я хочу сделать всё, чтобы это был лучший клуб на свете."

translate russian ch22_end_dd97e600:
    m "Хорошо?"

translate russian ch22_end_d9ed8713:
    y "...Я тоже."

translate russian ch22_end_479c6697:
    m 1a "Ну вот..."

translate russian ch22_end_1e1487cf:
    m "Давайте на сегодня разойдёмся по домам."

translate russian ch22_end_fcee625a:
    m "О фестивале поговорим завтра."

translate russian ch22_end_40f3f0f5:
    y 1m "Хорошо."

translate russian ch22_end_795d2cfb:
    y "Буду ждать."

translate russian ch22_end_2336314d:
    y 1a "Пойдём, [player]?"

translate russian ch22_end_97752aee:
    m 1d "Э-э—"

translate russian ch22_end_b43b7c4d:
    m 1p "Пожалуйста, не пойми неправильно, но..."

translate russian ch22_end_da739202:
    m "Пусть [player] ещё немного задержится — я хочу с ним поболтать перед уходом."

translate russian ch22_end_d3635fb7:
    m 1d "Просто узнать, как ему тут нравится, и всё такое..."

translate russian ch22_end_8a11ce5c:
    m "Как для президента, для меня это важно."

translate russian ch22_end_a3dfe221:
    y 2v "..."

translate russian ch22_end_043d7f4b:
    "Юри выглядит немного встревоженной, но не возражает."

translate russian ch22_end_55494016:
    y 2t "Хорошо."

translate russian ch22_end_4ed2c539:
    y 2s "Я доверяю твоему решению, Моника."

translate russian ch22_end_3420e858:
    y "Тогда увидимся с вами обоими завтра."

translate russian ch22_end_3b3793d9:
    m 1j "До завтра~"

translate russian ch22_end_b6403be2:
    "Моника машет, пока Юри выходит из класса."

translate russian ch22_end_8085152d:
    m "Фух..."

translate russian ch22_end_18d8766c:
    m 2e "В последнее время всё как-то суматошно, правда?"

translate russian ch22_end_e54cec20:
    m "[player], я просто хотела убедиться, что тебе нравится в этом клубе."

translate russian ch22_end_5008fdb7:
    m "Мне бы очень не хотелось видеть тебя несчастным."

translate russian ch22_end_d6986044:
    m 2m "Мне кажется, как президент, я за это в ответе..."

translate russian ch22_end_c99edde7:
    m 4e "И ты мне правда очень дорог... понимаешь?"

translate russian ch22_end_011299d4:
    m "Мне не нравится, когда другие девочки тебя донимают."

translate russian ch22_end_43ecdfef:
    m 4r "То, какая грубая Нацуки, и всё такое..."

translate russian ch22_end_6e822e2e:
    m 4m "И Юри, которая немного... ну, ты понимаешь."

translate russian ch22_end_77bb8890:
    m 5a "А-ха-ха..."

translate russian ch22_end_8ba70b28:
    m "Иногда мне кажется, что только мы с тобой здесь настоящие."

translate russian ch22_end_0f0846ba:
    m "Понимаешь, о чём я?"

translate russian ch22_end_c2457032:
    m 1g "Но странно: за всё время, что ты здесь, мы почти не проводили время вместе."

translate russian ch22_end_98c60e88:
    m 1n "Ах... То есть..."

translate russian ch22_end_1a2636b3:
    m "Формально прошла всего пара дней..."

translate russian ch22_end_8cd8c881:
    m 1l "Прости, я не хотела сказать ничего странного!"

translate russian ch22_end_e552ed88:
    m 1e "Просто есть кое-что, о чём я надеялась с тобой поговорить..."

translate russian ch22_end_d1080c20:
    m "То, что, я знаю, можешь понять только ты."

translate russian ch22_end_b290e9fb:
    m "Поэтому—»{space=5000}{w=0.75}{nw}"

translate russian ch22_end_fac3f0f0:
    m 1g "Стой, ещё рано!»{space=5000}{w=0.5}{nw}"

translate russian ch22_end_13ae2bd2:
    m "Нет!»{space=5000}{w=0.5}{nw}"

translate russian ch22_end_22e3a165:
    m "Прекрати!»{space=5000}{w=1.0}{nw}"
