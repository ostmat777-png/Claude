# Русский перевод: script-exclusives-natsuki

translate russian natsuki_exclusive_1_f5f51468:
    n "Фу-у...!"

translate russian natsuki_exclusive_1_e174f989:
    "Из шкафа доносится раздражённый вздох Нацуки."

translate russian natsuki_exclusive_1_0fb627f5:
    "Похоже, её что-то бесит."

translate russian natsuki_exclusive_1_e62c6690:
    "Я подхожу к ней — вдруг нужна помощь."

translate russian natsuki_exclusive_1_32722f83:
    mc "Ищешь там что-то?"

translate russian natsuki_exclusive_1_5e9a5cc3:
    n 4x "Чёртова Моника..."

translate russian natsuki_exclusive_1_0e3ba913:
    n "Вечно она кладёт мои вещи не на место!"

translate russian natsuki_exclusive_1_bbbe4215:
    n "Какой смысл держать коллекцию в порядке, если кто-то другой всё равно её перепутает?"

translate russian natsuki_exclusive_1_19933c2f:
    "Нацуки передвигает по полке стопки книг и коробки."

translate russian natsuki_exclusive_1_3d3a82c5:
    mc "Манга..."

translate russian natsuki_exclusive_1_760f87e9:
    n 2c "Ты же читаешь мангу, да?"

translate russian natsuki_exclusive_1_f9d65918:
    mc "А—"

translate russian natsuki_exclusive_1_fdb5ed84:
    mc "...Иногда..."

translate russian natsuki_exclusive_1_935299a4:
    "Манга — одна из тех вещей, в увлечении которыми нельзя признаваться, пока не поймёшь, как к ней относится собеседник."

translate russian natsuki_exclusive_1_fe2f3706:
    mc "...А откуда ты вообще узнала?"

translate russian natsuki_exclusive_1_d0e38205:
    n 2k "Слышала, как ты как-то об этом обмолвился."

translate russian natsuki_exclusive_1_3688c727:
    n "К тому же это у тебя на лице написано."

translate russian natsuki_exclusive_1_c145e81e:
    "Это ещё что значит...?"

translate russian natsuki_exclusive_1_f11161d0:
    mc "П-понятно..."

translate russian natsuki_exclusive_1_9262900f:
    "Сбоку на одной из полок, посреди стопки разных книг, лежит одинокий том манги."

translate russian natsuki_exclusive_1_e06f14e6:
    "Из любопытства я вытаскиваю его из стопки."

translate russian natsuki_exclusive_1_02dc322f:
    n 1b "Вот {i}он{/i} где!"

translate russian natsuki_exclusive_1_df52ab96:
    "Нацуки выхватывает его у меня из рук."

translate russian natsuki_exclusive_1_f2ebfaf0:
    "Потом поворачивается к коробке с мангой и вставляет том ровно в середину остальных."

translate russian natsuki_exclusive_1_f7505123:
    n 4d "А-ах, так-то лучше!"

translate russian natsuki_exclusive_1_41cc269d:
    n "Подарочное издание без одного тома — это, наверное, самое бесящее зрелище на свете."

translate russian natsuki_exclusive_1_3405b196:
    mc "Понимаю тебя..."

translate russian natsuki_exclusive_1_e9a28cdf:
    "Я присматриваюсь к коробке, которой она любуется."

translate russian natsuki_exclusive_1_6c14e515:
    mc "«Девочки-парфе»...?"

translate russian natsuki_exclusive_1_611bb932:
    "В жизни не слышал о такой серии."

translate russian natsuki_exclusive_1_9063d972:
    "Наверное, значит, она либо совсем не для моей аудитории, либо просто ужасная."

translate russian natsuki_exclusive_1_25561b25:
    n 5g "Если собираешься осуждать, можешь делать это через стекло вон той двери."

translate russian natsuki_exclusive_1_62958553:
    "Она показывает на дверь класса."

translate russian natsuki_exclusive_1_e0baf49e:
    mc "Э-эй, я ничего не осуждал...!"

translate russian natsuki_exclusive_1_e11cdc69:
    mc "Я даже ничего не сказал."

translate russian natsuki_exclusive_1_81abce97:
    n 5c "Это было по тону понятно."

translate russian natsuki_exclusive_1_99d676ef:
    n "Но вот что я тебе скажу, [player]."

translate russian natsuki_exclusive_1_70e41b54:
    n 4l "Считай это уроком прямо от Литературного клуба: не суди книгу по обложке!"

translate russian natsuki_exclusive_1_55994a4c:
    n "Вообще—"

translate russian natsuki_exclusive_1_c864c1c4:
    "Нацуки вытаскивает из коробки первый том «Девочек-парфе»."

translate russian natsuki_exclusive_1_6ca1c062:
    n "Сейчас я тебе докажу почему!"

translate russian natsuki_exclusive_1_8c231d22:
    "Она пихает книгу прямо мне в руки."

translate russian natsuki_exclusive_1_93deaf69:
    mc "А..."

translate russian natsuki_exclusive_1_ea5a5f1b:
    "Я смотрю на обложку."

translate russian natsuki_exclusive_1_e3a67a99:
    "На ней четыре девочки в ярких нарядах в нарочито девчачьих позах."

translate russian natsuki_exclusive_1_d546682a:
    "Она... невероятно «моэ»."

translate russian natsuki_exclusive_1_2530be57:
    n 4b "Не стой столбом!"

translate russian natsuki_exclusive_1_f0b857d1:
    mc "Уа—"

translate russian natsuki_exclusive_1_7bb26e7b:
    "Нацуки хватает меня за руку и вытаскивает из шкафа."

translate russian natsuki_exclusive_1_dd24a43a:
    "Потом садится на пол у стены, под подоконниками."

translate russian natsuki_exclusive_1_257d9d09:
    "Она похлопывает по полу рядом с собой — мол, садись сюда."

translate russian natsuki_exclusive_1_a388cb6c:
    mc "На стульях разве не удобнее...?"

translate russian natsuki_exclusive_1_6b32c532:
    "Я сажусь."

translate russian natsuki_exclusive_1_8664d124:
    n 2k "На стульях не получится."

translate russian natsuki_exclusive_1_5e4bb5e8:
    n "Так мы не сможем читать одновременно."

translate russian natsuki_exclusive_1_635adbe8:
    mc "А? Почему?"

translate russian natsuki_exclusive_1_b57e800b:
    mc "А... Наверное, так проще сидеть поближе друг к другу..."

translate russian natsuki_exclusive_1_b8d9f096:
    n 2o "—!"

translate russian natsuki_exclusive_1_b2178e0d:
    n 5r "Н-не говори так!"

translate russian natsuki_exclusive_1_0552d4c2:
    n "Из-за тебя мне теперь неловко!"

translate russian natsuki_exclusive_1_8496ec88:
    "Нацуки скрещивает руки и отодвигается от меня на пару сантиметров."

translate russian natsuki_exclusive_1_4bbe5891:
    mc "Прости..."

translate russian natsuki_exclusive_1_1c753a2f:
    "Я и сам не ожидал, что буду сидеть к ней так близко..."

translate russian natsuki_exclusive_1_980af971:
    "Не то чтобы это было так уж плохо."

translate russian natsuki_exclusive_1_dabf6e7e:
    "Я открываю книгу."

translate russian natsuki_exclusive_1_297d8d04:
    "Не проходит и нескольких секунд, как Нацуки снова потихоньку придвигается, возвращая себе отвоёванное место в надежде, что я не замечу."

translate russian natsuki_exclusive_1_91c84663:
    "Я чувствую, как она заглядывает мне через плечо — ей куда больше не терпится начать читать, чем мне."

translate russian natsuki_exclusive_1_e4b36a19:
    n 1k "Ого, сколько же я не перечитывала начало...?"

translate russian natsuki_exclusive_1_582359ea:
    mc "Хм?"

translate russian natsuki_exclusive_1_855a6256:
    mc "Ты разве не перелистываешь иногда старые тома?"

translate russian natsuki_exclusive_1_94edd37c:
    n 2k "Не особо."

translate russian natsuki_exclusive_1_694aae97:
    n "Ну, может, иногда, когда уже дочитаю серию."

translate russian natsuki_exclusive_1_124c99bd:
    n 2c "Эй, ты вообще внимательно читаешь?"

translate russian natsuki_exclusive_1_8114a09f:
    mc "Э-э..."

translate russian natsuki_exclusive_1_7073f2ea:
    "Внимательно, просто пока ничего не происходит, так что я могу и поговорить."

translate russian natsuki_exclusive_1_e0d85fbb:
    "Похоже, это про компанию подружек в старшей школе."

translate russian natsuki_exclusive_1_511a3baf:
    "Типичная повседневность."

translate russian natsuki_exclusive_1_7c851bd7:
    "Я вроде как из такого вырос — редко когда написано настолько увлекательно, чтобы это искупало отсутствие сюжета."

translate russian natsuki_exclusive_1_cb70afb1:
    mc "Так..."

translate russian natsuki_exclusive_1_c786690e:
    mc "Чего мне от этого ждать?"

translate russian natsuki_exclusive_1_7d992dc5:
    mc "Сюжет будет?"

translate russian natsuki_exclusive_1_5a5ee160:
    n 4w "Ну, разумеется!"

translate russian natsuki_exclusive_1_aca8733a:
    n "Думаешь, мне бы понравилось что-то без сюжета?"

translate russian natsuki_exclusive_1_5a541bbb:
    n 4c "Ну..."

translate russian natsuki_exclusive_1_cf2adbdc:
    n 2c "Ну, хотя я понимаю, о чём ты..."

translate russian natsuki_exclusive_1_c95412aa:
    n 2k "В начале много всяких простых вещей..."

translate russian natsuki_exclusive_1_44935a46:
    n "Например, там есть очень смешная глава, где они все сохнут по парню из кафе-мороженого..."

translate russian natsuki_exclusive_1_70363d37:
    n 2c "Но это просто помогает узнать персонажей!"

translate russian natsuki_exclusive_1_9741f471:
    n "И к тому же это всё равно интересно."

translate russian natsuki_exclusive_1_9155c87b:
    n 2d "А дальше там столько драмы..."

translate russian natsuki_exclusive_1_57c42c04:
    n "Когда начинают раскрываться их предыстории и закручивается романтика..."

translate russian natsuki_exclusive_1_313721a5:
    n "Вот за это я её так и люблю."

translate russian natsuki_exclusive_1_bff30210:
    n 2a "Там столько трогательных моментов."

translate russian natsuki_exclusive_1_2cc4aa9e:
    mc "А, вот как?"

translate russian natsuki_exclusive_1_5be963ef:
    mc "Похоже, ты прекрасно знаешь, о чём говоришь."

translate russian natsuki_exclusive_1_f6a90886:
    mc "Может, я тебя недооценивал."

translate russian natsuki_exclusive_1_5bcc6564:
    n 2z "Э-хе-хе."

translate russian natsuki_exclusive_1_2efacfde:
    n 1f "...Эй, стоп!"

translate russian natsuki_exclusive_1_6e9e1c62:
    n "Это {i}что{/i} ещё значит?!"

translate russian natsuki_exclusive_1_f0b857d1_1:
    mc "Уа—"

translate russian natsuki_exclusive_1_64b69331:
    "Нацуки легонько меня толкает."

translate russian natsuki_exclusive_1_21ee27ca:
    mc "Я просто имел в виду, что ещё не видел тебя во всей красе..."

translate russian natsuki_exclusive_1_b6cb3a66:
    n 5s "Хмф. Выкрутился."

translate russian natsuki_exclusive_1_246ccb7a:
    mc "О... Эта глава, кажется, про выпечку."

translate russian natsuki_exclusive_1_5a373390:
    mc "Это просто догадка, но в этой манге много выпечки?"

translate russian natsuki_exclusive_1_8f42018a:
    n 5b "Ну—"

translate russian natsuki_exclusive_1_5be403e0:
    "Нацуки на мгновение замолкает, будто не хочет в чём-то признаваться."

translate russian natsuki_exclusive_1_0068b16f:
    n 2q "...Да."

translate russian natsuki_exclusive_1_2bff6b3c:
    n "Какая разница?"

translate russian natsuki_exclusive_1_5e2a3c24:
    mc "Никакой, просто стало любопытно..."

translate russian natsuki_exclusive_1_f7b093de:
    mc "Ты ведь тоже любишь печь, правда?"

translate russian natsuki_exclusive_1_f6366859:
    n 1o "Это—"

translate russian natsuki_exclusive_1_894db4d3:
    n "Просто совпадение!"

translate russian natsuki_exclusive_1_b4d812c9:
    n 1t "Я просто случайно начала печь примерно тогда же, когда купила эту мангу."

translate russian natsuki_exclusive_1_86ae8773:
    n "Можно подумать, я бы увлеклась чем-то только потому, что это есть в манге."

translate russian natsuki_exclusive_1_98a8c8d4:
    n 4y "Мне жаль тех, кто настолько впечатлительный."

translate russian natsuki_exclusive_1_5ba50678:
    n "А-ха-ха!"

translate russian natsuki_exclusive_1_15a36bd6:
    "Точно не совпадение..."

translate russian natsuki_exclusive_1_fb7886e0:
    "Что ж, теперь понятно, откуда у Нацуки интерес к выпечке."

translate russian natsuki_exclusive_1_b61feb9d:
    "И всё-таки из всех хобби, которые можно подхватить из манги, это определённо одно из лучших."

translate russian natsuki_exclusive_1_fdf81891:
    "Не говоря уже о том, что у неё здорово получается, так что не мне её судить."

translate russian natsuki_exclusive_1_a20cefa7:
    "..."

translate russian natsuki_exclusive_1_1819e974:
    "Мы читаем дальше ещё несколько минут."

translate russian natsuki_exclusive_1_dfa4d6d1:
    "Я уже успел дочитать пару глав."

translate russian natsuki_exclusive_1_2b35b6fe:
    mc "..."

translate russian natsuki_exclusive_1_7421f499:
    mc "...Тебе точно не скучно?"

translate russian natsuki_exclusive_1_2d028262:
    n "Нет!"

translate russian natsuki_exclusive_1_f92b8b31:
    mc "Даже притом что ты просто смотришь, как я читаю?"

translate russian natsuki_exclusive_1_8d52f3b6:
    n "Ну...!"

translate russian natsuki_exclusive_1_0d8d3782:
    n "Меня... это устраивает."

translate russian natsuki_exclusive_1_0f240219:
    mc "Как скажешь..."

translate russian natsuki_exclusive_1_e9a6fb41:
    mc "...Наверное, это весело — делиться с кем-то тем, что тебе нравится."

translate russian natsuki_exclusive_1_62b59994:
    mc "Я всегда радуюсь, когда уговариваю кого-нибудь из друзей взяться за серию, которая мне нравится."

translate russian natsuki_exclusive_1_fec87230:
    mc "Понимаешь, о чём я?"

translate russian natsuki_exclusive_1_913a614e:
    n "...?"

translate russian natsuki_exclusive_1_582359ea_1:
    mc "Хм?"

translate russian natsuki_exclusive_1_02d45d2f:
    mc "Нет?"

translate russian natsuki_exclusive_1_2889c693:
    n "Э-э..."

translate russian natsuki_exclusive_1_5ca88476:
    n "Дело не..."

translate russian natsuki_exclusive_1_5536a673:
    n "Ну, я бы не знала."

translate russian natsuki_exclusive_1_5537750c:
    mc "...В смысле?"

translate russian natsuki_exclusive_1_a5685cc1:
    mc "Ты разве не даёшь свою мангу почитать друзьям?"

translate russian natsuki_exclusive_1_2595cac7:
    n "Можешь не сыпать соль на рану?"

translate russian natsuki_exclusive_1_a8557d5c:
    n "Блин..."

translate russian natsuki_exclusive_1_8c8bfeaa:
    mc "А... Прости..."

translate russian natsuki_exclusive_1_ffa2b290:
    n "Хмф."

translate russian natsuki_exclusive_1_ef747705:
    n "Как будто я когда-нибудь уговорю своих друзей это читать..."

translate russian natsuki_exclusive_1_0b331d4f:
    n "Они считают, что манга — для детей."

translate russian natsuki_exclusive_1_50b06aca:
    n "Я даже заикнуться о ней не могу, чтобы они не начали..."

translate russian natsuki_exclusive_1_b1ca56d6:
    n "„А? Ты что, всё ещё из этого не выросла?“"

translate russian natsuki_exclusive_1_446342e2:
    n "Так и хочется врезать им по лицу..."

translate russian natsuki_exclusive_1_183334f1:
    mc "Фу, знаю я таких людей..."

translate russian natsuki_exclusive_1_60cbb2cd:
    mc "Честно, найти друзей, которые не осуждают, и то непросто, а уж таких, кто сам этим увлекается..."

translate russian natsuki_exclusive_1_d9a25b5a:
    mc "Я и так вроде как неудачник, так что со временем, наверное, просто прибился к другим неудачникам."

translate russian natsuki_exclusive_1_18ccc31d:
    mc "Но такой, как ты, наверное, сложнее..."

translate russian natsuki_exclusive_1_94e08ea3:
    n "Хм."

translate russian natsuki_exclusive_1_3243cf7d:
    n "Да, в точку."

translate russian natsuki_exclusive_1_6607ad07:
    "{i}...Стоп, в какую именно??{/i}"

translate russian natsuki_exclusive_1_458559a0:
    n "Ну, мне кажется, я даже у себя в комнате её держать не могу..."

translate russian natsuki_exclusive_1_d0ddcf73:
    n "Даже не знаю, что сделает папа, если это найдёт."

translate russian natsuki_exclusive_1_df80381b:
    n "Здесь, в клубной комнате, хотя бы безопасно."

translate russian natsuki_exclusive_1_ca96df24:
    n "Вот только Моника повела себя как-то по-свински..."

translate russian natsuki_exclusive_1_d8940374:
    n "Фу! Ну никак мне не выиграть, да?"

translate russian natsuki_exclusive_1_99eb6c77:
    mc "Ну, в итоге-то оно того стоило, разве нет?"

translate russian natsuki_exclusive_1_c32a8e96:
    mc "В смысле, вот он я — читаю."

translate russian natsuki_exclusive_1_8d57229c:
    n "Ну, это не решает ни одной моей проблемы."

translate russian natsuki_exclusive_1_6ddddd1f:
    mc "Может быть..."

translate russian natsuki_exclusive_1_cb991f4e:
    mc "Но тебе ведь хотя бы весело, правда?"

translate russian natsuki_exclusive_1_b92ff8c5:
    n "—"

translate russian natsuki_exclusive_1_bb2cf764:
    n "..."

translate russian natsuki_exclusive_1_8e4ceee1:
    n "...И что?"

translate russian natsuki_exclusive_1_ee7d9dbd:
    mc "А-ха-ха."

translate russian natsuki_exclusive_1_4daa32b4:
    n "Блин, хватит уже!"

translate russian natsuki_exclusive_1_1606fdc6:
    n "Ты будешь читать дальше или как?"

translate russian natsuki_exclusive_1_e9ea92f3:
    mc "Да-да..."

translate russian natsuki_exclusive_1_c1f9d35e:
    "Я переворачиваю страницу."

translate russian natsuki_exclusive_1_15f483ef:
    "Вдруг Нацуки начинает смеяться."

translate russian natsuki_exclusive_1_f991fa72:
    n "А-ха-ха-ха!"

translate russian natsuki_exclusive_1_1cd62078:
    n "Я совсем забыла, что тут такое!"

translate russian natsuki_exclusive_1_0793c470:
    "Нацуки тычет пальцем в один из кадров."

translate russian natsuki_exclusive_1_a82192a0:
    n "Минори — мой любимый персонаж."

translate russian natsuki_exclusive_1_ea7828e8:
    n "Её всегда немножко жалко, она ведь такая невезучая."

translate russian natsuki_exclusive_1_ef8c2291:
    n "Но особенно плохо становится, когда—"

translate russian natsuki_exclusive_1_e349a681:
    n "У-у..."

translate russian natsuki_exclusive_1_59cb15ff:
    n "Мне пока нельзя об этом рассказывать!"

translate russian natsuki_exclusive_1_fea95830:
    n "Просто дочитай главу!"

translate russian natsuki_exclusive_1_b2e89501:
    "Голос Нацуки так и искрится от восторга."

translate russian natsuki_exclusive_1_d391e57f:
    "Это разительно отличается от её обычного командирского тона."

translate russian natsuki_exclusive_1_b3cf1565:
    "Но если она не привыкла делиться любимой мангой с друзьями, я понимаю почему."

translate russian natsuki_exclusive_1_ebfaba83:
    "Сложно выразить словами, каково это — вот так найти с кем-то общий язык."

translate russian natsuki_exclusive_1_b2987ad8:
    "И подарить это Нацуки, для которой это такая редкость..."

translate russian natsuki_exclusive_1_738f4054:
    "От этой мысли я слегка улыбаюсь сам себе."

translate russian natsuki_exclusive_1_90de9c4d:
    m "Итак, ребята!"

translate russian natsuki_exclusive_1_fb2e5377:
    mc "А?"

translate russian natsuki_exclusive_1_38450dd4:
    m "Все готовы со своими сегодняшними стихами?"

translate russian natsuki_exclusive_1_2b35b6fe_1:
    mc "..."

translate russian natsuki_exclusive_1_b6d243af:
    n "Ну вот!"

translate russian natsuki_exclusive_1_71b0c5cc:
    n "Можно было выбрать момент ещё хуже?"

translate russian natsuki_exclusive_1_ec0c9d1e:
    m 5 "Простите~!"

translate russian natsuki_exclusive_1_54c6fd3e:
    m "Мне просто нужно убедиться, что у нас хватит времени."

translate russian natsuki_exclusive_1_569b548e:
    m "Хотя вы там так уютно устроились. А-ха-ха!"

translate russian natsuki_exclusive_1_f9fdc4e1:
    n 4o "А...?"

translate russian natsuki_exclusive_1_97cc8428:
    n 1p "А-ах!"

translate russian natsuki_exclusive_1_349b43fd:
    "Нацуки вдруг замечает, как близко ко мне придвинулась."

translate russian natsuki_exclusive_1_05260637:
    "Она поспешно отодвигается от меня сантиметров на тридцать."

translate russian natsuki_exclusive_1_b12907fb:
    mc "Ладно..."

translate russian natsuki_exclusive_1_e9612366:
    mc "Что ж, пожалуй, пока на этом остановлюсь."

translate russian natsuki_exclusive_1_73e19c2f:
    "Я закрываю книгу и протягиваю её Нацуки."

translate russian natsuki_exclusive_1_c9ff408a:
    n 2m "Ты что, просто отдаёшь её обратно...?"

translate russian natsuki_exclusive_1_da60f865:
    n "Тебе разве не интересно, что будет дальше?"

translate russian natsuki_exclusive_1_6ddf54dc:
    mc "А... Интересно, но..."

translate russian natsuki_exclusive_1_7229c890:
    mc "Моника только что сказала—"

translate russian natsuki_exclusive_1_dc55ffc9:
    n 2u "Не тупи."

translate russian natsuki_exclusive_1_c5b06922:
    n "Просто возьми её домой."

translate russian natsuki_exclusive_1_fb2e5377_1:
    mc "А?"

translate russian natsuki_exclusive_1_db272561:
    mc "...Правда можно?"

translate russian natsuki_exclusive_1_0e34cd99:
    "Я говорю это в основном потому, что вообще-то не собирался тратить на это своё свободное время..."

translate russian natsuki_exclusive_1_69f3672f:
    n 4h "Ну, конечно."

translate russian natsuki_exclusive_1_491977d0:
    n "Если не брать домой, ты её вечность будешь читать."

translate russian natsuki_exclusive_1_90e710d5:
    n "Просто дочитай этот том до завтра, чтобы мы начали следующий."

translate russian natsuki_exclusive_1_a5d8d788:
    n 4g "А если помнёшь — убью."

translate russian natsuki_exclusive_1_d802271c:
    mc "До завтра...?"

translate russian natsuki_exclusive_1_5a11364f:
    "Пока я прочитал только часть тома."

translate russian natsuki_exclusive_1_c8df51e0:
    "Если попробую его осилить, могу отстать с парой сериалов..."

translate russian natsuki_exclusive_1_2a29eb4a:
    "Но, пожалуй, это необходимая жертва в обмен на воодушевлённое лицо Нацуки."

translate russian natsuki_exclusive_1_1eac80ea:
    "Или я больше боюсь того, что будет, если я его {i}не{/i} дочитаю...?"

translate russian natsuki_exclusive_1_af2a614d:
    mc "Ладно, договорились!"

translate russian natsuki_exclusive_1_1950528a:
    "Я встаю."

translate russian natsuki_exclusive_1_d9693005:
    "Возвращаюсь туда, где оставил вещи, и аккуратно кладу книгу в сумку."

translate russian natsuki_exclusive_2_bb2cf764:
    n "..."

translate russian natsuki_exclusive_2_1c949878:
    "Вскоре Нацуки подходит ко мне с выжидающим видом."

translate russian natsuki_exclusive_2_fe5be12c:
    mc "Да-да."

translate russian natsuki_exclusive_2_51341510:
    mc "Не волнуйся, я сдержал обещание."

translate russian natsuki_exclusive_2_ch3_1517f2ce:
    "Я достаю из сумки первый том «Девочек-парфе»."

translate russian natsuki_exclusive_2_ch3_ae826c40:
    "Нацуки забирает его у меня из рук и тут же переворачивает — видимо, проверяет, нет ли заломов."

translate russian natsuki_exclusive_2_ch3_27b0c9d7:
    mc "Эй, я не настолько неаккуратный..."

translate russian natsuki_exclusive_2_ch3_d09ee7b4:
    mc "Я, между прочим, постоянно имею дело с мангой."

translate russian natsuki_exclusive_2_ch3_97b42920:
    n 1m "Я просто хотела убедиться!"

translate russian natsuki_exclusive_2_ch3_41434a6e:
    n 1c "Можешь ли ты меня винить за паранойю?"

translate russian natsuki_exclusive_2_ch3_68339437:
    n "Знаешь, я не каждый день даю людям свою мангу."

translate russian natsuki_exclusive_2_ch3_3c4580b7:
    mc "Это правда..."

translate russian natsuki_exclusive_2_ch3_66b14b6a:
    mc "Я тебя не виню."

translate russian natsuki_exclusive_2_ch3_84443ef5:
    n 2j "Ну, в общем, дай я положу этот на место."

translate russian natsuki_exclusive_2_ch3_5536fe42:
    n "Я возьму следующий, ладно?"

translate russian natsuki_exclusive_2_ch3_3bacb08d:
    "Нацуки направляется к шкафу."

translate russian natsuki_exclusive_2_ch3_fd6adbe5:
    "Я иду следом."

translate russian natsuki_exclusive_2_ch3_8f485b4a:
    n "Ты ведь расскажешь мне всё, что думаешь, да??"

translate russian natsuki_exclusive_2_ch3_82b367f1:
    n 2k "На чём там закончился этот том? Я забыла."

translate russian natsuki_exclusive_2_ch3_d3e58482:
    mc "А, глава закончилась, когда Минори и Алиса нашли—"

translate russian natsuki_exclusive_2_ch3_91d91271:
    n "{i}Моника!!{/i}"

translate russian natsuki_exclusive_2_ch3_fe1ea2e2:
    "Голос Нацуки гулко разносится из шкафа."

translate russian natsuki_exclusive_2_ch3_bbe4458e:
    mc "А...?"

translate russian natsuki_exclusive_2_ch3_a666f07b:
    "Я заглядываю внутрь."

translate russian natsuki_exclusive_2_ch3_0c2e8b54:
    "Все книги Нацуки выстроены на верхней полке."

translate russian natsuki_exclusive_2_ch3_c580c645:
    n "Ты опять переложила мою мангу?!"

translate russian natsuki_exclusive_2_ch3_96b67ead:
    m "Ой, прости, прости!"

translate russian natsuki_exclusive_2_ch3_cf02ffb4:
    m "Учительница на меня рассердилась, что мы занимаем столько места в её шкафу..."

translate russian natsuki_exclusive_2_ch3_aab78bdd:
    m "Так что мне пришлось кое-что переставить и немного прибраться."

translate russian natsuki_exclusive_2_ch3_4120383d:
    m 3b "Всё на месте, я просто немножко навела порядок!"

translate russian natsuki_exclusive_2_ch3_83b5fd61:
    n 1r "Фу..."

translate russian natsuki_exclusive_2_ch3_c6a28064:
    "Верхняя полка гораздо выше головы Нацуки."

translate russian natsuki_exclusive_2_ch3_84c37428:
    "Она безуспешно подпрыгивает, пытаясь придумать, как дотянуться до своей манги."

translate russian natsuki_exclusive_2_ch3_29a51a04:
    n 1q "Блин...!"

translate russian natsuki_exclusive_2_ch3_b068ef78:
    n "Это так неудобно!"

translate russian natsuki_exclusive_2_ch3_7f2f28c5:
    n 1c "Я всё переложу обратно вниз."

translate russian natsuki_exclusive_2_ch3_7ab45016:
    n "Тут полно места на полках."

translate russian natsuki_exclusive_2_ch3_cbf5db0f:
    n "И к тому же..."

translate russian natsuki_exclusive_2_ch3_5523ce90:
    n 4w "Они так красиво смотрятся, когда стоят в ряд!"

translate russian natsuki_exclusive_2_ch3_b3e04671:
    n "Зачем прятать это на верхней полке?"

translate russian natsuki_exclusive_2_ch3_fa810c86:
    mc "А, Нацуки..."

translate russian natsuki_exclusive_2_ch3_da0ff16e:
    mc "Вон там на стене табуретка."

translate russian natsuki_exclusive_2_ch3_9125866c:
    "В шкафу на стене висит складная табуретка."

translate russian natsuki_exclusive_2_ch3_622a336f:
    mc "Если хочешь, я могу дотянуться и подать их тебе..."

translate russian natsuki_exclusive_2_ch3_99e0acd8:
    n 1g "Я и сама могу достать!"

translate russian natsuki_exclusive_2_ch3_b4aa0bca:
    "Нацуки снимает табуретку со стены и раскладывает её."

translate russian natsuki_exclusive_2_ch3_7d6f303a:
    n "Думаешь, я слишком низкая или что?"

translate russian natsuki_exclusive_2_ch3_d876ae52:
    mc "Ну—"

translate russian natsuki_exclusive_2_ch3_c79f7cd9:
    n 5x "Я {i}так{/i} и знала!"

translate russian natsuki_exclusive_2_ch3_7a2e300e:
    n 5w "Ну, знаешь что?"

translate russian natsuki_exclusive_2_ch3_468c811f:
    n "Смотри и учись!"

translate russian natsuki_exclusive_2_ch3_619846a9:
    "Нацуки запрыгивает на табуретку, которая из-за складной конструкции немного шатается."

translate russian natsuki_exclusive_2_ch3_5f51c6af:
    n 1f "А-ах..."

translate russian natsuki_exclusive_2_ch3_68d06110:
    mc "Осторожнее..."

translate russian natsuki_exclusive_2_ch3_5fe6bc30:
    n 1r "Я знаю, что делаю!!"

translate russian natsuki_exclusive_2_ch3_052bfa98:
    "Стоя на табуретке, Нацуки едва касается кончиками пальцев верхней полки."

translate russian natsuki_exclusive_2_ch3_28e734d3:
    "Мне бы табуретки хватило, чтобы с лёгкостью достать книги, но Нацуки, как обычно, упрямится."

translate russian natsuki_exclusive_2_ch3_47e4220d:
    n "У-у-у-ух..."

translate russian natsuki_exclusive_2_ch3_8d4d8827:
    "Нацуки пальцами подталкивает одну из коробок поменьше к краю полки."

translate russian natsuki_exclusive_2_ch3_a27c3e6f:
    n 1t "Видишь...?"

translate russian natsuki_exclusive_2_ch3_fe17973e:
    n 1v "Кья—!"

translate russian natsuki_exclusive_2_ch3_8982ecb6:
    "Коробка вдруг накреняется."

translate russian natsuki_exclusive_2_ch3_3edc7642:
    "Нацуки едва успевает поймать её, прежде чем та упадёт на пол."

translate russian natsuki_exclusive_2_ch3_b4d0261c:
    "Табуретка шатается."

translate russian natsuki_exclusive_2_ch3_ae68d9f6:
    n "Ва-а-а—"

translate russian natsuki_exclusive_2_ch3_cb670026:
    "Потеряв равновесие, Нацуки спрыгивает с табуретки."

translate russian natsuki_exclusive_2_ch3_729b9c24:
    "К счастью, ей удаётся устоять на ногах."

translate russian natsuki_exclusive_2_ch3_1129075a:
    "Она торжествующе держит коробку."

translate russian natsuki_exclusive_2_ch3_65110220:
    n 4y "В-вот!"

translate russian natsuki_exclusive_2_ch3_f0dd7c4f:
    "Чуть не упав, Нацуки слегка напугана."

translate russian natsuki_exclusive_2_ch3_9098da49:
    mc "Ну ты даёшь..."

translate russian natsuki_exclusive_2_ch3_403070d1:
    mc "Не нужно мне ничего доказывать."

translate russian natsuki_exclusive_2_ch3_559fb2f0:
    mc "Так ты ни за что не достанешь коробки побольше."

translate russian natsuki_exclusive_2_ch3_4202c4cd:
    mc "Я дотягиваюсь, так что просто—"

translate russian natsuki_exclusive_2_ch3_b9d87bdd:
    n 2h "Я сказала, что сама могу!"

translate russian natsuki_exclusive_2_ch3_ff4ef696:
    n "Мне не нужна твоя помощь, ясно?"

translate russian natsuki_exclusive_2_ch3_0a69f768:
    mc "Эх..."

translate russian natsuki_exclusive_2_ch3_31e0117b:
    n "Сейчас возьму стул, так что подожди."

translate russian natsuki_exclusive_2_ch3_4d7e6d77:
    "Нацуки протискивается мимо меня из шкафа."

translate russian natsuki_exclusive_2_ch3_b7f4bef4:
    n "Так-так..."

translate russian natsuki_exclusive_2_ch3_bb07e385:
    "К школьным стульям приделаны парты, так что в шкаф их не втиснуть."

translate russian natsuki_exclusive_2_ch3_d1c3e445:
    n "Ага!"

translate russian natsuki_exclusive_2_ch3_4ac234dc:
    "Нацуки семенит к учительскому столу, за которым стоит компьютерное кресло."

translate russian natsuki_exclusive_2_ch3_3209f02d:
    "Она катит его на колёсиках обратно к шкафу."

translate russian natsuki_exclusive_2_ch3_f9d65918:
    mc "А—"

translate russian natsuki_exclusive_2_ch3_01c130a5:
    "Это немного опасно — кресло крутится и ездит."

translate russian natsuki_exclusive_2_ch3_6077ba81:
    "Но я уже усвоил урок, так что помалкиваю."

translate russian natsuki_exclusive_2_ch3_fd921c69:
    n 1 "У-ух—"

translate russian natsuki_exclusive_2_ch3_7c19c44e:
    "Нацуки забирается на кресло, а потом медленно встаёт на ноги, ловя равновесие."

translate russian natsuki_exclusive_2_ch3_d1f19f93:
    "Раз уж она отказывается от моей помощи, я сажусь, прислонившись спиной к дверному косяку, и просто наблюдаю."

translate russian natsuki_exclusive_2_ch3_bee4145f:
    n "Ага! Вот так-то!"

translate russian natsuki_exclusive_2_ch3_58604fd8:
    n "Видишь? Теперь я легко дотягиваюсь."

translate russian natsuki_exclusive_2_ch3_2d32bcfb:
    "Нацуки берёт стопку манги и наклоняется, чтобы положить её на полку ниже."

translate russian natsuki_exclusive_2_ch3_0d79a028:
    n "В-ва-а—"

translate russian natsuki_exclusive_2_ch3_7f1410f6:
    "Кресло поворачивается."

translate russian natsuki_exclusive_2_ch3_6beea472:
    "Нацуки хватается за полку."

translate russian natsuki_exclusive_2_ch3_d9284456:
    n "Ты что делаешь??"

translate russian natsuki_exclusive_2_ch3_a60d169d:
    n "Может, хотя бы подержишь кресло, вместо того чтобы сидеть сложа руки?"

translate russian natsuki_exclusive_2_ch3_0fba7211:
    "{i}(И кто мне говорил не помогать...?){/i}"

translate russian natsuki_exclusive_2_ch3_e20fd47c:
    mc "Да-да... держу."

translate russian natsuki_exclusive_2_ch3_ffbaf59d:
    "Я держу кресло, пока Нацуки снова тянется наверх."

translate russian natsuki_exclusive_2_ch3_55feb8f4:
    mc "—!"

translate russian natsuki_exclusive_2_ch3_74a55d6a:
    "Мне..."

translate russian natsuki_exclusive_2_ch3_2c430f18:
    "{i}Мне почти видно, что у неё под юбкой?!{/i}"

translate russian natsuki_exclusive_2_ch3_596ac1ee:
    mc "Кх—"

translate russian natsuki_exclusive_2_ch3_0510f4b3:
    "Я заставляю себя отвернуться."

translate russian natsuki_exclusive_2_ch3_690b1a81:
    "Нацуки явно об этом не подумала...!"

translate russian natsuki_exclusive_2_ch3_5b3158b1:
    "Как только до неё дойдёт, мне конец!"

translate russian natsuki_exclusive_2_ch3_67356251:
    n "Оп—"

translate russian natsuki_exclusive_2_ch3_070c6d61:
    "Нацуки обхватывает руками коробку «Девочек-парфе» — самую большую на полке."

translate russian natsuki_exclusive_2_ch3_358de399:
    n "У-у... тяжёлая..."

translate russian natsuki_exclusive_2_ch3_c88e1762:
    n "Эй, [player]..."

translate russian natsuki_exclusive_2_ch3_23af2462:
    n "К-кажется, я не смогу наклониться и не упасть...!"

translate russian natsuki_exclusive_2_ch3_9ef27350:
    n "Скорее возьми её..."

translate russian natsuki_exclusive_2_ch3_fb2e5377:
    mc "А?"

translate russian natsuki_exclusive_2_ch3_bdaebe90:
    mc "Но тогда мне придётся отпустить кресло..."

translate russian natsuki_exclusive_2_ch3_a695f9b4:
    n "Ничего...!"

translate russian natsuki_exclusive_2_ch3_5310eb4b:
    n "Всего на секунду!"

translate russian natsuki_exclusive_2_ch3_457543fb:
    n "Быстрее..."

translate russian natsuki_exclusive_2_ch3_6b542e54:
    mc "Ладно...!"

translate russian natsuki_exclusive_2_ch3_89b431d5:
    mc "Дай только встану."

translate russian natsuki_exclusive_2_ch3_00caffc3:
    "Я медленно отпускаю кресло."

translate russian natsuki_exclusive_2_ch3_182a4ce7:
    n "В смысле «встану»?"

translate russian natsuki_exclusive_2_ch3_3ed33abc:
    "Нацуки смотрит на меня сверху вниз."

translate russian natsuki_exclusive_2_ch3_2c026fa9:
    n "Почему ты сидишь так далеко—"

translate russian natsuki_exclusive_2_ch3_ca0c4e4c:
    n "А-а...?"

translate russian natsuki_exclusive_2_ch3_cc2c02c3:
    "Похоже, до Нацуки только что что-то дошло, но если она пошевелится — потеряет равновесие."

translate russian natsuki_exclusive_2_ch3_0877fb18:
    mc "Нацуки, коробка—"

translate russian natsuki_exclusive_2_ch3_78030b31:
    n "{i}Т-ты куда это смотришь?!{/i}"

translate russian natsuki_exclusive_2_ch3_55feb8f4_1:
    mc "—!"

translate russian natsuki_exclusive_2_ch3_c2a0ec5d:
    n "Ты пытаешься разглядеть мои... м-мои..."

translate russian natsuki_exclusive_2_ch3_f4372639:
    "Ноги Нацуки дрожат."

translate russian natsuki_exclusive_2_ch3_c18e74ce:
    mc "Я-я не пытаюсь! Я просто—"

translate russian natsuki_exclusive_2_ch3_3d7c1c48:
    mc "—Нацуки, не двигайся!"

translate russian natsuki_exclusive_2_ch3_bececf00:
    mc "Просто дай мне коробку!"

translate russian natsuki_exclusive_2_ch3_82869d1e:
    n "Ты... ты извращенец!"

translate russian natsuki_exclusive_2_ch3_8d82e7cc:
    n "Ты всё подстроил!!"

translate russian natsuki_exclusive_2_ch3_972e469b:
    n "Уйди!"

translate russian natsuki_exclusive_2_ch3_0fd7736a:
    n "Вон отсюда!"

translate russian natsuki_exclusive_2_ch3_0a6ea5a1:
    mc "Но—"

translate russian natsuki_exclusive_2_ch3_3937f109:
    n "Я сама справлюсь!!"

translate russian natsuki_exclusive_2_ch3_c3b64b42:
    n "А-ах—"

translate russian natsuki_exclusive_2_ch3_06960e64:
    "Кресло вдруг проворачивается у Нацуки под ногами."

translate russian natsuki_exclusive_2_ch3_3d53117d:
    mc "Нацуки—!"

translate russian natsuki_exclusive_2_ch3_70555b3c:
    n "{i}Кья-а-а-а-а!{/i}"

translate russian natsuki_exclusive_2_ch3_ef6107cd:
    "В долю секунды всё превращается в хаос."

translate russian natsuki_exclusive_2_ch3_884ce5c2:
    "Кресло вылетает у Нацуки из-под ног."

translate russian natsuki_exclusive_2_ch3_4a2e80ff:
    "Я отчаянно пытаюсь её поймать."

translate russian natsuki_exclusive_2_ch3_06cd40b6:
    "Коробка вываливается у неё из рук, и книги разлетаются во все стороны."

translate russian natsuki_exclusive_2_ch3_8da20773:
    mc "Держу—"

translate russian natsuki_exclusive_2_ch3_87b7efd6:
    "{i}Грохот!{/i}"

translate russian natsuki_exclusive_2_ch3_455fbcf4:
    "Нацуки всем телом налетает на меня и сбивает с ног."

translate russian natsuki_exclusive_2_ch3_e2c4a11f:
    "Целая куча книг лупит меня по лицу."

translate russian natsuki_exclusive_2_ch3_88f0cb6e:
    "Нацуки пытается прикрыться руками и падает лицом прямо мне на грудь."

translate russian natsuki_exclusive_2_ch3_408c6b6f:
    mc "У-ух..."

translate russian natsuki_exclusive_2_ch3_3c359cf4:
    "Правая рука и спина основательно приняли удар на себя."

translate russian natsuki_exclusive_2_ch3_ace1a5dd:
    n "У-у..."

translate russian natsuki_exclusive_2_ch3_b5ed8c6d:
    "Нацуки медленно приходит в себя."

translate russian natsuki_exclusive_2_ch3_83787087:
    mc "Кх—!"

translate russian natsuki_exclusive_2_ch3_5241b631:
    "Она упирается в меня руками, чтобы приподняться."

translate russian natsuki_exclusive_2_ch3_3cea7e1d:
    n 1h "А...?"

translate russian natsuki_exclusive_2_ch3_05c0eef4:
    "Похоже, Нацуки понимает, что под ней вовсе не пол."

translate russian natsuki_exclusive_2_ch3_7199f3ed:
    n 1o "Г-гу-у-у-у...!!"

translate russian natsuki_exclusive_2_ch3_65035b80:
    n "Фу! Фу!"

translate russian natsuki_exclusive_2_ch3_391e1fc9:
    mc "Кха—!"

translate russian natsuki_exclusive_2_ch3_39e7a2ca:
    "В грудь мне впечатывается кулак."

translate russian natsuki_exclusive_2_ch3_a03aa661:
    "Затем Нацуки поднимается на ноги."

translate russian natsuki_exclusive_2_ch3_0321014b:
    n "О чём ты только думал?!"

translate russian natsuki_exclusive_2_ch3_9f56530f:
    n "Извращенец!"

translate russian natsuki_exclusive_2_ch3_2cf00965:
    m "У вас там всё в порядке...?"

translate russian natsuki_exclusive_2_ch3_6f3fecb7:
    m "Я слышала сильный грохот..."

translate russian natsuki_exclusive_2_ch3_25a59b0b:
    "Внезапно заглядывает Моника."

translate russian natsuki_exclusive_2_ch3_2981d491:
    n 1e "Моника!"

translate russian natsuki_exclusive_2_ch3_85ec5778:
    n "Видишь, что бывает, когда кладёшь мангу на верхнюю полку?!"

translate russian natsuki_exclusive_2_ch3_c4bdc953:
    n 1w "Ты что, пытаешься угробить членов своего клуба?"

translate russian natsuki_exclusive_2_ch3_4acdf8ea:
    n "Блин!"

translate russian natsuki_exclusive_2_ch3_d6997433:
    m 5 "П-прости, прости!"

translate russian natsuki_exclusive_2_ch3_f6daf90a:
    m "А-ха-ха..."

translate russian natsuki_exclusive_2_ch3_317527c7:
    n 5r "Ах да, и ещё кое-что."

translate russian natsuki_exclusive_2_ch3_c34ab66c:
    n "Похоже, твой новенький — законченный извращенец."

translate russian natsuki_exclusive_2_ch3_4e67f8c4:
    n "Так что надеюсь, ты довольна."

translate russian natsuki_exclusive_2_ch3_3dfecb20:
    mc "Я не—!"

translate russian natsuki_exclusive_2_ch3_66aa93cb:
    "Объяснить Монике всю эту нелепую ситуацию почему-то совершенно невозможно."

translate russian natsuki_exclusive_2_ch3_26c7889b:
    mc "Я ничего не делал, клянусь...!"

translate russian natsuki_exclusive_2_ch3_be102949:
    m 1l "Знаю, знаю, не волнуйся~"

translate russian natsuki_exclusive_2_ch3_a93a1274:
    "Моника говорит мне это тихонько."

translate russian natsuki_exclusive_2_ch3_c11b19ef:
    "Кажется, я спасён..."

translate russian natsuki_exclusive_2_ch3_983f95be:
    n 1p "О нет...!"

translate russian natsuki_exclusive_2_ch3_0a6a99cd:
    n "Моя... моя..."

translate russian natsuki_exclusive_2_ch3_fb2e5377_1:
    mc "А?"

translate russian natsuki_exclusive_2_ch3_f68cfca4:
    "Я опускаю взгляд."

translate russian natsuki_exclusive_2_ch3_056d83b1:
    "Нацуки стоит на коленях на полу, держа одну из разбросанных книг."

translate russian natsuki_exclusive_2_ch3_29ae9747:
    "Через всю страницу тянется большой диагональный залом, который она отчаянно пытается разгладить."

translate russian natsuki_exclusive_2_ch3_78b050ac:
    mc "А, наверное, она упала прямо на страницу..."

translate russian natsuki_exclusive_2_ch3_af725f0b:
    "Нацуки ещё немного пытается расправить залом, но ничего не выходит."

translate russian natsuki_exclusive_2_ch3_1aa6754f:
    "Вдруг она сдаётся, захлопывает книгу и швыряет её на пол."

translate russian natsuki_exclusive_2_ch3_0aea4ae7:
    "Вместо того чтобы продолжать кричать, она просто опускает голову."

translate russian natsuki_exclusive_2_ch3_1bc976a2:
    n "{i}*Всхлип*{/i}"

translate russian natsuki_exclusive_2_ch3_d2046703:
    mc "...Нацуки, ты—"

translate russian natsuki_exclusive_2_ch3_e69dab25:
    n 12f "Нет!"

translate russian natsuki_exclusive_2_ch3_71b53da6:
    "Голос Нацуки срывается на писк."

translate russian natsuki_exclusive_2_ch3_812e0f32:
    "Я вижу слёзы у неё на лице."

translate russian natsuki_exclusive_2_ch3_93deaf69:
    mc "А..."

translate russian natsuki_exclusive_2_ch3_0846eec7:
    mc "Я помогу разгладить залом, ладно?"

translate russian natsuki_exclusive_2_ch3_75f38a9a:
    mc "Я ведь тоже отчасти виноват, так что..."

translate russian natsuki_exclusive_2_ch3_4f1b5c81:
    "Нацуки качает головой, так и не поднимая взгляда."

translate russian natsuki_exclusive_2_ch3_03e340ee:
    n "Нет..."

translate russian natsuki_exclusive_2_ch3_67600f6c:
    n "Да мне даже не так уж важно..."

translate russian natsuki_exclusive_2_ch3_0a96048f:
    n "Просто у меня..."

translate russian natsuki_exclusive_2_ch3_0389face:
    n "Сегодня очень плохой день..."

translate russian natsuki_exclusive_2_ch3_ef6baab9:
    "Нацуки снова всхлипывает."

translate russian natsuki_exclusive_2_ch3_b91f07cb:
    n 12i "Я не хотела срываться на тебе..."

translate russian natsuki_exclusive_2_ch3_b2ecdb48:
    n "Правда не хотела!"

translate russian natsuki_exclusive_2_ch3_3d1f8469:
    mc "Ничего... ничего страшного."

translate russian natsuki_exclusive_2_ch3_06f8103e:
    mc "...Может, хочешь о чём-нибудь поговорить?"

translate russian natsuki_exclusive_2_ch3_58a33d30:
    "Нацуки качает головой."

translate russian natsuki_exclusive_2_ch3_527e1928:
    n "Просто..."

translate russian natsuki_exclusive_2_ch3_9e68e89e:
    n "Каждый день..."

translate russian natsuki_exclusive_2_ch3_5c7e6955:
    n "...так... тяжело."

translate russian natsuki_exclusive_2_ch3_403bf723:
    n "Я просто хочу..."

translate russian natsuki_exclusive_2_ch3_7f5f52df:
    n "...приходить в клуб и..."

translate russian natsuki_exclusive_2_ch3_bb2cf764:
    n "..."

translate russian natsuki_exclusive_2_ch3_7c82291b:
    "Нацуки снова замолкает."

translate russian natsuki_exclusive_2_ch3_1f4f8fe8:
    "Давить на неё я не могу, так что остаётся делать то, что умею."

translate russian natsuki_exclusive_2_ch3_b12907fb:
    mc "Ладно..."

translate russian natsuki_exclusive_2_ch3_0933a463:
    mc "Что ж, я помогу тут прибраться."

translate russian natsuki_exclusive_2_ch3_a72a892b:
    mc "И переложу за тебя остальную мангу."

translate russian natsuki_exclusive_2_ch3_f2316b97:
    mc "А."

translate russian natsuki_exclusive_2_ch3_705c9d7a:
    "Я поднимаю второй том «Девочек-парфе»."

translate russian natsuki_exclusive_2_ch3_a2098188:
    mc "Этот отложим в сторонку."

translate russian natsuki_exclusive_2_ch3_d5488f86:
    mc "Он ведь поможет тебе немножко взбодриться, правда?"

translate russian natsuki_exclusive_2_ch3_cbbc612d:
    mc "Начнём его, как только я тут закончу."

translate russian natsuki_exclusive_2_ch3_09261119:
    "Нацуки поднимает на меня блестящие от слёз глаза."

translate russian natsuki_exclusive_2_ch3_35c0c424:
    "Её губа дрожит."

translate russian natsuki_exclusive_2_ch3_45e4e633:
    n "Ты..."

translate russian natsuki_exclusive_2_ch3_714ac447:
    n "Ты правда очень добр ко мне..."

translate russian natsuki_exclusive_2_ch3_fb2e5377_2:
    mc "А?"

translate russian natsuki_exclusive_2_ch3_87c8fb04:
    "Из уст Нацуки это звучит очень странно."

translate russian natsuki_exclusive_2_ch3_3ab62f98:
    "Я совсем этого не ожидал."

translate russian natsuki_exclusive_2_ch3_c14c584c:
    mc "Ну..."

translate russian natsuki_exclusive_2_ch3_e764e874:
    mc "Я ведь просто отношусь к тебе как к другу, понимаешь?"

translate russian natsuki_exclusive_2_ch3_07ed5951:
    n 12f "Н-н..."

translate russian natsuki_exclusive_2_ch3_b2b589da:
    "Нацуки опускает голову и сдерживает очередной всхлип."

translate russian natsuki_exclusive_2_ch3_8fe0bd7d:
    "Не знаю, что с ней сегодня случилось, но быть с ней добрым — меньшее, что я могу сделать."

translate russian natsuki_exclusive_2_ch3_a1b548d5:
    "Следующие пару минут мы молчим, пока я собираю разбросанные книги."

translate russian natsuki_exclusive_2_ch3_e59057e2:
    "Я стараюсь вставить их в коробку в правильном порядке."

translate russian natsuki_exclusive_2_ch3_c3343162:
    "Через какое-то время Нацуки начинает помогать."

translate russian natsuki_exclusive_2_ch3_40d3ec9e:
    "Вскоре мы заканчиваем, и я водружаю коробку на полку, куда Нацуки хотела её поставить."

translate russian natsuki_exclusive_2_ch3_9b6dafb7:
    "Потом встаю на табуретку и быстро перекладываю с верхней полки остальные её книги."

translate russian natsuki_exclusive_2_ch3_1ef377da:
    mc "Так—!"

translate russian natsuki_exclusive_2_ch3_da95669b:
    mc "Вот и всё."

translate russian natsuki_exclusive_2_ch3_13d8e7da:
    "Я спрыгиваю с табуретки."

translate russian natsuki_exclusive_2_ch3_5868bb1a:
    "Нацуки отводит взгляд."

translate russian natsuki_exclusive_2_ch3_102cdced:
    n "С-спасибо..."

translate russian natsuki_exclusive_2_ch3_7a59b594:
    mc "А-ха-ха..."

translate russian natsuki_exclusive_2_ch3_5d062774:
    mc "Не за что."

translate russian natsuki_exclusive_2_ch3_5add4c86:
    "Нацуки держит в руках том, который я отложил."

translate russian natsuki_exclusive_2_ch3_cbaa4f78:
    mc "Ну всё, я готов."

translate russian natsuki_exclusive_2_ch3_1c682213:
    n 2n "Вот и хорошо."

translate russian natsuki_exclusive_2_ch3_fa0160f8:
    n "Даже если бы не был, я бы всё равно тебя заставила."

translate russian natsuki_exclusive_2_ch3_28001d17:
    n 2u "Ты в ответе за свои слова."

translate russian natsuki_exclusive_2_ch3_033c6a89:
    n "Ну, про то, чтобы меня взбодрить."

translate russian natsuki_exclusive_2_ch3_2ad33ed6:
    mc "Раз ты настаиваешь!"

translate russian natsuki_exclusive_2_ch3_22eb0e44:
    "Мы садимся на то же место, что и в прошлый раз, и я открываю второй том."

translate russian natsuki_exclusive_2_ch3_810de178:
    "Настроение Нацуки быстро улучшается: она смеётся и показывает мне разные моменты."

translate russian natsuki_exclusive_2_ch3_98c65fde:
    "Она на удивление внимательна и подмечает множество неочевидных повторяющихся шуток и деталей на фоне."

translate russian natsuki_exclusive_2_ch3_3a9320da:
    "В итоге меня довольно впечатляет, как в этой манге всё увязано между собой."

translate russian natsuki_exclusive_2_ch3_91c88c35:
    "Похоже, у Нацуки всё-таки хороший вкус."

translate russian natsuki_exclusive_2_ch3_db9deb6e:
    "Через какое-то время Моника, как обычно, привлекает наше внимание — снова пора делиться стихами."

translate russian natsuki_exclusive_2_ch3_b32d5756:
    mc "Пожалуй, пока подержу её у себя."

translate russian natsuki_exclusive_2_ch3_a910372f:
    n "Ага!"

translate russian natsuki_exclusive_2_ch3_0ad75efb:
    n "В этот раз даже у тебя голос повеселее."

translate russian natsuki_exclusive_2_ch3_d556a490:
    mc "Ну, знаешь, я начинаю втягиваться."

translate russian natsuki_exclusive_2_ch3_e36e39a2:
    n 4z "Э-хе-хе."

translate russian natsuki_exclusive_2_ch3_3e76d6fe:
    n "Я же говорила."

translate russian natsuki_exclusive_2_ch3_e9ea92f3:
    mc "Да-да..."

translate russian natsuki_exclusive_2_ch3_7d10c262:
    "Я возвращаюсь на своё место и кладу книгу в сумку."
