# Русский перевод: script-poemresponses2

translate russian ch22_y_end_709da3c5:
    y 2q "А-ха-ха..."

translate russian ch22_y_end_005f1523:
    y "Неважно, о чём оно."

translate russian ch22_y_end_8d062ca2:
    y "Мой разум в последнее время немного перевозбуждён, так что мне пришлось выместить это на твоей ручке."

translate russian ch22_y_end_2dc936e0:
    y 2o "А—"

translate russian ch22_y_end_7556e94a:
    y 2q "То есть... в-вчера у тебя из рюкзака выпала ручка, и я взяла её домой на хранение и..."

translate russian ch22_y_end_56626e8b:
    y "Я, э-э..."

translate russian ch22_y_end_5663b4c6:
    y 2y6 "Мне просто... очень нравится... как она... пишет."

translate russian ch22_y_end_12f2538c:
    y "Вот я и написала этим... стихотворение."

translate russian ch22_y_end_5c7660a7:
    y "А теперь ты к нему прикасаешься..."

translate russian ch22_y_end_cbbbf3af:
    y 2y5 "А-ха-ха."

translate russian ch22_y_end_cecba1d7:
    y 3p "Я-я в порядке!!"

translate russian ch22_y_end_c0c2258c:
    y 3o "Что я сейчас..."

translate russian ch22_y_end_71a86863:
    y "..."

translate russian ch22_y_end_8097fed9:
    y 4c "...Может, сделаем вид, что этого разговора не было?"

translate russian ch22_y_end_124753ac:
    y "Но стихотворение можешь оставить себе..."

translate russian ch23_y_end_e6e44e97:
    y "Тебе нравится??"

translate russian ch23_y_end_3c3e3b26:
    y "Я написала его для тебя!"

translate russian ch23_y_end_95004e48:
    y "Если ты не понял, это стихотворение о [gtext]"

translate russian ch23_y_end_c2fc4ff1:
    y 1y6 "Что ещё важнее, я наделила его своим запахом."

translate russian ch23_y_end_128e58b1:
    y "Видишь, разве я не самая заботливая в клубе?"

translate russian ch23_y_end_71a86863:
    y "..."

translate russian ch23_y_end_e44c3441:
    y 4d "Я..."

translate russian ch23_y_end_3cf752d2:
    y "Кажется, меня... сейчас стошнит."

translate russian ch22_n_end_dd108a9d:
    n 2a "Неплохо, правда?"

translate russian ch22_n_end_60187f07:
    mc "Оно куда длиннее вчерашнего."

translate russian ch22_n_end_eb02eb50:
    n 2w "Вчерашнее было слишком коротким..."

translate russian ch22_n_end_3f4cc55b:
    n "Я просто разминалась!"

translate russian ch22_n_end_d1347742:
    n 2c "Надеюсь, ты не подумал, что это предел моих возможностей."

translate russian ch22_n_end_9b943f22:
    mc "Нет, конечно..."

translate russian ch22_n_end_ae8ffbf5:
    n 2a "В общем, смысл у этого стихотворения довольно очевидный."

translate russian ch22_n_end_038f9631:
    n "Вряд ли его нужно объяснять."

translate russian ch22_n_end_d97a6e91:
    n 2g "Ну, то есть любой согласится, что герой этого стихотворения — невежественный придурок..."

translate russian ch22_n_end_81bb56c3:
    n "У всех есть какое-нибудь странное хобби или тайная слабость."

translate russian ch22_n_end_ff0627ba:
    n 5q "Что-то, о чём боишься, что если люди узнают — засмеют или станут думать о тебе хуже."

translate russian ch22_n_end_a24ab514:
    n 1e "...Но от этого глупые как раз они!"

translate russian ch22_n_end_0a24a428:
    n "Какая разница, что кому нравится, если это никому не вредит и делает человека счастливым?"

translate russian ch22_n_end_89f0d418:
    n 1q "По-моему, людям правда нужно научиться уважать других, даже если тем нравятся странные вещи..."

translate russian ch22_n_end_73b78510:
    n 1x "...Например, две девушки из этого самого клуба, которых я из уважения называть не буду."

translate russian ch22_n_end_23fe4620:
    n 1s "Ирония в том, что даже в единственном месте, где мне спокойно, меня не могут уважать..."

translate russian ch22_n_end_7c4ea5ec:
    n 1u "...Блин, из-за тебя я слишком много жалуюсь!"

translate russian ch22_n_end_922b64f7:
    "{i}(...А я-то что сделал?){/i}"

translate russian ch22_n_end_f725c129:
    mc "Если тебе от этого легче, я тебя уважаю..."

translate russian ch22_n_end_da918150:
    n 1h "Ну—"

translate russian ch22_n_end_8f4d6807:
    n "Ну, спасибо, наверное..."

translate russian ch22_n_end_6328f785:
    n 1s "...Но вполне очевидно, что Юри ты „уважаешь“ больше, так что..."

translate russian ch22_n_end_3f1a63a3:
    n 42c "Ну и ладно... Мы закончили делиться, так что можешь идти."

translate russian ch22_n_end2_273bca1e:
    n 1g "[player]..."

translate russian ch22_n_end2_927a3d3a:
    n "Почему ты сегодня не пришёл читать со мной?"

translate russian ch22_n_end2_8c2d47f4:
    n 1m "Я тебя ждала."

translate russian ch22_n_end2_f1d93e02:
    n "Я долго тебя ждала."

translate russian ch22_n_end2_80e574d5:
    n "Это было единственное, чего я сегодня ждала."

translate russian ch22_n_end2_f2b3b9e8:
    n "Зачем ты всё испортил?"

translate russian ch22_n_end2_b78911e1:
    n "Тебе больше нравится Юри?"

translate russian ch22_n_end2_643e6047:
    n 1k "По-моему, тебе лучше с ней не связываться."

translate russian ch22_n_end2_69bb76d1:
    n "Ты меня слушаешь?"

translate russian ch22_n_end2_0f2e2956:
    n ghost1 "Юри — больная на голову."

translate russian ch22_n_end2_bedf84f6:
    n "Это уже должно быть очевидно."

translate russian ch22_n_end2_63a79a7c:
    n "Так что лучше играй со мной."

translate russian ch22_n_end2_345ab3ba:
    n "Хорошо?"

translate russian ch22_n_end2_ed854175:
    n "Ты ведь меня не ненавидишь, [player]?"

translate russian ch22_n_end2_0cb12625:
    n "Ты меня ненавидишь?"

translate russian ch22_n_end2_46dd5927:
    n "Хочешь, чтобы я ушла домой в слезах?"

translate russian ch22_n_end2_2dec6a19:
    n "Клуб — единственное место, где я чувствую себя в безопасности."

translate russian ch22_n_end2_ab3a049d:
    n "Не порти мне его."

translate russian ch22_n_end2_175f70e6:
    n "Не порти."

translate russian ch22_n_end2_2cfb4a98:
    n "Умоляю."

translate russian ch22_n_end2_a69147ab:
    n "Просто перестань разговаривать с Юри."

translate russian ch22_n_end2_b8a41aff:
    n "Лучше играй со мной."

translate russian ch22_n_end2_56bf6066:
    n "Это всё, что у меня есть..."

translate russian ch22_n_end2_559f619c:
    n "Играй со мной."

translate russian ch22_n_end2_bc805864:
    n ghost2 "ИГРАЙ СО МНОЙ!!!"

translate russian ch23_n_end_197a2a8f:
    n "Я передумала."

translate russian ch23_n_end_e5cdc987:
    n "Забудь всё, что сейчас прочитал."

translate russian ch23_n_end_7ccb81a3:
    n "Нет смысла что-то делать."

translate russian ch23_n_end_43d633ac:
    n "Юри сама виновата, что она такая неприятная."

translate russian ch23_n_end_307c974f:
    n "Ты меня слышишь, [player]?"

translate russian ch23_n_end_deb6b51f:
    n "Если бы ты просто проводил больше времени с Моникой, все эти проблемы исчезли бы."

translate russian ch23_n_end_3418f148:
    n "Мы с Юри слишком испорчены для такого замечательного человека, как ты."

translate russian ch23_n_end_708e8f2f:
    n "Думай отныне только о Монике."

translate russian ch23_n_end_51c11221:
    n "Только Моника."

translate russian ch23_n_end_24b5bc76:
    "Только Моника."

translate russian ch22_m_end_83c4f89d:
    m 5 "Прости, я знаю, что оно какое-то абстрактное."

translate russian ch22_m_end_fc0ccc51:
    m "Я просто пытаюсь... э-э..."

translate russian ch22_m_end_7230704b:
    m 1r "Ладно, неважно."

translate russian ch22_m_end_3e1e8945:
    m "Объяснять нет смысла."

translate russian ch22_m_end_76b81468:
    m 1i "В общем..."

translate russian ch22_m_end_16f290c4:
    m 3b "Писательский совет дня от Моники!"

translate russian ch22_m_end_6417a080:
    m "Иногда тебе придётся принимать трудное решение..."

translate russian ch22_m_end_a151287c:
    m "Когда это случится, не забудь сохранить игру!"

translate russian ch22_m_end_f12b95e5:
    m 3k "Никогда не знаешь, когда... э-э..."

translate russian ch22_m_end_a9bffe18:
    m 3i "...С кем я разговариваю?"

translate russian ch22_m_end_4cd84cd1:
    m "Ты меня слышишь?"

translate russian ch22_m_end_0f112add:
    m 3g "Скажи, что слышишь."

translate russian ch22_m_end_f97ac3b8:
    m "Хоть что-нибудь."

translate russian ch22_m_end_a33519f4:
    m 3k "...Вот и мой совет на сегодня!"

translate russian ch22_m_end_d33852a1:
    m "Спасибо, что выслушал~"

translate russian ch23_m_end_62664d25:
    m "Боже! Как же я испугалась!{fast}"

translate russian ch23_m_end_619a4637:
    m "Э-э..."

translate russian ch23_m_end_45490c24:
    m 1m "Ну, кажется, я немного напортачила, когда... э-э... „писала“ это стихотворение."

translate russian ch23_m_end_d4549a8b:
    m "Я просто пыталась..."

translate russian ch23_m_end_f3cd2d78:
    m 1i "...Проехали."

translate russian ch23_m_end_71195760:
    m "Давай просто пойдём дальше..."

translate russian ch22_n_bad_80e20624:
    n 1r "..."

translate russian ch22_n_bad_019823be:
    n "Ага, так я и думала..."

translate russian ch22_n_bad_652650d3:
    mc "...?"

translate russian ch22_n_bad_451d4cef:
    n 2w "[player], да ладно тебе."

translate russian ch22_n_bad_fd57163a:
    n "Я не дура."

translate russian ch22_n_bad_8174cc0b:
    n 2h "Я знаю, сколько времени ты проводишь с Юри..."

translate russian ch22_n_bad_299cafdb:
    n "Очевидно, что тебе важнее впечатлить её, чем научиться лучше писать."

translate russian ch22_n_bad_62e121fb:
    n 2w "Если честно, это довольно жалко."

translate russian ch22_n_bad_c624ab6f:
    n 4h "Зачем ты вообще в этом клубе, [player]?"

translate russian ch22_n_bad_dcb46692:
    n "Честно..."

translate russian ch22_n_bad_4df757a3:
    n "Я думала, новый участник поможет всем больше заниматься чем-то вместе."

translate russian ch22_n_bad_77c6d82c:
    n 4s "А не ещё сильнее отдаляться друг от друга."

translate russian ch22_n_bad_f72b055f:
    n 1u "Всё равно это дурацкое занятие..."

translate russian ch22_n_bad_ab40f9db:
    n 12c "...Слушай, у меня сегодня плохое настроение, и мне правда не хочется сейчас разговаривать."

translate russian ch22_n_bad_c2207329:
    n "Пожалуйста, уйди."

translate russian ch22_n_bad_28817dab:
    n 1k "...Хм."

translate russian ch22_n_bad_74244aa4:
    n "Прошлое мне понравилось больше."

translate russian ch22_n_bad_d7b8459d:
    mc "А? Правда?"

translate russian ch22_n_bad_5956e212:
    n 2c "Ну да. Видно, что с этим ты немного рискнул."

translate russian ch22_n_bad_deb986a6:
    n "Но для такого ты пока недостаточно хорош. Не вышло."

translate russian ch22_n_bad_c267cc85:
    mc "Может, и так, но мне просто хотелось попробовать что-то новое."

translate russian ch22_n_bad_192d21e2:
    mc "Я ещё только во всём этом разбираюсь."

translate russian ch22_n_med_a9238065:
    n "...Хм."

translate russian ch22_n_med_5d9aad6c:
    n 2k "Что ж, признаю, оно лучше прошлого."

translate russian ch22_n_med_0d4958b9:
    n "Приятно видеть, что ты хоть немного стараешься."

translate russian ch22_n_med_0c1a926e:
    mc "Уже хорошо..."

translate russian ch22_n_med_shared_74a4a9ce:
    n 2c "Просто постарайся перенять что-нибудь у каждой из нас."

translate russian ch22_n_med_shared_950a824c:
    n "По-моему, Юри на тебя хоть немного да влияет, правда?"

translate russian ch22_n_med_shared_af1219fc:
    n 5q "Ну, я знаю, что ты, типа..."

translate russian ch22_n_med_shared_24759775:
    n "Проводишь с ней время, или что там..."

translate russian ch22_n_med_shared_fe8fa4e4:
    n 1w "Но знаешь, мы с Моникой ничуть не хуже её!"

translate russian ch22_n_med_shared_f1b86d5c:
    n 1q "В-в стихах, я имею в виду!"

translate russian ch22_n_med_shared_21ad41dd:
    n 1h "Так что тебе правда стоит чему-нибудь научиться, а то так и не станешь лучше!"

translate russian ch22_n_med_shared_2a124358:
    n "Вот что написала я..."

translate russian ch22_n_med_shared_0b6f62e2:
    n "Уж я позабочусь, чтобы ты из него что-нибудь вынес."

translate russian ch22_n_med_shared_a9238065:
    n "...Хм."

translate russian ch22_n_med_shared_96bb6129:
    n 2k "Что ж, оно не то чтобы хуже твоего прошлого."

translate russian ch22_n_med_shared_1a05189b:
    n "Но и сказать, что лучше, я тоже не могу."

translate russian ch22_n_med_shared_d91458f0:
    mc "Фух..."

translate russian ch22_n_med_shared_06c9456d:
    n 2c "А? Что значит „фух“?"

translate russian ch22_n_med_shared_f30730dc:
    mc "А... Ну, всё, что не полный провал, я считаю победой."

translate russian ch22_n_med_shared_293ad1f3:
    mc "К тому же мне кажется, что ты здесь самый строгий критик."

translate russian ch22_n_med_shared_7783e711:
    n 1p "Э-эй! С чего ты—"

translate russian ch22_n_med_shared_8968fb51:
    n 1q "{i}(Стоп, может, это был комплимент...?){/i}"

translate russian ch22_n_med_shared_190b81c1:
    n 4y "А-ха! Рада, что хоть кто-то признаёт мой опыт!"

translate russian ch22_n_med_shared_472981db:
    n "Ну что ж, тренируйся, и, может, когда-нибудь станешь таким же хорошим, как я!"

translate russian ch22_n_med_shared_d2fcd254:
    mc "Это... э-э..."

translate russian ch22_n_med_shared_6840c02e:
    "Что-то мне подсказывает, что Нацуки совершенно не поняла, к чему я."

translate russian ch22_n_med_shared_a9238065_1:
    n "...Хм."

translate russian ch22_n_med_shared_80bc2c6d:
    n 2c "Ну, оно не ужасное."

translate russian ch22_n_med_shared_95975dcd:
    n "Но после твоего прошлого — довольно разочаровывает."

translate russian ch22_n_med_shared_d9da8001:
    n 2s "Хотя, если бы это было таким же хорошим, как прошлое, я бы ужасно разозлилась."

translate russian ch22_n_med_shared_b0f3312e:
    mc "Ну, в этот раз мне, пожалуй, захотелось попробовать что-то немного другое."

translate russian ch22_n_med_shared2_42b36abf:
    n 2c "Справедливо. Ты ещё новичок, так что я не жду, что ты сразу найдёшь свой стиль."

translate russian ch22_n_med_shared2_2f4c46b4:
    n "В смысле, все в клубе пишут совершенно по-разному..."

translate russian ch22_n_med_shared2_6ad0bbc4:
    n "Может, ты переймёшь что-нибудь у каждой из нас."

translate russian ch22_n_med_shared2_5aea8b79:
    n 2q "Например..."

translate russian ch22_n_med_shared2_be74a7b3:
    n 5q "Я заметила, что сегодня ты проводил время с Юри..."

translate russian ch22_n_med_shared2_79a1e115:
    n "Не то чтобы мне было дело, с кем ты проводишь время."

translate russian ch22_n_med_shared2_87d95321:
    n 5w "В конце концов, меня учили никогда ничего ни от кого не ждать."

translate russian ch22_n_med_shared2_1e2af394:
    n 5s "Так что я вовсе тебя не ждала или что-то такое."

translate russian ch22_n_med_shared2_75f9fa8d:
    n 5h "И всё же тебе стоит хотя бы просмотреть моё стихотворение..."

translate russian ch22_n_med_shared2_2a38376c:
    n "Скорее всего, ты сможешь из него чему-нибудь научиться."

translate russian ch23_n_bad_49ef7472:
    n 5x "Я не буду читать очередной твой подлизывающийся к Юри стишок."

translate russian ch23_n_bad_49d58d58:
    n 5s "Но своё я тебя всё равно заставлю прочитать."

translate russian ch23_n_bad_5901bc46:
    n "На то есть причина."

translate russian ch23_n_bad_a2c8bab9:
    n 5x "Мне правда очень не хотелось бы этого делать..."

translate russian ch23_n_bad_2fbfeac2:
    n "Но, к сожалению, выбора у меня особо нет."

translate russian ch23_n_bad_13a2b39c:
    n 5h "Просто... прочитай его внимательно, ладно?"

translate russian ch23_n_bad_a79131e4:
    n "А потом можешь уходить."

translate russian ch23_n_bad_bb2cf764:
    n "..."

translate russian ch23_n_bad_58f95e02:
    n 2c "...Мда."

translate russian ch23_n_bad_7337ee1a:
    n "Видимо, ты так ничему и не научился."

translate russian ch23_n_bad_8e9ab461:
    n "Честно, не понимаю, с чего я вообще на что-то надеялась."

translate russian ch23_n_bad_shared_1442a9ae:
    n 42c "Это явно влияние Юри..."

translate russian ch23_n_bad_shared_38cf2868:
    n "Я и не знала, что ты такой внушаемый."

translate russian ch23_n_bad_shared_12cacc14:
    n "Проводишь с ней всё время в клубе..."

translate russian ch23_n_bad_shared_ca96819f:
    n "А теперь пытаешься писать как она..."

translate russian ch23_n_bad_shared_162846fe:
    n 1s "Это глупо."

translate russian ch23_n_bad_shared_1d3b6824:
    n "Хотя бы Моника ценит мои тексты..."

translate russian ch23_n_bad_shared_c80758bc:
    n 1r "...Фу."

translate russian ch23_n_bad_shared_7df93708:
    n 1q "Ладно... видимо, теперь я покажу тебе своё стихотворение."

translate russian ch23_n_bad_shared_c717fbad:
    n "Как же я ненавижу, что приходится это делать."

translate russian ch23_n_bad_shared_2fbfeac2:
    n "Но, к сожалению, выбора у меня особо нет."

translate russian ch23_n_bad_shared_a4659c3e:
    n 1h "Просто... прочитай его внимательно, ладно?"

translate russian ch23_n_bad_shared_a79131e4:
    n "А потом можешь уходить."

translate russian ch23_n_bad_shared_bb2cf764:
    n "..."

translate russian ch23_n_bad_shared_9cc23ece:
    n 2r "Ох, ну ты даёшь."

translate russian ch23_n_bad_shared_c7c09fee:
    n "Это же серьёзный шаг назад."

translate russian ch23_n_bad_shared_fb2e5377:
    mc "А?"

translate russian ch23_n_bad_shared_61696799:
    n 2c "Два прошлых мне понравились гораздо больше."

translate russian ch23_n_med_bb2cf764:
    n "..."

translate russian ch23_n_med_3e89254a:
    n 2k "...Это нормальное."

translate russian ch23_n_med_9790cac2:
    mc "Нормальное?"

translate russian ch23_n_med_384289aa:
    n "Ага, оно хотя бы лучше вчерашнего."

translate russian ch23_n_shared_919cece6:
    n 2c "Я до сих пор толком не пойму, насколько тебе на самом деле важно писать, но так или иначе у тебя неплохо получается."

translate russian ch23_n_shared_8b4ca590:
    n 4r "Хотя ты, по сути, ни с кем, кроме Юри, время не проводишь..."

translate russian ch23_n_shared_1b1f785e:
    n 4h "Я всё равно считаю, что здорово, когда у нас есть занятия, в которых участвуем все мы."

translate russian ch23_n_shared_9dcaea88:
    n 4w "Так что продолжай стараться!"

translate russian ch23_n_shared_d97c576a:
    n "Ну..."

translate russian ch23_n_shared_256f5427:
    n 1h "Я знаю, что я не президент и не вице-президент..."

translate russian ch23_n_shared_c114d92a:
    n "Но это не значит, что меня можно подводить, ясно?"

translate russian ch23_n_shared_bd025d78:
    n 1q "Так что пока хотя бы прочитай и моё."

translate russian ch23_n_shared_514531ab:
    n "Но чтобы было понятно..."

translate russian ch23_n_shared_6772410a:
    n 1h "Это стихотворение... очень много для меня значит."

translate russian ch23_n_shared_48a6b58c:
    n "Так что прочитай его внимательно, ладно?"

translate russian ch23_n_shared_bb2cf764:
    n "..."

translate russian ch23_n_shared_3e89254a:
    n 2k "...Это нормальное."

translate russian ch23_n_shared_9790cac2:
    mc "Нормальное?"

translate russian ch23_n_shared_37f7579e:
    n "Ну да."

translate russian ch23_n_shared_ef787c01:
    n "В общем, примерно как вчерашнее."

translate russian ch23_n_ygave_2337e9fd:
    n 1h "Что?"

translate russian ch23_n_ygave_573ed9ce:
    n "Ты отдал своё стихотворение Юри?"

translate russian ch23_n_ygave_9f5b8d9a:
    n 4x "Фу!"

translate russian ch23_n_ygave_094d7631:
    n "Да что с вами двумя такое?"

translate russian ch23_n_ygave_f36f981d:
    n 1s "Хмф..."

translate russian ch23_n_ygave_839719b9:
    n "Не то чтобы я вообще хотела его читать."

translate russian ch23_n_ygave_28ce978b:
    n 1r "Просто меня немного бесит, что ты даже не подумал мне его показать."

translate russian ch23_n_ygave_e92db113:
    n 1x "...Фу."

translate russian ch23_n_ygave_99060fb3:
    n 1q "Ладно... видимо, я всё равно покажу тебе своё."

translate russian ch23_n_ygave_c717fbad:
    n "Как же я ненавижу, что приходится это делать."

translate russian ch23_n_ygave_2fbfeac2:
    n "Но, к сожалению, выбора у меня особо нет."

translate russian ch23_n_ygave_a4659c3e:
    n 1h "Просто... прочитай его внимательно, ладно?"

translate russian ch23_n_ygave_a79131e4:
    n "А потом можешь уходить."

translate russian ch22_y_med_94ddb391:
    y 2b "Я этого ждала..."

translate russian ch22_y_med_e1432eef:
    y "Давай посмотрим, что ты написал на сегодня."

translate russian ch22_y_med_2c087461:
    y 3m "..."

translate russian ch22_y_med_b995a929:
    "Юри улыбается и делает глубокий вдох."

translate russian ch22_y_med_0aa09258:
    y "Мне нравится просто держать его в руках."

translate russian ch22_y_med_652650d3:
    mc "...?"

translate russian ch22_y_med_e2d6fa5d:
    y 3p "Ах, то есть—"

translate russian ch22_y_med_5fa73bc5:
    y "Стихотворение получилось хорошим!"

translate russian ch22_y_med_8cf5af87:
    y 3o "Оно, ах..."

translate russian ch22_y_med_bdd39969:
    y 2q "...Ну, есть кое-что, над чем можно поработать..."

translate russian ch22_y_med_d85fefff:
    y "Но это не так уж важно."

translate russian ch22_y_med_89dc40f0:
    y 2s "Мне кажется, всё, что написано тобой, — сокровище."

translate russian ch22_y_med_f876926a:
    y 2d "А-ха-ха..."

translate russian ch22_y_med_1ffa3f36:
    y 2o "Это прозвучало немного неловко..."

translate russian ch22_y_med_9b5f3b10:
    y "Д-давай дальше..."

translate russian ch22_y_med_138402ae:
    y 2t "Вот стихотворение, которое написала я."

translate russian ch22_y_med_2aa6177c:
    y "Оно не обязано тебе нравиться или что-то такое..."

translate russian ch22_y_good_94ddb391:
    y 2b "Я этого ждала..."

translate russian ch22_y_good_e1432eef:
    y "Давай посмотрим, что ты написал на сегодня."

translate russian ch22_y_good_b56cb4ee:
    y 2e "..."

translate russian ch22_y_good_57e586ab:
    y "......"

translate russian ch22_y_good_60fd42a2:
    "Юри с удивлённым лицом смотрит на стихотворение."

translate russian ch22_y_good_a4fb38a3:
    mc "Тебе... нравится?"

translate russian ch22_y_good_c60c5441:
    y "[player]..."

translate russian ch22_y_good_9c78e0ce:
    y "...Как ты так быстро это уловил?"

translate russian ch22_y_good_shared_9b7b3447:
    y 2v "Ведь только вчера я рассказывала тебе, какие приёмы стоит отрабатывать..."

translate russian ch22_y_good_shared_73030027:
    mc "Может, поэтому..."

translate russian ch22_y_good_shared_f8777275:
    mc "Ты хорошо объяснила."

translate russian ch22_y_good_shared_4ff08e3f:
    mc "Мне очень хотелось попробовать добавить больше образов."

translate russian ch22_y_good_shared_4ba84665:
    "Юри заметно сглатывает."

translate russian ch22_y_good_shared_886256e6:
    "Кажется, у неё даже вспотели ладони."

translate russian ch22_y_good_shared_ebaf0814:
    y 4e "А-ах..."

translate russian ch22_y_good_shared_29f23c37:
    y "Это делает меня такой счастливой..."

translate russian ch22_y_good_shared_d6f2c61c:
    y 3y5 "Так удивительно чувствовать, что меня ценят, [player]!"

translate russian ch22_y_good_shared_eb2eaa92:
    y "Всё, что ты пишешь, для меня — сокровище."

translate russian ch22_y_good_shared_fc7fc684:
    y 3m "У меня колотится сердце, стоит мне просто взять его в руки..."

translate russian ch22_y_good_shared_ad35b5dc:
    y 3q "А-ха-ха..."

translate russian ch22_y_good_shared_38f69c70:
    y "Хочу написать стихотворение об этом чувстве..."

translate russian ch22_y_good_shared_e4024fb3:
    y 3y6 "Это плохо, [player]?"

translate russian ch22_y_good_shared_b36688ad:
    y "Я ведь не веду себя странно, правда?"

translate russian ch22_y_good_shared_f69503df:
    y 3s "М-мне сложнее, чем обычно, скрывать свои эмоции..."

translate russian ch22_y_good_shared_a1ec5430:
    y 3m "Мне немного стыдно."

translate russian ch22_y_good_shared_f5e7ea05:
    y 3y6 "Но сейчас я просто хочу, чтобы ты тоже прочитал моё стихотворение."

translate russian ch22_y_good_shared_660d079b:
    y 3y5 "Хорошо?"

translate russian ch22_y_good_shared_94ddb391:
    y 2b "Я этого ждала..."

translate russian ch22_y_good_shared_e1432eef:
    y "Давай посмотрим, что ты написал на сегодня."

translate russian ch22_y_good_shared_b56cb4ee:
    y 2e "..."

translate russian ch22_y_good_shared_57e586ab:
    y "......"

translate russian ch22_y_good_shared_60fd42a2:
    "Юри с удивлённым лицом смотрит на стихотворение."

translate russian ch22_y_good_shared_a4fb38a3:
    mc "Тебе... нравится?"

translate russian ch22_y_good_shared_c60c5441:
    y "[player]..."

translate russian ch22_y_good_shared_4e94ed3b:
    y 2t "Это, возможно, даже лучше вчерашнего..."

translate russian ch22_y_good_shared_0b22d8b2:
    y "...Как ты вообще так быстро это уловил?"

translate russian ch23_y_good_475d4e53:
    y 1d "Наконец-то..."

translate russian ch23_y_good_e36a0b82:
    y 3y5 "А-ха-ха..."

translate russian ch23_y_good_78b28c03:
    "Юри подносит моё стихотворение к лицу и делает глубокий вдох."

translate russian ch23_y_good_bfae9e5d:
    y 3y6 "Я его обожаю."

translate russian ch23_y_good_ce50b5a1:
    y "Я обожаю в нём всё."

translate russian ch23_y_good_5298a60d:
    y 3y5 "[player], я хочу забрать его домой."

translate russian ch23_y_good_88fa4771:
    y "Ты разрешишь мне его оставить?"

translate russian ch23_y_good_48d5d224:
    y "Пожалуйста?"

translate russian ch23_y_good_ee493e7e:
    mc "Конечно, мне всё равно..."

translate russian ch23_y_good_cbbbf3af:
    y 2y5 "А-ха-ха."

translate russian ch23_y_good_1c6d0d01:
    y "Ты слишком добр ко мне, [player]..."

translate russian ch23_y_good_7cb6c628:
    y "Я никогда не встречала никого добрее тебя."

translate russian ch23_y_good_0aafbbbd:
    y 2y6 "Я могла бы умереть..."

translate russian ch23_y_good_1e648267:
    y 3y5 "Н-не на самом деле, но—!"

translate russian ch23_y_good_bf2696a9:
    y "Я просто не знаю, как это описать."

translate russian ch23_y_good_823f0cb2:
    y "Ведь ничего страшного, что я так себя чувствую, правда?"

translate russian ch23_y_good_481230d3:
    y "Это ведь не плохо, правда?"

translate russian ch23_y_good_405a3d1c:
    "Юри прижимает моё стихотворение к груди."

translate russian ch23_y_good_e4a26211:
    y 3m "Я заберу его домой и буду хранить у себя в комнате."

translate russian ch23_y_good_3972122a:
    y "Надеюсь, тебе будет приятно думать о том, что оно у меня."

translate russian ch23_y_good_7f73ff61:
    y 3y5 "Я буду очень бережно его хранить!"

translate russian ch23_y_good_4a87e057:
    y 3y6 "Я даже буду трогать себя, перечитывая его снова и снова."

translate russian ch23_y_good_ac37d617:
    y "Я буду резаться о бумагу, чтобы жир с твоей кожи попадал мне в кровь."

translate russian ch23_y_good_ed03b3f9:
    y 3y1 "А-ха-ха-ха-ха-ха."

translate russian ch23_y_good_d0844b38:
    y 2s "Можешь взять и моё стихотворение."

translate russian ch23_y_good_89d84e66:
    y "К тому же, когда ты его прочитаешь, я знаю, тебе очень захочется оставить его себе."

translate russian ch23_y_good_1685da47:
    y 2y6 "Вот, бери. Я больше не могу ждать."

translate russian ch23_y_good_ccb863d9:
    y 2y5 "Скорее! Читай!"

translate russian ch21_m_start_b00bb3c8:
    m 1b "Привет, [player]!"

translate russian ch21_m_start_1bd46f58:
    m "Пока всё нравится?"

translate russian ch21_m_start_21d5c9ec:
    mc "А... да."

translate russian ch21_m_start_666605e3:
    m 1k "Вот и хорошо! Рада это слышать!"

translate russian ch21_m_start_93e2ca00:
    m 4a "Кстати, раз уж ты новенький и всё такое..."

translate russian ch21_m_start_2c3797ba:
    m "Если у тебя появятся предложения для клуба — новые занятия или что мы могли бы делать лучше..."

translate russian ch21_m_start_c62ec065:
    m 4b "Я всегда готова выслушать!"

translate russian ch21_m_start_34df4ece:
    m "Не бойся говорить, хорошо?"

translate russian ch21_m_start_5c96db76:
    mc "Хорошо... буду иметь в виду."

translate russian ch21_m_start_5cef0dd8:
    "Конечно, я буду бояться что-то предлагать."

translate russian ch21_m_start_9a72c3bb:
    "Куда лучше просто плыть по течению, пока не освоюсь."

translate russian ch21_m_start_35ec09b1:
    m 1a "В общем..."

translate russian ch21_m_start_cfa8c28b:
    m "Покажешь мне своё стихотворение?"

translate russian ch21_m_start_81b8811a:
    mc "Немного стыдно, но, видимо, придётся."

translate russian ch21_m_start_8b55ecf2:
    m 5a "А-ха-ха-ха!"

translate russian ch21_m_start_5af81672:
    m "Не волнуйся, [player]!"

translate russian ch21_m_start_b174058f:
    m "Знаешь, нам всем сегодня немного неловко."

translate russian ch21_m_start_5fd498a1:
    m "Но мы все скоро научимся преодолевать этот барьер."

translate russian ch21_m_start_5cc82dfc:
    mc "Да, это правда."

translate russian ch21_m_start_18b074dd:
    "Я протягиваю Монике своё стихотворение."

translate russian ch21_m_start_e918c8cd:
    m 2a "...Угу!"

translate russian ch21_m_start_9d47e097:
    m 1a "В общем, хочешь теперь прочитать моё стихотворение?"

translate russian ch21_m_start_59efb257:
    m 1e "Не волнуйся, у меня не очень хорошо получается..."

translate russian ch21_m_start_1c27ea40:
    mc "Ты говоришь довольно уверенно для человека, который утверждает, что у него не очень получается."

translate russian ch21_m_start_e7765480:
    m 1j "Ну... это потому, что я должна звучать уверенно."

translate russian ch21_m_start_5f9f46a2:
    m 1b "Но это не значит, что я всегда себя так чувствую, понимаешь?"

translate russian ch21_m_start_a7bcf340:
    mc "Понятно..."

translate russian ch21_m_start_32258afa:
    mc "Что ж, тогда давай почитаем."

translate russian ch22_m_start_88abc401:
    m 1b "Снова привет, [player]!"

translate russian ch22_m_start_3b003159:
    m "Как продвигается писательство?"

translate russian ch22_m_start_e244b62c:
    mc "Нормально, наверное..."

translate russian ch22_m_start_bc898487:
    m 2k "Меня это устраивает."

translate russian ch22_m_start_dc4a1325:
    m 2b "Главное, чтобы не плохо!"

translate russian ch22_m_start_b5f97e3d:
    m 2a "Я рада, что ты стараешься."

translate russian ch22_m_start_2d8272d9:
    m "Может, скоро у тебя выйдет шедевр!"

translate russian ch22_m_start_a7b161e3:
    mc "А-ха-ха, я бы на это не рассчитывал..."

translate russian ch22_m_start_a73bf817:
    m 2a "Никогда не знаешь!"

translate russian ch22_m_start_42555ab9:
    m "Поделишься тем, что написал на сегодня?"

translate russian ch22_m_start_23eb6a63:
    mc "Конечно... Держи."

translate russian ch22_m_start_42bf4313:
    "Я отдаю своё стихотворение Монике."

translate russian ch22_m_start_e612037c:
    m "..."

translate russian ch22_m_start_42cf1711:
    m "...Отлично!"

translate russian ch22_m_start_c2677273:
    m 1a "Но в общем..."

translate russian ch22_m_start_333a7a57:
    m "Хочешь теперь прочитать моё?"

translate russian ch22_m_start_d3a78cd2:
    m "Мне нравится, как оно получилось, так что надеюсь, тебе тоже понравится~"

translate russian ch23_m_start_35ec09b1:
    m 1a "В общем..."

translate russian ch23_m_start_ce741454:
    m 1m "Пожалуй, о твоём стихотворении мы беспокоиться не будем..."

translate russian ch23_m_start_ba5121e4:
    m "Юри могла бы хоть из вежливости дать тебе закончить им делиться, прежде чем забирать."

translate russian ch23_m_start_695b66ab:
    m 1r "...Ну и ладно."

translate russian ch23_m_start_a4e8e8f9:
    m "Если ей от этого радостно, я не буду ей мешать."

translate russian ch23_m_start_d3a9e10d:
    m 1a "А что до моего..."

translate russian ch23_m_start_2c9e6f3f:
    m 1e "Я очень... очень старалась над этим стихотворением, так что..."

translate russian ch23_m_start_b7880f06:
    m "Надеюсь, оно, э-э, подействует."

translate russian ch23_m_start_f6493b16:
    m 1r "Вот..."

translate russian m2_natsuki_1_7c4c4591:
    m 2b "Мне нравится, [player]!"

translate russian m2_natsuki_1_72610a7c:
    mc "Правда...?"

translate russian m2_natsuki_1_0e8e49b9:
    m 2e "Оно гораздо милее, чем я ожидала."

translate russian m2_natsuki_1_e0245251:
    m 2k "А-ха-ха-ха!"

translate russian m2_natsuki_1_51ae0416:
    mc "Ох, ну вот..."

translate russian m2_natsuki_1_8760977f:
    m 1b "Нет-нет!"

translate russian m2_natsuki_1_525bf306:
    m "Оно чем-то напоминает то, что могла бы написать Нацуки."

translate russian m2_natsuki_1_7636a49e:
    m "А она, между прочим, хорошо пишет."

translate russian m2_natsuki_1_7524d622:
    m 5a "Так что считай это комплиментом!"

translate russian m2_natsuki_1_7a59b594:
    mc "А-ха-ха..."

translate russian m2_natsuki_1_f16c798b:
    mc "Раз ты так говоришь."

translate russian m2_natsuki_1_912606f9:
    m "Ага!"

translate russian m2_natsuki_1_50d0b4b1:
    m 3b "Если тебе интересна Нацуки, всегда держи при себе что-нибудь перекусить."

translate russian m2_natsuki_1_a6ca38b8:
    m "Она будет липнуть к тебе, как щенок."

translate russian m2_natsuki_1_6081cad7:
    m 3k "А-ха-ха!"

translate russian m2_natsuki_1_50f3ff66:
    m 1a "Отец Нацуки не даёт ей денег на обед и не оставляет дома никакой еды, так что она довольно часто капризничает..."

translate russian m2_natsuki_1_c56b4d81:
    m "Но иногда у неё просто кончаются все силы, и она отключается."

translate russian m2_natsuki_1_51dbafa5:
    m "Как сегодня."

translate russian m2_natsuki_1_35ad1efe:
    m 2d "Это просто догадка, но мне кажется, она такая маленькая потому, что недоедание мешает ей расти..."

translate russian m2_natsuki_1_6b721fbc:
    m 2b "...Но эй, некоторым парням ведь нравятся миниатюрные девушки, знаешь?"

translate russian m2_natsuki_1_ca758e44:
    m 5a "Прости... просто пытаюсь видеть во всём хорошее!"

translate russian m2_yuri_1_8702c778:
    m 1a "Отличная работа, [player]!"

translate russian m2_yuri_1_51d5365e:
    m "Пока читала, у меня в голове только и было: „Ух ты!“"

translate russian m2_yuri_1_68322c07:
    m 1j "Оно такое метафоричное!"

translate russian m2_yuri_1_df8cf596:
    m 1a "Не знаю почему, но я не ожидала, что ты возьмёшься за что-то настолько глубокое."

translate russian m2_yuri_1_a9a4780f:
    m 3b "Видимо, я тебя недооценивала!"

translate russian m2_yuri_1_3796b1c6:
    mc "Мне проще всего держать ожидания окружающих на низком уровне."

translate russian m2_yuri_1_b811b3be:
    mc "Тогда стоит мне хоть немного постараться — это сразу засчитывается."

translate russian m2_yuri_1_dc0ab338:
    m 5a "А-ха-ха! Это не очень-то честно!"

translate russian m2_yuri_1_820fd59f:
    m "Что ж, в любом случае это сработало."

translate russian m2_yuri_1_8d0f13fc:
    m 2a "Ты ведь знаешь, что Юри любит такие тексты?"

translate russian m2_yuri_1_0ec7a5f5:
    m "Тексты, полные образов и символов."

translate russian m2_yuri_1_920fac83:
    m 2d "Иногда мне кажется, что разум Юри полностью оторван от реальности."

translate russian m2_yuri_1_30867f56:
    m "Хотя я не имею в виду, что это плохо."

translate russian m2_yuri_1_6682efb9:
    m 2a "Но иногда у меня складывается впечатление, что она просто совершенно разочаровалась в людях."

translate russian m2_yuri_1_665ab325:
    m "Она проводит столько времени у себя в голове, что там ей, наверное, гораздо интереснее..."

translate russian m2_yuri_1_94cfdf9c:
    m 2b "Но поэтому она так радуется, когда к ней относятся с большой добротой."

translate russian m2_yuri_1_4b711bfe:
    m "Не думаю, что она привыкла, когда ей так потакают."

translate russian m2_yuri_1_b80a49f1:
    m 2j "Ей, должно быть, очень не хватает общения, так что не вини её за то, что она немного напирает."

translate russian m2_yuri_1_a4104638:
    m 2d "Как сегодня..."

translate russian m2_yuri_1_24d60780:
    m "Мне кажется, если её слишком сильно взбудоражить, она замыкается и ищет, где побыть одной."

translate russian m2_yuri_1_bcce4482:
    "Вдруг дверь открывается."

translate russian m2_yuri_1_c8ec6983:
    m 2b "Юри!"

translate russian m2_yuri_1_3f26578c:
    y "Я вернулась..."

translate russian m2_yuri_1_8e53004c:
    y "Я что-нибудь пропустила?"

translate russian m2_yuri_1_b6c1b501:
    m 2a "Не особо..."

translate russian m2_yuri_1_363271bd:
    m "Ну, мы все начали делиться стихами."

translate russian m2_yuri_1_4729869b:
    y 2t "А?"

translate russian m2_yuri_1_cebc9ddc:
    y "Уже?"

translate russian m2_yuri_1_bc6892c1:
    y 2v "П-простите, что опоздала..."

translate russian m2_yuri_1_7fc8ae5b:
    m 2j "Не нужно извиняться!"

translate russian m2_yuri_1_bc53640f:
    m 2a "У нас ещё полно времени, так что я скорее рада, что ты не торопилась."

translate russian m2_yuri_1_ea1ffe31:
    y 1s "Хорошо..."

translate russian m2_yuri_1_f0ffd929:
    y "Спасибо, Моника."

translate russian m2_yuri_1_0b61bbc2:
    y "Пожалуй, пойду возьму своё стихотворение."

translate russian m2_yuri_2_089aaea9:
    m 1i "[player], мне кажется, ты кое-что недавно видел из того, что тебе не следовало видеть."

translate russian m2_yuri_2_3e8540f9:
    m "Я не хотела тебе этого говорить, но, похоже, выбора у меня нет."

translate russian m2_yuri_2_652ae16d:
    m 1r "Проводить столько времени с Юри становится для тебя довольно опасно."

translate russian m2_yuri_2_0db9ee59:
    m 1i "Не знаю почему, но рядом с тобой она очень легко возбуждается..."

translate russian m2_yuri_2_45d2e006:
    m 3d "Что само по себе не должно быть проблемой."

translate russian m2_yuri_2_2d23c464:
    m "Но когда Юри слишком возбуждается, она находит, где спрятаться, и начинает резать себя складным ножом."

translate russian m2_yuri_2_df685d1a:
    m 2e "Это ведь как-то ненормально, правда?"

translate russian m2_yuri_2_9e0afc72:
    m "Она даже каждый день приносит в школу новый, будто у неё целая коллекция или что-то такое..."

translate russian m2_yuri_2_50688481:
    m 2d "Ну, точно не потому, что у неё депрессия или что-то в этом роде!"

translate russian m2_yuri_2_d1e9b51b:
    m "Мне кажется, она просто получает от этого какой-то кайф."

translate russian m2_yuri_2_9799bab9:
    m 2m "Может, это даже что-то, ну, сексуальное..."

translate russian m2_yuri_2_0cb81307:
    m 1i "Но суть в том, что ты, в общем-то, ей потакаешь."

translate russian m2_yuri_2_3271c57b:
    m 1d "Хотя я не говорю, что это твоя вина!"

translate russian m2_yuri_2_fd3981e9:
    m 1a "Но, наверное, поэтому мне и пришлось тебе всё это объяснить..."

translate russian m2_yuri_2_67395a9b:
    m "Так что, думаю, если ты будешь держаться на расстоянии, ей, наверное, будет лучше."

translate russian m2_yuri_2_679c322e:
    m 5 "А заодно не стесняйся проводить чуточку больше времени со мной..."

translate russian m2_yuri_2_c3ce1467:
    m "Мягко говоря, у меня-то с головой всё в порядке... и я знаю, как обращаться с участниками своего клуба."

translate russian m2_yuri_3_d221d38d:
    m 1i "Не говори потом, что я тебя не предупреждала, [player]."
