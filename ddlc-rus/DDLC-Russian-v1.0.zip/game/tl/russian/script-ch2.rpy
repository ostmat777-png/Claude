# Русский перевод: script-ch2

translate russian ch2_main_6ae8eabb:
    "Проходит ещё один день, и вот уже время клубного собрания."

translate russian ch2_main_dbdf4ac1:
    "За последние пару дней я тут немного освоился."

translate russian ch2_main_58487bde:
    "Войдя в клубную комнату, я вижу привычную картину."

translate russian ch2_main_168027c8:
    s "Привет, [player]~"

translate russian ch2_main_e99bda5c:
    mc "Привет, Сайори."

translate russian ch2_main_9997929b:
    mc "Похоже, у тебя сегодня хорошее настроение."

translate russian ch2_main_4fe8273d:
    s 1q "Э-хе-хе~"

translate russian ch2_main_ccafd709:
    s "Я просто всё ещё не привыкла, что ты в клубе, вот и всё."

translate russian ch2_main_a7bcf340:
    mc "Понятно..."

translate russian ch2_main_39b394f9:
    mc "...Не так уж много нужно, чтобы тебя порадовать."

translate russian ch2_main_96c60dbc:
    mc "Но с тобой, наверное, всегда всё просто."

translate russian ch2_main_d85c2c06:
    s 1d "Кстати об этом..."

translate russian ch2_main_97b5cf5f:
    s "Я что-то проголодалась..."

translate russian ch2_main_14c4cb8f:
    s "Сходишь со мной купить чего-нибудь перекусить?"

translate russian ch2_main_5c07512d:
    mc "Нет уж, спасибо."

translate russian ch2_main_c6a6dec3:
    s 4h "Э-э??"

translate russian ch2_main_e1474c37:
    s "Э-это совсем на тебя не похоже!!"

translate russian ch2_main_3bae62f3:
    mc "У меня есть причины."

translate russian ch2_main_0b6e6343:
    mc "Может, заглянем в твой кошелёк, Сайори?"

translate russian ch2_main_bfd2eb87:
    s 4l "А-а?"

translate russian ch2_main_e0d81cb9:
    s "С чего это... вдруг?"

translate russian ch2_main_e152763c:
    mc "Да ни с чего."

translate russian ch2_main_87e8a550:
    mc "Просто хотелось посмотреть."

translate russian ch2_main_f33bfbaf:
    s 1l "А-ах..."

translate russian ch2_main_49f874e5:
    "Сайори нервно достаёт кошелёк."

translate russian ch2_main_a9796a2b:
    "Она возится с застёжкой и наконец его открывает."

translate russian ch2_main_1048d989:
    "Потом переворачивает его и вытряхивает содержимое на парту."

translate russian ch2_main_ee2acba6:
    "Выпадают всего две мелкие монетки."

translate russian ch2_main_1b2c6d4f:
    s 5a "А-ха-ха..."

translate russian ch2_main_8c3318a5:
    mc "Так я и знал..."

translate russian ch2_main_508c728e:
    mc "Я вижу тебя насквозь, Сайори."

translate russian ch2_main_7b27546c:
    s 5c "Это нечестно!"

translate russian ch2_main_28e23ec3:
    s "Как ты вообще догадался?"

translate russian ch2_main_e10938c0:
    mc "Всё просто."

translate russian ch2_main_7467b559:
    mc "Если бы у тебя было достаточно денег, ты бы купила что-нибудь ещё до того, как прийти в клуб."

translate russian ch2_main_067bf3ce:
    mc "Значит, либо ты не голодна и просто хотела найти повод прогуляться..."

translate russian ch2_main_e3c2ac73:
    mc "Либо собиралась очень удобно «забыть», что потратила все деньги, чтобы я тебе одолжил!"

translate russian ch2_main_60755e5f:
    mc "Но есть ещё кое-что..."

translate russian ch2_main_4a8b32ee:
    mc "...Ты всегда голодная!"

translate russian ch2_main_f17cca0f:
    mc "А значит, остаётся только один вариант!"

translate russian ch2_main_57bde90e:
    s 4p "Уа-а-а~!"

translate russian ch2_main_5f447a92:
    s "Сдаюсь!"

translate russian ch2_main_29fe1eee:
    s "Не заставляй меня чувствовать себя виноватой!"

translate russian ch2_main_d3deba2f:
    mc "Если ты чувствуешь себя виноватой, значит, так тебе и надо..."

translate russian ch2_main_dd2b72b2:
    y "А-ха-ха."

translate russian ch2_main_2cc94326:
    "Юри вдруг хихикает."

translate russian ch2_main_fb2e5377:
    mc "А?"

translate russian ch2_main_5727dfc3:
    "Я и не заметил, что она подслушивает."

translate russian ch2_main_593f79a9:
    "Её лицо, как всегда, уткнуто в книгу."

translate russian ch2_main_5c35ac2a:
    y "А-ах!"

translate russian ch2_main_67fc7c0a:
    y "Я вовсе не подслушивала—!"

translate russian ch2_main_b010dc9d:
    y 3o "Это просто... кое-что в моей книге..."

translate russian ch2_main_1ef28c9d:
    s 1h "Ю-у-ури..."

translate russian ch2_main_53ac6664:
    s "Скажи [player], чтобы одолжил мне денег..."

translate russian ch2_main_aab4b4e3:
    y 3h "Это—!"

translate russian ch2_main_6c0f6079:
    y "Не впутывай меня, Сайори..."

translate russian ch2_main_a7b7bd96:
    y "К тому же..."

translate russian ch2_main_b89b6d80:
    y 1k "Покупать стоит только то, что можешь себе позволить..."

translate russian ch2_main_96753178:
    y "И, откровенно говоря, после такой озорной выходки твои страдания — вполне заслуженное возмездие."

translate russian ch2_main_2b35b6fe:
    mc "..."

translate russian ch2_main_0300c725:
    y 3n "Ах—!"

translate russian ch2_main_64718e50:
    y "Я что, только что..."

translate russian ch2_main_51dc1333:
    y 4c "Я-я не это имела в виду!!"

translate russian ch2_main_cca31a61:
    y "Я слишком увлеклась книгой..."

translate russian ch2_main_6559e79e:
    y "У-у..."

translate russian ch2_main_50e118dc:
    s 1r "А-ха-ха!"

translate russian ch2_main_3abaf147:
    s 3x "Мне очень нравится, когда ты говоришь, что думаешь, Юри..."

translate russian ch2_main_66c5a7ca:
    s "Такое нечасто бывает, но это твоя весёлая сторона!"

translate russian ch2_main_c96fe449:
    y 3v "Это..."

translate russian ch2_main_ca0ebda0:
    y "Не может быть, чтобы ты так думала..."

translate russian ch2_main_8fb10173:
    s 1x "Но ты ведь права..."

translate russian ch2_main_173236dc:
    s "Я поступила плохо и теперь должна принять возмущение."

translate russian ch2_main_22616fe3:
    y 3h "Возмездие..."

translate russian ch2_main_faf91463:
    s 1l "Вот!"

translate russian ch2_main_fb5459c5:
    y "И всё же от тебя, Сайори..."

translate russian ch2_main_59b13a2c:
    y 1a "Видимо, в каждом из нас живёт маленький чертёнок, правда?"

translate russian ch2_main_c2bfa866:
    s 1q "Э-хе-хе..."

translate russian ch2_main_3ede6d18:
    mc "Не дай ей себя одурачить."

translate russian ch2_main_2efdee52:
    mc "Сайори прекрасно знает, что делает."

translate russian ch2_main_c5733275:
    mc "Она ведь рассказала вам, что приведёт меня в клуб, раньше, чем сказала мне..."

translate russian ch2_main_50f6cdb2:
    s 1h "Н-но...!"

translate russian ch2_main_e07cdad9:
    s "Ты бы не пришёл, если бы не капкейки..."

translate russian ch2_main_1fe586c6:
    s "Вот мне и пришлось обхитрить Нацуки, чтобы она их испекла!"

translate russian ch2_main_3f2756e3:
    mc "Да ладно, Сайори, не такого уж ты обо мне низкого мнения."

translate russian ch2_main_bbf9836b:
    s 1l "Э-хе-хе..."

translate russian ch2_main_24628db4:
    "{i}Шлёп!{/i}"

translate russian ch2_main_a4d9382c:
    s 4p "Кья—!"

translate russian ch2_main_638a293a:
    "Откуда ни возьмись что-то шлёпает Сайори по лицу и падает на парту."

translate russian ch2_main_834df6b3:
    s 4j "Ай..."

translate russian ch2_main_92f44b3b:
    s "Что это было—"

translate russian ch2_main_110aa5fd:
    s 4n "Э-э??"

translate russian ch2_main_b198b5dd:
    s "П-печенька!"

translate russian ch2_main_a02a41a6:
    "И правда — огромное печенье в пластиковой упаковке."

translate russian ch2_main_32714aa8:
    "Сайори оглядывается."

translate russian ch2_main_7cbfaae7:
    s 4m "Э-это чудо??"

translate russian ch2_main_101c99c7:
    s "Это потому, что я заплатила возмещение!"

translate russian ch2_main_416ef8d0:
    mc "Возмездие..."

translate russian ch2_main_72186408:
    y 1u "Вообще-то, это почти подошло..."

translate russian ch2_main_f991fa72:
    n "А-ха-ха-ха!"

translate russian ch2_main_05851adc:
    n "Я {i}вообще-то{/i} собиралась просто тебе его отдать."

translate russian ch2_main_6df49279:
    n 3d "Но потом услышала, как ты разболтала про капкейки."

translate russian ch2_main_20b98db4:
    n "Хотя на твою реакцию стоило посмотреть. А-ха-ха!"

translate russian ch2_main_745d7442:
    s 4m "Н-Нацуки!"

translate russian ch2_main_d7caf166:
    s "Как это мило с твоей стороны!"

translate russian ch2_main_650a1e1b:
    s 4s "Я так счастлива..."

translate russian ch2_main_dff473e4:
    "Сайори обнимает печенье."

translate russian ch2_main_df6e6eb4:
    mc "Боже, просто съешь его..."

translate russian ch2_main_17bd1750:
    "Сайори стремительно разрывает обёртку и откусывает большой кусок."

translate russian ch2_main_e63552cd:
    s 4q "Вкуфнятина..."

translate russian ch2_main_3ade65de:
    s 4o "Мм-мф—!"

translate russian ch2_main_5c98a428:
    "Сайори вдруг зажимает рот руками."

translate russian ch2_main_dcee9ced:
    s 4p "Я прикусила язык..."

translate russian ch2_main_959a1935:
    n 3a "Э-хе-хе."

translate russian ch2_main_8535bc25:
    n "Сколько приключений из-за одного печенья."

translate russian ch2_main_111d1089:
    "Нацуки откусывает от своего печенья."

translate russian ch2_main_a044c942:
    s 1c "Ой, а твоё тоже выглядит очень вкусно, Нацуки!"

translate russian ch2_main_f86ade01:
    s "Можно попробовать?"

translate russian ch2_main_fb69174d:
    n 4e "Блин..."

translate russian ch2_main_4abb40de:
    n "Дарёному коню в зубы не смотрят!"

translate russian ch2_main_68a2ac75:
    s 1h "Но у тебя шоколадное..."

translate russian ch2_main_8713619e:
    n 4c "Ага, а почему, как думаешь, я отдала тебе то?"

translate russian ch2_main_67ef1edb:
    s 1g "Ладно..."

translate russian ch2_main_a7f601fb:
    s 1q "И всё равно я очень рада, что ты со мной поделилась."

translate russian ch2_main_c98e38ed:
    s "Э-хе-хе~"

translate russian ch2_main_dcdc5c53:
    "Сайори встаёт, заходит Нацуки за спину и обнимает её."

translate russian ch2_main_5a029537:
    n 12c "Ах— Блин..."

translate russian ch2_main_6b5007ca:
    n "Поняла я, поняла."

translate russian ch2_main_60d3f9ad:
    "Не выпуская печенья, Нацуки тянется, чтобы отпихнуть от себя Сайори."

translate russian ch2_main_8028ebcd:
    s "...{i}Ам.{/i}"

translate russian ch2_main_11bf06a9:
    "Сайори вдруг наклоняется и откусывает кусок от печенья Нацуки."

translate russian ch2_main_25bf814a:
    n 1p "{i}Э-эй!!{/i}"

translate russian ch2_main_fabfae4a:
    n "Ты что, серьёзно это сделала?!"

translate russian ch2_main_34347c86:
    s 1q "У-ху-ху!"

translate russian ch2_main_d07467d2:
    "С набитым ртом Сайори вприпрыжку удаляется в безопасное место."

translate russian ch2_main_615876d7:
    "Мы с Юри тоже смеёмся."

translate russian ch2_main_70444492:
    n 1w "Блин! Какой же ты иногда ребёнок!"

translate russian ch2_main_59b15235:
    n 1h "Моника! Скажи Сайори—"

translate russian ch2_main_d3e11c0f:
    n 1c "—А?"

translate russian ch2_main_0ecb7603:
    "Нацуки оглядывается."

translate russian ch2_main_e72cdf66:
    "Моники в клубной комнате нет."

translate russian ch2_main_078274a3:
    n 4q "Фу..."

translate russian ch2_main_0bb33328:
    n "А где вообще Моника?"

translate russian ch2_main_ee60054b:
    y "Хороший вопрос..."

translate russian ch2_main_86666842:
    y "Кто-нибудь слышал, что она сегодня опоздает?"

translate russian ch2_main_8b64da11:
    s "Я нет..."

translate russian ch2_main_4dc0b8a2:
    mc "Да, я тоже."

translate russian ch2_main_8a348c57:
    y 2l "Хм..."

translate russian ch2_main_b8872480:
    y "Это немного необычно."

translate russian ch2_main_a69ab63c:
    s 1g "Надеюсь, с ней всё в порядке..."

translate russian ch2_main_27cac223:
    n "Конечно, с ней всё в порядке."

translate russian ch2_main_47ab8214:
    n "Наверное, у неё просто сегодня какие-то дела."

translate russian ch2_main_6054d4f0:
    n 3t "Она ведь довольно популярная..."

translate russian ch2_main_89e08697:
    s "А?"

translate russian ch2_main_f7e6cfc6:
    s "Думаете, у неё..."

translate russian ch2_main_646110e5:
    s "У неё появился...!"

translate russian ch2_main_db8b0f04:
    y "А-ха-ха. Я бы не удивилась."

translate russian ch2_main_70ba72a2:
    y "Наверное, она привлекательнее нас всех, вместе взятых."

translate russian ch2_main_099161b3:
    s "Э-хе-хе, это правда..."

translate russian ch2_main_6471eed3:
    n "Прошу прощения?!"

translate russian ch2_main_558239d6:
    "Вдруг дверь распахивается."

translate russian ch2_main_80de9d79:
    m "Простите! Мне ужасно жаль!"

translate russian ch2_main_25a98130:
    mc "А, вот и ты..."

translate russian ch2_main_becd460a:
    m "Я не хотела опаздывать..."

translate russian ch2_main_66c01c68:
    m "Надеюсь, вы не волновались!"

translate russian ch2_main_3cd77e3d:
    s "Э-э??"

translate russian ch2_main_1b7644e1:
    s "Моника всё-таки выбрала клуб, а не своего парня!"

translate russian ch2_main_101fd332:
    s "Какая же ты волевая!"

translate russian ch2_main_ab4b8464:
    m 1l "П-парня...?"

translate russian ch2_main_aee8a417:
    m "О чём это ты вообще?"

translate russian ch2_main_84646f3e:
    "Моника вопросительно смотрит на меня."

translate russian ch2_main_f06093be:
    mc "А, не бери в голову..."

translate russian ch2_main_0719b1a8:
    mc "А что тебя задержало?"

translate russian ch2_main_58f300ec:
    m 1e "Ах..."

translate russian ch2_main_f83931e9:
    m "Ну, последним уроком сегодня у меня была самоподготовка."

translate russian ch2_main_b72f3b34:
    m "Если честно, я просто потеряла счёт времени..."

translate russian ch2_main_f6daf90a:
    m "А-ха-ха..."

translate russian ch2_main_208360f0:
    n "Но это же бред."

translate russian ch2_main_00451011:
    n "Ты бы хоть звонок услышала."

translate russian ch2_main_7fc94381:
    m 1m "Наверное, я его не услышала, потому что занималась на пианино..."

translate russian ch2_main_80775dcb:
    y "На пианино...?"

translate russian ch2_main_a64357f6:
    y "Я и не знала, что ты ещё и музыкой занимаешься, Моника."

translate russian ch2_main_d5886c97:
    m 1l "Ах, не то чтобы занимаюсь...!"

translate russian ch2_main_76ca91ae:
    m "Я, в общем-то, только недавно начала."

translate russian ch2_main_dea3ae45:
    m 1m "Мне всегда хотелось научиться играть на пианино."

translate russian ch2_main_2658deff:
    s "Как здорово!"

translate russian ch2_main_1fe8e782:
    s "Сыграй нам что-нибудь, Моника!"

translate russian ch2_main_d2b78eb3:
    m "Это..."

translate russian ch2_main_945f9609:
    "Моника смотрит на меня."

translate russian ch2_main_dc3597d8:
    m 1a "Может, когда научусь немножко лучше, сыграю."

translate russian ch2_main_05cf8fd8:
    s 4q "Ура~!"

translate russian ch2_main_e46e57d7:
    mc "Звучит здорово."

translate russian ch2_main_772ab6af:
    mc "Я бы тоже с нетерпением этого ждал."

translate russian ch2_main_90d3c46f:
    m 1b "Правда?"

translate russian ch2_main_148978dd:
    m "В таком случае..."

translate russian ch2_main_d72b952e:
    m "Я тебя не подведу, [player]."

translate russian ch2_main_3049c3ae:
    "Моника мило улыбается."

translate russian ch2_main_93deaf69:
    mc "А..."

translate russian ch2_main_71613eca:
    mc "Я вовсе не хотел на тебя давить или что-то в этом роде!"

translate russian ch2_main_f157299a:
    m 1a "А-ха-ха, не волнуйся."

translate russian ch2_main_4d3c6da5:
    m "В последнее время я очень много занимаюсь."

translate russian ch2_main_e54c41d7:
    m "И мне бы очень хотелось поделиться, когда буду готова."

translate russian ch2_main_a7bcf340_1:
    mc "Понятно..."

translate russian ch2_main_d6e7d28c:
    mc "Тогда удачи тебе."

translate russian ch2_main_47a2e349:
    m 1j "Спасибо~!"

translate russian ch2_main_4da3801e:
    m 1a "Так я ничего не пропустила?"

translate russian ch2_main_56bba7bc:
    mc "Не... не особо."

translate russian ch2_main_8b2fb824:
    "Про озорную выходку Сайори я решаю промолчать."

translate russian ch2_main_eedd19b5:
    "Уверен, Нацуки и так ей нажалуется."

translate russian ch2_main_5501daee:
    "Похоже, все уже устроились."

translate russian ch2_main_8ed7eb12:
    "Сайори каким-то образом уже доела всё печенье."

translate russian ch2_main_2775c0ce:
    "Юри вернулась к своей книге, а Нацуки исчезла в шкафу."

translate russian ch2_end_90de9c4d:
    m "Итак, ребята!"

translate russian ch2_end_1fabc1ae:
    m "Мы ведь все прочитали стихи друг друга, да?"

translate russian ch2_end_4562c880:
    m "Сегодня я запланировала кое-что ещё, так что если бы все сели поближе ко мне..."

translate russian ch2_end_b36c642f:
    n "Это насчёт фестиваля?"

translate russian ch2_end_e5e5ca00:
    m "Ну, вроде того~"

translate russian ch2_end_2dd4b404:
    n "Фу. Нам что, правда обязательно что-то делать для фестиваля?"

translate russian ch2_end_a8b0c466:
    n "За пару дней мы всё равно ничего хорошего не подготовим."

translate russian ch2_end_0ce4e5b7:
    n "Мы просто опозоримся вместо того, чтобы найти новых участников."

translate russian ch2_end_d738eef9:
    y "Меня это тоже беспокоит."

translate russian ch2_end_ff8199d8:
    y "Я не очень хорошо справляюсь с подготовкой в последний момент..."

translate russian ch2_end_1d7cd41c:
    m 1b "Не волнуйтесь вы так!"

translate russian ch2_end_439c726d:
    m "Мы всё сделаем просто, хорошо?"

translate russian ch2_end_adc2c059:
    m 1a "Нам понадобится всего лишь немного украшений."

translate russian ch2_end_951a1c87:
    m "Сайори делает плакаты, а я придумала буклеты, которые мы будем раздавать во время мероприятия."

translate russian ch2_end_d1e18924:
    n "Ну ладно, всё это здорово..."

translate russian ch2_end_95bab597:
    n "Но из этого непонятно, что мы, собственно, будем делать на мероприятии."

translate russian ch2_end_5901d7b4:
    m 1d "Ой, простите! Я думала, вы уже слышали."

translate russian ch2_end_54d918f1:
    m 1b "Мы будем выступать!"

translate russian ch2_end_4e3dc84c:
    n 3h "Выступать?"

translate russian ch2_end_378ad5a3:
    y 3n "В..."

translate russian ch2_end_14540e5c:
    y 3o "Э-э, Моника..."

translate russian ch2_end_df419194:
    m 1k "Ага! Мы устроим поэтическое выступление."

translate russian ch2_end_926f6422:
    m 1b "Каждая из нас выберет стихотворение и прочитает его на мероприятии."

translate russian ch2_end_d2972141:
    m "Но самое классное — мы разрешим выйти и прочитать стихи кому угодно!"

translate russian ch2_end_0e488008:
    m 1a "Сайори пишет это на всех плакатах — на случай, если кто-то захочет подготовиться заранее."

translate russian ch2_end_c98e38ed:
    s "Э-хе-хе~"

translate russian ch2_end_a17230ae:
    "Сайори, которая раскрашивала плакат, поднимает его, чтобы показать нам."

translate russian ch2_end_45af9c8a:
    n "Ты издеваешься, Моника?"

translate russian ch2_end_7af8ba3c:
    n "Ты ведь... ты ведь не начала уже развешивать эти плакаты?"

translate russian ch2_end_9f368752:
    m 1d "А? Ну, начала..."

translate russian ch2_end_ed68fa36:
    m "Неужели вы правда думаете, что это такая плохая идея...?"

translate russian ch2_end_414b0568:
    n "Ну, нет."

translate russian ch2_end_b0f90690:
    n "Идея неплохая."

translate russian ch2_end_259d3952:
    n 1w "Но я на такое не подписывалась, знаешь ли!"

translate russian ch2_end_a0e7e528:
    n 1x "Я {i}ни за что{/i} не стану выступать перед толпой людей!"

translate russian ch2_end_416051b9:
    y 3r "Я... я согласна с Нацуки!"

translate russian ch2_end_3bcbcdfc:
    y 3w "Я бы никогда... в жизни... не смогла такое сделать..."

translate russian ch2_end_7a46202b:
    "Представив это, Юри в ужасе качает головой."

translate russian ch2_end_e1db9a49:
    s "Девочки..."

translate russian ch2_end_bc7fa4a8:
    m 1g "Нет, Сайори..."

translate russian ch2_end_d948fc20:
    m "Я понимаю, что они чувствуют."

translate russian ch2_end_c93c95cf:
    m "Вспомни, что Нацуки и Юри до позавчерашнего дня ни с кем не делились своими стихами..."

translate russian ch2_end_9171c73f:
    m "Просить их прочитать свои стихи вслух перед целым залом людей — это слишком."

translate russian ch2_end_feec417d:
    m 1r "Наверное, я это упустила."

translate russian ch2_end_b6084e11:
    m "Так что простите."

translate russian ch2_end_bb2cf764:
    n "..."

translate russian ch2_end_48d2becc:
    m 1i "...Но!"

translate russian ch2_end_5197b99b:
    m "Я всё равно считаю, что нам нужно постараться изо всех сил!"

translate russian ch2_end_14ade49d:
    m 1d "Только от нас зависит судьба этого клуба."

translate russian ch2_end_5bd30388:
    m "Если мы начнём мероприятие и каждая хорошо выступит..."

translate russian ch2_end_006ed4f7:
    m 3a "Это вдохновит и других!"

translate russian ch2_end_4fc6ab0f:
    m "И чем больше людей выступит, тем лучше мы сможем показать всем, что такое литература!"

translate russian ch2_end_a03b41d0:
    s "Да!"

translate russian ch2_end_aab6fcc5:
    s 1x "Это значит выражать свои чувства..."

translate russian ch2_end_741bbaf8:
    s "Быть откровенной с собой..."

translate russian ch2_end_9978499a:
    s "Открывать новые горизонты..."

translate russian ch2_end_ed84b2c9:
    s "И веселиться!"

translate russian ch2_end_972c392e:
    m 4b "Вот именно!"

translate russian ch2_end_d29823d1:
    m "И именно поэтому мы все сегодня в этом клубе."

translate russian ch2_end_729a5c4e:
    m 4e "Разве вам не хочется поделиться этим с другими?"

translate russian ch2_end_fb33c3be:
    m "Вдохновить их найти те же чувства, что когда-то привели сюда вас?"

translate russian ch2_end_2a4aa521:
    m 1e "Я знаю, что хочется."

translate russian ch2_end_cdb93574:
    m "Я знаю, что нам всем хочется."

translate russian ch2_end_48e971ca:
    m 1b "И если для этого нужно всего лишь пару минут постоять перед залом и прочитать стихотворение..."

translate russian ch2_end_66a19cbe:
    m "...То я знаю, что вы справитесь!"

translate russian ch2_end_bb2cf764_1:
    n "..."

translate russian ch2_end_71a86863:
    y "..."

translate russian ch2_end_97fda73d:
    "Нацуки и Юри молчат."

translate russian ch2_end_cfd1bae0:
    "Сайори выглядит обеспокоенной."

translate russian ch2_end_2b928ae2:
    "Похоже, выбора у меня нет..."

translate russian ch2_end_c9176119:
    mc "Я согласен..."

translate russian ch2_end_dcc750cb:
    mc "По-моему, это не так уж много."

translate russian ch2_end_e7188481:
    mc "Мне кажется, Сайори и Моника очень стараются найти новых участников."

translate russian ch2_end_ec402b9c:
    mc "Меньшее, что мы можем сделать, — немного им помочь."

translate russian ch2_end_b1040846:
    n 5h "Ну... может быть, но..."

translate russian ch2_end_bb2cf764_2:
    n "..."

translate russian ch2_end_ec8adcf1:
    "Похоже, у Нацуки закончились аргументы."

translate russian ch2_end_e349a681:
    n "У-у..."

translate russian ch2_end_49b6c84c:
    n 1q "...Ладно, хорошо!"

translate russian ch2_end_825ba599:
    n "Видимо, придётся просто отмучиться."

translate russian ch2_end_81f9edea:
    s 4r "Ура~!"

translate russian ch2_end_e07361c2:
    m 1e "Фух..."

translate russian ch2_end_dd856e21:
    m "Спасибо, Нацуки."

translate russian ch2_end_dda5c45e:
    m "А ты, Юри...?"

translate russian ch2_end_71a86863_1:
    y "..."

translate russian ch2_end_454e5345:
    "Юри уныло оглядывает выжидающие лица остальных."

translate russian ch2_end_ad226d63:
    y "Эх..."

translate russian ch2_end_8ca97570:
    y "П-похоже, выбора у меня особо нет..."

translate russian ch2_end_7fd1dbaf:
    s 4r "А-ха-ха! Значит, все!"

translate russian ch2_end_a4e7b59f:
    s "Ты лучшая, Юри~"

translate russian ch2_end_2d922e43:
    y "Этот клуб меня точно в могилу сведёт..."

translate russian ch2_end_f892e275:
    m 1l "Боже..."

translate russian ch2_end_83c19ebc:
    m 1n "Всё будет хорошо, Юри."

translate russian ch2_end_d57ef83e:
    m "Но в общем..."

translate russian ch2_end_f416622c:
    m 1b "Переходим к главному!"

translate russian ch2_end_4812a284:
    m "Я хочу, чтобы каждая из вас выбрала одно своё стихотворение."

translate russian ch2_end_808b446e:
    m "Будем тренироваться читать их друг перед другом."

translate russian ch2_end_bde7d3c8:
    n 1p "Н-н-ни за что!!"

translate russian ch2_end_3335a5b9:
    y "Моника...!"

translate russian ch2_end_c09adfaa:
    y "Это слишком внезапно...!"

translate russian ch2_end_34f824e1:
    m 2a "Ну, если вы не можете прочитать стихотворение перед клубом, как же вы прочитаете его перед незнакомцами?"

translate russian ch2_end_b3cf27ce:
    y "О нет..."

translate russian ch2_end_76bfea80:
    m 2a "Не волнуйтесь."

translate russian ch2_end_0fc549df:
    m "Я начну первой, чтобы всем было немного спокойнее."

translate russian ch2_end_43a66da1:
    s "Можно я следующая??"

translate russian ch2_end_d7f5c18a:
    m "А-ха-ха. Конечно."

translate russian ch2_end_0ed13f65:
    m 2d "Так, посмотрим..."

translate russian ch2_end_3e3e4ab2:
    "Моника листает тетрадь в поисках стихотворения, которое для себя выбрала."

translate russian ch2_end_18f13a6b:
    "Потом встаёт за кафедру."

translate russian ch2_end_fa3efc9d:
    m 1a "Это стихотворение называется {i}«Как они летают»{/i}."

translate russian ch2_end_62da269d:
    m 1r "Кхм..."

translate russian ch2_end_7c17ec80:
    "Моника начинает читать своё стихотворение."

translate russian ch2_end_6db8287a:
    "Её чистый уверенный голос заполняет комнату."

translate russian ch2_end_c47de62e:
    "Более того, интонации у неё безупречные."

translate russian ch2_end_bdc04beb:
    "Она точно знает, какие чувства вложить в каждую строчку, и слова оживают."

translate russian ch2_end_b29dda09:
    "Она уже делала это раньше или у неё просто природный талант?"

translate russian ch2_end_8c8c072b:
    "Я оглядываюсь."

translate russian ch2_end_53cd150c:
    "Все не сводят глаз с Моники."

translate russian ch2_end_db734dd0:
    "Сайори выглядит поражённой."

translate russian ch2_end_29d873ee:
    "У Юри напряжённое выражение лица, которого я не понимаю."

translate russian ch2_end_2b47a7c6:
    "Наконец Моника заканчивает читать."

translate russian ch2_end_17c32d03:
    "Мы вчетвером аплодируем."

translate russian ch2_end_2f85c2e7:
    "Моника переводит дыхание и улыбается."

translate russian ch2_end_2a809cd8:
    s "Это... это было так здорово, Моника!"

translate russian ch2_end_87544b48:
    m 1j "А-ха-ха, большое спасибо."

translate russian ch2_end_08387f13:
    m 1a "Я просто надеялась подать хороший пример."

translate russian ch2_end_e9e8055c:
    m "Готова быть следующей, Сайори?"

translate russian ch2_end_f7d11b41:
    y "Я... я пойду следующей!!"

translate russian ch2_end_5bac19cb:
    s 1n "Уа! Юри вдруг так загорелась!"

translate russian ch2_end_173e580a:
    "Юри сжимает в руках листок и встаёт."

translate russian ch2_end_0fe52e7c:
    "Не поднимая головы, она быстро идёт к кафедре."

translate russian ch2_end_881e4a21:
    y 2v "Это стихотворение называется—!"

translate russian ch2_end_8238750d:
    "Юри тревожно оглядывает каждого из нас."

translate russian ch2_end_4214e775:
    s "Ты справишься, Юри..."

translate russian ch2_end_d5227e10:
    y "Оно... Оно называется... {i}«Отсвет алого глаза»{/i}."

translate russian ch2_end_5fa70849:
    "Голос Юри дрожит, когда она начинает читать."

translate russian ch2_end_6ed49329:
    "Ещё минуту назад она практически отказывалась это делать."

translate russian ch2_end_be5b6b64:
    "Почему она вдруг так старается?"

translate russian ch2_end_fc3b59f8:
    "Когда Юри одолевает первые пару строк, её голос меняется."

translate russian ch2_end_b00f669a:
    "Это почти как то, что происходит, когда Юри погружается в свои книги."

translate russian ch2_end_b83af3b6:
    "Дрожащие слова превращаются в чёткие слоги яростной и уверенной в себе женщины."

translate russian ch2_end_a6f0ac40:
    "Стихотворение полно неожиданных поворотов, и каждый она выделяет с идеальной точностью."

translate russian ch2_end_d5ff2d91:
    "Должно быть, это редкий проблеск того бушующего пламени, что Юри скрывает у себя в голове...!"

translate russian ch2_end_4a65ac5f:
    "И вдруг она заканчивает."

translate russian ch2_end_025716df:
    "Все ошеломлены."

translate russian ch2_end_e974169d:
    "Юри возвращается в реальность и оглядывается, будто сама себя поразила."

translate russian ch2_end_3c9e8a16:
    y 3o "Я..."

translate russian ch2_end_72fb06ad:
    "...Спасать положение придётся мне."

translate russian ch2_end_0c21cdb9:
    "Я первым начинаю аплодировать."

translate russian ch2_end_f02298e8:
    "Остальные подхватывают, и мы воздаём Юри должное."

translate russian ch2_end_17306ab8:
    "Дело не в том, что мы не хотели ей аплодировать."

translate russian ch2_end_9531a229:
    "Просто мы были так застигнуты врасплох, что, видимо, забыли."

translate russian ch2_end_3db310c3:
    "Пока мы хлопаем, Юри прижимает стихотворение к груди и спешит на своё место."

translate russian ch2_end_6514d0f3:
    m "Юри, это было очень хорошо."

translate russian ch2_end_54f1d699:
    m "Спасибо, что поделилась."

translate russian ch2_end_71a86863_2:
    y "..."

translate russian ch2_end_adc50fea:
    "Похоже, Юри в нокауте..."

translate russian ch2_end_bb868ca6:
    s "Ла-а-адно~"

translate russian ch2_end_acdc4497:
    s "Значит, теперь я!"

translate russian ch2_end_68259a43:
    "Сайори спрыгивает со стула и весело идёт к кафедре."

translate russian ch2_end_66791e2a:
    s 1x "Это называется... {i}«Мой луг»{/i}."

translate russian ch2_end_699ac020:
    s "Ах..."

translate russian ch2_end_be260f56:
    s 1s "...А-ха-ха!"

translate russian ch2_end_a1548a53:
    s 4s "Простите, я захихикала..."

translate russian ch2_end_5b525ad4:
    s 4q "Э-хе-хе..."

translate russian ch2_end_e87e0575:
    mc "Сайори..."

translate russian ch2_end_5b98b763:
    s 1l "Это гораздо сложнее, чем я думала!"

translate russian ch2_end_69e30928:
    s "Как у вас так легко получилось?"

translate russian ch2_end_f0139694:
    m "Ах..."

translate russian ch2_end_79faa99a:
    m "Постарайся не думать, что читаешь для других людей."

translate russian ch2_end_0392ea6c:
    m "Представь, что читаешь его самой себе — перед зеркалом или у себя в голове."

translate russian ch2_end_73e6566a:
    m "Это твоё стихотворение, так у тебя получится лучше всего."

translate russian ch2_end_eda8c9b0:
    s "Понятно, понятно..."

translate russian ch2_end_899ef0e3:
    s "Ну, тогда..."

translate russian ch2_end_43a19f01:
    "Сайори начинает читать своё стихотворение."

translate russian ch2_end_281ecfa4:
    "Почему-то кажется, что её мягкий голос будто создан именно для него."

translate russian ch2_end_3c3af200:
    "Стихотворение не бесцельно весёлое, как сама Сайори."

translate russian ch2_end_3cd91d22:
    "Оно безмятежное и светло-грустное."

translate russian ch2_end_ab263d04:
    "Если бы я прочитал его на бумаге, то, наверное, не придал бы ему значения..."

translate russian ch2_end_5aab9ff6:
    "Но в голосе Сайори оно словно обретает совершенно новый смысл."

translate russian ch2_end_aa8b528e:
    "Может, это и имела в виду Сайори, когда говорила, что ей нравятся мои стихи."

translate russian ch2_end_9eba53fd:
    "Будто я могу глубже заглянуть в человека, которого, как мне казалось, знаю насквозь."

translate russian ch2_end_8dec374a:
    "Сайори заканчивает, и мы аплодируем."

translate russian ch2_end_a0f04fa2:
    s 3q "У меня получилось~!"

translate russian ch2_end_261147aa:
    mc "Молодец, Сайори."

translate russian ch2_end_e21292e5:
    s "Э-хе-хе, даже [player] оценил."

translate russian ch2_end_1a34bc11:
    s "Наверное, это хороший знак~"

translate russian ch2_end_d671595a:
    mc "Это вообще что значит...?"

translate russian ch2_end_179a3566:
    m "Хорошо вышло, Сайори."

translate russian ch2_end_ef36a575:
    m "Атмосфера стихотворения тебе очень подходит."

translate russian ch2_end_3be3ea41:
    m "Но, возможно, другие стихи с такой подачей звучали бы не так хорошо..."

translate russian ch2_end_4ec31a64:
    s 1g "А? Я не совсем понимаю..."

translate russian ch2_end_1c8e6eaf:
    m 1a "Другими словами, я видела у тебя стихи, с которыми такая мягкая подача сработала бы хуже."

translate russian ch2_end_39bad68c:
    m "Им, может быть, понадобится немного больше силы — смотря что читаешь..."

translate russian ch2_end_e57fbe56:
    s 1x "А, я поняла, о чём ты!"

translate russian ch2_end_ce75194e:
    s "Это... ну, я тренировалась так читать..."

translate russian ch2_end_3312af78:
    s 5 "Просто это стыдно делать перед всеми..."

translate russian ch2_end_cc3db8cd:
    s "Э-хе-хе..."

translate russian ch2_end_9c52d6fe:
    m 4a "Тогда в следующий раз я заставлю тебя выбрать стихотворение посложнее."

translate russian ch2_end_d03cf0f1:
    m "До фестиваля осталось не так много времени, понимаешь?"

translate russian ch2_end_dbce585d:
    s 1q "Ла-а-а-адно."

translate russian ch2_end_dad84ae8:
    m 1a "Итак, кто следующий...?"

translate russian ch2_end_e0540e08:
    m "Нацуки?"

translate russian ch2_end_ffa2b290:
    n "Хмф."

translate russian ch2_end_61d3b26b:
    n "Пусть [player] пойдёт раньше меня."

translate russian ch2_end_321d5396:
    n "Мне всё равно с вами не сравниться..."

translate russian ch2_end_6039c06b:
    n "Пусть лучше [player] сначала немного опустит для всех планку."

translate russian ch2_end_75d5f6d1:
    s 1g "Нацуки..."

translate russian ch2_end_4255537f:
    mc "Ничего-ничего."

translate russian ch2_end_e026ba26:
    mc "Что ж, пожалуй, отмучаюсь."

translate russian ch2_end_5c9a9693:
    mc "Правда, выбирать мне особо не из чего..."

translate russian ch2_end_f92b6256:
    mc "Придётся читать то, что написал на сегодня."

translate russian ch2_end_a275dbee:
    "Я встаю и выхожу к кафедре."

translate russian ch2_end_b50ceaed:
    "Все смотрят на меня, и мне ужасно неловко."

translate russian ch2_end_ec8f99a2:
    "Я читаю своё стихотворение."

translate russian ch2_end_9eff646e:
    "Поскольку в своих текстах я не особо уверен, вкладывать в чтение силы трудно."

translate russian ch2_end_c19a5d45:
    "И всё же, когда я заканчиваю, мне всё равно аплодируют."

translate russian ch2_end_68a8daa2:
    mc "Простите, у меня выходит не так хорошо, как у всех..."

translate russian ch2_end_adf9b0fc:
    m 1a "Не переживай ты так."

translate russian ch2_end_c8ab5943:
    m "По-моему, дело не столько в способностях, сколько в том, что ты не уверен в своих текстах."

translate russian ch2_end_443126e0:
    m "Хотя со временем это пройдёт."

translate russian ch2_end_def332e9:
    mc "Да... Может быть."

translate russian ch2_end_7e71afb1:
    m 1j "Ну что ж!"

translate russian ch2_end_e987b77e:
    m 1a "Осталась только ты, Нацуки."

translate russian ch2_end_9ff8dc31:
    n 2g "Да-да."

translate russian ch2_end_2fee7809:
    n "Иду."

translate russian ch2_end_87b6c508:
    "Нацуки нехотя встаёт и направляется к кафедре."

translate russian ch2_end_090057a7:
    n 2c "Стихотворение называется..."

translate russian ch2_end_593d0813:
    n 2q "Оно называется..."

translate russian ch2_end_d9ecd5da:
    n 1x "Ч-чего вы все на меня уставились?!"

translate russian ch2_end_4a718c10:
    m "Потому что ты выступаешь..."

translate russian ch2_end_ea4b9ca5:
    n 2x "Хмф..."

translate russian ch2_end_bde029d8:
    n 2h "В общем... стихотворение называется {i}«Прыжок»{/i}."

translate russian ch2_end_700fd121:
    "Нацуки набирает в грудь воздуха."

translate russian ch2_end_5e2b7947:
    "Стоит ей начать читать, как её кислая мина немного тает."

translate russian ch2_end_0b371622:
    "Хоть она всё ещё без особого энтузиазма, в её стихотворении есть ритм и рифма."

translate russian ch2_end_9e4e82d2:
    "Это фирменный стиль Нацуки, и вслух он звучит на удивление хорошо."

translate russian ch2_end_512493a0:
    "Слова будто подпрыгивают вверх и вниз, вдыхая в стихотворение жизнь."

translate russian ch2_end_aa8fca9d:
    "Нацуки заканчивает, и все аплодируют."

translate russian ch2_end_eee35b2e:
    "Фыркнув, она возвращается на своё место."

translate russian ch2_end_3ba3e312:
    m "Не так уж и страшно, правда?"

translate russian ch2_end_c512e9c0:
    n "Тебе легко говорить..."

translate russian ch2_end_fe106c88:
    n "Только попробуй ещё раз меня заставить."

translate russian ch2_end_7fee0771:
    m "А, ну..."

translate russian ch2_end_76822100:
    m "Ты хотя бы чувствуешь, что готова прочитать стихотворение перед другими людьми?"

translate russian ch2_end_0a20ee75:
    n "Да перед другими людьми будет гораздо проще!"

translate russian ch2_end_23cc3e2e:
    n "Перед чужими я могу сделать любое лицо, какое захочу."

translate russian ch2_end_b3a4b9d7:
    n 2q "А когда тут только мои друзья..."

translate russian ch2_end_4ffc8529:
    n "Это просто... стыдно."

translate russian ch2_end_19ab6ffc:
    s "Вот так неожиданность, Нацуки..."

translate russian ch2_end_aadf171f:
    s "Мне кажется, у меня было бы наоборот."

translate russian ch2_end_edf87759:
    n "Ну, вот так уж, так что..."

translate russian ch2_end_10afa9a2:
    m 1a "Что ж, тогда, наверное..."

translate russian ch2_end_9e9d3412:
    m "Тебе нечего особо бояться на фестивале."

translate russian ch2_end_98975268:
    m 2b "В общем, хочу поблагодарить всех, что справились."

translate russian ch2_end_0499da0d:
    m "Может, было и трудно, но надеюсь, теперь вы все представляете, каково это."

translate russian ch2_end_7e15372d:
    m 4b "Обязательно выберите стихотворение и как следует потренируйтесь до фестиваля, хорошо?"

translate russian ch2_end_1cd2ad86:
    m "Я буду делать буклеты, так что заранее скажите мне, что будете читать."

translate russian ch2_end_9098da49:
    mc "Ну ты даёшь..."

translate russian ch2_end_3e1a4f76:
    mc "Наверное, мне лучше найти какое-нибудь другое стихотворение."

translate russian ch2_end_c3ea60f0:
    m 1j "Это тоже можно!"

translate russian ch2_end_fbfe401d:
    m 1a "Оно не обязательно должно быть твоим."

translate russian ch2_end_59b9c4f6:
    m "Я и так приятно удивлена, что ты вкладываешь в клуб столько сил."

translate russian ch2_end_80757a6d:
    m 5 "Меня это очень радует."

translate russian ch2_end_ab593820:
    mc "А... Да, не за что..."

translate russian ch2_end_215e00ed:
    m 4b "Итак, ребята!"

translate russian ch2_end_d9a605b0:
    m "Думаю, на сегодня всё."

translate russian ch2_end_b1232a1f:
    m "Я знаю, что скоро фестиваль, но давайте и к завтрашнему дню постараемся написать стихи."

translate russian ch2_end_a464a3cc:
    m "Пока что всё получается очень хорошо, так что я бы хотела продолжить."

translate russian ch2_end_8bc47b65:
    m "Что касается фестиваля, завтра закончим планировать, а потом у нас будут выходные на подготовку."

translate russian ch2_end_dd8b9fcf:
    m "В понедельник — великий день!"

translate russian ch2_end_ebf4c7a9:
    s "Мне уже не терпится~!"

translate russian ch2_end_03a54bb7:
    y "Я справлюсь... Я справлюсь..."

translate russian ch2_end_506f5ac0:
    mc "Ну ладно—"

translate russian ch2_end_1950528a:
    "Я встаю."

translate russian ch2_end_5b4208e2:
    "Мне ни за что не набраться такого энтузиазма, как у Сайори и Моники, но я постараюсь как-нибудь пережить это."

translate russian ch2_end_0919e951:
    "Если это ради клуба..."

translate russian ch2_end_eaf848d9:
    "И ради того, чтобы впечатлить Монику..."

translate russian ch2_end_ce44a035:
    "То придётся постараться."

translate russian ch2_end_086c5ef4:
    mc "Идём, Сайори?"

translate russian ch2_end_40cab6a7:
    s 1x "Ага!"

translate russian ch2_end_070556f6:
    n "Вы только посмотрите на них — вечно вдвоём домой ходят."

translate russian ch2_end_2f80fe28:
    m "Это даже как-то мило, правда?"

translate russian ch2_end_4fe8273d:
    s 1q "Э-хе-хе~"

translate russian ch2_end_8d7a82ed:
    mc "Ну вы даёте..."

translate russian ch2_end_10bcaf32:
    mc "Не делайте из этого событие."

translate russian ch2_end_9a0639ed:
    y "Но, наверное, это хоть немного приятно..."

translate russian ch2_end_c14c584c:
    mc "Ну..."

translate russian ch2_end_93deaf69:
    mc "А..."

translate russian ch2_end_97034e8b:
    "И что мне на это ответить?"

translate russian ch2_end_bae2ecfe:
    s 1d "Ничего, [player], можешь не отвечать."

translate russian ch2_end_9742cd65:
    mc "...Как скажешь. Пойдём уже."

translate russian ch2_end_f8bf6941:
    "Я снова иду домой с Сайори."

translate russian ch2_end_2caadb4f:
    "Хоть прошло всего несколько дней, многое уже изменилось."

translate russian ch2_end_49a48c7b:
    "Но сегодня по дороге домой Сайори немного тише обычного."

translate russian ch2_end_2d47587c:
    mc "Слушай, Сайори..."

translate russian ch2_end_e1554201:
    s "..."

translate russian ch2_end_5ac60e15:
    s 1n "...Прости! Я задумалась!"

translate russian ch2_end_7301b25e:
    mc "А, теперь понятно..."

translate russian ch2_end_bcd7bc7f:
    s 1d "Э-э..."

translate russian ch2_end_4e0390fd:
    s "Я... думала кое о чём из сегодняшнего."

translate russian ch2_end_e3e9dbd6:
    s "Мне нравится, что мы можем..."

translate russian ch2_end_985d7403:
    s 1y "Т-то есть..."

translate russian ch2_end_1fbc80ee:
    "Сайори путается в словах."

translate russian ch2_end_c4ee50a6:
    s 1a "Так... давай представим, что однажды [ch2_winner!t] попросила бы проводить её домой..."

translate russian ch2_end_e4c4b2af:
    mc "Что?!"

translate russian ch2_end_cee4d147:
    s "Что бы ты сделал?"

translate russian ch2_end_71b1a052:
    mc "Что это вообще за вопрос...?"

translate russian ch2_end_8e55821d:
    mc "Ты меня как-то врасплох застаёшь..."

translate russian ch2_end_a75a398f:
    s 1y "Э-хе-хе..."

translate russian ch2_end_d52b7930:
    "Хотя, с другой стороны, до фестиваля всего несколько дней..."

translate russian ch2_end_01f64b7c:
    "Кто знает, что может за это время случиться?"

translate russian ch2_end_sayori_e87e0575:
    mc "Сайори..."

translate russian ch2_end_sayori_24121141:
    mc "Ты правда думаешь, что я брошу тебя ради [ch2_winner!t]?"

translate russian ch2_end_sayori_208b890a:
    s 1e "А?!"

translate russian ch2_end_sayori_2c2dfcfb:
    s "Н-но..."

translate russian ch2_end_sayori_12830247:
    s "Она такая милая, и с ней так весело..."

translate russian ch2_end_sayori_8d15488c:
    s "Она такая красивая и умная..."

translate russian ch2_end_sayori_9098da49:
    mc "Ну ты даёшь..."

translate russian ch2_end_sayori_ef1e53ba:
    mc "Я и так вижу её в клубе каждый день."

translate russian ch2_end_sayori_ec507a66:
    mc "К тому же тебе вроде бы всегда очень нравится, что мы ходим домой вместе..."

translate russian ch2_end_sayori_d1d27e04:
    mc "Я не стану просто так тебе это портить."

translate russian ch2_end_sayori_682a5a6a:
    s 1y "Какой же ты глупый, [player]..."

translate russian ch2_end_sayori_ee391249:
    s "Иногда ты слишком много обо мне думаешь."

translate russian ch2_end_sayori_bf0a2c77:
    s "[ch2_winner!t] заслуживает этого, если бы захотела, так что..."

translate russian ch2_end_sayori_d609de76:
    mc "Сайори, я уже всё решил."

translate russian ch2_end_sayori_715ef421:
    mc "Иногда я тебя совершенно не понимаю..."

translate russian ch2_end_sayori_11b59043:
    s "Прости..."

translate russian ch2_end_sayori_3af7afd1:
    mc "И вообще, какой смысл гадать о том, что никогда не случится?"

translate russian ch2_end_sayori_d4eb38f4:
    s 1k "Хм..."

translate russian ch2_end_sayori_dfa99acb:
    "Разговор сходит на нет."

translate russian ch2_end_sayori_a2625442:
    "Странно, что Сайори так переживает из-за этого..."

translate russian ch2_end_sayori_00b80506:
    "Но я тоже хочу уважать её чувства и чтобы она была счастлива."

translate russian ch2_end_natsuki_0b69a6de:
    mc "Проводить Нацуки домой, значит..."

translate russian ch2_end_natsuki_d626012f:
    "Почему от этой мысли у меня колотится сердце...?"

translate russian ch2_end_natsuki_7136c946:
    mc "Ну..."

translate russian ch2_end_natsuki_b068f01e:
    mc "Наверное, я бы боялся, что она со мной сделает, если я ей откажу..."

translate russian ch2_end_natsuki_808e1746:
    s 1x "Разве она не милая и разве с ней не весело?"

translate russian ch2_end_yuri_f146b61e:
    mc "Проводить Юри домой, значит..."

translate russian ch2_end_yuri_d626012f:
    "Почему от этой мысли у меня колотится сердце...?"

translate russian ch2_end_yuri_7136c946:
    mc "Ну..."

translate russian ch2_end_yuri_db26810f:
    mc "Учитывая, как ей трудно общаться, мне было бы ужасно неловко ей отказать, так что..."

translate russian ch2_end_yuri_8d4d0f16:
    s 1x "Разве она не красивая и не умная?"

translate russian ch2_end_shared_4715d2cf:
    mc "Это вообще никак не связано с тем, что я сказал!"

translate russian ch2_end_shared_860f6b2b:
    s 4s "А-ха-ха! Ты признался!"

translate russian ch2_end_shared_9098da49:
    mc "Ну ты даёшь..."

translate russian ch2_end_shared_eb3aa3a1:
    mc "Нет никакого смысла гадать о том, что никогда не случится."

translate russian ch2_end_shared_171200b4:
    s 1d "Ну, может быть..."

translate russian ch2_end_shared_fd709dc3:
    s "Но мне просто нравится об этом думать."

translate russian ch2_end_shared_5dee20eb:
    s 1y "Знаешь, совсем скоро я тебе стану не нужна."

translate russian ch2_end_shared_29551931:
    mc "Не нужна...?"

translate russian ch2_end_shared_e87e0575:
    mc "Сайори..."

translate russian ch2_end_shared_1aac6df9:
    mc "Не понимаю, как ты сейчас всё это видишь у себя в голове."

translate russian ch2_end_shared_11b59043:
    s "Прости..."

translate russian ch2_end_shared_3f557db3:
    mc "Все разные..."

translate russian ch2_end_shared_af66983c:
    mc "Никто в клубе тебя не заменит."

translate russian ch2_end_shared_4c0e171a:
    s 1k "Хм-м..."

translate russian ch2_end_shared_66bb9612:
    s "Раз ты так говоришь..."

translate russian ch2_end_shared_3f8a9632:
    "Разговор сходит на нет, и мне становится неловко."

translate russian ch2_end_shared_388884dc:
    "Но она сама виновата, что загнала меня в угол таким странным вопросом..."

translate russian ch2_end_shared_ac037571:
    "Я не могу ей просто соврать."

translate russian ch2_end_shared_57396b14:
    "Но если что-то делает её счастливой, мне бы совсем не хотелось это у неё отнимать."

translate russian ch2_end_shared_8d2027c6:
    "Поэтому я и сказал, что нет смысла гадать."
