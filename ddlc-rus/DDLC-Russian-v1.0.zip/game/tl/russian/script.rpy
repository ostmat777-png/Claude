# Русский перевод: script

translate russian playthrough2_b23f6c03:
    "Конец демоверсии"
