# Русский перевод: script-ch20

translate russian ch20_main2_b68875d5:
    "Обычный учебный день, как и любой другой."

translate russian ch20_main2_55a610db:
    "Утро обычно хуже всего: вокруг меня парочки и компании друзей, идущие в школу вместе."

translate russian ch20_main2_cf8d9925:
    "А я всегда хожу в школу один."

translate russian ch20_main2_2848646c:
    "Я всё твержу себе, что пора бы уже познакомиться с какими-нибудь девушками или вроде того..."

translate russian ch20_main2_e646ec70:
    "Но у меня нет никакого желания вступать в клубы."

translate russian ch20_main2_5b22de21:
    "Меня вполне устраивает быть середнячком, а свободное время тратить на игры и аниме."

translate russian ch20_main2_cdfda5ab:
    "Есть, конечно, аниме-клуб, но девушек там всё равно наверняка нет..."

translate russian ch20_main2_d234f771:
    "Учебный день проходит как обычно и заканчивается прежде, чем я успеваю это заметить."

translate russian ch20_main2_7a46ab7f:
    "Собрав вещи, я тупо смотрю в стену в поисках хоть капли мотивации."

translate russian ch20_main2_64e92eab:
    mc "Клубы..."

translate russian ch20_main2_31d6ccab:
    "Да и нет таких, которые бы меня интересовали."

translate russian ch20_main2_581d00cc:
    "К тому же большинство из них наверняка слишком требовательные, чтобы мне хотелось с ними возиться."

translate russian ch20_main2_aded22ad:
    "Похоже, выбора нет — начну с аниме-клуба..."

translate russian ch20_main2_a92199a4:
    m "...[player]?"

translate russian ch20_main2_9a60ad41:
    mc "...Моника?"

translate russian ch20_main2_0fbdca71:
    m 1b "Боже мой, вот уж не ожидала тебя здесь встретить!"

translate russian ch20_main2_a80abc6a:
    m 5 "Давно не виделись, да?"

translate russian ch20_main2_93deaf69:
    mc "А..."

translate russian ch20_main2_62e2fb41:
    mc "Да, давно."

translate russian ch20_main2_3049c3ae:
    "Моника мило улыбается."

translate russian ch20_main2_7c7cb783:
    "Мы и правда знакомы — ну, почти не разговаривали, но в прошлом году учились в одном классе."

translate russian ch20_main2_f583350f:
    "Моника была, пожалуй, самой популярной девчонкой в классе — умная, красивая, спортивная."

translate russian ch20_main2_e3e8565d:
    "Короче говоря, совершенно не моего полёта птица."

translate russian ch20_main2_f83977c1:
    "Поэтому, когда она так искренне мне улыбается, мне становится немного..."

translate russian ch20_main2_36039a80:
    mc "А что ты здесь делаешь?"

translate russian ch20_main2_07a71c86:
    m 1a "О, я просто ищу кое-какие принадлежности для своего клуба."

translate russian ch20_main2_d6fe707b:
    m 1d "Не знаешь, здесь есть цветная бумага?"

translate russian ch20_main2_4ed91e88:
    m "Или фломастеры?"

translate russian ch20_main2_7793921e:
    mc "Может, посмотри в шкафу."

translate russian ch20_main2_c1339618:
    mc "...Ты ведь в дебатном клубе, да?"

translate russian ch20_main2_1598c2e2:
    m 5 "А-ха-ха, насчёт этого..."

translate russian ch20_main2_e427c62a:
    m "Вообще-то, я ушла из дебатного клуба."

translate russian ch20_main2_e70da75f:
    mc "Правда? Ушла?"

translate russian ch20_main2_7e7f246d:
    m "Ну вот..."

translate russian ch20_main2_45b73312:
    m 2e "Честно говоря, меня воротит от всех этих интриг в крупных клубах."

translate russian ch20_main2_0ee5c447:
    m "Сплошные споры о бюджете, рекламе и подготовке к мероприятиям..."

translate russian ch20_main2_874ed9a4:
    m "Мне куда больше хочется взять то, что нравится лично мне, и сделать из этого что-то особенное."

translate russian ch20_main2_1ca09fe2:
    mc "Тогда в какой клуб ты решила вступить?"

translate russian ch20_main2_17805c80:
    m 1b "Вообще-то, я открываю новый!"

translate russian ch20_main2_49f35015:
    m "Литературный клуб!{nw}"

translate russian ch20_main2_3faf8904:
    m "Литературный клуб!{fast}"

translate russian ch20_main2_a8fe5f7e:
    mc "Литературный...?"

translate russian ch20_main2_584e99e4:
    "Звучит как-то... скучновато?"

translate russian ch20_main2_49c2d156:
    mc "И сколько у тебя пока участников?"

translate russian ch20_main2_1c8c1053:
    m 5 "Э-э..."

translate russian ch20_main2_f6daf90a:
    m "А-ха-ха..."

translate russian ch20_main2_3e48ae26:
    m "Немного неловко, но пока нас всего трое."

translate russian ch20_main2_3b257766:
    m "Очень трудно найти новых участников для чего-то, что звучит так скучно..."

translate russian ch20_main2_af2a83ac:
    mc "Что ж, понимаю..."

translate russian ch20_main2_bc1a4311:
    m 3d "Но на самом деле это совсем не скучно, знаешь!"

translate russian ch20_main2_e754f821:
    m "Литература может быть чем угодно. Чтение, писательство, поэзия..."

translate russian ch20_main2_c7f06a68:
    m 3e "Ну, одна из участниц даже хранит в клубной комнате свою коллекцию манги..."

translate russian ch20_main2_76f46bb5:
    mc "Стоп... правда?"

translate russian ch20_main2_48209ebb:
    m 2k "Ага, забавно, правда?"

translate russian ch20_main2_43bd010c:
    m 2e "Она всё время настаивает, что манга — это тоже литература."

translate russian ch20_main2_43d75f5f:
    m "Ну, наверное, она не так уж и неправа..."

translate russian ch20_main2_bbd414b4:
    m "И к тому же участница есть участница, правда?"

translate russian ch20_main2_ef8942cb:
    "...Моника сказала «участница»?"

translate russian ch20_main2_11bedf1c:
    "Хм-м..."

translate russian ch20_main2_0e946372:
    m 1a "Эй, [player]..."

translate russian ch20_main2_d5f8d49c:
    m "А ты случайно... ещё не выбрал, в какой клуб вступить?"

translate russian ch20_main2_f9d65918:
    mc "А—"

translate russian ch20_main2_e0a3e98e:
    mc "Ну, пожалуй, нет, но..."

translate russian ch20_main2_148978dd:
    m "В таком случае..."

translate russian ch20_main2_6f26aacb:
    m 5 "Может, сделаешь мне одно большое одолжение?"

translate russian ch20_main2_9019334d:
    m "Я не прошу тебя вступать, но..."

translate russian ch20_main2_cea6fd10:
    m "Если бы ты хотя бы заглянул в мой клуб, я была бы очень рада."

translate russian ch20_main2_5b9fdb10:
    m "Пожалуйста?"

translate russian ch20_main2_6b0ed824:
    mc "Э-э..."

translate russian ch20_main2_94ea595d:
    "Что ж, пожалуй, у меня нет причин отказываться..."

translate russian ch20_main2_24dcf38e:
    "Да и разве можно отказать такой, как Моника?"

translate russian ch20_main2_a6ec6469:
    mc "Конечно, можно заглянуть."

translate russian ch20_main2_31c2f59c:
    m 1k "А-ах, здорово!"

translate russian ch20_main2_7f15368b:
    m 1b "Ты такой милый, [player], ты знаешь?"

translate russian ch20_main2_4e43723a:
    mc "Д-да ничего особенного..."

translate russian ch20_main2_df96810e:
    m 1a "Тогда идём?"

translate russian ch20_main2_b21a8ccf:
    m "Принадлежности поищу в другой раз — ты важнее."

translate russian ch20_main2_fe6b0db2:
    "Вот так этот день и стал днём, когда я продал душу Монике и её неотразимой улыбке."

translate russian ch20_main2_ab62062b:
    "Я робко иду за Моникой через всю школу и поднимаюсь наверх — в ту часть здания, где почти не бываю: там в основном проходят занятия и мероприятия выпускных классов."

translate russian ch20_main2_b2195ace:
    "Моника, полная энергии, распахивает дверь класса."

translate russian ch20_main2_33f9b307:
    m "Я вернулась~!"

translate russian ch20_main2_9e0a9684:
    m "И привела гостя!"

translate russian ch20_main2_444e7092:
    y "А?"

translate russian ch20_main2_d52d2254:
    y "Г-гостя?"

translate russian ch20_main2_cc7dab55:
    n "Серьёзно? Ты привела парня?"

translate russian ch20_main2_2bfb1f2f:
    n "Вся атмосфера насмарку."

translate russian ch20_main2_cef21d6a:
    m "Не вредничай, Нацуки..."

translate russian ch20_main2_e6485931:
    m 3b "...Но в общем, добро пожаловать в клуб, [player]!"

translate russian ch20_main2_2b35b6fe:
    mc "..."

translate russian ch20_main2_00244a6d:
    "В такой ситуации у меня просто нет слов."

translate russian ch20_main2_7903e6e7:
    "Этот клуб..."

translate russian ch20_main2_4c13a14b:
    "{i}...полон невероятно милых девушек!!{/i}"

translate russian ch20_main2_5dd39c1a:
    n 5c "Так, дай угадаю..."

translate russian ch20_main2_9d91e589:
    n "Ты парень Моники, да?"

translate russian ch20_main2_109fa1ce:
    mc "Что—"

translate russian ch20_main2_3dc221a5:
    mc "Нет, не парень!"

translate russian ch20_main2_36e4566e:
    y 2l "Нацуки..."

translate russian ch20_main2_3b270b09:
    "Девчонку с кислой миной — видимо, её зовут Нацуки — я раньше не встречал."

translate russian ch20_main2_5e0f976f:
    "Судя по её миниатюрной фигуре, она, наверное, первогодка."

translate russian ch20_main2_95b17045:
    m 2l "В-в общем, это Нацуки, энергичная, как всегда..."

translate russian ch20_main2_204e7b10:
    m 2b "А это Юри, вице-президент!"

translate russian ch20_main2_de6dffcc:
    y 4 "Р-рада познакомиться..."

translate russian ch20_main2_73e961d1:
    "Юри выглядит заметно взрослее и застенчивее и, похоже, с трудом поспевает за такими, как Нацуки."

translate russian ch20_main2_273d4c55:
    mc "Да... Приятно познакомиться с вами обеими."

translate russian ch20_main2_d5adce07:
    m 1a "В общем, я встретила [player] в одном из классов, и он решил заглянуть в клуб."

translate russian ch20_main2_bcaaba8c:
    m "Здорово, правда?"

translate russian ch20_main2_0e88f1eb:
    n 4e "Стоп! Моника!"

translate russian ch20_main2_d321684b:
    n "Разве я не просила предупреждать меня заранее, прежде чем приводить кого-то новенького?"

translate russian ch20_main2_36775efa:
    n 4q "Я собиралась... ну, ты поняла..."

translate russian ch20_main2_f537036e:
    m 1e "Простите, простите!"

translate russian ch20_main2_9b8367fd:
    m "Я не забыла, просто случайно его встретила."

translate russian ch20_main2_0fed35e5:
    y 1a "Тогда мне стоит хотя бы заварить чаю, правда?"

translate russian ch20_main2_fe32ff21:
    m 1b "Да, было бы здорово!"

translate russian ch20_main2_7df2370c:
    m "Садись, [player]!"

translate russian ch20_main2_9f8ec8cb:
    "Девушки сдвинули несколько парт, чтобы получился стол."

translate russian ch20_main2_dd548a27:
    "Юри идёт в угол комнаты и открывает шкаф."

translate russian ch20_main2_7bc19a0f:
    "Тем временем Моника и Нацуки садятся друг напротив друга."

translate russian ch20_main2_26f03535:
    "Всё ещё чувствуя себя неловко, я сажусь рядом с Моникой."

translate russian ch20_main2_f7bd3d65:
    m "Я знаю, ты не собирался сюда приходить..."

translate russian ch20_main2_774dba28:
    m "Но мы сделаем всё, чтобы ты чувствовал себя как дома, хорошо?"

translate russian ch20_main2_3f9e20f6:
    m 1j "Как президент Литературного клуба, я обязана сделать так, чтобы в клубе всем было весело и интересно!"

translate russian ch20_main2_f2f7dc32:
    mc "Странно, что в клубе до сих пор так мало людей."

translate russian ch20_main2_d49bb743:
    mc "Наверное, сложно открыть новый клуб."

translate russian ch20_main2_be7ec00e:
    m 3b "Можно и так сказать."

translate russian ch20_main2_75b36957:
    m "Не так уж много людей готовы вкладывать столько сил, чтобы начать что-то совершенно новое..."

translate russian ch20_main2_e8c57f75:
    m "Особенно когда это что-то не особо привлекает внимание — вот как литература."

translate russian ch20_main2_1ca5227d:
    m "Нужно очень постараться, чтобы убедить людей, что с тобой и весело, и не зря."

translate russian ch20_main2_2d2540fa:
    m "Зато школьные мероприятия вроде фестиваля становятся от этого куда важнее."

translate russian ch20_main2_5d278e4b:
    m 2k "Я уверена, что вместе мы по-настоящему разовьём этот клуб, прежде чем выпустимся!"

translate russian ch20_main2_6648f9f1:
    m "Правда, Нацуки?"

translate russian ch20_main2_228e3b68:
    n "Ну..."

translate russian ch20_main2_b6f6d9e1:
    n "...Наверное."

translate russian ch20_main2_c40dd420:
    "Нацуки нехотя соглашается."

translate russian ch20_main2_fffaaae6:
    "Такие разные девушки — и все стремятся к одной цели..."

translate russian ch20_main2_76b88d58:
    "Монике, наверное, пришлось очень постараться, чтобы найти хотя бы этих двоих."

translate russian ch20_main2_28adc331:
    "Юри возвращается к столу с чайным сервизом."

translate russian ch20_main2_356ce113:
    "Она аккуратно ставит перед каждым из нас чашку, а потом опускает чайник посередине стола."

translate russian ch20_main2_b0102204:
    mc "Вы держите в классе целый чайный сервиз?"

translate russian ch20_main2_63fe0000:
    y "Не волнуйся, учителя нам разрешили."

translate russian ch20_main2_efc4ed34:
    y "В конце концов, разве чашка горячего чая не помогает насладиться хорошей книгой?"

translate russian ch20_main2_a3a3b943:
    mc "А... Н-наверное..."

translate russian ch20_main2_de8b3252:
    m "Э-хе-хе, не тушуйся, Юри просто хочет произвести на тебя впечатление."

translate russian ch20_main2_d1e9e5c9:
    y 3n "А?! Н-неправда..."

translate russian ch20_main2_6f8e7fc9:
    "Обиженная Юри отводит взгляд."

translate russian ch20_main2_0403ff06:
    y 4b "Я имела в виду, ну..."

translate russian ch20_main2_03220b59:
    mc "Я тебе верю."

translate russian ch20_main2_e29518b6:
    mc "Ну, чтение за чаем — это, может, и не моё, но чай я хотя бы люблю."

translate russian ch20_main2_fb4dad3b:
    y 2u "Я рада..."

translate russian ch20_main2_c171e465:
    "Юри с облегчением едва заметно улыбается."

translate russian ch20_main2_63db5da7:
    y "Итак, [player], что ты любишь читать?"

translate russian ch20_main2_cf79ccdb:
    mc "Ну... Э-э..."

translate russian ch20_main2_5fcc5273:
    "Учитывая, как мало я прочитал за последние несколько лет, внятно ответить на этот вопрос я не могу."

translate russian ch20_main2_1947382b:
    mc "...Мангу..."

translate russian ch20_main2_459c1918:
    "Я бормочу это себе под нос, наполовину в шутку."

translate russian ch20_main2_c6e48974:
    "Нацуки вдруг резко поднимает голову."

translate russian ch20_main2_9101cacb:
    "Кажется, она хочет что-то сказать, но молчит."

translate russian ch20_main2_8c105e2a:
    y 3u "З-значит, ты не особо любишь читать..."

translate russian ch20_main2_68d50b2d:
    mc "...Ну, это можно исправить..."

translate russian ch20_main2_ccf38a3c:
    "Что я несу?"

translate russian ch20_main2_3b4ce5c9:
    "Я ляпнул не подумав, когда увидел грустную улыбку Юри."

translate russian ch20_main2_ca4f61b8:
    mc "В общем, а как насчёт тебя, Юри?"

translate russian ch20_main2_a89289a8:
    y 1l "Ну, дай подумать..."

translate russian ch20_main2_de0357e1:
    "Юри обводит пальцем край своей чашки."

translate russian ch20_main2_17dec8ac:
    y 1a "Больше всего я люблю романы, в которых выстроены глубокие и сложные фантастические миры."

translate russian ch20_main2_24dcace1:
    y "Меня поражает, сколько в них творческой фантазии и мастерства."

translate russian ch20_main2_ff3c844f:
    y 1f "А рассказать хорошую историю в таком чуждом мире — это не менее впечатляюще."

translate russian ch20_main2_c77e0dd8:
    "Юри продолжает, явно увлечённая своими книгами."

translate russian ch20_main2_30d11e87:
    "С самого моего прихода она казалась такой сдержанной и робкой, но по тому, как загораются её глаза, ясно: утешение она находит в мире книг, а не людей."

translate russian ch20_main2_830d7316:
    y 2m "Но, знаешь, мне нравится очень многое."

translate russian ch20_main2_7aa57972:
    y "Истории с глубоким психологизмом тоже обычно меня затягивают."

translate russian ch20_main2_b1a75737:
    y 2a "Разве не удивительно, как писатель может намеренно сыграть на недостатке твоего воображения, чтобы застать тебя врасплох?"

translate russian ch20_main2_98f09acd:
    y "В общем, в последнее время я много читаю ужасы..."

translate russian ch20_main2_b274f53a:
    mc "А, я однажды читал книгу ужасов..."

translate russian ch20_main2_e7c359a6:
    "Я отчаянно хватаюсь за то, к чему имею хоть какое-то отношение."

translate russian ch20_main2_6b8ceb25:
    "С таким успехом Юри могла бы разговаривать с камнем."

translate russian ch20_main2_d407ea82:
    m "А-ха-ха. От тебя я другого и не ждала, Юри."

translate russian ch20_main2_8ae45235:
    m 1a "Это так в твоём характере."

translate russian ch20_main2_17c1f817:
    y 1a "О, правда?"

translate russian ch20_main2_c853c8f6:
    y "Правда, если история заставляет меня задуматься или переносит в другой мир, я просто не могу от неё оторваться."

translate russian ch20_main2_fa55ff2a:
    y "Сюрреалистичный хоррор часто прекрасно умеет изменить то, как ты смотришь на мир, — пусть даже ненадолго."

translate russian ch20_main2_b8c3c144:
    n "Фу, ненавижу ужасы..."

translate russian ch20_main2_1c139e48:
    y 1f "О? Почему же?"

translate russian ch20_main2_ab1562c5:
    n 5c "Ну, просто я..."

translate russian ch20_main2_7aac067b:
    "Нацуки на долю секунды бросает взгляд на меня."

translate russian ch20_main2_98c7c1c1:
    n 5q "Забудь."

translate russian ch20_main2_5d936510:
    m 1a "Точно, ты ведь обычно любишь писать о чём-нибудь милом, да, Нацуки?"

translate russian ch20_main2_f053d184:
    n "Ч-чего?"

translate russian ch20_main2_3df32e44:
    n "С чего ты это взяла?"

translate russian ch20_main2_550dd777:
    m 3b "На прошлом собрании ты оставила черновик."

translate russian ch20_main2_e37f3c62:
    m "Похоже, ты писала стихотворение под названием—"

translate russian ch20_main2_1e455dfe:
    n "Не говори вслух!!"

translate russian ch20_main2_ff703620:
    n "И отдай сейчас же!"

translate russian ch20_main2_7ae96939:
    m 1j "Ладно, ладно~"

translate russian ch20_main2_af8472c2:
    mc "Нацуки, ты сама пишешь стихи?"

translate russian ch20_main2_30d37f9a:
    n 1c "А? Ну, бывает иногда."

translate russian ch20_main2_842dce39:
    n "Тебе-то что?"

translate russian ch20_main2_fe27eb16:
    mc "По-моему, это впечатляет."

translate russian ch20_main2_ccafd1bb:
    mc "Может, как-нибудь покажешь?"

translate russian ch20_main2_3f199bd2:
    n 5q "Н-нет!"

translate russian ch20_main2_edb6ed7f:
    "Нацуки отводит взгляд."

translate russian ch20_main2_9d7b9bad:
    n "Тебе бы они... не понравились..."

translate russian ch20_main2_35a5aeea:
    mc "А... Ещё не очень уверена в себе как автор?"

translate russian ch20_main2_68312196:
    y 2f "Я понимаю, что чувствует Нацуки."

translate russian ch20_main2_a387c89f:
    y "Чтобы делиться такими текстами, одной уверенности мало."

translate russian ch20_main2_e06ca773:
    y 2k "Самое настоящее творчество — это когда пишешь для себя."

translate russian ch20_main2_d2b7c428:
    y "Нужно быть готовой открыться читателям, обнажить свои слабости и показать даже самые потаённые уголки своего сердца."

translate russian ch20_main2_d526bbf0:
    m "Юри, у тебя тоже есть опыт в писательстве?"

translate russian ch20_main2_2bc6a16e:
    m "Может, если ты поделишься своими работами, то подашь пример, и Нацуки будет спокойнее показать свои."

translate russian ch20_main2_5a6499dc:
    y 3o "..."

translate russian ch20_main2_19552c38:
    mc "Видимо, с Юри то же самое..."

translate russian ch20_main2_701e440d:
    "Какое-то время мы все сидим молча."

translate russian ch20_main2_fdf041b5:
    m 5a "Слушайте, у меня идея!"

translate russian ch20_main2_005c60ce:
    m "Как насчёт такого?"

translate russian ch20_main2_95cd0d51:
    ny "...?"

translate russian ch20_main2_d080e0ca:
    "Нацуки и Юри вопросительно смотрят на Монику."

translate russian ch20_main2_a4f63044:
    m 2b "Давайте все пойдём домой и напишем по стихотворению!"

translate russian ch20_main2_cd1a6280:
    m "А в следующий раз, когда соберёмся, покажем их друг другу."

translate russian ch20_main2_a106107a:
    m "Так все будут в равных условиях!"

translate russian ch20_main2_963b3971:
    n 5q "Э-э..."

translate russian ch20_main2_71a86863:
    y "..."

translate russian ch20_main2_f0139694:
    m "Ах..."

translate russian ch20_main2_9b894fcc:
    m "Ну, мне показалось, что идея хорошая..."

translate russian ch20_main2_d2a1aba6:
    y 2l "Ну..."

translate russian ch20_main2_1570106e:
    y "...Думаю, ты права, Моника."

translate russian ch20_main2_358acf11:
    y 2f "Нам, наверное, стоит начать придумывать занятия, в которых могли бы участвовать мы все вместе."

translate russian ch20_main2_97473fce:
    y 2h "Я ведь всё-таки взяла на себя обязанности вице-президента..."

translate russian ch20_main2_6400d1aa:
    y "Мне нужно изо всех сил заботиться о клубе и его участниках."

translate russian ch20_main2_a515a8b2:
    y 2a "К тому же теперь, когда у нас новый участник..."

translate russian ch20_main2_6cd4d347:
    y "Это кажется правильным шагом."

translate russian ch20_main2_d5d48b8f:
    y "Ты тоже согласен, [player]?"

translate russian ch20_main2_cf25d371:
    mc "Погоди... есть ещё одна проблема."

translate russian ch20_main2_bee826cb:
    m 1d "А? Какая?"

translate russian ch20_main2_d078fb85:
    "Раз уж мы дошли до самого важного вопроса, я прямо выкладываю то, что всё это время было у меня на уме."

translate russian ch20_main2_5ce8ccfa:
    mc "Я ведь не говорил, что вступлю в этот клуб!"

translate russian ch20_main2_1cb46f5d:
    mc "Моника, может, и уговорила меня заглянуть, но я ещё ничего не решил."

translate russian ch20_main2_4de02539:
    mc "Мне нужно посмотреть и другие клубы, и... э-э..."

translate russian ch20_main2_1e4b58a1:
    "Я теряю нить мысли."

translate russian ch20_main2_aa92c4c7:
    "Все три девушки смотрят на меня полными уныния глазами."

translate russian ch20_main2_8911e105:
    m 1p "Н-но..."

translate russian ch20_main2_a403322e:
    y 2v "Прости, я думала..."

translate russian ch20_main2_bc64dbb8:
    n 5s "Хмф."

translate russian ch20_main2_bbe4458e:
    mc "А...?"

translate russian ch20_main2_d6738775:
    "Девушки переглядываются, а потом Моника снова поворачивается ко мне."

translate russian ch20_main2_6a0c763d:
    m 1m "Похоже... мне придётся сказать тебе правду, [player]."

translate russian ch20_main2_80d67ce2:
    m "Дело в том..."

translate russian ch20_main2_3ecd0ecb:
    m 1p "...У нас пока недостаточно участников, чтобы стать официальным клубом."

translate russian ch20_main2_c4b6f680:
    m "Нужно четверо..."

translate russian ch20_main2_2b9a1be6:
    m "А я очень-очень стараюсь найти новых участников."

translate russian ch20_main2_9e1492ef:
    m "И если мы не найдём ещё одного до фестиваля..."

translate russian ch20_main2_2b35b6fe_1:
    mc "..."

translate russian ch20_main2_966cc463:
    "Я... я беззащитен перед этими девушками."

translate russian ch20_main2_d4da3079:
    "Как тут вообще можно принять взвешенное решение?"

translate russian ch20_main2_ce9e8607:
    "Мне было бы ужасно стыдно подвести их всех в такой ситуации..."

translate russian ch20_main2_03c36b6c:
    "К тому же сам клуб, кажется, довольно расслабленный..."

translate russian ch20_main2_b8826b43:
    "Так что если писать стихи — это цена, которую придётся заплатить, чтобы каждый день проводить с этими красавицами..."

translate russian ch20_main2_36037676:
    mc "...Ладно."

translate russian ch20_main2_ee38c6e2:
    mc "Хорошо, тогда я решил."

translate russian ch20_main2_bfead9f9:
    mc "Я вступаю в Литературный клуб."

translate russian ch20_main2_4423eaff:
    "Глаза девушек одна за другой загораются."

translate russian ch20_main2_2833368d:
    m "Боже мой, правда?"

translate russian ch20_main2_4967ad00:
    m "Ты правда так думаешь, [player]?"

translate russian ch20_main2_69c25b65:
    mc "Да..."

translate russian ch20_main2_32db0986:
    mc "Может быть весело, правда?"

translate russian ch20_main2_792dfef8:
    y 1m "Ты меня и правда на миг напугал..."

translate russian ch20_main2_0cada34f:
    n 5q "Ну, если бы ты после всего этого просто взял и ушёл, я бы ужасно разозлилась."

translate russian ch20_main2_28ffefdc:
    m "[player], я так рада..."

translate russian ch20_main2_ef0e1a2a:
    m 1k "Теперь мы можем стать официальным клубом!"

translate russian ch20_main2_f0a88022:
    m 1e "Огромное тебе спасибо. Ты просто потрясающий."

translate russian ch20_main2_33324090:
    m "Я сделаю всё, чтобы тебе здесь было здорово, хорошо?"

translate russian ch20_main2_fc5c3668:
    mc "А... ну, спасибо, наверное."

translate russian ch20_main2_e719ebca:
    m 3b "Итак, ребята!"

translate russian ch20_main2_94ecc185:
    m "Думаю, на этом можно официально закончить сегодняшнее собрание на хорошей ноте."

translate russian ch20_main2_435b8f44:
    m "Все помните сегодняшнее задание:"

translate russian ch20_main2_f3222edc:
    m "Напишите к следующему собранию стихотворение, чтобы мы все могли ими поделиться!"

translate russian ch20_main2_f7602550:
    "Моника снова смотрит на меня."

translate russian ch20_main2_7c3950aa:
    m 1a "[player], мне не терпится увидеть, как ты себя выразишь."

translate russian ch20_main2_45d9cd96:
    m "Э-хе-хе~"

translate russian ch20_main2_5aa72ccd:
    mc "Д-да..."

translate russian ch20_main2_c5a873f7:
    "Неужели я правда смогу впечатлить Монику, звезду класса, своими посредственными писательскими способностями?"

translate russian ch20_main2_6944e055:
    "Внутри уже нарастает тревога."

translate russian ch20_main2_00553df6:
    "Тем временем девушки продолжают болтать, а Юри убирает чайный сервиз."

translate russian ch20_main2_19cf7098:
    mc "Ну, тогда я, пожалуй, пойду..."

translate russian ch20_main2_e74385d7:
    m "Так!"

translate russian ch20_main2_120cd030:
    m "Тогда увидимся завтра."

translate russian ch20_main2_d9382816:
    m "Жду не дождусь!"

translate russian ch20_main2_6afc1118:
    "На этом я покидаю клубную комнату и направляюсь домой."

translate russian ch20_main2_922e4616:
    "Всю дорогу мои мысли то и дело возвращаются к трём девушкам:"

translate russian ch20_main2_fa99dc55:
    "Нацуки,"

translate russian ch20_main2_f8ee4cf6:
    "Юри"

translate russian ch20_main2_b3c6e50b:
    "и, конечно же, Моника."

translate russian ch20_main2_3ec099e1:
    "Буду ли я и правда счастлив, проводя каждый день после уроков в литературном клубе?"

translate russian ch20_main2_2b5dfb83:
    "Может, мне выпадет шанс сблизиться с одной из этих девушек..."

translate russian ch20_main2_16cd82b1:
    "Решено!"

translate russian ch20_main2_b0188844:
    "Нужно просто извлечь максимум из того, что есть, и удача обязательно мне улыбнётся."

translate russian ch20_main2_dff2799d:
    "А начинается это, видимо, с того, что сегодня вечером я напишу стихотворение..."
