# Русский перевод: script-ch1

translate russian ch1_main_0f077782:
    m "Снова привет, [player]!"

translate russian ch1_main_95ea4bac:
    m "Рада видеть, что ты от нас не сбежал. Ха-ха-ха!"

translate russian ch1_main_ecaf5654:
    mc "Не-а, не волнуйся."

translate russian ch1_main_a0e98f5a:
    mc "Пусть мне тут немного непривычно, но своё слово я держу."

translate russian ch1_main_5bff8fb6:
    "Что ж, я снова в Литературном клубе."

translate russian ch1_main_0565e928:
    "Я пришёл последним, так что все остальные уже вовсю общаются."

translate russian ch1_main_209577b0:
    y "Спасибо, что сдержал обещание, [player]."

translate russian ch1_main_fc35d1a5:
    y "Надеюсь, это не слишком тяжёлое для тебя обязательство."

translate russian ch1_main_0b033aa0:
    y 1u "Заставлять тебя с головой нырять в литературу, когда ты к ней не привык..."

translate russian ch1_main_4bc8df14:
    n "Ой, да брось! Можно подумать, ему нужны поблажки."

translate russian ch1_main_54887548:
    n "Сайори сказала мне, что ты вообще не хотел вступать ни в какие клубы в этом году."

translate russian ch1_main_0e4e14ce:
    n "И в прошлом тоже!"

translate russian ch1_main_131e8e4b:
    n 4c "Не знаю, собираешься ты сюда просто приходить потусоваться или что..."

translate russian ch1_main_8ef8abd3:
    n "Но если не будешь воспринимать нас всерьёз, тебе это ещё долго будут припоминать."

translate russian ch1_main_e8cad960:
    m "Нацуки, для человека, который хранит в клубной комнате свою коллекцию манги, ты слишком много болтаешь."

translate russian ch1_main_28526ae4:
    n 4o "М-М-М...!!"

translate russian ch1_main_6ff88347:
    "Нацуки застревает где-то между «Моника» и «Манга»."

translate russian ch1_main_8e1ee84b:
    n 1v "Манга — это литература!!"

translate russian ch1_main_036357ba:
    "Мгновенно поверженная, Нацуки плюхается обратно на стул."

translate russian ch1_main_a84b9413:
    s "Не волнуйтесь, девочки~"

translate russian ch1_main_d7cf9956:
    s "[player] всегда старается изо всех сил, если ему весело."

translate russian ch1_main_f466355f:
    s "Он помогает мне со всякими делами, даже когда я не прошу."

translate russian ch1_main_13c9b95d:
    s "Например, готовит, убирается у меня в комнате..."

translate russian ch1_main_6c9290b7:
    y 2m "Какой надёжный..."

translate russian ch1_main_01768f1a:
    mc "Сайори, это потому, что у тебя в комнате такой бардак, что глаза разбегаются."

translate russian ch1_main_f03a36de:
    mc "А ещё однажды ты чуть не подожгла дом."

translate russian ch1_main_46619abb:
    s 5 "Правда?.. Э-хе-хе..."

translate russian ch1_main_e3d60137:
    y 1s "Вы двое и правда хорошие друзья, да?"

translate russian ch1_main_5150f59d:
    y "Я, пожалуй, даже немного завидую..."

translate russian ch1_main_b7fd516c:
    s 1 "Почему? Ты и [player] тоже можете стать хорошими друзьями!"

translate russian ch1_main_6897629e:
    y 4b "Э-э..."

translate russian ch1_main_7b7e4806:
    mc "С-Сайори—"

translate russian ch1_main_cb503a81:
    s "Хм-м?"

translate russian ch1_main_2b35b6fe:
    mc "..."

translate russian ch1_main_ba3de90d:
    "Сайори, как обычно, не замечает, в какое неловкое положение меня поставила."

translate russian ch1_main_f55ccd4d:
    s 4x "Ой, ой! Знаешь, Юри сегодня даже кое-что тебе принесла~"

translate russian ch1_main_ea01e1e9:
    y 3n "П-подожди! Сайори..."

translate russian ch1_main_5f167be7:
    mc "А? Мне?"

translate russian ch1_main_919bbc2a:
    y 3o "Э-э... Не совсем..."

translate russian ch1_main_828bb88b:
    s 4r "Не стесняйся~"

translate russian ch1_main_05eb3e49:
    y "Да это сущие пустяки..."

translate russian ch1_main_def0ad19:
    mc "А что там?"

translate russian ch1_main_637268ae:
    y 4c "Н-ничего!"

translate russian ch1_main_cb7eb154:
    y "Сайори всё так подала, будто это что-то важное, а это совсем не так..."

translate russian ch1_main_d9e54b67:
    y "У-у-у, что же мне делать..."

translate russian ch1_main_2224ad48:
    s 1g "А? Прости, Юри, я не подумала..."

translate russian ch1_main_9ff3c337:
    "Видимо, спасать положение придётся мне..."

translate russian ch1_main_6f06b205:
    mc "Эй, не переживай."

translate russian ch1_main_04495733:
    mc "Во-первых, я вообще ничего не ждал."

translate russian ch1_main_c8eaf1f5:
    mc "Так что любой приятный жест с твоей стороны — это приятный сюрприз."

translate russian ch1_main_22fbe112:
    mc "Мне будет приятно в любом случае."

translate russian ch1_main_a1560f15:
    y 3v "П-правда..."

translate russian ch1_main_d86fe35f:
    mc "Ага. Я не буду делать из этого событие, раз ты не хочешь."

translate russian ch1_main_6e92cc87:
    y "Хорошо..."

translate russian ch1_main_f4383968:
    y 1a "Вот, держи."

translate russian ch1_main_5c6d9095:
    "Юри лезет в сумку и достаёт книгу."

translate russian ch1_main_394a6121:
    y "Я не хотела, чтобы ты чувствовал себя лишним..."

translate russian ch1_main_1879c00c:
    y "Поэтому выбрала книгу, которая, как мне показалось, может тебе понравиться."

translate russian ch1_main_c76bcbd9:
    y "Она короткая, так что не успеет наскучить, даже если ты обычно не читаешь."

translate russian ch1_main_1c1fa68f:
    y "И мы могли бы, ну..."

translate russian ch1_main_262616a0:
    y 4b "Обсудить её... если захочешь..."

translate russian ch1_main_257a5a4c:
    "Э-это же..."

translate russian ch1_main_dbd79240:
    "Как у этой девушки получается быть такой милой, даже не стараясь?"

translate russian ch1_main_067cb0c1:
    "Она даже выбрала книгу, которая, по её мнению, мне понравится, хотя я почти не читаю..."

translate russian ch1_main_063782d3:
    mc "Юри, спасибо! Обязательно прочитаю!"

translate russian ch1_main_a0d526be:
    "Я с воодушевлением беру книгу."

translate russian ch1_main_f6554ff6:
    y "Фух..."

translate russian ch1_main_3b5e8d6c:
    y 2a "Ну, читай в своём темпе."

translate russian ch1_main_17c99d12:
    y "С нетерпением жду, что ты о ней скажешь."

translate russian ch1_main_5d35cc1a:
    "Я ожидал, что теперь, когда все собрались, Моника начнёт какие-нибудь запланированные занятия."

translate russian ch1_main_be0f213d:
    "Но, похоже, ничего такого не предвидится."

translate russian ch1_main_f081c8d6:
    "Сайори с Моникой весело болтают в углу."

translate russian ch1_main_301982d1:
    "Юри уже уткнулась в книгу."

translate russian ch1_main_b18fd321:
    "Я не могу не заметить её сосредоточенное лицо — будто она только и ждала этого момента."

translate russian ch1_main_6713a333:
    "А Нацуки тем временем копается в шкафу."

translate russian ch1_main_25d7e7ce:
    m "Кстати, ты не забыл написать вчера стихотворение?"

translate russian ch1_main_5aa72ccd:
    mc "Д-да..."

translate russian ch1_main_b8d87d90:
    "Моя расслабленность улетучивается."

translate russian ch1_main_070e9df2:
    "Поверить не могу, что согласился на такую неловкую затею."

translate russian ch1_main_0b915520:
    "Вдохновения особо не нашлось — я ведь никогда раньше этим не занимался."

translate russian ch1_main_96a5a5c4:
    m "Ну что, раз все готовы, почему бы тебе не найти, с кем поделиться?"

translate russian ch1_main_ebf4c7a9:
    s "Мне уже не терпится~!"

translate russian ch1_main_65e6fcbd:
    "Сайори и Моника с энтузиазмом достают свои стихи."

translate russian ch1_main_b87d3078:
    "Сайори написала своё на мятом листке, вырванном из тетрадки на пружине."

translate russian ch1_main_ccd4f660:
    "А вот Моника записала своё в аккуратную тетрадь."

translate russian ch1_main_a3b175bf:
    "Даже отсюда видно безупречный почерк Моники."

translate russian ch1_main_7354e005:
    "Нацуки и Юри нехотя следуют их примеру и лезут в сумки."

translate russian ch1_main_5bc5f049:
    "Я делаю то же самое."

translate russian ch1_end_d91458f0:
    mc "Фух..."

translate russian ch1_end_1782371d:
    "Кажется, это все."

translate russian ch1_end_58e4d71b:
    "Я оглядываю комнату."

translate russian ch1_end_21f37dea:
    "Это оказалось чуть напряжённее, чем я рассчитывал."

translate russian ch1_end_5b12ad4c:
    "Такое чувство, будто все судят меня за мои посредственные писательские способности..."

translate russian ch1_end_72e6b5de:
    "Даже если они просто вежливы, мои стихи никак не могут тягаться с их стихами."

translate russian ch1_end_3e6d2aa1:
    "Это всё-таки литературный клуб."

translate russian ch1_end_3f739ce1:
    "Я вздыхаю."

translate russian ch1_end_e55af38e:
    "Видимо, вот во что я ввязался."

translate russian ch1_end_21c3ee10:
    "В другом конце комнаты весело болтают Сайори и Моника."

translate russian ch1_end_841184ee:
    "Мой взгляд падает на Юри и Нацуки."

translate russian ch1_end_1705c9fe:
    "Они осторожно обмениваются листками и показывают друг другу свои стихи."

translate russian ch1_end_37b74d39:
    "Пока они читают, я наблюдаю, как меняются их лица."

translate russian ch1_end_f3def454:
    "Нацуки раздражённо хмурит брови."

translate russian ch1_end_1583e001:
    "А Юри грустно улыбается."

translate russian ch1_end_36ce7fb5:
    n 1q "{i}(Что это вообще за язык такой...?){/i}"

translate russian ch1_end_5f1028e8:
    y 2f "А?"

translate russian ch1_end_392e3f64:
    y "Э-э... ты что-то сказала?"

translate russian ch1_end_5a23a338:
    n 2c "А, ничего."

translate russian ch1_end_73b87d84:
    "Нацуки небрежно, одной рукой, кладёт стихотворение обратно на парту."

translate russian ch1_end_678d666c:
    n "Ну, можно сказать, что оно вычурное."

translate russian ch1_end_ee8faee5:
    y 2i "А— Спасибо..."

translate russian ch1_end_1705b12d:
    y "А твоё... милое..."

translate russian ch1_end_d53cb64f:
    n 2h "Милое?"

translate russian ch1_end_d7a2229c:
    n 1h "Ты что, совсем не поняла символизм?"

translate russian ch1_end_a5b7430f:
    n "Оно же явно о чувстве, когда сдаёшься."

translate russian ch1_end_0db745ab:
    n "Что тут может быть милого?"

translate russian ch1_end_d42c351b:
    y 3f "Я-я это поняла!"

translate russian ch1_end_b698ba3b:
    y "Я просто имела в виду..."

translate russian ch1_end_2c3a3a03:
    y 3h "Язык, наверное..."

translate russian ch1_end_678374ea:
    y "Я пыталась сказать что-то приятное..."

translate russian ch1_end_5adabccb:
    n "А?"

translate russian ch1_end_b10ead8d:
    n 4w "То есть тебе пришлось так стараться, чтобы найти, что бы такого приятного сказать?"

translate russian ch1_end_f9cdd784:
    n "Спасибо, но приятным это совсем не прозвучало!"

translate russian ch1_end_64c0a3eb:
    y 1i "Э-э..."

translate russian ch1_end_15db327d:
    y "Ну, у меня есть пара предложений..."

translate russian ch1_end_ebd6a743:
    n 5x "Хмф."

translate russian ch1_end_a87c36dd:
    n "Если бы мне нужны были предложения, я бы спросила того, кому оно правда понравилось."

translate russian ch1_end_4466dbb0:
    n "А такие, между прочим, {i}были{/i}."

translate russian ch1_end_9a6ca7e3:
    n 5e "Сайори понравилось."

translate russian ch1_end_0ea3372f:
    n "И [player] тоже оценил!"

translate russian ch1_end_3afcd245:
    n "Так что, исходя из этого, я с радостью дам тебе пару советов от себя."

translate russian ch1_end_4fda8f5a:
    n "Во-первых—"

translate russian ch1_end_0b794b70:
    y 2l "Прошу прощения..."

translate russian ch1_end_166ab7be:
    y "Я ценю твоё предложение, но я очень долго вырабатывала свой стиль."

translate russian ch1_end_0d2b663b:
    y 2h "И не думаю, что он изменится в ближайшее время, разве что мне попадётся что-то особенно вдохновляющее."

translate russian ch1_end_7cad6bf8:
    y "А такого пока не было."

translate russian ch1_end_8487fc0c:
    n 1o "Н-н...!"

translate russian ch1_end_f72b1c71:
    y 1k "Между прочим, [player] тоже оценил моё стихотворение."

translate russian ch1_end_75dd3224:
    y "Он даже сказал, что оно его впечатлило."

translate russian ch1_end_a5061963:
    "Нацуки вдруг вскакивает."

translate russian ch1_end_2824bf93:
    n 4y "Да ну?"

translate russian ch1_end_693f0dc5:
    n "Я и не знала, что ты так стараешься впечатлить нашего нового участника, Юри."

translate russian ch1_end_b63049e5:
    y 1n "Ч-что?!"

translate russian ch1_end_3df614f2:
    y "Я совсем не это...!"

translate russian ch1_end_803d0e3c:
    y 1o "У-у..."

translate russian ch1_end_acc94b27:
    y "Ты... Ты просто..."

translate russian ch1_end_6a5c0c7b:
    "Юри тоже встаёт."

translate russian ch1_end_fb24704f:
    y 2r "Может, ты просто завидуешь, что [player] оценил мои советы больше, чем твои!"

translate russian ch1_end_ee52e8e3:
    n 1e "Ха! А откуда ты знаешь, что он не оценил {i}мои{/i} советы больше?"

translate russian ch1_end_6d2144a0:
    n "Ты настолько высокого мнения о себе?"

translate russian ch1_end_c1eb1e36:
    y 3h "Я...!"

translate russian ch1_end_bfadd2bc:
    y "Нет..."

translate russian ch1_end_8d1dcf35:
    y "Если бы я была высокого мнения о себе..."

translate russian ch1_end_5e4e458d:
    y 1r "...я бы из кожи вон лезла, чтобы всё, что я делаю, было приторно-милым!"

translate russian ch1_end_ccdb66db:
    n 1o "У-у-у-у-у...!"

translate russian ch1_end_7e82068e:
    s "Э-э-эй!!"

translate russian ch1_end_983f9fbc:
    s "Вы обе в порядке...?"

translate russian ch1_end_f982a2f8:
    n 1f "Ну, знаешь что?!"

translate russian ch1_end_09b7047e:
    n "Это не у меня грудь волшебным образом выросла на размер, как только тут начал появляться [player]!!"

translate russian ch1_end_9b07aefd:
    y "Н-Нацуки!!"

translate russian ch1_end_d6f8c030:
    m "Э-э, Нацуки, это уже немного—"

translate russian ch1_end_6f0acf5a:
    ny "Тебя это не касается!"

translate russian ch1_end_13234d47:
    s "Я-я не люблю, когда ссорятся...!"

translate russian ch1_end_92bd4b5a:
    "Вдруг обе девушки поворачиваются ко мне, будто только сейчас заметили, что я стою рядом."

translate russian ch1_end_1e4f93b8:
    y 2n "[player]...!"

translate russian ch1_end_470c0d03:
    y "Она... Она просто хочет выставить меня в дурном свете...!"

translate russian ch1_end_c5e00378:
    n 4w "Неправда!"

translate russian ch1_end_0c50491a:
    n "Она первая начала!"

translate russian ch1_end_7081a731:
    n 4e "Если бы она перестала задирать нос и поняла, что {i}простые{/i} тексты действуют сильнее..."

translate russian ch1_end_38ebaf85:
    n "То ничего бы этого вообще не случилось!"

translate russian ch1_end_927de68a:
    n "Какой смысл запутывать свои стихи без всякой причины?"

translate russian ch1_end_ce57fb32:
    n "Смысл должен сам бросаться в глаза, а не заставлять читателя ломать голову."

translate russian ch1_end_0cc9b929:
    n 1f "Помоги мне ей это объяснить, [player]!"

translate russian ch1_end_b182fab9:
    y 3o "П-подожди!"

translate russian ch1_end_871a6f95:
    y "В нашем языке так много глубоких и выразительных слов не просто так!"

translate russian ch1_end_31c575da:
    y 3w "Только так можно по-настоящему точно передать сложные чувства и смысл."

translate russian ch1_end_fb49746f:
    y "Избегая их, ты не просто зря себя ограничиваешь... это ещё и расточительство!"

translate russian ch1_end_1d6207cf:
    y 1t "Ты ведь это понимаешь, правда, [player]?"

translate russian ch1_end_949bf05b:
    mc "Э-э...!"

translate russian ch1_end_7d732439:
    ny "Ну??"

translate russian ch1_end_2b35b6fe:
    mc "..."

translate russian ch1_end_7bcc12ff:
    "И как меня вообще в это втянули?!"

translate russian ch1_end_92ecde6c:
    "Я же ничего не смыслю в писательстве..."

translate russian ch1_end_a01de81d:
    "Но с кем бы я ни согласился, она наверняка станет думать обо мне лучше!"

translate russian ch1_end_90de9c4d:
    m "Итак, ребята!"

translate russian ch1_end_a0d65f57:
    m "Нам почти пора расходиться."

translate russian ch1_end_85aa30cf:
    m "Как вам понравилось делиться стихами?"

translate russian ch1_end_e548ca2d:
    s "Было очень весело!"

translate russian ch1_end_71f4c90a:
    y "Что ж, я бы сказала, оно того стоило."

translate russian ch1_end_5a3f1947:
    n "Нормально. Ну, в основном."

translate russian ch1_end_4e8e7a24:
    m 1a "[player], а тебе?"

translate russian ch1_end_ee94d4f4:
    mc "...Да, я бы сказал так же."

translate russian ch1_end_ac5036c4:
    mc "Было интересно это со всеми обсудить."

translate russian ch1_end_1bd97473:
    m 1j "Здорово!"

translate russian ch1_end_0c347b60:
    m 1a "Тогда завтра сделаем то же самое."

translate russian ch1_end_255c071e:
    m "И, может быть, ты чему-то научился у своих друзей."

translate russian ch1_end_f826e16b:
    m 3b "Так что твои стихи получатся ещё лучше!"

translate russian ch1_end_2b35b6fe_1:
    mc "..."

translate russian ch1_end_30393e48:
    "Я задумываюсь."

translate russian ch1_end_fa51c8c1:
    "Я и правда немного лучше узнал, какие стихи кому нравятся."

translate russian ch1_end_653fb55d:
    "Если повезёт, мне будет проще впечатлить тех, кого я хочу впечатлить."

translate russian ch1_end_ef583e4f:
    "Я киваю сам себе с новой решимостью."

translate russian ch1_end_62e85122:
    s "[player]!"

translate russian ch1_end_7f035113:
    s "Идём домой?"

translate russian ch1_end_13c4b998:
    mc "Конечно, пошли."

translate russian ch1_end_e688cc67:
    s 4q "Э-хе-хе~"

translate russian ch1_end_8301dff6:
    "Сайори сияет."

translate russian ch1_end_4020474b:
    "Мы с Сайори и правда давно не проводили вместе столько времени."

translate russian ch1_end_d2aad54c:
    "И не могу сказать, что мне это не нравится."

translate russian ch1_end_e87e0575:
    mc "Сайори..."

translate russian ch1_end_00d40828:
    mc "Насчёт того, что было сегодня..."

translate russian ch1_end_cebd3143:
    s 1b "А? Ты о чём?"

translate russian ch1_end_ab70957b:
    mc "Ну, между Юри и Нацуки."

translate russian ch1_end_83a291bc:
    mc "Такое часто случается?"

translate russian ch1_end_5b6266e8:
    s 4j "Нет-нет-нет!"

translate russian ch1_end_51e2edaa:
    s "Я правда в первый раз вижу, чтобы они так ссорились..."

translate russian ch1_end_e7e072a2:
    s "Честное слово, они обе замечательные."

translate russian ch1_end_972589c7:
    s 1g "Ты ведь... Ты ведь их не возненавидел??"

translate russian ch1_end_5130e1ef:
    mc "Нет, конечно, не возненавидел!"

translate russian ch1_end_f4dff198:
    mc "Мне просто было интересно твоё мнение, вот и всё."

translate russian ch1_end_08ee0a33:
    mc "Понимаю, почему вы с ними подружились."

translate russian ch1_end_4b14d678:
    s 1d "Фух..."

translate russian ch1_end_4e43dbcd:
    s "Знаешь, [player]..."

translate russian ch1_end_db975472:
    s "Мне очень нравится проводить с тобой время в клубе."

translate russian ch1_end_38b701db:
    s "Но, кажется, больше всего меня радует, что ты со всеми ладишь."

translate russian ch1_end_158077ca:
    s 1x "И, по-моему, ты тоже всем очень нравишься!"

translate russian ch1_end_783953b3:
    mc "Это—!"

translate russian ch1_end_e688cc67_1:
    s 4q "Э-хе-хе~"

translate russian ch1_end_c91bd0a4:
    s "Каждый день будет таким весёлым~"

translate russian ch1_end_0a69f768:
    mc "Эх..."

translate russian ch1_end_9266189c:
    "Похоже, Сайори так и не поняла, в каком я положении."

translate russian ch1_end_b7681491:
    "Конечно, дружить со всеми здорово, но..."

translate russian ch1_end_f9856566:
    "...Обязательно ли на этом останавливаться?"

translate russian ch1_end_541bf745:
    mc "Поживём — увидим, Сайори."

translate russian ch1_end_87c0a22e:
    "Я хлопаю Сайори по плечу."

translate russian ch1_end_59c79ef1:
    "Это я сказал скорее себе, чем ей, но иногда очень удобно использовать Сайори как внутренний монолог."

translate russian ch1_end_0e972831:
    s 1x "Ага~!"

translate russian ch1_end_4914da37:
    "Да..."

translate russian ch1_end_74c5fcd0:
    "Вперёд!"

translate russian ch1_end_natsuki_6b0ed824:
    mc "Э-э..."

translate russian ch1_end_natsuki_530f484c:
    mc "Юри!"

translate russian ch1_end_natsuki_2948d978:
    mc "Ты по-настоящему талантлива."

translate russian ch1_end_natsuki_cef5cdd2:
    y "А? Н-ну..."

translate russian ch1_end_natsuki_22a83972:
    mc "Но Нацуки в чём-то права!"

translate russian ch1_end_natsuki_238ab007:
    mc "Мне кажется..."

translate russian ch1_end_natsuki_3f4021d6:
    "Я ломаю голову, пытаясь подкрепить свои слова."

translate russian ch1_end_natsuki_3b9ffb4a:
    mc "Мне кажется, что передавать чувства немногими словами..."

translate russian ch1_end_natsuki_c2d4bea8:
    mc "Может быть не менее впечатляюще!"

translate russian ch1_end_natsuki_49009af5:
    mc "Это даёт волю воображению читателя."

translate russian ch1_end_natsuki_ea8608a3:
    mc "И у стихотворения Нацуки это отлично получилось!"

translate russian ch1_end_natsuki_86a8805e:
    n 5y "...Вот!!"

translate russian ch1_end_natsuki_02741fe7:
    n "Получилось ведь, правда?!"

translate russian ch1_end_natsuki_92b8c94a:
    n "Ага!"

translate russian ch1_end_natsuki_73e7cb3c:
    n "Много {i}ты{/i} понимаешь!"

translate russian ch1_end_natsuki_51b927a8:
    y 4b "Э-это не..."

translate russian ch1_end_natsuki_3aa42c3b:
    mc "Нацуки..."

translate russian ch1_end_natsuki_d7abd363:
    mc "По-моему, хватит."

translate russian ch1_end_natsuki_afccc67b:
    n 1m "А?"

translate russian ch1_end_natsuki_d355ffe4:
    n "Мне?"

translate russian ch1_end_natsuki_94f204ed:
    n "Но она так грубо со мной обошлась...!"

translate russian ch1_end_natsuki_63711e82:
    "Нацуки начинает хныкать."

translate russian ch1_end_natsuki_ff0f1aa3:
    mc "Послушай..."

translate russian ch1_end_natsuki_0b4a4df1:
    mc "То, о чём мы говорили вчера, — правда."

translate russian ch1_end_natsuki_0211a0f3:
    mc "Писательство — очень личное дело."

translate russian ch1_end_natsuki_0a897eb2:
    mc "И делиться им бывает по-настоящему трудно."

translate russian ch1_end_natsuki_cd66aa89:
    mc "Похоже, сегодня мы в этом убедились."

translate russian ch1_end_natsuki_fe651b95:
    mc "Даже небольшая критика может обернуться жаркой ссорой."

translate russian ch1_end_natsuki_3cb79211:
    "Я оглядываюсь через плечо."

translate russian ch1_end_natsuki_b4126f31:
    "Сайори энергично кивает."

translate russian ch1_end_natsuki_3f908872:
    mc "Да, так что..."

translate russian ch1_end_natsuki_f07274fb:
    mc "Тебе не нужно защищаться."

translate russian ch1_end_natsuki_1413b0f7:
    mc "Ты отлично пишешь, Нацуки."

translate russian ch1_end_natsuki_e41fc448:
    n 1h "А—"

translate russian ch1_end_natsuki_bd7f6044:
    "От удивления у Нацуки перехватывает голос."

translate russian ch1_end_natsuki_b08cfab5:
    n 1q "...Спасибо, что заметил."

translate russian ch1_end_natsuki_1cc2aa55:
    "Наконец она бормочет это еле слышно."

translate russian ch1_end_natsuki_d90390e4:
    mc "Юри..."

translate russian ch1_end_natsuki_f9e2ab2a:
    y 4a "...?"

translate russian ch1_end_natsuki_2da93ee0:
    "Юри смотрит на меня с унылым видом."

translate russian ch1_end_natsuki_e68e7bea:
    "С таким лицом мне и её становится жалко."

translate russian ch1_end_natsuki_08fd3e10:
    mc "Уверен, Нацуки не всерьёз говорила всё это."

translate russian ch1_end_natsuki_43de7911:
    mc "Так что и тебе не нужно защищаться."

translate russian ch1_end_natsuki_de41a4f9:
    y 2v "Ну..."

translate russian ch1_end_natsuki_aae9fe8e:
    y "Раз ты так говоришь..."

translate russian ch1_end_natsuki_adc03d3c:
    n 1g "Эй...!"

translate russian ch1_end_natsuki_4ddde058:
    n "Не надо извиняться {i}за{/i} меня, [player]."

translate russian ch1_end_natsuki_6fecb12a:
    n 1w "Вот ещё."

translate russian ch1_end_natsuki_700fd121:
    "Нацуки набирает в грудь воздуха."

translate russian ch1_end_natsuki_5337a10e:
    n 1q "Я..."

translate russian ch1_end_natsuki_40e7592e:
    n "Насчёт того, что..."

translate russian ch1_end_natsuki_e349a681:
    n "У-у..."

translate russian ch1_end_natsuki_318a845f:
    "Нацуки оглядывает комнату."

translate russian ch1_end_natsuki_d82c3958:
    n 1x "{i}Может, хватит на меня пялиться??{/i}"

translate russian ch1_end_natsuki_4d4ce7e2:
    "Ничего удивительного: Нацуки даётся это куда тяжелее, чем она хвасталась."

translate russian ch1_end_natsuki_36414005:
    "Сайори и Моника отводят взгляды."

translate russian ch1_end_natsuki_45914793:
    n 1i "Хмф."

translate russian ch1_end_natsuki_99ec11cf:
    n "В общем...!"

translate russian ch1_end_natsuki_21071d4a:
    n 1q "Насчёт твоей груди. Я не всерьёз, ясно?"

translate russian ch1_end_natsuki_726a8413:
    n "Вот и всё."

translate russian ch1_end_natsuki_91b851bb:
    "Нацуки отворачивается, стараясь ни с кем не встречаться взглядом."

translate russian ch1_end_natsuki_29c61c30:
    s "Точно! Ты красавица от природы, Юри!!"

translate russian ch1_end_natsuki_04b993cf:
    mc "Сайори?!"

translate russian ch1_end_natsuki_71a86863:
    y "..."

translate russian ch1_end_natsuki_1b5f1f04:
    y "П-пойду заварю чаю..."

translate russian ch1_end_natsuki_a0361679:
    s 4h "Э-э?"

translate russian ch1_end_natsuki_ebd4f509:
    s "Я же просто хотела помочь!"

translate russian ch1_end_natsuki_9f7b6d8e:
    mc "Уверен, она это оценила, Сайори."

translate russian ch1_end_natsuki_87c0a22e:
    "Я хлопаю Сайори по плечу."

translate russian ch1_end_natsuki_0a668bd6:
    m "Что ж, раз с этим разобрались..."

translate russian ch1_end_natsuki_09bd72e2:
    m 4b "Все ведь прочитали стихи друг друга, да?"

translate russian ch1_end_natsuki_bef0b23b:
    m "Надеюсь, это было полезно для всех!"

translate russian ch1_end_natsuki_63e99776:
    m 5 "Особенно для тебя, [player]!"

translate russian ch1_end_natsuki_f262d45c:
    m "И, если честно..."

translate russian ch1_end_natsuki_b35f094a:
    m "Это приятная перемена после безделья, к которому мы слишком уж привыкли."

translate russian ch1_end_natsuki_0be65a41:
    m "А-ха-ха-ха!"

translate russian ch1_end_natsuki_486594ac:
    mc "А, так это моё вступление в клуб испортило всю атмосферу..."

translate russian ch1_end_natsuki_9f47eaa8:
    m 1d "Нет, что ты, что ты!"

translate russian ch1_end_natsuki_c0eea162:
    m "До ухода домой ещё есть время."

translate russian ch1_end_natsuki_434768a2:
    m 1a "Так что давайте немного отдохнём."

translate russian ch1_end_natsuki_17703def:
    m "Конечно, кроме болтовни мы в клубе занимаемся и литературой..."

translate russian ch1_end_natsuki_71c5632c:
    m "Так что, может, ты воспользуешься случаем и возьмёшь книгу или что-нибудь напишешь."

translate russian ch1_end_natsuki_9c2e4773:
    m 1b "В конце концов, для этого клуб и существует!"

translate russian ch1_end_natsuki_6ec4e41b:
    s "Я не согласна, Моника!"

translate russian ch1_end_natsuki_4dea9d63:
    m 1d "А? С чем?"

translate russian ch1_end_natsuki_80d3e081:
    s 2i "Это не самое главное в литературном клубе!"

translate russian ch1_end_natsuki_3b646d1d:
    s "Самое главное..."

translate russian ch1_end_natsuki_528afc18:
    s "Это веселиться!"

translate russian ch1_end_natsuki_48b2a88f:
    m 2l "А-ха-ха, ну конечно..."

translate russian ch1_end_natsuki_e27c2b2d:
    m 2a "Что ж, наверное, поэтому вице-президент у нас ты, Сайори."

translate russian ch1_end_natsuki_5b525ad4:
    s 4q "Э-хе-хе..."

translate russian ch1_end_natsuki_80c6af4f:
    "Но в итоге Моника права."

translate russian ch1_end_natsuki_0e6c35d6:
    "Раз я в Литературном клубе, вряд ли получится всё время бездельничать."

translate russian ch1_end_natsuki_24e861c2:
    "Но в конце концов..."

translate russian ch1_end_natsuki_70780fb7:
    "...пока что оно, пожалуй, того стоило."

translate russian ch1_end_yuri_9659bc81:
    mc "Нацуки."

translate russian ch1_end_yuri_d81c8e78:
    mc "Ты права, мне понравилось твоё стихотворение."

translate russian ch1_end_yuri_2d9714a4:
    n 1e "Вот видишь??"

translate russian ch1_end_yuri_8b5e620a:
    mc "Подожди!"

translate russian ch1_end_yuri_edf31e07:
    mc "Это не повод так грубить!"

translate russian ch1_end_yuri_75b3fe90:
    mc "Нельзя затевать ссору только потому, что у кого-то другое мнение."

translate russian ch1_end_yuri_b56b2122:
    n 1m "Всё было совсем не так!"

translate russian ch1_end_yuri_31979c34:
    n "Юри даже не восприняла моё стихотворение всерьёз!"

translate russian ch1_end_yuri_48b99b4e:
    mc "М-м..."

translate russian ch1_end_yuri_83495ed0:
    mc "Понимаю."

translate russian ch1_end_yuri_1e4625b7:
    mc "Юри."

translate russian ch1_end_yuri_4729869b:
    y 2t "А?"

translate russian ch1_end_yuri_b2a3413d:
    mc "Ты по-настоящему талантливый автор."

translate russian ch1_end_yuri_afe77c34:
    mc "Ни для кого не секрет, что я был впечатлён."

translate russian ch1_end_yuri_ba5ada9a:
    y 2u "Н-ну, это..."

translate russian ch1_end_yuri_0045dfbc:
    mc "Но дело вот в чём."

translate russian ch1_end_yuri_6ba215bf:
    mc "Неважно, насколько простой или изысканный у человека стиль..."

translate russian ch1_end_yuri_d2525a4d:
    mc "Он всё равно вкладывает в текст чувства, и это становится чем-то очень личным."

translate russian ch1_end_yuri_8fcbadf1:
    mc "Вот почему Нацуки начала защищаться, когда ты назвала её стихотворение милым."

translate russian ch1_end_yuri_b150645d:
    y 2v "Я... понимаю..."

translate russian ch1_end_yuri_39b1ea43:
    y "Я и не заметила, что..."

translate russian ch1_end_yuri_5683b46a:
    y 2w "П-прости..."

translate russian ch1_end_yuri_9f719d9d:
    y "У-у-у..."

translate russian ch1_end_yuri_48c7e0a8:
    mc "Но, Нацуки, ты слишком перегнула палку!"

translate russian ch1_end_yuri_4e6d87c6:
    mc "Юри желала тебе добра, и если бы ты просто сказала ей, что чувствуешь..."

translate russian ch1_end_yuri_b0d9bf22:
    mc "То ничего бы этого вообще не случилось."

translate russian ch1_end_yuri_d5127d63:
    n 1e "Ты издеваешься?"

translate russian ch1_end_yuri_d9b46044:
    n "Я именно так и сделала!"

translate russian ch1_end_yuri_09d725af:
    n "Это {i}она{/i} начала—"

translate russian ch1_end_yuri_c6fe493e:
    m "Нацуки, по-моему, хватит."

translate russian ch1_end_yuri_399d2173:
    m "Вы обе наговорили лишнего."

translate russian ch1_end_yuri_05f0c03e:
    m "Юри извинилась. Тебе не кажется, что и тебе стоит?"

translate russian ch1_end_yuri_29595ec8:
    n 1x "Н-н-н...!"

translate russian ch1_end_yuri_20eeda7a:
    "Нацуки сжимает кулаки."

translate russian ch1_end_yuri_940dea9a:
    "В итоге на её сторону так никто и не встал."

translate russian ch1_end_yuri_7434a905:
    "Она загнана в угол и упрямится уже только потому, что не выдерживает давления."

translate russian ch1_end_yuri_c5360e5d:
    "Мне даже становится её жалко."

translate russian ch1_end_yuri_56e59f03:
    s "Э-э-эй!"

translate russian ch1_end_yuri_9e8a9d04:
    s "Иногда, когда мне обидно..."

translate russian ch1_end_yuri_b3751fb5:
    s "Мне помогает прогуляться и проветрить голову!"

translate russian ch1_end_yuri_84376b43:
    mc "Сайори, ей не нужно—"

translate russian ch1_end_yuri_60fe5771:
    n 2q "Знаешь что?"

translate russian ch1_end_yuri_6bdde6a4:
    n "Так я и сделаю."

translate russian ch1_end_yuri_93173112:
    n 2w "Хоть не придётся сейчас смотреть на ваши физиономии."

translate russian ch1_end_yuri_441f711c:
    "Без предупреждения Нацуки хватает со стола своё стихотворение и вылетает из комнаты."

translate russian ch1_end_yuri_7cf2345f:
    "По пути она комкает листок и швыряет его в мусорку."

translate russian ch1_end_yuri_e7a740d1:
    s 1k "Нацуки..."

translate russian ch1_end_yuri_7ba2c629:
    m 1r "Ну зачем же она так..."

translate russian ch1_end_yuri_73c0fb35:
    "Я смотрю в другой конец комнаты."

translate russian ch1_end_yuri_5ae422b9:
    "Юри сидит, уткнувшись подбородком в ладони, и смотрит в парту."

translate russian ch1_end_yuri_1b68bff2:
    "Я осторожно подхожу и сажусь на соседний стул."

translate russian ch1_end_yuri_ad226d63:
    y "Эх..."

translate russian ch1_end_yuri_f8c4c766:
    mc "Ты в порядке?"

translate russian ch1_end_yuri_85b7dd24:
    y "Мне так стыдно..."

translate russian ch1_end_yuri_ba8e7514:
    y "Не могу поверить, что так себя повела."

translate russian ch1_end_yuri_718a2f22:
    y "Ты, наверное, теперь меня ненавидишь..."

translate russian ch1_end_yuri_dcf6cb7d:
    mc "Нет — Юри!"

translate russian ch1_end_yuri_fa231374:
    mc "Да кто угодно бы вышел из себя, если бы с ним так обошлись!"

translate russian ch1_end_yuri_5e1844ee:
    mc "Ты справилась с этим лучше, чем справился бы кто угодно."

translate russian ch1_end_yuri_4ca7c420:
    mc "Я о тебе хуже думать не стал."

translate russian ch1_end_yuri_de41a4f9:
    y 2v "Ну..."

translate russian ch1_end_yuri_f5f2a22d:
    y "...Хорошо, я тебе верю."

translate russian ch1_end_yuri_79444b65:
    y 2s "Спасибо, [player]. Ты слишком добр."

translate russian ch1_end_yuri_38de4bb8:
    y "Я благодарна, что теперь ты с нами в клубе."

translate russian ch1_end_yuri_310f394c:
    mc "Э-э— Да не за что."

translate russian ch1_end_yuri_04235200:
    y 2v "И ещё кое-что..."

translate russian ch1_end_yuri_cee713e7:
    y "Э-э, то, что сказала Нацуки..."

translate russian ch1_end_yuri_e47d1cac:
    y 4c "Про... ну, ты понимаешь..."

translate russian ch1_end_yuri_667a6ce4:
    y "Я бы никогда не сделала ничего... настолько постыдного..."

translate russian ch1_end_yuri_87f9f194:
    y "Так что..."

translate russian ch1_end_yuri_26aa6c42:
    mc "...А?"

translate russian ch1_end_yuri_5b75b814:
    mc "А что такого сказала Нацуки?"

translate russian ch1_end_yuri_3bf2b8ba:
    y 3n "—!"

translate russian ch1_end_yuri_d782d4e1:
    y "Э-э-эй!"

translate russian ch1_end_yuri_92ab898a:
    y 3q "Н-ну, неважно..."

translate russian ch1_end_yuri_f2c4c677:
    y "Я-я пойду заварю чаю..."

translate russian ch1_end_yuri_49d0bbb5:
    mc "А, хорошая мысль."

translate russian ch1_end_yuri_e26add62:
    mc "Только завари больше, чем на одного, ладно?"

translate russian ch1_end_yuri_f0f5c095:
    y "Д-да."

translate russian ch1_end_sayori_86d1bc42:
    mc "Н-Нацуки..."

translate russian ch1_end_sayori_b65d9f5e:
    "Нацуки сверлит меня взглядом, и все слова застревают у меня в горле."

translate russian ch1_end_sayori_791e2b5d:
    "Тогда я поворачиваюсь к Юри."

translate russian ch1_end_sayori_d90390e4:
    mc "Юри..."

translate russian ch1_end_sayori_1588679c:
    y 4a "..."

translate russian ch1_end_sayori_4bfbf76f:
    "Но у Юри такое беззащитное лицо, что у меня язык не поворачивается ей что-то сказать."

translate russian ch1_end_sayori_2b35b6fe:
    mc "..."

translate russian ch1_end_sayori_5b165481:
    mc "...Сайори!"

translate russian ch1_end_sayori_acb5ef4d:
    s "А?!"

translate russian ch1_end_sayori_0eb6a980:
    mc "...Вот!"

translate russian ch1_end_sayori_7fd71ad4:
    mc "Из-за ваших ссор Сайори не по себе."

translate russian ch1_end_sayori_b4d080d8:
    mc "Как вы можете продолжать ругаться, когда видите, что из-за вас подруге так плохо?"

translate russian ch1_end_sayori_ef24e809:
    s 4d "[player]..."

translate russian ch1_end_sayori_a6b4c29f:
    n "Ну... Это её проблемы! Это её не касается."

translate russian ch1_end_sayori_eced5cbe:
    y "Я-я согласна..."

translate russian ch1_end_sayori_766ba12b:
    y "Нечестно, когда другие вмешивают свои чувства в наш конфликт."

translate russian ch1_end_sayori_2ed45361:
    n 4c "Ага, разве что Сайори хочет сказать Юри, какая та заносчивая зазнайка."

translate russian ch1_end_sayori_23912704:
    y "Она бы никогда...!"

translate russian ch1_end_sayori_52ec56bd:
    y "Это твоя незрелость её расстроила!"

translate russian ch1_end_sayori_42241b7e:
    n "{i}Прошу{/i} прощения?"

translate russian ch1_end_sayori_6479962c:
    n "Ты сама-то себя слышишь?"

translate russian ch1_end_sayori_1d2fa79b:
    n 1x "Вот именно поэтому..."

translate russian ch1_end_sayori_455f4a18:
    n 1w "Вот именно поэтому никто не любит—"

translate russian ch1_end_sayori_3adeb13a:
    s "{i}Хватит!!{/i}"

translate russian ch1_end_sayori_e653000f:
    ny "—"

translate russian ch1_end_sayori_6240666a:
    s 1h "Нацуки! Юри!"

translate russian ch1_end_sayori_38a648d2:
    s "Вы же мои подруги!"

translate russian ch1_end_sayori_76b4b721:
    s 1v "Я-я просто хочу, чтобы все ладили и были счастливы!"

translate russian ch1_end_sayori_0f177121:
    s "Мои подруги — замечательные люди..."

translate russian ch1_end_sayori_526b5d77:
    s "И я люблю их как раз за то, что они разные!"

translate russian ch1_end_sayori_686b868d:
    s 1g "Стихи Нацуки..."

translate russian ch1_end_sayori_1912e29b:
    s "Они потрясающие, потому что всего несколькими словами вызывают столько чувств!"

translate russian ch1_end_sayori_5e0af94b:
    s "А стихи Юри потрясающие, потому что рисуют в голове прекрасные картины!"

translate russian ch1_end_sayori_2ae6cad8:
    s 4k "Все такие талантливые..."

translate russian ch1_end_sayori_fb76c44c:
    s "...Так зачем же мы ссоримся...?"

translate russian ch1_end_sayori_c4672663:
    n 1r "П-потому что..."

translate russian ch1_end_sayori_ae7f22e8:
    y "Ну..."

translate russian ch1_end_sayori_238c7a6b:
    s 1j "И ещё!"

translate russian ch1_end_sayori_ddff02c9:
    s "Нацуки милая, и в этом нет ничего плохого!"

translate russian ch1_end_sayori_86bdd4d9:
    s 1i "А грудь у Юри такая же, как всегда!"

translate russian ch1_end_sayori_62779f02:
    s 1j "Большая и красивая!!"

translate russian ch1_end_sayori_2d032434:
    n 1o "..."

translate russian ch1_end_sayori_58a53015:
    y 3n "..."

translate russian ch1_end_sayori_e87e0575:
    mc "Сайори..."

translate russian ch1_end_sayori_d255fe0f:
    "Сайори стоит с торжествующим видом."

translate russian ch1_end_sayori_82fb35f0:
    "Позади неё Моника с совершенно растерянным лицом."

translate russian ch1_end_sayori_1be1e038:
    y 3q "Я... заварю чаю..."

translate russian ch1_end_sayori_6bd77772:
    "Юри поспешно уходит."

translate russian ch1_end_sayori_94e8be2c:
    "Нацуки садится и с пустым выражением лица смотрит в никуда."

translate russian ch1_end_sayori_7fc95ed7:
    mc "Так вот почему Сайори — вице-президент..."

translate russian ch1_end_sayori_aeb009e1:
    "Я шепчу это Монике."

translate russian ch1_end_sayori_4467525d:
    "Она в ответ кивает."

translate russian ch1_end_sayori_d2418739:
    m 1d "Если честно..."

translate russian ch1_end_sayori_3e359faf:
    m "Я, может, и кажусь хорошим лидером, и организовывать умею..."

translate russian ch1_end_sayori_d9387db7:
    m 3e "Но с людьми я не очень-то лажу..."

translate russian ch1_end_sayori_603ffd99:
    m "Я даже не решилась вмешаться."

translate russian ch1_end_sayori_de2b2608:
    m 1m "Для президента это как-то стыдно."

translate russian ch1_end_sayori_f06e3a51:
    m 1l "А-ха-ха..."

translate russian ch1_end_sayori_fa3ab68b:
    mc "Да брось..."

translate russian ch1_end_sayori_9f8ebf5d:
    mc "Я не могу тебя за это винить."

translate russian ch1_end_sayori_ba2a31f9:
    mc "Я ведь тоже ничего не смог сказать."

translate russian ch1_end_sayori_d3107ef6:
    m "Ну..."

translate russian ch1_end_sayori_ff212328:
    m 2a "Наверное, это просто значит, что Сайори по-своему потрясающая, правда?"

translate russian ch1_end_sayori_fbeffde4:
    mc "Можно и так сказать."

translate russian ch1_end_sayori_f9167286:
    mc "Она, может, и простушка, но иногда подозрительно похоже, что она прекрасно знает, что делает."

translate russian ch1_end_sayori_950f75ec:
    m 5 "Вот как~"

translate russian ch1_end_sayori_ef746270:
    m "Береги её, ладно?"

translate russian ch1_end_sayori_de07f7a1:
    m "Мне бы очень не хотелось, чтобы она пострадала."

translate russian ch1_end_sayori_8c567b2c:
    mc "Мне тоже..."

translate russian ch1_end_sayori_f4589107:
    mc "Можешь на меня рассчитывать."

translate russian ch1_end_sayori_e16c6dbb:
    "Моника мило мне улыбается, и у меня внутри всё сжимается."

translate russian ch1_end_sayori_9d604853:
    "Такой искренний человек — и правда хороший президент, что бы она там ни говорила."

translate russian ch1_end_sayori_46cf2648:
    "Вот бы мне выпал шанс поговорить с ней подольше..."
