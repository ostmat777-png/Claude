# Русский перевод: splash

translate russian splashscreen_f490803a:
    "Удаление сохранений...{nw}"

translate russian splashscreen_365de68f:
    "Эта игра не предназначена для детей и впечатлительных людей."

translate russian splashscreen_b895d9b1:
    "Игра может быть небезопасна для людей, страдающих тревожностью или депрессией. Подробнее о тревожном содержании: http://ddlc.moe/warning.html"

translate russian after_load_78a4e9dc:
    "Не удалось загрузить сохранение."

translate russian after_load_5c5510ae:
    "Пытаешься жульничать?"

translate russian after_load_46c240e4:
    m "Ты меня смешишь."

translate russian after_load_e5a463d0:
    m "Ты меня смешишь, [persistent.playername]."

translate russian readonly_c0c137c6:
    "Игру нельзя запустить, потому что она находится в папке, доступной только для чтения."

translate russian readonly_db394637:
    "Пожалуйста, скопируйте игру DDLC на рабочий стол или в другое доступное место и попробуйте снова."
