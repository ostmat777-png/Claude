# Русский перевод: script-ch21

translate russian ch21_main_0f077782:
    m "Снова привет, [player]!"

translate russian ch21_main_95ea4bac:
    m "Рада видеть, что ты от нас не сбежал. Ха-ха-ха!"

translate russian ch21_main_ecaf5654:
    mc "Не-а, не волнуйся."

translate russian ch21_main_a0e98f5a:
    mc "Пусть мне тут немного непривычно, но своё слово я держу."

translate russian ch21_main_5bff8fb6:
    "Что ж, я снова в Литературном клубе."

translate russian ch21_main_0565e928:
    "Я пришёл последним, так что все остальные уже вовсю общаются."

translate russian ch21_main_209577b0:
    y "Спасибо, что сдержал обещание, [player]."

translate russian ch21_main_0762f28d:
    y 1a "Надеюсь, это не слишком тяжёлое для тебя обязательство."

translate russian ch21_main_0b033aa0:
    y 1u "Заставлять тебя с головой нырять в литературу, когда ты к ней не привык..."

translate russian ch21_main_4bc8df14:
    n "Ой, да брось! Можно подумать, ему нужны поблажки."

translate russian ch21_main_f114fc18:
    n 4e "Тебя и так пришлось притащить сюда Монике."

translate russian ch21_main_e6e52d65:
    n "Не знаю, собираешься ты сюда просто приходить потусоваться или что..."

translate russian ch21_main_8ef8abd3:
    n "Но если не будешь воспринимать нас всерьёз, тебе это ещё долго будут припоминать."

translate russian ch21_main_e8cad960:
    m "Нацуки, для человека, который хранит в клубной комнате свою коллекцию манги, ты слишком много болтаешь."

translate russian ch21_main_28526ae4:
    n 4o "М-М-М...!!"

translate russian ch21_main_6ff88347:
    "Нацуки застревает где-то между «Моника» и «Манга»."

translate russian ch21_main_8e1ee84b:
    n 1v "Манга — это литература!!"

translate russian ch21_main_036357ba:
    "Мгновенно поверженная, Нацуки плюхается обратно на стул."

translate russian ch21_main_134f5bf0:
    y "Прости, [player]..."

translate russian ch21_main_13b672c8:
    y "Мы обязательно позаботимся, чтобы тебе было комфортно, хорошо?"

translate russian ch21_main_0f6b17e0:
    "Юри бросает на Нацуки разочарованный взгляд."

translate russian ch21_main_98f2c2ea:
    y 1a "Э-э, в общем..."

translate russian ch21_main_1d2411ac:
    y "Раз уж ты теперь в клубе и всё такое..."

translate russian ch21_main_15cca953:
    y "...Может, тебе было бы интересно взять почитать какую-нибудь книгу?"

translate russian ch21_main_c14c584c:
    mc "Ну..."

translate russian ch21_main_89fd5cc7:
    mc "Я в любом случае не могу отказаться."

translate russian ch21_main_7c680eca:
    mc "Как ты и сказала, теперь я в этом клубе."

translate russian ch21_main_47b42db1:
    mc "Так что будет правильно, если я что-нибудь почитаю, раз ты просишь."

translate russian ch21_main_014522fc:
    y 4b "П-подожди..."

translate russian ch21_main_4031f60f:
    y "Я совсем не это имела в виду!"

translate russian ch21_main_6559e79e:
    y "У-у..."

translate russian ch21_main_2add5b01:
    y "Если тебе не очень хочется, то, наверное, забудь, что я сказала..."

translate russian ch21_main_1bbe57dc:
    mc "А— Нет, дело не в этом, Юри."

translate russian ch21_main_a3efbc9a:
    mc "Я хочу постараться стать частью этого клуба."

translate russian ch21_main_720ff8ea:
    mc "Так что, даже если я нечасто читаю, я с радостью возьму книгу, если ты хочешь."

translate russian ch21_main_d39c2555:
    y 3t "Т-ты уверен...?"

translate russian ch21_main_6234a550:
    y "Мне просто показалось..."

translate russian ch21_main_5cc899a6:
    y 3u "...Ну, раз уж я вице-президент и всё такое..."

translate russian ch21_main_400ef1e7:
    y "...Что мне стоит помочь тебе начать с чего-нибудь, что может тебе понравиться."

translate russian ch21_main_5c6d9095:
    "Юри лезет в сумку и достаёт книгу."

translate russian ch21_main_bb6c4878:
    y 1s "Я не хотела, чтобы ты чувствовал себя лишним..."

translate russian ch21_main_1879c00c:
    y "Поэтому выбрала книгу, которая, как мне показалось, может тебе понравиться."

translate russian ch21_main_c76bcbd9:
    y "Она короткая, так что не успеет наскучить, даже если ты обычно не читаешь."

translate russian ch21_main_1c1fa68f:
    y "И мы могли бы, ну..."

translate russian ch21_main_262616a0:
    y 4b "Обсудить её... если захочешь..."

translate russian ch21_main_257a5a4c:
    "Э-это же..."

translate russian ch21_main_dbd79240:
    "Как у этой девушки получается быть такой милой, даже не стараясь?"

translate russian ch21_main_067cb0c1:
    "Она даже выбрала книгу, которая, по её мнению, мне понравится, хотя я почти не читаю..."

translate russian ch21_main_063782d3:
    mc "Юри, спасибо! Обязательно прочитаю!"

translate russian ch21_main_a0d526be:
    "Я с воодушевлением беру книгу."

translate russian ch21_main_f6554ff6:
    y "Фух..."

translate russian ch21_main_3b5e8d6c:
    y 2a "Ну, читай в своём темпе."

translate russian ch21_main_17c99d12:
    y "С нетерпением жду, что ты о ней скажешь."

translate russian ch21_main_5d35cc1a:
    "Я ожидал, что теперь, когда все собрались, Моника начнёт какие-нибудь запланированные занятия."

translate russian ch21_main_be0f213d:
    "Но, похоже, ничего такого не предвидится."

translate russian ch21_main_301982d1:
    "Юри уже уткнулась в книгу."

translate russian ch21_main_b18fd321:
    "Я не могу не заметить её сосредоточенное лицо — будто она только и ждала этого момента."

translate russian ch21_main_6713a333:
    "А Нацуки тем временем копается в шкафу."

translate russian ch21_end_d91458f0:
    mc "Фух..."

translate russian ch21_end_1782371d:
    "Кажется, это все."

translate russian ch21_end_58e4d71b:
    "Я оглядываю комнату."

translate russian ch21_end_21f37dea:
    "Это оказалось чуть напряжённее, чем я рассчитывал."

translate russian ch21_end_5b12ad4c:
    "Такое чувство, будто все судят меня за мои посредственные писательские способности..."

translate russian ch21_end_72e6b5de:
    "Даже если они просто вежливы, мои стихи никак не могут тягаться с их стихами."

translate russian ch21_end_3e6d2aa1:
    "Это всё-таки литературный клуб."

translate russian ch21_end_3f739ce1:
    "Я вздыхаю."

translate russian ch21_end_e55af38e:
    "Видимо, вот во что я ввязался."

translate russian ch21_end_ad956e20:
    "В другом конце комнаты Моника что-то пишет в своей тетради."

translate russian ch21_end_841184ee:
    "Мой взгляд падает на Юри и Нацуки."

translate russian ch21_end_1705c9fe:
    "Они осторожно обмениваются листками и показывают друг другу свои стихи."

translate russian ch21_end_37b74d39:
    "Пока они читают, я наблюдаю, как меняются их лица."

translate russian ch21_end_f3def454:
    "Нацуки раздражённо хмурит брови."

translate russian ch21_end_1583e001:
    "А Юри грустно улыбается."

translate russian ch21_end_36ce7fb5:
    n 1q "{i}(Что это вообще за язык такой...?){/i}"

translate russian ch21_end_5f1028e8:
    y 2f "А?"

translate russian ch21_end_392e3f64:
    y "Э-э... ты что-то сказала?"

translate russian ch21_end_5a23a338:
    n 2c "А, ничего."

translate russian ch21_end_73b87d84:
    "Нацуки небрежно, одной рукой, кладёт стихотворение обратно на парту."

translate russian ch21_end_678d666c:
    n "Ну, можно сказать, что оно вычурное."

translate russian ch21_end_ee8faee5:
    y 2i "А— Спасибо..."

translate russian ch21_end_1705b12d:
    y "А твоё... милое..."

translate russian ch21_end_d53cb64f:
    n 2h "Милое?"

translate russian ch21_end_d7a2229c:
    n 1h "Ты что, совсем не поняла символизм?"

translate russian ch21_end_a5b7430f:
    n "Оно же явно о чувстве, когда сдаёшься."

translate russian ch21_end_0db745ab:
    n "Что тут может быть милого?"

translate russian ch21_end_d42c351b:
    y 3f "Я-я это поняла!"

translate russian ch21_end_b698ba3b:
    y "Я просто имела в виду..."

translate russian ch21_end_2c3a3a03:
    y 3h "Язык, наверное..."

translate russian ch21_end_678374ea:
    y "Я пыталась сказать что-то приятное..."

translate russian ch21_end_5adabccb:
    n "А?"

translate russian ch21_end_b10ead8d:
    n 4w "То есть тебе пришлось так стараться, чтобы найти, что бы такого приятного сказать?"

translate russian ch21_end_f9cdd784:
    n "Спасибо, но приятным это совсем не прозвучало!"

translate russian ch21_end_64c0a3eb:
    y 1i "Э-э..."

translate russian ch21_end_15db327d:
    y "Ну, у меня есть пара предложений..."

translate russian ch21_end_ebd6a743:
    n 5x "Хмф."

translate russian ch21_end_a87c36dd:
    n "Если бы мне нужны были предложения, я бы спросила того, кому оно правда понравилось."

translate russian ch21_end_4466dbb0:
    n "А такие, между прочим, {i}были{/i}."

translate russian ch21_end_321942a4:
    n 5e "Монике понравилось."

translate russian ch21_end_0ea3372f:
    n "И [player] тоже оценил!"

translate russian ch21_end_3afcd245:
    n "Так что, исходя из этого, я с радостью дам тебе пару советов от себя."

translate russian ch21_end_4fda8f5a:
    n "Во-первых—"

translate russian ch21_end_0b794b70:
    y 2l "Прошу прощения..."

translate russian ch21_end_166ab7be:
    y "Я ценю твоё предложение, но я очень долго вырабатывала свой стиль."

translate russian ch21_end_0d2b663b:
    y 2h "И не думаю, что он изменится в ближайшее время, разве что мне попадётся что-то особенно вдохновляющее."

translate russian ch21_end_7cad6bf8:
    y "А такого пока не было."

translate russian ch21_end_8487fc0c:
    n 1o "Н-н...!"

translate russian ch21_end_f72b1c71:
    y 1k "Между прочим, [player] тоже оценил моё стихотворение."

translate russian ch21_end_75dd3224:
    y "Он даже сказал, что оно его впечатлило."

translate russian ch21_end_a5061963:
    "Нацуки вдруг вскакивает."

translate russian ch21_end_2824bf93:
    n 4y "Да ну?"

translate russian ch21_end_693f0dc5:
    n "Я и не знала, что ты так стараешься впечатлить нашего нового участника, Юри."

translate russian ch21_end_b63049e5:
    y 1n "Ч-что?!"

translate russian ch21_end_3df614f2:
    y "Я совсем не это...!"

translate russian ch21_end_803d0e3c:
    y 1o "У-у..."

translate russian ch21_end_acc94b27:
    y "Ты... Ты просто..."

translate russian ch21_end_6a5c0c7b:
    "Юри тоже встаёт."

translate russian ch21_end_fb24704f:
    y 2r "Может, ты просто завидуешь, что [player] оценил мои советы больше, чем твои!"

translate russian ch21_end_ee52e8e3:
    n 1e "Ха! А откуда ты знаешь, что он не оценил {i}мои{/i} советы больше?"

translate russian ch21_end_6d2144a0:
    n "Ты настолько высокого мнения о себе?"

translate russian ch21_end_c1eb1e36:
    y 3h "Я...!"

translate russian ch21_end_bfadd2bc:
    y "Нет..."

translate russian ch21_end_8d1dcf35:
    y "Если бы я была высокого мнения о себе..."

translate russian ch21_end_5e4e458d:
    y 1r "...я бы из кожи вон лезла, чтобы всё, что я делаю, было приторно-милым!"

translate russian ch21_end_ccdb66db:
    n 1o "У-у-у-у-у...!"

translate russian ch21_end_daedfb90:
    n "Ну, знаешь что?!"

translate russian ch21_end_09b7047e:
    n "Это не у меня грудь волшебным образом выросла на размер, как только тут начал появляться [player]!!"

translate russian ch21_end_9b07aefd:
    y "Н-Нацуки!!"

translate russian ch21_end_d6f8c030:
    m "Э-э, Нацуки, это уже немного—"

translate russian ch21_end_6f0acf5a:
    ny "Тебя это не касается!"

translate russian ch21_end_0a64f0ef:
    y "Вымещать свою неуверенность на других..."

translate russian ch21_end_9bc5cf9f:
    y "Ты и правда ведёшь себя на столько, на сколько выглядишь, Нацуки."

translate russian ch21_end_43ed1d91:
    n 4o "{i}Я?{/i} На себя посмотри, стерва, косящая под мрачную!"

translate russian ch21_end_92e2b02f:
    y "Под мрачную...?"

translate russian ch21_end_0d84550c:
    y 2r "Прости, что мой образ жизни слишком сложен для понимания человека твоего умственного возраста!"

translate russian ch21_end_90bf09b2:
    n 4f "Вот видишь??"

translate russian ch21_end_63390205:
    n "Вот этими словами ты и доказываешь мою правоту!"

translate russian ch21_end_f5bbcc4e:
    n 4e "Большинство людей, знаешь ли, перестают задирать нос, когда заканчивают среднюю школу."

translate russian ch21_end_3171f8f3:
    y "Если хочешь что-то доказать, перестань изводить других своим тошнотворным поведением!"

translate russian ch21_end_d558e8d9:
    y "Думаешь, можно уравновесить свой ядовитый характер, если одеваться и вести себя мило?"

translate russian ch21_end_22920899:
    y 1k "Единственное, что в тебе милого, — это то, как отчаянно ты стараешься."

translate russian ch21_end_380c7903:
    n 2y "Ого, осторожнее, Юри, не порежься о свои острые углы."

translate russian ch21_end_7e404b8d:
    n "Ой, прости... Ты ведь и так режешься, да?"

translate russian ch21_end_10c6da39:
    y 3n "Т-ты что, обвиняешь меня в том, что я себя режу??"

translate russian ch21_end_73f33284:
    y 3r "Какого хрена у тебя в голове?!"

translate russian ch21_end_44ab981f:
    n 1e "Давай, продолжай!"

translate russian ch21_end_07dadfb4:
    n "Пусть [player] услышит всё, что ты на самом деле думаешь!"

translate russian ch21_end_a42a7d2b:
    n "Уверена, после этого он по уши в тебя влюбится!"

translate russian ch21_end_c64d04ee:
    y 3n "А-ах—!"

translate russian ch21_end_d2e9959c:
    "Вдруг Юри поворачивается ко мне, будто только сейчас заметила, что я стою рядом."

translate russian ch21_end_1e4f93b8:
    y 2n "[player]...!"

translate russian ch21_end_470c0d03:
    y "Она... Она просто хочет выставить меня в дурном свете...!"

translate russian ch21_end_c5e00378:
    n 4w "Неправда!"

translate russian ch21_end_0c50491a:
    n "Она первая начала!"

translate russian ch21_end_2b35b6fe:
    mc "..."

translate russian ch21_end_96c06797:
    "{cps=*2}И как меня вообще в это втянули?!{/cps}{nw}"

translate russian ch21_end_2541ac61:
    "{cps=*2}Я же ничего не смыслю в писательстве...{/cps}{nw}"

translate russian ch21_end_7d9d98c4:
    "{cps=*2}Но с кем бы я ни согласился, она наверняка станет думать обо мне лучше!{/cps}{nw}"

translate russian ch21_end_41c4781c:
    "{cps=*2}Так что, разумеется, это будет...!{/cps}{nw}"

translate russian menu_click_e612037c:
    m "..."

translate russian menu_click_e612037c_1:
    m "..."

translate russian menu_click_e612037c_2:
    m "..."

translate russian menu_click_619a4637:
    m "Э-э..."

translate russian menu_click_a6fb49ba:
    m "Эй, [player]..."

translate russian menu_click_cf6f7c57:
    m "Может, выйдем\nненадолго\nв коридор?"

translate russian menu_click_dd97e600:
    m "Хорошо?"

translate russian menu_click_2f9f306e:
    m "Прости за это..."

translate russian menu_click_67ee9bb9:
    m "Им правда не стоило тебя в это втягивать."

translate russian menu_click_11a2229c:
    m 1e "Нам, наверное, лучше в это не вмешиваться..."

translate russian menu_click_f2dd2e3d:
    m "Вернёмся, когда они перестанут кричать."

translate russian menu_click_4e571793:
    m 5 "А-ха-ха..."

translate russian menu_click_cb621371:
    m "Хорош из меня президент, да?"

translate russian menu_click_1a371204:
    m 1m "Не могу даже как следует поставить на место собственных участниц..."

translate russian menu_click_b7464616:
    m "Хотела бы я иногда быть чуточку напористее."

translate russian menu_click_cfaea3b3:
    m "Но у меня никогда не хватает духу дать кому-то отпор..."

translate russian menu_click_b1450be3:
    m 1e "Ты ведь понимаешь, правда?"

translate russian menu_click_c9062bfa:
    m "В общем..."

translate russian menu_click_e113be5f:
    m 1a "Если из-за этого тебе захочется проводить меньше времени с остальными, ничего страшного."

translate russian menu_click_7c0419af:
    m 1j "Я бы с радостью проводила время с тобой..."

translate russian menu_click_f62b9f71:
    "Вдруг из класса выбегает Нацуки."

translate russian menu_click_bb2cf764:
    n "..."

translate russian menu_click_105c6c9a:
    "Она быстро убегает прочь."

translate russian menu_click_15225d9f:
    m "Ох, батюшки..."

translate russian menu_click_0aa55db2:
    m "...Что ж, похоже, они закончили..."

translate russian menu_click_e464b6e5:
    y "Я не хотела..."

translate russian menu_click_e464b6e5_1:
    y "Я не хотела..."

translate russian menu_click_e464b6e5_2:
    y "Я не хотела..."

translate russian menu_click_5eb4546c:
    "Юри раскачивается взад-вперёд за партой, прижав ладони ко лбу."

translate russian menu_click_c934e5a0:
    mc "Юри...?"

translate russian menu_click_463d1bed:
    y "Я не хотела!!"

translate russian menu_click_dd4d3f4b:
    mc "Я-я тебе верю..."

translate russian menu_click_7031a8ce:
    "Понятия не имею, что Юри могла сказать Нацуки."

translate russian menu_click_1e020a7e:
    "Или сделать."

translate russian menu_click_2f37247c:
    y "[player]."

translate russian menu_click_b5fc3340:
    y "Пожалуйста, не ненавидь меня."

translate russian menu_click_d02fdb85:
    y "Пожалуйста!"

translate russian menu_click_7c4ea4ee:
    y "Я не такая!"

translate russian menu_click_fac4e8e9:
    y "Со мной сегодня что-то не так..."

translate russian menu_click_f74888eb:
    m "Всё в порядке, Юри."

translate russian menu_click_f4e93bf7:
    m "Мы знаем, что ты не хотела."

translate russian menu_click_35d4e88d:
    m 1j "К тому же, уверена, к завтрашнему дню Нацуки обо всём забудет."

translate russian menu_click_51f3751d:
    m 1a "Совершенно."

translate russian menu_click_0dbaabdd:
    y 4b "..."

translate russian menu_click_78755f7e:
    m "В общем, собрание окончено, так что можете идти домой, если хотите."

translate russian menu_click_1588679c:
    y 4a "..."

translate russian menu_click_2bd1e4a4:
    "Юри смотрит на меня так, будто хочет что-то сказать."

translate russian menu_click_f5925d23:
    "Но она то и дело поглядывает на Монику."

translate russian menu_click_81a77c4f:
    y 2v "Т-ты можешь идти первой, Моника..."

translate russian menu_click_da187b06:
    y "Я бы хотела задержаться ещё ненадолго."

translate russian menu_click_53c405bf:
    m 2k "Я президент, так что уходить последней должна я."

translate russian menu_click_6d467e1f:
    m "Я подожду, пока ты закончишь."

translate russian menu_click_0dbaabdd_1:
    y 4b "..."

translate russian menu_click_71a86863:
    y "..."

translate russian menu_click_e5298b26:
    y "Ну— Я вице-президент, так что..."

translate russian menu_click_fd86d333:
    y "Пожалуйста, позволь сегодня мне взять эту ответственность на себя."

translate russian menu_click_b187a000:
    m 2i "Похоже, ты почему-то не хочешь, чтобы я была рядом, Юри."

translate russian menu_click_ee5208e3:
    y 3p "Д-дело не в этом!"

translate russian menu_click_472923e1:
    y 3o "Дело не в этом..."

translate russian menu_click_4cdfda49:
    y 3n "Мне просто..."

translate russian menu_click_fba950a3:
    y 3q "Я толком не успела обсудить свою книгу с [player]..."

translate russian menu_click_f5ffdbaa:
    y "Просто было бы... неловко, если бы ты слушала..."

translate russian menu_click_256540cd:
    m 1r "{i}*Вздох*{/i}"

translate russian menu_click_87fe856c:
    m 1d "Похоже, выбора у меня особо нет, да?"

translate russian menu_click_f742ec5e:
    y 1t "П-прости, что доставляю хлопоты..."

translate russian menu_click_3ff20095:
    y 1s "Но я правда ценю, что ты понима{nw}"

translate russian menu_click_d7508341:
    y glitch "Но я правда ценю, что ты понима{fast}[gtext] [gtext][gtext]{nw}"
