# Русский перевод: script-exclusives-yuri

translate russian yuri_exclusive_1_e440bb66:
    "Мне очень хочется ещё немного поговорить с Юри..."

translate russian yuri_exclusive_1_621b29bd:
    "Но в то же время неловко отвлекать её от чтения."

translate russian yuri_exclusive_1_98b79815:
    "Я мельком вижу обложку её книги."

translate russian yuri_exclusive_1_1385bf59:
    "Похоже, это та же книга, которую она одолжила мне..."

translate russian yuri_exclusive_1_e35e4f57:
    "Более того, она, кажется, только на первых страницах."

translate russian yuri_exclusive_1_728dcbc5:
    y "Ах..."

translate russian yuri_exclusive_1_a3e7f3d1:
    "Чёрт—"

translate russian yuri_exclusive_1_f669242a:
    "Кажется, она заметила, что я на неё смотрю..."

translate russian yuri_exclusive_1_990b5d3a:
    "Она снова украдкой бросает на меня взгляд, и на долю секунды наши глаза встречаются."

translate russian yuri_exclusive_1_0dbaabdd:
    y 4b "..."

translate russian yuri_exclusive_1_aef29682:
    "Но от этого она лишь глубже прячет лицо в книгу."

translate russian yuri_exclusive_1_4bbe5891:
    mc "Прости..."

translate russian yuri_exclusive_1_225dcd47:
    mc "Я просто задумался..."

translate russian yuri_exclusive_1_9a0048e8:
    "Я бормочу это, чувствуя, что смутил её."

translate russian yuri_exclusive_1_8b12779f:
    y 1i "Ох..."

translate russian yuri_exclusive_1_a41cea99:
    y "Ничего..."

translate russian yuri_exclusive_1_9f30b822:
    y 1a "Если бы я была сосредоточена, то, наверное, и не заметила бы."

translate russian yuri_exclusive_1_749d562e:
    y "Но я просто немного перечитываю это, так что..."

translate russian yuri_exclusive_1_8dcab0c1:
    mc "Это та книга, которую ты мне дала, да?"

translate russian yuri_exclusive_1_7b0a03ee:
    y "Угу."

translate russian yuri_exclusive_1_9de78180:
    y "Мне захотелось перечитать её кусочек."

translate russian yuri_exclusive_1_b6b08cc7:
    y 2q "Без какой-то особой причины...!"

translate russian yuri_exclusive_1_63031f4d:
    mc "Просто любопытно — откуда у тебя два экземпляра одной книги?"

translate russian yuri_exclusive_1_728dcbc5_1:
    y "Ах..."

translate russian yuri_exclusive_1_8be5857f:
    y "Ну, когда я вчера зашла в книжный—"

translate russian yuri_exclusive_1_56924230:
    y 3o "Ах, я не это хотела сказать..."

translate russian yuri_exclusive_1_5daab38f:
    y "То есть—"

translate russian yuri_exclusive_1_1fb27bb9:
    y 1w "Я... просто так вышло, что купила две."

translate russian yuri_exclusive_1_236ab8d0:
    mc "А, понятно."

translate russian yuri_exclusive_1_40855474:
    "Тут есть что-то довольно очевидное, о чём Юри мне не говорит, но я решаю не допытываться."

translate russian yuri_exclusive_1_4f372d32:
    mc "Я обязательно скоро начну её читать!"

translate russian yuri_exclusive_1_9fa7e925:
    y 2u "Рада это слышать..."

translate russian yuri_exclusive_1_6a834c69:
    y "Когда сюжет начнёт набирать обороты, тебе, возможно, будет трудно оторваться."

translate russian yuri_exclusive_1_336b89ef:
    y 2c "Это очень увлекательная история, в которой легко узнать себя."

translate russian yuri_exclusive_1_85d4ab1c:
    mc "Правда...?"

translate russian yuri_exclusive_1_c6f1e734:
    mc "А о чём она вообще?"

translate russian yuri_exclusive_1_cae7b7d0:
    y 1f "Ну..."

translate russian yuri_exclusive_1_5c53d1aa:
    y "М-м-м..."

translate russian yuri_exclusive_1_9edded30:
    "Юри закрывает книгу и пробегает глазами по задней обложке."

translate russian yuri_exclusive_1_0c75c656:
    "Книга называется «Портрет Маркова»."

translate russian yuri_exclusive_1_fd714eb0:
    "На передней обложке зловещий символ в виде глаза."

translate russian yuri_exclusive_1_a151f4d8:
    y 1a "Хорошо..."

translate russian yuri_exclusive_1_3b65810b:
    y "Я просто хотела убедиться, что случайно ничего не выдам."

translate russian yuri_exclusive_1_2373a2f7:
    y "Если вкратце, она о старшекласснице, которая переезжает к давно потерянной младшей сестре..."

translate russian yuri_exclusive_1_d564b8e1:
    y "Но как только она это делает, её жизнь становится очень странной."

translate russian yuri_exclusive_1_dc851a35:
    y 1m "На неё начинают охотиться люди, сбежавшие из тюрьмы, где ставили опыты над людьми..."

translate russian yuri_exclusive_1_8908c88c:
    y "И пока её жизнь в опасности, ей приходится отчаянно выбирать, кому доверять."

translate russian yuri_exclusive_1_5af42571:
    y 1i "Что бы она ни делала, в итоге она рушит почти все свои отношения, и её жизнь начинает разваливаться..."

translate russian yuri_exclusive_1_0a469adb:
    mc "Это как-то—!"

translate russian yuri_exclusive_1_89546258:
    "Это как-то мрачновато, нет?"

translate russian yuri_exclusive_1_7bcce1db:
    "Юри так это преподнесла, будто история будет милой, так что этот мрачный поворот взялся словно из ниоткуда."

translate russian yuri_exclusive_1_94de94f1:
    y 1c "А-ха-ха."

translate russian yuri_exclusive_1_19716728:
    "Юри вдруг тихонько хихикает."

translate russian yuri_exclusive_1_7bc89322:
    y "Тебе такое не по душе, [player]?"

translate russian yuri_exclusive_1_ce487936:
    mc "Нет, дело не в этом..."

translate russian yuri_exclusive_1_7c7d4031:
    mc "В смысле, мне такие истории вполне могут нравиться, так что не волнуйся."

translate russian yuri_exclusive_1_3c899c8c:
    y 2u "Надеюсь..."

translate russian yuri_exclusive_1_2269e4aa:
    "Да... Я совсем забыл, что Юри такое любит."

translate russian yuri_exclusive_1_b87c0f68:
    "Снаружи она такая застенчивая и замкнутая, но, похоже, внутри у неё совсем другой мир."

translate russian yuri_exclusive_1_d0642c8b:
    y "Просто такие истории..."

translate russian yuri_exclusive_1_22101599:
    y 1a "Они заставляют взглянуть на жизнь под странным новым углом."

translate russian yuri_exclusive_1_93e29306:
    y "Когда ужасные вещи происходят не просто потому, что кто-то хочет творить зло..."

translate russian yuri_exclusive_1_b38a3643:
    y 1m "А потому, что у него свои цели или своя философия, в которую он верит."

translate russian yuri_exclusive_1_4673d793:
    y "И вдруг, когда тебе казалось, что ты понимаешь главного героя..."

translate russian yuri_exclusive_1_68acbfaa:
    y "Наивным оказывается он сам — за то, что позволил своей однобокой морали помешать планам злодея."

translate russian yuri_exclusive_1_2d6e3c72:
    y 3v "Я... я заболталась, да...?"

translate russian yuri_exclusive_1_5dac5c99:
    y "Опять..."

translate russian yuri_exclusive_1_d287205e:
    y 4b "Прости..."

translate russian yuri_exclusive_1_47b1016d:
    mc "Эй, не извиняйся...!"

translate russian yuri_exclusive_1_0fbafffa:
    mc "Мне вовсе не стало скучно."

translate russian yuri_exclusive_1_ae7f22e8:
    y "Ну..."

translate russian yuri_exclusive_1_9520be33:
    y "Тогда, наверное, всё в порядке..."

translate russian yuri_exclusive_1_432dd786:
    y 4a "Но мне кажется, стоит предупредить тебя, что у меня есть такая проблема..."

translate russian yuri_exclusive_1_f902f7cf:
    y "Когда я позволяю книгам и писательству заполнить мои мысли..."

translate russian yuri_exclusive_1_cbb32f29:
    y "Я как будто забываю обращать внимание на других людей..."

translate russian yuri_exclusive_1_1b4a2d9b:
    y 3t "Так что прости, если я вдруг скажу что-нибудь странное!"

translate russian yuri_exclusive_1_7e573792:
    y "И, пожалуйста, останови меня, если начну слишком много болтать!"

translate russian yuri_exclusive_1_db2f7cec:
    mc "Это—"

translate russian yuri_exclusive_1_c443f13d:
    mc "По-моему, тебе правда не о чем беспокоиться..."

translate russian yuri_exclusive_1_9c6f8ec5:
    mc "Это просто значит, что ты увлечена чтением."

translate russian yuri_exclusive_1_7bfa8270:
    mc "Меньшее, что я могу сделать, — это послушать."

translate russian yuri_exclusive_1_3bea2478:
    mc "Это ведь всё-таки литературный клуб..."

translate russian yuri_exclusive_1_c2dd3459:
    y 4a "А—"

translate russian yuri_exclusive_1_717cb0f3:
    y "Это..."

translate russian yuri_exclusive_1_7c11a798:
    y "Что ж, это правда..."

translate russian yuri_exclusive_1_0a788c2f:
    mc "Вообще-то..."

translate russian yuri_exclusive_1_23631788:
    mc "Почему бы мне не начать её читать прямо сейчас?"

translate russian yuri_exclusive_1_92e92567:
    y 3n "Т-тебе не обязательно!"

translate russian yuri_exclusive_1_4e8c6ca5:
    mc "А-ха-ха, что ты несёшь?"

translate russian yuri_exclusive_1_1ace8887:
    mc "Ты же только что сказала, что ждёшь этого."

translate russian yuri_exclusive_1_5a6499dc:
    y 3o "..."

translate russian yuri_exclusive_1_d671f554:
    mc "Дай только возьму книгу..."

translate russian yuri_exclusive_1_5b5dd31b:
    "Я быстро достаю книгу, которую положил в сумку."

translate russian yuri_exclusive_1_64614a30:
    mc "Так... можно я сяду здесь?"

translate russian yuri_exclusive_1_6ab0c7c0:
    "Я сажусь за парту рядом с Юри."

translate russian yuri_exclusive_1_acedfa3b:
    y 3n "Ах...!"

translate russian yuri_exclusive_1_92fa2786:
    y "Ну вот..."

translate russian yuri_exclusive_1_cfce055e:
    mc "Точно можно?"

translate russian yuri_exclusive_1_17b81435:
    mc "Ты, кажется, немного напряглась..."

translate russian yuri_exclusive_1_717cb0f3_1:
    y "Это..."

translate russian yuri_exclusive_1_d287205e_1:
    y 4b "Прости..."

translate russian yuri_exclusive_1_678618c7:
    y "Дело не в том, что я не хочу!"

translate russian yuri_exclusive_1_b683d384:
    y "Просто я к такому не очень привыкла..."

translate russian yuri_exclusive_1_a44cd31c:
    y "В смысле, читать в чьей-то компании."

translate russian yuri_exclusive_1_a7bcf340:
    mc "Понятно..."

translate russian yuri_exclusive_1_7ddffb3c:
    mc "Ну, просто скажи, если я буду тебя отвлекать или вроде того."

translate russian yuri_exclusive_1_6efff781:
    y "Х-хорошо..."

translate russian yuri_exclusive_1_b7550a3e:
    "Я открываю книгу и начинаю читать пролог."

translate russian yuri_exclusive_1_695b1b6b:
    "Вскоре я понимаю, что Юри имела в виду, говоря о чтении в компании."

translate russian yuri_exclusive_1_d2bc4359:
    "Я словно чувствую её присутствие у себя за плечом, пока читаю."

translate russian yuri_exclusive_1_336c3ecb:
    "Ничего плохого в этом нет."

translate russian yuri_exclusive_1_7099b9f9:
    "Может, немного отвлекает, но это чувство даже успокаивает."

translate russian yuri_exclusive_1_79904e73:
    "Краем глаза я вижу Юри."

translate russian yuri_exclusive_1_ffe5cfa7:
    "И понимаю, что на самом деле она не смотрит в свою книгу."

translate russian yuri_exclusive_1_e241e6b4:
    "Я бросаю на неё взгляд."

translate russian yuri_exclusive_1_c5bc1b32:
    "Похоже, вместо этого она читает из моей книги—"

translate russian yuri_exclusive_1_510cdaf3:
    y "П-прости!"

translate russian yuri_exclusive_1_c2d3dc87:
    y "Я просто—!"

translate russian yuri_exclusive_1_d23d4ffa:
    mc "Юри, ты правда очень часто извиняешься, да?"

translate russian yuri_exclusive_1_4712ee86:
    y "Я... правда?"

translate russian yuri_exclusive_1_6e71265b:
    y 4a "Я не нарочно..."

translate russian yuri_exclusive_1_485fb852:
    y "Прости..."

translate russian yuri_exclusive_1_89f89f32:
    y 4c "То есть—!"

translate russian yuri_exclusive_1_ee7d9dbd:
    mc "А-ха-ха."

translate russian yuri_exclusive_1_42937a87:
    mc "Вот, так ведь будет удобнее?"

translate russian yuri_exclusive_1_4be018f3:
    "Я придвигаю свою парту вплотную к парте Юри и держу книгу между нами."

translate russian yuri_exclusive_1_74f60a14:
    y 2v "Ах..."

translate russian yuri_exclusive_1_fcfbd4b1:
    y "Пожалуй..."

translate russian yuri_exclusive_1_bdf7b243:
    "Юри робко закрывает свой экземпляр."

translate russian yuri_exclusive_1_c8915827:
    "Стоит нам обоим чуть наклониться, как наши плечи почти соприкасаются."

translate russian yuri_exclusive_1_ffa8cf07:
    "Левая рука будто мешает, поэтому я держу книгу открытой правой."

translate russian yuri_exclusive_1_7d3a640c:
    mc "А, кажется, так неудобно переворачивать страницы..."

translate russian yuri_exclusive_1_9572fcba:
    y "Давай так..."

translate russian yuri_exclusive_1_e50b1a55:
    "Юри левой рукой придерживает левую сторону книги большим и указательным пальцами."

translate russian yuri_exclusive_1_93deaf69:
    mc "А..."

translate russian yuri_exclusive_1_8aa7edbf:
    "Я делаю то же самое правой рукой с правой стороной."

translate russian yuri_exclusive_1_f4605bd6:
    "Так я переворачиваю страницу, а Юри, когда та перелистывается на её сторону, прижимает её большим пальцем."

translate russian yuri_exclusive_1_24340c2f:
    "Но если держать книгу вот так..."

translate russian yuri_exclusive_1_34a46315:
    "Мы сидим, прижавшись друг к другу ещё теснее, чем раньше."

translate russian yuri_exclusive_1_274fbd4a:
    "Это меня, вообще-то, здорово отвлекает...!"

translate russian yuri_exclusive_1_e1a2be34:
    "Будто я чувствую тепло её лица, и она всё время у меня на краю зрения..."

translate russian yuri_exclusive_1_44384bd1:
    y "...Ты готов?"

translate russian yuri_exclusive_1_fb2e5377:
    mc "А?"

translate russian yuri_exclusive_1_22bd46cd:
    y "Перевернуть страницу..."

translate russian yuri_exclusive_1_960cc2a4:
    mc "А... прости!"

translate russian yuri_exclusive_1_103817d4:
    mc "Кажется, я на секунду отвлёкся..."

translate russian yuri_exclusive_1_5252b0b0:
    "Я снова бросаю взгляд на лицо Юри, и наши глаза встречаются."

translate russian yuri_exclusive_1_7a860699:
    "Не знаю, как мне за ней поспевать..."

translate russian yuri_exclusive_1_728dcbc5_2:
    y "Ах..."

translate russian yuri_exclusive_1_6668580d:
    y "Ничего страшного."

translate russian yuri_exclusive_1_dd97e184:
    y "Ты ведь не так привык читать, верно?"

translate russian yuri_exclusive_1_f5f71ae0:
    y "Я не против подождать, если у тебя уйдёт чуть больше времени..."

translate russian yuri_exclusive_1_506c74d6:
    y "Это, наверное, меньшее, что я могу сделать..."

translate russian yuri_exclusive_1_9f203c74:
    y "Раз ты был со мной так терпелив..."

translate russian yuri_exclusive_1_5aa72ccd:
    mc "Д-да..."

translate russian yuri_exclusive_1_a64e8bc0:
    mc "Спасибо."

translate russian yuri_exclusive_1_880606e6:
    "Мы продолжаем читать."

translate russian yuri_exclusive_1_91dcd78e:
    "Юри больше не спрашивает, готов ли я перевернуть страницу."

translate russian yuri_exclusive_1_6051933b:
    "Вместо этого я просто исхожу из того, что она дочитывает страницу раньше меня, и переворачиваю её сам."

translate russian yuri_exclusive_1_e76a0690:
    "Первую главу мы дочитываем молча."

translate russian yuri_exclusive_1_94aeb271:
    "И всё же каждая перевёрнутая страница кажется почти интимным обменом..."

translate russian yuri_exclusive_1_b3d1da47:
    "Мой большой палец мягко отпускает страницу, позволяя ей перелететь на её сторону, где она ловит её своим."

translate russian yuri_exclusive_1_54daf6f3:
    mc "Слушай, Юри..."

translate russian yuri_exclusive_1_a38f93a8:
    mc "Может, это глупая мысль, но..."

translate russian yuri_exclusive_1_dc2668cf:
    mc "Главная героиня мне немного напоминает тебя."

translate russian yuri_exclusive_1_ea844295:
    y "Ты... так думаешь?"

translate russian yuri_exclusive_1_a1432063:
    y "Чем же?"

translate russian yuri_exclusive_1_a6cdef49:
    mc "Ну, во многом она, пожалуй, прямолинейнее..."

translate russian yuri_exclusive_1_13679fa1:
    mc "Но она тоже всё время сомневается во всём, что говорит и делает."

translate russian yuri_exclusive_1_521a49f4:
    mc "Будто боится сделать что-то не так."

translate russian yuri_exclusive_1_9c97ddc4:
    mc "Не то чтобы я мог заглянуть тебе в голову..."

translate russian yuri_exclusive_1_c1d47386:
    mc "Но это чем-то напоминает некоторые твои привычки."

translate russian yuri_exclusive_1_2cf3a26d:
    y "П-понятно..."

translate russian yuri_exclusive_1_eee017b7:
    "Юри какое-то время молчит."

translate russian yuri_exclusive_1_3ea6615e:
    y "Но, [player]..."

translate russian yuri_exclusive_1_8949a2e2:
    y "Это, наверное..."

translate russian yuri_exclusive_1_d377e169:
    y "...ужасная черта, которая у нас с ней общая!"

translate russian yuri_exclusive_1_aa12ec76:
    y 4b "У-у-ух, как стыдно, что ты так думаешь..."

translate russian yuri_exclusive_1_a0208d1c:
    mc "П-подожди!"

translate russian yuri_exclusive_1_77c18923:
    mc "Я не имел в виду ничего плохого!"

translate russian yuri_exclusive_1_c7f5fbff:
    mc "Прости, я правда не знал, что ты так стесняешься этого..."

translate russian yuri_exclusive_1_71a86863:
    y "..."

translate russian yuri_exclusive_1_cbe370dd:
    mc "Я скорее хотел сказать, что это даже мило..."

translate russian yuri_exclusive_1_4181bb38:
    y 3q "А-ах—"

translate russian yuri_exclusive_1_9444dd56:
    y "Что ты вдруг такое говоришь...?"

translate russian yuri_exclusive_1_3328ab95:
    y "Я...!"

translate russian yuri_exclusive_1_90de9c4d:
    m "Итак, ребята!"

translate russian yuri_exclusive_1_85976b77:
    y "...!"

translate russian yuri_exclusive_1_196d5a2a:
    m "Думаю, пора нам поделиться друг с другом сегодняшними стихами."

translate russian yuri_exclusive_1_095693f5:
    m "Если слишком долго ждать, может не хватить времени."

translate russian yuri_exclusive_1_417c4895:
    y 3w "Ах..."

translate russian yuri_exclusive_1_8b293e73:
    "Юри выдыхает, избавленная от необходимости договаривать."

translate russian yuri_exclusive_1_28245b36:
    m 1 "Ты не против, Юри?"

translate russian yuri_exclusive_1_ae055152:
    m "Ты выглядишь какой-то подавленной..."

translate russian yuri_exclusive_1_a60031f7:
    m "Прости, если ты этого не ждала..."

translate russian yuri_exclusive_1_6767e92a:
    y 3v "Ах, дело не..."

translate russian yuri_exclusive_1_3f38c617:
    y "...Всё хорошо."

translate russian yuri_exclusive_1_22de134e:
    "Юри отпускает книгу, и та захлопывается прямо на моём большом пальце."

translate russian yuri_exclusive_1_b12907fb:
    mc "Ладно..."

translate russian yuri_exclusive_1_30a619aa:
    mc "Пожалуй, почитаю ещё вечером."

translate russian yuri_exclusive_1_7130b630:
    mc "Или ты бы предпочла, чтобы я читал её только с тобой?"

translate russian yuri_exclusive_1_22d77bf9:
    y 2f "Э-э...!"

translate russian yuri_exclusive_1_e52646df:
    y "Я... пожалуй, мне всё равно..."

translate russian yuri_exclusive_1_8fea2db2:
    mc "Хм-м..."

translate russian yuri_exclusive_1_11220766:
    mc "Тогда я почитаю ещё немного вечером."

translate russian yuri_exclusive_1_f73baa8c:
    mc "С тобой будет интереснее читать, когда сюжет немного разгонится, понимаешь?"

translate russian yuri_exclusive_1_a4bcfb86:
    y 2a "Разумное рассуждение."

translate russian yuri_exclusive_1_f6ee4da5:
    y "В таком случае можешь спокойно дочитать первые две главы в своём темпе."

translate russian yuri_exclusive_1_e3c9018a:
    mc "Решено!"

translate russian yuri_exclusive_1_1950528a:
    "Я встаю."

translate russian yuri_exclusive_1_c0c90965:
    "Я запоминаю, где остановился, и снова убираю книгу в сумку."

translate russian yuri_exclusive_2_e72920b3:
    mc "Эй, Юри."

translate russian yuri_exclusive_2_444e7092:
    y "А?"

translate russian yuri_exclusive_2_93deaf69:
    mc "А..."

translate russian yuri_exclusive_2_826f0290:
    "Вдруг я замечаю, что Юри читает не ту книгу, которую мы читаем вместе."

translate russian yuri_exclusive_2_58cac761:
    mc "Прости! Я не хотел мешать..."

translate russian yuri_exclusive_2_8849a940:
    y 2m "Ах, нет..."

translate russian yuri_exclusive_2_043b8fc5:
    y "Я, в общем-то, просто ждала тебя..."

translate russian yuri_exclusive_2_17aaad6d:
    mc "А, раз так..."

translate russian yuri_exclusive_2_ch3_9814a6fd:
    mc "Может, сразу и начнём?"

translate russian yuri_exclusive_2_ch3_fb0e5788:
    y 2c "Да, давай!"

translate russian yuri_exclusive_2_ch3_8bdc1c86:
    y 3a "Вообще-то, у меня есть просьба..."

translate russian yuri_exclusive_2_ch3_8649e7f4:
    y "...Ты не против, если я сначала заварю чай?"

translate russian yuri_exclusive_2_ch3_5a86862f:
    mc "Вовсе нет."

translate russian yuri_exclusive_2_ch3_61544195:
    y 1c "Большое спасибо."

translate russian yuri_exclusive_2_ch3_68e78420:
    y 1a "Если что-то и может сделать моё время для чтения здесь ещё лучше, так это хорошая чашка чая."

translate russian yuri_exclusive_2_ch3_1ac81ad1:
    y "Не говоря уже о тебе."

translate russian yuri_exclusive_2_ch3_f364f34f:
    "Юри встаёт и направляется к шкафу."

translate russian yuri_exclusive_2_ch3_2a287e1b:
    "Я иду следом и смотрю, как она достаёт с полки небольшой кувшин для воды — из тех, что с фильтром внутри."

translate russian yuri_exclusive_2_ch3_ec60897b:
    y "Подержишь секунду?"

translate russian yuri_exclusive_2_ch3_2fcc7ac5:
    mc "Конечно..."

translate russian yuri_exclusive_2_ch3_bd9eb39a:
    "Юри отдаёт мне кувшин и достаёт ещё и электрический чайник."

translate russian yuri_exclusive_2_ch3_705fd731:
    y "Я включу его в розетку у учительского стола, а потом сходим за водой."

translate russian yuri_exclusive_2_ch3_35920c24:
    "Она проходит мимо меня и ставит чайник на учительский стол."

translate russian yuri_exclusive_2_ch3_ecb93295:
    "Я просто наблюдаю за её движениями."

translate russian yuri_exclusive_2_ch3_1c3b026c:
    "К моему удивлению, то, как она двигается, разительно отличается от её манеры говорить."

translate russian yuri_exclusive_2_ch3_c89e5a0e:
    "Особенно благодаря длинным ногам Юри выглядит изящной и собранной."

translate russian yuri_exclusive_2_ch3_38a1bb11:
    y "Так, можно мне кувшин?"

translate russian yuri_exclusive_2_ch3_5219ddb4:
    y 1a "Спасибо. Я скоро вернусь."

translate russian yuri_exclusive_2_ch3_9e2c0e50:
    mc "А, давай я лучше схожу с тобой..."

translate russian yuri_exclusive_2_ch3_40d53f92:
    y 1s "Да... почему бы и нет?"

translate russian yuri_exclusive_2_ch3_62ac1ba6:
    y "Тогда идём?"

translate russian yuri_exclusive_2_ch3_69c25b65:
    mc "Да..."

translate russian yuri_exclusive_2_ch3_a9ab7161:
    m "Хм? Куда это вы двое?"

translate russian yuri_exclusive_2_ch3_fb2e5377:
    mc "А?"

translate russian yuri_exclusive_2_ch3_8fe4f781:
    mc "Мы просто... Юри собиралась заварить чай, вот..."

translate russian yuri_exclusive_2_ch3_d5715e62:
    "Вдруг до меня доходит, как странно звучит, когда объясняешь это Монике."

translate russian yuri_exclusive_2_ch3_08617021:
    mc "Мы просто наберём воды в кувшин..."

translate russian yuri_exclusive_2_ch3_fbc22bb0:
    m "А, понятно!"

translate russian yuri_exclusive_2_ch3_50cd3a0e:
    m 4j "Прости, мне просто стало немного любопытно..."

translate russian yuri_exclusive_2_ch3_8dad8afe:
    m "С этим ведь вполне справится и один человек, разве нет?"

translate russian yuri_exclusive_2_ch3_db2f7cec:
    mc "Это—"

translate russian yuri_exclusive_2_ch3_f9124228:
    y 1k "Моника, пожалуйста, хоть раз не лезь не в своё дело."

translate russian yuri_exclusive_2_ch3_539f0f4f:
    y "Или ты хочешь сказать, что плохо привлекать [player] к делам клуба?"

translate russian yuri_exclusive_2_ch3_61f737dd:
    m 1g "А-а...?"

translate russian yuri_exclusive_2_ch3_55feb8f4:
    mc "—!"

translate russian yuri_exclusive_2_ch3_ec53cc26:
    "У меня отвисает челюсть."

translate russian yuri_exclusive_2_ch3_0116dd72:
    m 5a "Я..."

translate russian yuri_exclusive_2_ch3_5b5dab2a:
    m "Пожалуй, в этом нет ничего плохого..."

translate russian yuri_exclusive_2_ch3_749d0352:
    y 2l "Хмф..."

translate russian yuri_exclusive_2_ch3_4d46fbf6:
    y "Тогда пойдём, [player]."

translate russian yuri_exclusive_2_ch3_93deaf69:
    mc "А..."

translate russian yuri_exclusive_2_ch3_a33042ac:
    "Юри быстро выходит из комнаты, и я иду следом."

translate russian yuri_exclusive_2_ch3_32ffd9b4:
    "Оказавшись в коридоре, она вдруг упирается лбом в стену."

translate russian yuri_exclusive_2_ch3_421b8735:
    y "Я сказала не подумав..."

translate russian yuri_exclusive_2_ch3_c299c098:
    y "Как я могла такое сказать...?"

translate russian yuri_exclusive_2_ch3_d90390e4:
    mc "Юри..."

translate russian yuri_exclusive_2_ch3_566499ce:
    y 4b "Мне просто..."

translate russian yuri_exclusive_2_ch3_17faf4b7:
    y "Что-то в том, как она это сказала..."

translate russian yuri_exclusive_2_ch3_0da874b1:
    y "Меня это так... разозлило."

translate russian yuri_exclusive_2_ch3_9f028e59:
    y "Что со мной не так...?"

translate russian yuri_exclusive_2_ch3_679a547f:
    mc "Нет, Юри."

translate russian yuri_exclusive_2_ch3_681eef25:
    mc "По-моему... ты всё правильно сделала!"

translate russian yuri_exclusive_2_ch3_2b65320f:
    mc "Я такого не ожидал, но..."

translate russian yuri_exclusive_2_ch3_ca949713:
    mc "Монике тоже нехорошо так судить о людях."

translate russian yuri_exclusive_2_ch3_5506a397:
    y 4a "[player]..."

translate russian yuri_exclusive_2_ch3_ce332702:
    y "Почему, даже когда я делаю что-то плохое..."

translate russian yuri_exclusive_2_ch3_a9e81cda:
    y "Ты так добр ко мне?"

translate russian yuri_exclusive_2_ch3_e4481ad0:
    mc "Потому что."

translate russian yuri_exclusive_2_ch3_584c210f:
    mc "Всё, что ты делаешь, никогда не бывает так плохо, как тебе кажется."

translate russian yuri_exclusive_2_ch3_a791bbe3:
    mc "Никто не идеален."

translate russian yuri_exclusive_2_ch3_5f34b76f:
    mc "У нас есть эмоции, и мы не всегда можем их скрыть."

translate russian yuri_exclusive_2_ch3_e531f5f5:
    mc "Но ты всегда всё раздуваешь у себя в голове..."

translate russian yuri_exclusive_2_ch3_8d1fbbc7:
    mc "Твой разум превращает лёгкий дождик в ураган."

translate russian yuri_exclusive_2_ch3_b68fdac6:
    y 3q "Ах..."

translate russian yuri_exclusive_2_ch3_0d7a2fec:
    y "Н-нет..."

translate russian yuri_exclusive_2_ch3_f31caf25:
    y "Разве ты бы не возненавидел меня за что-то настолько ужасное...?"

translate russian yuri_exclusive_2_ch3_d6ad76cb:
    mc "С чего бы мне тебя ненавидеть?"

translate russian yuri_exclusive_2_ch3_2b5d26e1:
    mc "Нельзя ненавидеть человека за то, что у него есть эмоции..."

translate russian yuri_exclusive_2_ch3_44e8a821:
    mc "Какой друг так поступит?"

translate russian yuri_exclusive_2_ch3_b03243da:
    y 4c "Друг... говоришь?"

translate russian yuri_exclusive_2_ch3_872cf474:
    y "Ах... э-э..."

translate russian yuri_exclusive_2_ch3_5166e39e:
    "Юри поднимает голову."

translate russian yuri_exclusive_2_ch3_8f0af103:
    y 3w "[player]..."

translate russian yuri_exclusive_2_ch3_f51623d1:
    y 3t "Мне правда очень нравится... дружить с тобой!"

translate russian yuri_exclusive_2_ch3_7a59b594:
    mc "А-ха-ха..."

translate russian yuri_exclusive_2_ch3_0fb9fde4:
    mc "Спасибо, Юри."

translate russian yuri_exclusive_2_ch3_a0a47ac1:
    mc "Мне тоже нравится дружить с тобой..."

translate russian yuri_exclusive_2_ch3_d061a888:
    "Мне как-то неловко говорить такие вещи..."

translate russian yuri_exclusive_2_ch3_931b6e65:
    "Но я изо всех сил стараюсь, чтобы Юри стало легче."

translate russian yuri_exclusive_2_ch3_1b9ad4e3:
    mc "В общем...!"

translate russian yuri_exclusive_2_ch3_fc553608:
    y 3u "Ах— Да..."

translate russian yuri_exclusive_2_ch3_ec46d419:
    y "Идём?"

translate russian yuri_exclusive_2_ch3_cf1adef2:
    mc "Ага."

translate russian yuri_exclusive_2_ch3_ec172061:
    "Мы с Юри доходим до ближайшего питьевого фонтанчика."

translate russian yuri_exclusive_2_ch3_34937634:
    "Наполнив кувшин, мы возвращаемся в класс."

translate russian yuri_exclusive_2_ch3_ca073357:
    y "[player], ты любишь улун?"

translate russian yuri_exclusive_2_ch3_eafd0bfb:
    mc "А, да."

translate russian yuri_exclusive_2_ch3_1c080aaf:
    mc "Мне любой подойдёт."

translate russian yuri_exclusive_2_ch3_5304a307:
    y "Очень хорошо."

translate russian yuri_exclusive_2_ch3_b1265635:
    "Юри выставляет на чайнике температуру девяносто три градуса."

translate russian yuri_exclusive_2_ch3_cbbbfba3:
    y 1f "Теперь пора достать заварочный чайник."

translate russian yuri_exclusive_2_ch3_e0a461fa:
    mc "Ты и правда всё делаешь как положено, да?"

translate russian yuri_exclusive_2_ch3_ac6b359f:
    y 1u "Конечно..."

translate russian yuri_exclusive_2_ch3_9eec2a3c:
    y "Когда я завариваю чай для других, нельзя делать это кое-как."

translate russian yuri_exclusive_2_ch3_5199bad0:
    mc "Даже если я совсем не разбираюсь в чае?"

translate russian yuri_exclusive_2_ch3_976e8033:
    y 2m "Хи-хи."

translate russian yuri_exclusive_2_ch3_38b77528:
    y 2a "Тогда тем сильнее ты будешь впечатлён."

translate russian yuri_exclusive_2_ch3_beb50f2c:
    mc "А... может, и буду!"

translate russian yuri_exclusive_2_ch3_bd6ceeb4:
    "Юри достаёт заварочный чайник и начинает отмерять чайные листья."

translate russian yuri_exclusive_2_ch3_b78eae4f:
    "К моему удивлению, она даже начинает тихонько напевать себе под нос."

translate russian yuri_exclusive_2_ch3_ba599efa:
    mc "У тебя, похоже, хорошее настроение..."

translate russian yuri_exclusive_2_ch3_c32eedbb:
    y 1a "Правда?"

translate russian yuri_exclusive_2_ch3_ab893d32:
    y "Я дала этому проявиться..."

translate russian yuri_exclusive_2_ch3_7f41b19f:
    y "И ты заметил."

translate russian yuri_exclusive_2_ch3_bca12f15:
    y 2u "Я немного подумала..."

translate russian yuri_exclusive_2_ch3_0164772c:
    y "И решила, что попробую чуть больше себя проявлять."

translate russian yuri_exclusive_2_ch3_b699d4da:
    y "Оказывается, это не так уж трудно..."

translate russian yuri_exclusive_2_ch3_c52c4a97:
    y 1c "По крайней мере, когда рядом ты."

translate russian yuri_exclusive_2_ch3_93deaf69_1:
    mc "А..."

translate russian yuri_exclusive_2_ch3_1c90c29a:
    mc "Это здорово, Юри!"

translate russian yuri_exclusive_2_ch3_28e6d662:
    mc "Только не перенапрягайся."

translate russian yuri_exclusive_2_ch3_5aab8dd2:
    y 3u "Ты вечно обо мне беспокоишься, [player]..."

translate russian yuri_exclusive_2_ch3_6f88fe35:
    y "Это очень трогательно."

translate russian yuri_exclusive_2_ch3_b7f7559b:
    mc "Это..."

translate russian yuri_exclusive_2_ch3_04ca9dc1:
    "Юри не шутила..."

translate russian yuri_exclusive_2_ch3_7604063e:
    "Даже не знаю, смогу ли я за этим поспеть...!"

translate russian yuri_exclusive_2_ch3_58805ea1:
    "Я смотрю, как Юри наливает каждому из нас по чашке чая."

translate russian yuri_exclusive_2_ch3_f2be1624:
    y 1a "[player], у меня ещё одна просьба."

translate russian yuri_exclusive_2_ch3_dcf2efbc:
    y "Ты не против, если сегодня мы сядем на пол?"

translate russian yuri_exclusive_2_ch3_635adbe8:
    mc "А? Почему?"

translate russian yuri_exclusive_2_ch3_953ca257:
    y 1h "Так моей спине немного легче..."

translate russian yuri_exclusive_2_ch3_4b80e874:
    y "Я смогу читать, прислонившись к стене, а не сгорбившись над партой."

translate russian yuri_exclusive_2_ch3_c34e0b47:
    mc "А, прости, я не знал."

translate russian yuri_exclusive_2_ch3_1b0a66cf:
    y 1a "Ничего страшного."

translate russian yuri_exclusive_2_ch3_d5b75401:
    y "Просто у меня довольно часто болит спина, вот я и стараюсь с этим справляться."

translate russian yuri_exclusive_2_ch3_09f2de35:
    mc "Правда?"

translate russian yuri_exclusive_2_ch3_f735ccd8:
    mc "Интересно, отчего это..."

translate russian yuri_exclusive_2_ch3_e8d54652:
    y 1f "Скорее всего, это из-за моей—"

translate russian yuri_exclusive_2_ch3_504ba04a:
    y 1n "А—"

translate russian yuri_exclusive_2_ch3_68c6e8a6:
    y 1o "М-моей..."

translate russian yuri_exclusive_2_ch3_3c30f162:
    mc "Осанки, да?"

translate russian yuri_exclusive_2_ch3_2462174e:
    mc "Вечно сутулишься, пока читаешь..."

translate russian yuri_exclusive_2_ch3_579a96b7:
    y 2p "Да!"

translate russian yuri_exclusive_2_ch3_ef46eb2d:
    y 2q "У меня ужасная осанка, когда я читаю!"

translate russian yuri_exclusive_2_ch3_5a43e3b2:
    y "Поэтому нам и стоит сесть на пол."

translate russian yuri_exclusive_2_ch3_d5ae2301:
    mc "Справедливо."

translate russian yuri_exclusive_2_ch3_ba08de52:
    mc "Сейчас возьму книгу."

translate russian yuri_exclusive_2_ch3_fa75c129:
    "Я достаю книгу из сумки."

translate russian yuri_exclusive_2_ch3_33179bd7:
    mc "А, у меня ещё и шоколадки есть..."

translate russian yuri_exclusive_2_ch3_c42403a3:
    "Это пакетик маленьких шоколадных конфет, который я прятал от конфетного радара Сайори."

translate russian yuri_exclusive_2_ch3_e1063e85:
    "Беру его — к чаю как раз подойдёт."

translate russian yuri_exclusive_2_ch3_d9a2ecee:
    "Мы с Юри садимся у стены, поставив чашки рядом."

translate russian yuri_exclusive_2_ch3_ad740ef3:
    "Словно по команде, мы устраиваемся так же, как в прошлый раз, — каждый держит свою половину книги."

translate russian yuri_exclusive_2_ch3_308596e5:
    "Вот только на этот раз..."

translate russian yuri_exclusive_2_ch3_de366d08:
    "Мы сидим ещё ближе друг к другу."

translate russian yuri_exclusive_2_ch3_5d023884:
    y "Мне не очень хорошо видно..."

translate russian yuri_exclusive_2_ch3_55feb8f4_1:
    mc "—!"

translate russian yuri_exclusive_2_ch3_b25a40d6:
    "Юри придвигается, пока наши плечи не соприкасаются."

translate russian yuri_exclusive_2_ch3_85980a12:
    "И как мне сосредоточиться на чтении в таком положении...?!"

translate russian yuri_exclusive_2_ch3_73b16b02:
    "Юри всегда была милой, но..."

translate russian yuri_exclusive_2_ch3_784f0af8:
    "Когда она не так скованна, это почти выше моих сил!"

translate russian yuri_exclusive_2_ch3_afd2de9d:
    y 2f "Твоя чашка..."

translate russian yuri_exclusive_2_ch3_7075f030:
    "Юри протягивает мне мою чашку."

translate russian yuri_exclusive_2_ch3_b94c1535:
    "Я держу её свободной от книги рукой и оказываюсь в позе, в которой сосредоточиться ещё сложнее."

translate russian yuri_exclusive_2_ch3_738fef00:
    "Потому что теперь приходится следить, чтобы случайно не коснуться её груди...!"

translate russian yuri_exclusive_2_ch3_31a38b20:
    "А Юри тем временем ничего не замечает."

translate russian yuri_exclusive_2_ch3_cb5218b7:
    "У неё то самое сосредоточенное выражение лица, и, могу лишь предположить, весь мир вокруг для неё исчез."

translate russian yuri_exclusive_2_ch3_8b064b16:
    "Я напрягаю всю силу воли, чтобы сосредоточиться на чтении."

translate russian yuri_exclusive_2_ch3_a20cefa7:
    "..."

translate russian yuri_exclusive_2_ch3_c510b9b5:
    "Через несколько минут мне наконец удаётся немного расслабиться."

translate russian yuri_exclusive_2_ch3_76549943:
    "Я ставлю чашку между ног и вожусь с обёрткой шоколадок."

translate russian yuri_exclusive_2_ch3_2787f9a7:
    mc "Ой, прости..."

translate russian yuri_exclusive_2_ch3_61683ed9:
    "Я ненадолго отпускаю книгу, чтобы открыть пакетик."

translate russian yuri_exclusive_2_ch3_0183dede:
    mc "Бери сколько хочешь."

translate russian yuri_exclusive_2_ch3_a9ce267b:
    y 2s "Ах, это..."

translate russian yuri_exclusive_2_ch3_54b4955c:
    y "Ничего, я не буду..."

translate russian yuri_exclusive_2_ch3_276afef2:
    mc "А? Точно?"

translate russian yuri_exclusive_2_ch3_de41a4f9:
    y 2v "Ну..."

translate russian yuri_exclusive_2_ch3_701aa4c1:
    y "Если я её возьму, на страницах могут остаться пятна..."

translate russian yuri_exclusive_2_ch3_6a87efd4:
    mc "А, ты права..."

translate russian yuri_exclusive_2_ch3_db8aec53:
    mc "Я даже не подумал об этом."

translate russian yuri_exclusive_2_ch3_9e480491:
    mc "Мой косяк..."

translate russian yuri_exclusive_2_ch3_0eb2861d:
    y 2a "Не нужно извиняться."

translate russian yuri_exclusive_2_ch3_13b3e059:
    y "Давай я подержу книгу, хорошо?"

translate russian yuri_exclusive_2_ch3_977e733b:
    mc "Ты уверена...?"

translate russian yuri_exclusive_2_ch3_d32f8ecc:
    y "Конечно."

translate russian yuri_exclusive_2_ch3_f9749fd6:
    "Юри раскрывает книгу обеими руками."

translate russian yuri_exclusive_2_ch3_d4c91dff:
    "Она держит её так, чтобы мне было так же удобно читать."

translate russian yuri_exclusive_2_ch3_d764c329:
    "Но в результате её левая рука практически лежит у меня на ноге."

translate russian yuri_exclusive_2_ch3_59dd503e:
    mc "Что ж, раз так..."

translate russian yuri_exclusive_2_ch3_54138664:
    "Юри уже снова полностью погружена в чтение."

translate russian yuri_exclusive_2_ch3_a28daeb1:
    "Я беру шоколадную конфетку и кладу её в рот."

translate russian yuri_exclusive_2_ch3_2fbb5434:
    "Потом беру ещё одну..."

translate russian yuri_exclusive_2_ch3_6bf56b05:
    "И подношу её к Юри."

translate russian yuri_exclusive_2_ch3_73bd295b:
    "Она даже не отрывает взгляда от книги."

translate russian yuri_exclusive_2_ch3_b1c5258a:
    "Она просто приоткрывает губы, будто всё это совершенно естественно."

translate russian yuri_exclusive_2_ch3_cd91f7db:
    "Но тогда отступать уже нельзя!"

translate russian yuri_exclusive_2_ch3_dd709b9d:
    "Я с опаской кладу конфету ей в рот."

translate russian yuri_exclusive_2_ch3_ff42d43c:
    "Вот так просто Юри смыкает губы."

translate russian yuri_exclusive_2_ch3_d1820aca:
    y "А...?"

translate russian yuri_exclusive_2_ch3_5dbb8342:
    "Выражение лица Юри вдруг меняется."

translate russian yuri_exclusive_2_ch3_66238965:
    y "Я..."

translate russian yuri_exclusive_2_ch3_64718e50:
    y "Я что, только что..."

translate russian yuri_exclusive_2_ch3_f2565bf9:
    "Юри смотрит на меня так, словно ей нужно убедиться в том, что сейчас произошло."

translate russian yuri_exclusive_2_ch3_35dc00ff:
    y "Э-э..."

translate russian yuri_exclusive_2_ch3_c60c5441:
    y "[player]..."

translate russian yuri_exclusive_2_ch3_c817a551:
    mc "П-прости!"

translate russian yuri_exclusive_2_ch3_304b7207:
    mc "Наверное, не стоило так делать..."

translate russian yuri_exclusive_2_ch3_3c879c45:
    y "Ах, это..."

translate russian yuri_exclusive_2_ch3_ae7f22e8:
    y "Ну..."

translate russian yuri_exclusive_2_ch3_dff5b544:
    y "Т-ты же просто помогал..."

translate russian yuri_exclusive_2_ch3_032ecbde:
    y "Так поступают... друзья..."

translate russian yuri_exclusive_2_ch3_f4da81f6:
    y "...Правда?"

translate russian yuri_exclusive_2_ch3_7136c946:
    mc "Ну..."

translate russian yuri_exclusive_2_ch3_9765b19b:
    "Не совсем в такой ситуации, но..."

translate russian yuri_exclusive_2_ch3_69c25b65_1:
    mc "Да..."

translate russian yuri_exclusive_2_ch3_8327793c:
    mc "...Только и всего."

translate russian yuri_exclusive_2_ch3_92fa2786:
    y "Ну вот..."

translate russian yuri_exclusive_2_ch3_ebeae167:
    y "Тогда..."

translate russian yuri_exclusive_2_ch3_bf64f37f:
    y "Тебе вовсе не обязательно прекращать..."

translate russian yuri_exclusive_2_ch3_f11161d0:
    mc "П-понятно..."

translate russian yuri_exclusive_2_ch3_db77dc05:
    "Обстановка накалилась до предела..."

translate russian yuri_exclusive_2_ch3_7ffb1852:
    "Юри пытается вернуться к книге."

translate russian yuri_exclusive_2_ch3_17848ffc:
    "Но по её лицу видно, что теперь даже она не может сосредоточиться."

translate russian yuri_exclusive_2_ch3_5b723450:
    "Сердце колотится..."

translate russian yuri_exclusive_2_ch3_11eeff15:
    "Я нервно беру между пальцами ещё одну конфету."

translate russian yuri_exclusive_2_ch3_908fadd1:
    "Но на этот раз Юри встречается со мной взглядом."

translate russian yuri_exclusive_2_ch3_71a86863:
    y "..."

translate russian yuri_exclusive_2_ch3_7a53109d:
    "Как вообще до этого дошло...?"

translate russian yuri_exclusive_2_ch3_1c0553c0:
    "Юри не отводит глаз."

translate russian yuri_exclusive_2_ch3_b752d63a:
    "Я замечаю, как в такт дыханию поднимается и опускается её грудь."

translate russian yuri_exclusive_2_ch3_e6176dff:
    "Я поднимаю руку..."

translate russian yuri_exclusive_2_ch3_728dcbc5:
    y "Ах..."

translate russian yuri_exclusive_2_ch3_41427b33:
    "Как и прежде, Юри приоткрывает губы."

translate russian yuri_exclusive_2_ch3_6fc33d03:
    "Но... на этот раз всё иначе."

translate russian yuri_exclusive_2_ch3_5df5e619:
    "Я беру конфету и кладу ей в рот."

translate russian yuri_exclusive_2_ch3_27867937:
    "Я чувствую на пальцах её горячее дыхание."

translate russian yuri_exclusive_2_ch3_90de9c4d:
    m "Итак, ребята!"

translate russian yuri_exclusive_2_ch3_f0b857d1:
    mc "Уа—"

translate russian yuri_exclusive_2_ch3_5c35ac2a:
    y "А-ах!"

translate russian yuri_exclusive_2_ch3_8e87fe8d:
    "Юри резко отшатывается."

translate russian yuri_exclusive_2_ch3_9eb8e820:
    m "Пора делиться стихами!"

translate russian yuri_exclusive_2_ch3_841ca391:
    m "[player], ты ведь поможешь Юри убрать чайные принадлежности?"

translate russian yuri_exclusive_2_ch3_b603a1ba:
    mc "Д-да... конечно."

translate russian yuri_exclusive_2_ch3_9c6fd498:
    m "Хорошо, спасибо!"

translate russian yuri_exclusive_2_ch3_89cc198f:
    "Наваждение резко рассеивается."

translate russian yuri_exclusive_2_ch3_09df592d:
    y 4c "Я..."

translate russian yuri_exclusive_2_ch3_a20ef654:
    y "Я уберу чашки..."

translate russian yuri_exclusive_2_ch3_69c25b65_2:
    mc "Да..."

translate russian yuri_exclusive_2_ch3_9fcc188d:
    "Юри поднимает с пола чашки."

translate russian yuri_exclusive_2_ch3_a8008265:
    "Я подбираю пакетик с конфетами."

translate russian yuri_exclusive_2_ch3_34290ea1:
    "В итоге мы торопливо прибираемся, не говоря друг другу ни слова."

translate russian yuri_exclusive_2_ch3_5c8a9cca:
    "У меня такое чувство, что ни у кого из нас не хватит смелости об этом заговорить..."
