# Русский перевод: script-poemresponses

translate russian poemresponse_start2_aa080a54:
    "Мне определённо спокойнее всего показать его сначала Сайори."

translate russian poemresponse_start2_6121f1ef:
    "Она всё-таки мой хороший друг."

translate russian poemresponse_start2_a3fd3750:
    "Вчера я сказал Нацуки, что мне интересны её стихи."

translate russian poemresponse_start2_de2677e6:
    "Будет честно, если сначала я покажу своё ей."

translate russian poemresponse_start2_43088b10:
    "Юри, похоже, самая опытная, так что начну с неё."

translate russian poemresponse_start2_5931141c:
    "Её мнению можно доверять — она будет справедлива."

translate russian poemresponse_start2_0f8b71e3:
    "Начну с Моники."

translate russian poemresponse_start2_e08b3378:
    "Вчера ей очень хотелось прочитать моё стихотворение, и я хочу, чтобы она знала: я стараюсь."

translate russian ch1_y_end_62a6d5c9:
    y 3t "..."

translate russian ch1_y_end_54de4381:
    y "Я... Прости, у меня такой ужасный почерк!"

translate russian ch1_y_end_e4e4c339:
    mc "Что??"

translate russian ch1_y_end_3a1792ff:
    mc "Я совсем не об этом думал..."

translate russian ch1_y_end_4e0012b7:
    y 2v "Но ты так долго читал..."

translate russian ch1_y_end_f9d65918:
    mc "А—"

translate russian ch1_y_end_04346c66:
    mc "Ну, просто я нечасто читаю рукописный текст..."

translate russian ch1_y_end_bd562fe8:
    mc "Вообще-то, по-моему, у тебя красивый почерк."

translate russian ch1_y_end_4729869b:
    y 2t "А?"

translate russian ch1_y_end_35b535d9:
    y 2u "Тогда... хорошо..."

translate russian ch1_y_end_76c8042f:
    mc "И ещё мне понравилось стихотворение."

translate russian ch1_y_end_7cf344dc:
    mc "Хоть оно и короткое, в нём столько образов."

translate russian ch1_y_end_108013e4:
    y 2t "Оно не слишком короткое?"

translate russian ch1_y_end_58ffffd4:
    y "Обычно я пишу стихи длиннее..."

translate russian ch1_y_end_5a86862f:
    mc "Вовсе нет."

translate russian ch1_y_end_7fad786e:
    y 1m "Я... очень рада, что тебе понравилось."

translate russian ch1_y_end_3a719e2d:
    y "Буду честна..."

translate russian ch1_y_end_6539d963:
    y 1a "Раз уж мы делимся впервые, мне хотелось написать что-нибудь помягче."

translate russian ch1_y_end_484c63bd:
    y "Что-нибудь, что легко воспринять, пожалуй."

translate russian ch1_y_end_ba4db005:
    mc "Ты увлекаешься призраками, Юри?"

translate russian ch1_y_end_d7a81f76:
    y 1m "Хи-хи."

translate russian ch1_y_end_e3273660:
    y "Вообще-то, эта история совсем не о призраке, [player]."

translate russian ch1_y_end_a31340dd:
    mc "Правда?"

translate russian ch1_y_end_af8693e1:
    mc "Видимо, я совсем не понял смысла..."

translate russian ch1_y_end_3a91ba77:
    y 1u "Ну, ты ведь только пробежался по нему глазами..."

translate russian ch1_y_end_1a94054d:
    y "Но помни, что поэты часто выражают в творчестве собственные мысли, чувства и переживания."

translate russian ch1_y_end_6be05212:
    y 1a "Обычно они делают больше, чем просто рассказывают историю или рисуют картину."

translate russian ch1_y_end_938caf1c:
    y "В этом случае, возможно, героиню стихотворения лишь символически сравнивают с призраком."

translate russian ch1_y_end_0cd4bc42:
    y 2l "Она задерживается в последнем оставшемся уютном месте, не в силах отпустить прошлое."

translate russian ch1_y_end_140d2a9d:
    y "И скоро у неё не останется ничего..."

translate russian ch1_y_end_89080f2b:
    mc "...Если так посмотреть, это куда мрачнее."

translate russian ch1_y_end_c810472d:
    mc "Я об этом даже не задумывался..."

translate russian ch1_y_end_effb7f3e:
    mc "Это впечатляет."

translate russian ch1_y_end_5f1028e8:
    y 2f "А?"

translate russian ch1_y_end_4d2a1a4f:
    y 3v "Д-да ничего особенного!"

translate russian ch1_y_end_cfc8a40d:
    y "Твоё тоже было впечатляющим, так что..."

translate russian ch1_y_end_fa3ab68b:
    mc "Да брось..."

translate russian ch1_y_end_9dd42f3a:
    mc "Мне скорее самому стоит у тебя кое-чему поучиться."

translate russian ch1_y_end_c279c3ed:
    y 4a "...Ты так думаешь?"

translate russian ch1_y_end_51c6b5b9:
    mc "Да, конечно."

translate russian ch1_y_end_728dcbc5:
    y "Ах..."

translate russian ch1_y_end_5543dae0:
    y 2s "Знаешь..."

translate russian ch1_y_end_4647487b:
    y "Я очень волновалась из-за всего этого."

translate russian ch1_y_end_b58230da:
    y "Но в итоге мне понравилось."

translate russian ch1_y_end_41c5cdf9:
    y "Я и дальше буду стараться ради тебя, [player]."

translate russian ch1_y_end_93deaf69:
    mc "А..."

translate russian ch1_y_end_74fc6761:
    mc "Я тоже."

translate russian ch1_y_end_ff013f4a:
    y 1u "Да ничего особенного..."

translate russian ch1_y_end_e15bb642:
    y "Ну... мне приятно, что ты так думаешь."

translate russian ch1_y_end_2e27b3d6:
    y 1a "Только помни, что совсем скоро ты и сам начнёшь замечать такие вещи."

translate russian ch1_y_end_8ea70f62:
    mc "Да, может, ты и права."

translate russian ch1_y_end_2f2ae776:
    mc "Видимо, придётся и дальше стараться."

translate russian ch1_y_end_e5d84112:
    y "Я на тебя рассчитываю."

translate russian ch2_y_end_cd1493e3:
    y 2m "Э-э..."

translate russian ch2_y_end_6585df55:
    y "С этим я была чуть смелее, чем со вчерашним..."

translate russian ch2_y_end_3f6e38d6:
    mc "Я заметил."

translate russian ch2_y_end_4888dff6:
    mc "Здесь куда больше метафор..."

translate russian ch2_y_end_9c659558:
    "Не знаю, моя ли это вина, но я даже не представляю, о чём это стихотворение."

translate russian ch2_y_end_13fc8943:
    y 1a "Верно."

translate russian ch2_y_end_2f8c26bb:
    y "Оно чуть ближе к моему любимому стилю..."

translate russian ch2_y_end_9be13222:
    y "Использовать стихотворение как холст для ярких образов и передавать через них чувства."

translate russian ch2_y_end_098fe1b5:
    mc "Да, если понимать его буквально, я даже не могу разобрать, что оно значит..."

translate russian ch2_y_end_5bb3878c:
    y 2f "Ну..."

translate russian ch2_y_end_cc48a841:
    y "Думаю, каждый может найти в нём что-то своё."

translate russian ch2_y_end_654bbb90:
    y "Мне хотелось передать, что я чувствую, когда предаюсь своим не совсем обычным увлечениям..."

translate russian ch2_y_end_47f73e1c:
    y 2v "Обычно такие вещи мне приходится держать при себе."

translate russian ch2_y_end_1f32ec0d:
    y "Поэтому иногда мне нравится о них писать."

translate russian ch2_y_end_5b1ae15d:
    mc "Хм, забавно..."

translate russian ch2_y_end_a430f515:
    y 2e "...?"

translate russian ch2_y_end_4157bae8:
    mc "Разве Нацуки не писала о чём-то похожем?"

translate russian ch2_y_end_38c5f95b:
    mc "О том, как над кем-то смеются из-за странного увлечения?"

translate russian ch2_y_end_8655d68b:
    y 2h "А?"

translate russian ch2_y_end_ae4f1b4c:
    y "Она... правда?"

translate russian ch2_y_end_69c25b65:
    mc "Да..."

translate russian ch2_y_end_4e26493b:
    mc "Она говорила, что неважно, чем ты увлекаешься, если никому не вредишь."

translate russian ch2_y_end_45968c7d:
    y 3r "Она... Она права!"

translate russian ch2_y_end_4273620a:
    y 3o "Ах— То есть..."

translate russian ch2_y_end_e1cac8eb:
    y "Она правда так думает...?"

translate russian ch2_y_end_cf1adef2:
    mc "Ага."

translate russian ch2_y_end_bf781a34:
    mc "Похоже, в этом вы с ней похожи..."

translate russian ch2_y_end_9b4519dc:
    y 3h "Это... что ж, это интересно..."

translate russian ch2_y_end_73d8e99f:
    y "Мне казалось, она из тех, кто стал бы смеяться над моими увлечениями..."

translate russian ch2_y_end_f8af02c3:
    y "Но, наверное, я сама виновата, что поспешила с выводами, правда...?"

translate russian ch2_y_end_6d016ac3:
    y 3p "Ах— Пожалуйста, не говори ей, что я так сказала!"

translate russian ch2_y_end_623348ec:
    mc "А-ха-ха. Не волнуйся, мне незачем."

translate russian ch2_y_end_f2b41049:
    y 1l "Хорошо..."

translate russian ch2_y_end_0517fd60:
    y 1a "Что ж, спасибо, что поделился со мной."

translate russian ch2_y_end_d24e5eb7:
    mc "А почему ты держишь их при себе?"

translate russian ch2_y_end_56f2aa86:
    y 3v "П-потому что..."

translate russian ch2_y_end_8560c665:
    y "Это стыдно..."

translate russian ch2_y_end_4259a3cd:
    y "И люди стали бы надо мной смеяться."

translate russian ch2_y_end_de485323:
    y "Разве у тебя нет ничего такого, [player]?"

translate russian ch2_y_end_c14c584c:
    mc "Ну..."

translate russian ch2_y_end_a9fe10e6:
    mc "Да, пожалуй, есть..."

translate russian ch2_y_end_5e287de9:
    y 2h "Мне кажется, у каждого есть что-то подобное."

translate russian ch2_y_end_eb5f566c:
    y "Лучшее, что мы можем, — уважать друг друга и то, что делает каждого особенным."

translate russian ch2_y_end_0b0ba581:
    y "Даже если порой это трудно и что-то нас смущает..."

translate russian ch2_y_end_d432be6f:
    y 1a "В конце концов, если бы я не научилась принимать свои странности, я бы, наверное, себя ненавидела."

translate russian ch2_y_end_9414f0ff:
    y 2u "К-кажется, меня немного понесло..."

translate russian ch2_y_end_8a34447f:
    y "...Но я рада, что ты умеешь слушать."

translate russian ch2_y_end_0518f0dc:
    y 2s "Ты столько всего умеешь..."

translate russian ch2_y_end_2836755d:
    y "Писать, слушать..."

translate russian ch2_y_end_baba92fe:
    y 2u "Таких людей, как ты, и правда немного, [player]..."

translate russian ch2_y_end_d7d0ba51:
    mc "Т-ты немного преувеличиваешь..."

translate russian ch2_y_end_b2ba803e:
    y 2v "Я просто... так чувствую."

translate russian ch2_y_end_9c0d0405:
    y "Никогда не думала, что мне будет так легко делиться своими текстами..."

translate russian ch2_y_end_0a1f5a95:
    y 2s "А теперь я, пожалуй, даже жду этого с нетерпением..."

translate russian ch2_y_end_ce287f9f:
    y 2m "Это просто... очень приятное чувство."

translate russian ch2_y_end_d74b1d3e:
    y "И за это нужно благодарить тебя."

translate russian ch2_y_end_35f9a051:
    mc "Да это... это ерунда..."

translate russian ch2_y_end_45a41fba:
    "Юри искренне мне улыбается."

translate russian ch2_y_end_fae43e77:
    "На мгновение её робость будто исчезает."

translate russian ch3_y_end_a1300026:
    y "Э-э..."

translate russian ch3_y_end_8c575607:
    y "Я понимаю, что пляж — довольно банальная тема для стихов."

translate russian ch3_y_end_39dc46eb:
    y "Но я постаралась подойти к ней через метафору."

translate russian ch3_y_end_c3617635:
    mc "Ты так говоришь, будто вообще не хотела об этом писать..."

translate russian ch3_y_end_dade8ef0:
    y 2e "Ах, ты не слышал...?"

translate russian ch3_y_end_207456d1:
    y 2h "После вчерашнего мы с Нацуки... ну..."

translate russian ch3_y_end_884aa2b8:
    y "Было... забавно, что мы написали о похожем так по-разному."

translate russian ch3_y_end_91b76390:
    y "Поэтому Нацуки захотела, чтобы мы снова написали на одну и ту же тему."

translate russian ch3_y_end_a7bcf340:
    mc "Понятно..."

translate russian ch3_y_end_9fc21808:
    "Нацуки даже не дала мне прочитать своё стихотворение, так что мне особо нечего сказать."

translate russian ch3_y_end_a7bcf340_1:
    mc "Понятно..."

translate russian ch3_y_end_d516d084:
    "Что-то мне подсказывает, что стихотворение, которое показала мне Нацуки, — не то, которым она собирается делиться с остальными..."

translate russian ch3_y_end_14d09b04:
    "Разумеется, Юри я об этом не говорю."

translate russian ch3_y_end_fa563fa8:
    mc "Да, Нацуки мне уже рассказала."

translate russian ch3_y_end_e0389ed2:
    y 3t "П-правда...?"

translate russian ch3_y_end_e1845edf:
    y "Она ведь не сказала ничего странного?"

translate russian ch3_y_end_6ad40ee2:
    y "Она просто хотела, чтобы мы снова написали на одну тему..."

translate russian ch3_y_end_353b328b:
    y 2f "Наверное, чтобы лучше сравнить, чем различаются наши стили... или ход мыслей."

translate russian ch3_y_end_cd8b294a:
    y 2w "В общем, это была её идея...!"

translate russian ch3_y_end_dc6a3380:
    y "Зная её, неудивительно, что ей захотелось чего-то такого."

translate russian ch3_y_end_10a5f574:
    y "Наверное, она просто хочет покрасоваться."

translate russian ch3_y_end_5d22b7d3:
    y 2v "Не то чтобы меня особо интересовал её стиль..."

translate russian ch3_y_end_afb52001:
    y "Я просто пошла ей навстречу."

translate russian ch3_y_end_e45b137d:
    y "Но..."

translate russian ch3_y_end_c68d2702:
    y 1s "Что ж, пожалуй, иногда написать о чём-то простом не так уж плохо."

translate russian ch3_y_end_79454ffe:
    y 1m "Это может освежить, понимаешь?"

translate russian ch3_y_end_5d1bb453:
    y "Мне полезно время от времени успокаивать свои мысли."

translate russian ch3_y_end_9d91c067:
    mc "Да... пожалуй, соглашусь."

translate russian ch3_y_end_aa50b32a:
    mc "Спасибо, что поделилась."

translate russian ch3_y_end_special_2a706aa2:
    "Дочитав стихотворение, я протягиваю его обратно Юри."

translate russian ch3_y_end_special_00650c09:
    "Но вместо того чтобы взять его, она отводит взгляд."

translate russian ch3_y_end_special_71a86863:
    y "..."

translate russian ch3_y_end_special_41745b04:
    y "Тебе... не нравится?"

translate russian ch3_y_end_special_9dc95788:
    mc "А— нет, конечно, нравится."

translate russian ch3_y_end_special_0c90f7c0:
    mc "Я просто... не знаю, что на это сказать."

translate russian ch3_y_end_special_967ce531:
    "Хоть стихи Юри обычно загадочны, понять, о чём это, было несложно."

translate russian ch3_y_end_special_40da8714:
    "А ещё это явно не то стихотворение, о котором говорила Нацуки..."

translate russian ch3_y_end_special_bacefe7d:
    "...А значит, скорее всего, его она показывает только мне."

translate russian ch3_y_end_special_66a66311:
    y 2v "Н-не знаю, смогу ли я его объяснить..."

translate russian ch3_y_end_special_d969f247:
    mc "Ничего страшного."

translate russian ch3_y_end_special_693b3366:
    mc "Это я понимаю."

translate russian ch3_y_end_special_778bbd0d:
    y 4c "..."

translate russian ch3_y_end_special_0d32b932:
    "Юри даётся говорить ещё тяжелее, чем обычно."

translate russian ch3_y_end_special_9af5ef03:
    mc "Это стихотворение... много для тебя значит?"

translate russian ch3_y_end_special_c588c8d6:
    "Юри кивает."

translate russian ch3_y_end_special_b88f0f95:
    mc "Я не очень умею подбирать слова, но..."

translate russian ch3_y_end_special_b39d66df:
    mc "Я рад, что ты им со мной поделилась."

translate russian ch3_y_end_special_5ad4095e:
    mc "Так что спасибо."

translate russian ch3_y_end_special_dc89fda3:
    mc "И надеюсь, мы и дальше будем проводить время вместе."

translate russian ch3_y_end_special_db13f9fb:
    "Хоть я и не могу посмотреть ей в глаза, я вижу, как на губах Юри появляется лёгкая улыбка."

translate russian ch3_y_end_special_81bfeaf4:
    "Я снова пытаюсь вернуть ей стихотворение."

translate russian ch3_y_end_special_c137d0ec:
    "Но вместо этого Юри мягко берёт меня за руки и отодвигает их обратно ко мне."

translate russian ch3_y_end_special_5df5fce4:
    "От её тёплого прикосновения я замираю."

translate russian ch3_y_end_special_3373ed73:
    y 1v "Ты можешь..."

translate russian ch3_y_end_special_a1300026:
    y "Э-э..."

translate russian ch3_y_end_special_24b12ec4:
    y "Стихотворение..."

translate russian ch3_y_end_special_e570a115:
    "Юри снова не удаётся закончить фразу."

translate russian ch3_y_end_special_84847dff:
    mc "Хочешь сказать, я могу его оставить себе?"

translate russian ch3_y_end_special_c588c8d6_1:
    "Юри кивает."

translate russian ch3_y_end_special_8b8a764a:
    mc "С удовольствием."

translate russian ch3_y_end_special_569c5de3:
    "Юри снова едва заметно улыбается, будто не хочет, чтобы я это заметил."

translate russian ch3_y_end_special_3962c4bd:
    y "С тобой мне всегда..."

translate russian ch3_y_end_special_b41f1bcf:
    y "С тобой мне всегда... так хорошо."

translate russian ch3_y_end_special_44f10fda:
    y "Я знаю, что не очень лажу с людьми, но..."

translate russian ch3_y_end_special_a0352924:
    y "Надеюсь, что... иногда смогу отплатить тебе тем же."

translate russian ch3_y_end_special_cf1adef2:
    mc "Ага."

translate russian ch3_y_end_special_94d64b74:
    mc "Не волнуйся."

translate russian ch3_y_end_special_0c64be78:
    mc "По-моему, у тебя прекрасно получается."

translate russian ch3_y_end_special_cfa2b519:
    "Юри наконец снова поворачивается ко мне."

translate russian ch3_y_end_special_4454245f:
    y 1s "Наверное... нам пора двигаться дальше, пока Моника ничего не сказала."

translate russian ch3_y_end_special_e3f8b2c9:
    y "Но, уверена, мы ещё поговорим потом..."

translate russian ch3_y_end_special_cf1adef2_1:
    mc "Ага."

translate russian ch3_y_end_special_fed264ae:
    mc "Обязательно поговорим."

translate russian ch3_y_end_special_d486bdfc:
    "Юри робко мне улыбается, и я возвращаюсь на своё место, чтобы убрать её стихотворение."

translate russian ch1_n_end_8bc60d0a:
    n 2q "Ну вот..."

translate russian ch1_n_end_142c173a:
    n "Я же говорила, что тебе не понравится."

translate russian ch1_n_end_d3dee951:
    mc "Мне нравится."

translate russian ch1_n_end_34480524:
    n 2h "Что?"

translate russian ch1_n_end_a21b5078:
    n "Просто скажи честно!"

translate russian ch1_n_end_21d60d8b:
    mc "Я честно."

translate russian ch1_n_end_ecb80d6e:
    mc "С чего ты так уверена, что мне не понравится?"

translate russian ch1_n_end_5ac436cf:
    n 5w "Ну—"

translate russian ch1_n_end_a0fd7848:
    n "Потому что!"

translate russian ch1_n_end_1c679434:
    n "В старшей школе все считают, что писать нужно как-нибудь заумно и всё такое..."

translate russian ch1_n_end_b0362bb0:
    n 5q "Поэтому мои тексты даже всерьёз не воспринимают."

translate russian ch1_n_end_37bb2ed8:
    mc "Но разве смысл стихов не в том, чтобы люди выражали себя?"

translate russian ch1_n_end_1037df30:
    mc "Твой стиль никак не умаляет того, что ты хочешь сказать."

translate russian ch1_n_end_e590aff4:
    n 1k "Да! Вот именно!"

translate russian ch1_n_end_07c4c67c:
    n "Мне нравится, когда читается легко, но бьёт прямо в цель."

translate russian ch1_n_end_4953d883:
    n 1c "Как в этом стихотворении."

translate russian ch1_n_end_eb023f69:
    n "Когда видишь, как все вокруг добиваются чего-то великого, это может здорово выбить из колеи..."

translate russian ch1_n_end_856d9a9c:
    n "Вот я и решила об этом написать."

translate russian ch1_n_end_17bdd5f5:
    mc "Да, я понимаю."

translate russian ch1_n_end_2d5e407c:
    n 2a "Но в простых текстах есть и ещё один плюс: больше значит игра слов."

translate russian ch1_n_end_b7bddf1e:
    n "Например, я подвела к рифме в конце, а потом нарочно её сломала."

translate russian ch1_n_end_30b4c81a:
    n "Так сильнее чувствуется последняя строчка."

translate russian ch1_n_end_2e7cfcfe:
    mc "И правда..."

translate russian ch1_n_end_cbc76093:
    mc "Похоже, в него вложено больше, чем я думал."

translate russian ch1_n_end_3e80a161:
    n 4y "Вот что значит профи!"

translate russian ch1_n_end_d399c51a:
    n "Рада, что ты чему-то научился."

translate russian ch1_n_end_cb6fa18b:
    n "Не ожидал такого от самой младшей, а?"

translate russian ch1_n_end_e94aacb9:
    mc "Да... пожалуй, нет."

translate russian ch1_n_end_fb5f7062:
    "На последнюю фразу я решаю ей подыграть."

translate russian ch1_n_end_87970ac1:
    "Мне, в общем-то, всё равно, кому сколько лет, но раз Нацуки так гордится, не буду её разубеждать."

translate russian ch2_n_end_dd108a9d:
    n 2a "Неплохо, правда?"

translate russian ch2_n_end_60187f07:
    mc "Оно куда длиннее вчерашнего."

translate russian ch2_n_end_eb02eb50:
    n 2w "Вчерашнее было слишком коротким..."

translate russian ch2_n_end_3f4cc55b:
    n "Я просто разминалась!"

translate russian ch2_n_end_d1347742:
    n 2c "Надеюсь, ты не подумал, что это предел моих возможностей."

translate russian ch2_n_end_9b943f22:
    mc "Нет, конечно..."

translate russian ch2_n_end_ae8ffbf5:
    n 2a "В общем, смысл у этого стихотворения довольно очевидный."

translate russian ch2_n_end_038f9631:
    n "Вряд ли его нужно объяснять."

translate russian ch2_n_end_b1f57678:
    n 2c "Иногда сложные вещи можно объяснить куда более простыми сравнениями..."

translate russian ch2_n_end_3172d35d:
    n "И тогда люди понимают, как глупо себя ведут."

translate russian ch2_n_end_d97a6e91:
    n 2g "Ну, то есть любой согласится, что герой этого стихотворения — невежественный придурок..."

translate russian ch2_n_end_83e5c791:
    mc "Ты знаешь таких людей?"

translate russian ch2_n_end_b5672bed:
    n 2c "Конечно. Это о том, как все считают, что моя—"

translate russian ch2_n_end_c7bb1f66:
    n 5w "...Это неважно! Оно может быть о чём угодно!"

translate russian ch2_n_end_585f6446:
    n 5h "Я написала его так, чтобы каждый мог узнать в нём себя..."

translate russian ch2_n_end_81bb56c3:
    n "У всех есть какое-нибудь странное хобби или тайная слабость."

translate russian ch2_n_end_ff0627ba:
    n 5q "Что-то, о чём боишься, что если люди узнают — засмеют или станут думать о тебе хуже."

translate russian ch2_n_end_a24ab514:
    n 1e "...Но от этого глупые как раз они!"

translate russian ch2_n_end_0a24a428:
    n "Какая разница, что кому нравится, если это никому не вредит и делает человека счастливым?"

translate russian ch2_n_end_89f0d418:
    n 1q "По-моему, людям правда нужно научиться уважать других, даже если тем нравятся странные вещи..."

translate russian ch2_n_end_5b1ae15d:
    mc "Хм, забавно..."

translate russian ch2_n_end_d1065305:
    mc "Юри сегодня написала о чём-то похожем."

translate russian ch2_n_end_00a51a21:
    n 1h "А?"

translate russian ch2_n_end_dbe127d0:
    n "Ты сказал — Юри?"

translate russian ch2_n_end_69c25b65:
    mc "Да..."

translate russian ch2_n_end_ed23577e:
    mc "Она сказала, что её стихотворение — об одном её необычном увлечении."

translate russian ch2_n_end_f7ab9610:
    mc "Я его толком не понял, но она говорила что-то похожее на тебя..."

translate russian ch2_n_end_a403e768:
    mc "Что люди не должны заставлять друг друга стыдиться таких вещей."

translate russian ch2_n_end_9bdce4df:
    n 1q "Правда?"

translate russian ch2_n_end_228e3b68:
    n "Ну..."

translate russian ch2_n_end_6fbb1460:
    n 1t "Ну, Юри довольно странная, так что я не удивлюсь, если у неё какие-нибудь странные хобби..."

translate russian ch2_n_end_5437b16a:
    n "...Не то чтобы в этом было что-то плохое!"

translate russian ch2_n_end_84b5aa9d:
    n 1u "У-у..."

translate russian ch2_n_end_6c4b6440:
    n "Не то чтобы... я стала её осуждать или ещё что..."

translate russian ch2_n_end_6095f763:
    "Нацуки никак не может подобрать слова."

translate russian ch2_n_end_0f2ba2e6:
    n 1q "Н-наверное, мне стоит быть с ней не такой злюкой..."

translate russian ch2_n_end_dbe057d9:
    n "Раз она стесняется своих странностей и всего такого..."

translate russian ch2_n_end_37e21fa0:
    n "Ну, я вот всегда терпеть не могу людей, из-за которых чувствую себя неуверенно..."

translate russian ch2_n_end_db0decad:
    n 1w "А вчера Юри как раз заставила меня так себя почувствовать!"

translate russian ch2_n_end_96a143b0:
    n 1s "Но по твоим словам похоже, что она усвоила урок..."

translate russian ch2_n_end_c8200692:
    mc "Что ж, я бы сказал, что да."

translate russian ch2_n_end_005bbbce:
    mc "Пусть у неё совсем другой стиль, уверен, она оценит смысл твоего стихотворения."

translate russian ch2_n_end_15d04663:
    mc "Что ж, ты абсолютно права."

translate russian ch2_n_end_5c3fc08d:
    mc "По крайней мере, мне это знакомо."

translate russian ch2_n_end_e4b24602:
    mc "И, уверен, многим другим тоже."

translate russian ch2_n_end_cb52b8b3:
    n 4h "Знаешь..."

translate russian ch2_n_end_1b4d30d3:
    n "Я рада, что ты ценишь такие тексты..."

translate russian ch2_n_end_01b8854b:
    n 4q "Ну... я знаю, что вчера уже об этом говорила."

translate russian ch2_n_end_ea6ff1f9:
    n "Но мне... в общем, мне нравится показывать тебе свои тексты, так что..."

translate russian ch2_n_end_da826cb1:
    n 4w "...Так что считай, что тебе повезло, ясно?"

translate russian ch2_n_end_ee7d9dbd:
    mc "А-ха-ха."

translate russian ch2_n_end_30f93a8f:
    mc "Что ж, спасибо за честность."

translate russian ch2_n_end_fe3d9171:
    n 1n "Это ещё что значит?"

translate russian ch2_n_end_4989bca6:
    n "Я всегда честная!"

translate russian ch2_n_end_afb600b7:
    n 12b "Блин..."

translate russian ch2_n_end_07b7c0fd:
    n "Просто жди и завтрашнего тоже, ладно?"

translate russian ch2_n_end_fd5f8bbc:
    mc "Ладно, буду ждать."

translate russian ch2_n_end_df407eec:
    n 4c "Это ведь у меня лучше всего получается!"

translate russian ch2_n_end_2dfb5cb0:
    n "Не люблю писать, если из текста нельзя вынести что-то стоящее."

translate russian ch2_n_end_ea30310f:
    n "Ну, передавать чувства — это важно..."

translate russian ch2_n_end_8c60d0ad:
    n "Но я хочу, чтобы люди задумывались, а не только чувствовали."

translate russian ch2_n_end_d2d33a6f:
    n 4b "Запомни это!"

translate russian ch2_n_end_551f7269:
    n "К завтрашнему дню я тоже напишу хорошее стихотворение, так что жди."

translate russian ch3_n_end_414b5f0c:
    n 2a "Ну вот..."

translate russian ch3_n_end_a8d27ddf:
    n "Мне показалось, что я всё время пишу о плохом, так что в кои-то веки захотелось написать что-то с хорошим смыслом."

translate russian ch3_n_end_badae2c6:
    n 2z "К тому же... пляж — это здорово!"

translate russian ch3_n_end_d4849c6b:
    n 2j "О пляже как-то сложно написать что-нибудь плохое."

translate russian ch3_n_end_fcf484f2:
    mc "То есть ты сначала решила написать о пляже, а смысл придумала потом?"

translate russian ch3_n_end_d9e61fcc:
    n 2c "Ну да, в общем..."

translate russian ch3_n_end_ff427fc5:
    n "Это всё из-за вчерашнего."

translate russian ch3_n_end_a898b508:
    n 5q "Ну, после того как мы с Юри поняли, что написали как бы об одном и том же..."

translate russian ch3_n_end_9c8cb24c:
    n "Она захотела выбрать тему, чтобы мы обе по ней написали, или что-то такое."

translate russian ch3_n_end_a7bcf340:
    mc "Понятно..."

translate russian ch3_n_end_f69d1672:
    "Мне особо нечего добавить — стихотворение Юри я ведь так и не прочитал..."

translate russian ch3_n_end_a7bcf340_1:
    mc "Понятно..."

translate russian ch3_n_end_c5c52c14:
    "Что-то мне подсказывает, что стихотворение, которое показала мне Юри, — не то, которым она собирается делиться с остальными..."

translate russian ch3_n_end_7a8c5a9c:
    "Разумеется, Нацуки я об этом не говорю."

translate russian ch3_n_end_c722c4b2:
    mc "Ну, у Юри получилось немного мрачнее."

translate russian ch3_n_end_3355af86:
    n 5h "Ну, это—"

translate russian ch3_n_end_e897feb4:
    n 42c "Блин... пусть только попробует сказать что-нибудь плохое про моё!"

translate russian ch3_n_end_d19ef80f:
    n "Она ведь сама захотела, чтобы мы писали на одну тему."

translate russian ch3_n_end_4e355357:
    n 1s "Фу... это так на неё похоже."

translate russian ch3_n_end_415f6d11:
    n "Заставить нас писать на простую тему, а потом пытаться впечатлить меня какой-нибудь вычурной ерундой."

translate russian ch3_n_end_68618747:
    n 1w "Ну и ладно, мне-то что."

translate russian ch3_n_end_a70f6259:
    n "Я всё равно написала."

translate russian ch3_n_end_11801a2a:
    n 1q "То есть моё тоже вышло, наверное, немного метафоричным..."

translate russian ch3_n_end_2b3a7296:
    n "...Но иногда в этом нет ничего плохого!"

translate russian ch3_n_end_2221c3bc:
    n "По крайней мере, хорошая тренировка."

translate russian ch3_n_end_special_e9173862:
    n 1q "..."

translate russian ch3_n_end_special_e6529392:
    n "...Ты чего на меня так смотришь?"

translate russian ch3_n_end_special_1825e66c:
    n "Если не нравится, так и скажи."

translate russian ch3_n_end_special_0342295b:
    n 1u "Я не... разозлюсь."

translate russian ch3_n_end_special_69e4e05c:
    mc "Нет, дело не в том, что мне не нравится...!"

translate russian ch3_n_end_special_1a40fb94:
    mc "Просто... было немного неожиданно это прочитать."

translate russian ch3_n_end_special_83b6981f:
    "Это явно не то стихотворение, о котором мне рассказывала Юри..."

translate russian ch3_n_end_special_bacefe7d:
    "...А значит, скорее всего, его она показывает только мне."

translate russian ch3_n_end_special_ea8aa9a8:
    mc "Э-э... наверное, я просто не привык слышать от тебя такие приятные вещи..."

translate russian ch3_n_end_special_f9917ed7:
    n 1h "Н-не говори так!"

translate russian ch3_n_end_special_a26aa930:
    n 1n "Дурак..."

translate russian ch3_n_end_special_50b8fc71:
    n "Как ты думаешь... в чём смысл писательства?"

translate russian ch3_n_end_special_667815e2:
    n 1u "Выразить то, что не можешь просто сказать..."

translate russian ch3_n_end_special_8f04ea9e:
    mc "Да... понимаю."

translate russian ch3_n_end_special_c9fcaaa9:
    mc "Прости, что иногда не улавливаю смысла."

translate russian ch3_n_end_special_2ea97b1b:
    mc "Я всегда желаю только хорошего..."

translate russian ch3_n_end_special_9563dbe7:
    mc "И... я рад, что ты мне это показала."

translate russian ch3_n_end_special_8dec91ad:
    mc "Мне понравилось."

translate russian ch3_n_end_special_aaeb54a0:
    n 1h "Ну... да..."

translate russian ch3_n_end_special_faf3284b:
    n 1q "Я же... я же профи, так что..."

translate russian ch3_n_end_special_a230e7fc:
    "Нацуки бормочет это, и у неё совсем не получается звучать уверенно, как обычно."

translate russian ch3_n_end_special_527e1928:
    n "Просто..."

translate russian ch3_n_end_special_66d32072:
    n 12c "Запомни, что... я тоже иногда так думаю!"

translate russian ch3_n_end_special_f4d23eb0:
    n "Знаешь, когда ты со мной добр, это..."

translate russian ch3_n_end_special_3aeee00a:
    n 12a "..."

translate russian ch3_n_end_special_33cc570e:
    n "...Много значит."

translate russian ch3_n_end_special_df93c20f:
    mc "А... я рад."

translate russian ch3_n_end_special_6e96852a:
    "Почувствовав, что Нацуки довольна, я протягиваю ей стихотворение обратно."

translate russian ch3_n_end_special_d33d2ed4:
    "Но Нацуки берёт меня за руки и отталкивает их."

translate russian ch3_n_end_special_f19a9b83:
    "Меня удивляет, как настойчивы её маленькие мягкие ладони."

translate russian ch3_n_end_special_0ff74f7f:
    n 12b "Мне оно не нужно."

translate russian ch3_n_end_special_bbe4458e:
    mc "А...?"

translate russian ch3_n_end_special_56c3991c:
    mc "Почему?"

translate russian ch3_n_end_special_185521b7:
    n 12c "Просто не нужно!"

translate russian ch3_n_end_special_a8557d5c:
    n "Блин..."

translate russian ch3_n_end_special_9a0675d7:
    "Я понимаю, что делает Нацуки."

translate russian ch3_n_end_special_5ecdadf6:
    "Не в силах сказать прямо, она пытается окольными путями подарить мне это стихотворение."

translate russian ch3_n_end_special_00801b73:
    mc "Ну... раз так, я его оставлю себе."

translate russian ch3_n_end_special_aedc0f57:
    "Вместо того чтобы её подкалывать, я решаю ей подыграть."

translate russian ch3_n_end_special_c27d8493:
    n 1t "...Вот и хорошо."

translate russian ch3_n_end_special_552ff42d:
    n "А то я бы..."

translate russian ch3_n_end_special_bb2cf764:
    n "..."

translate russian ch3_n_end_special_b5e34640:
    n 1h "Забудь..."

translate russian ch3_n_end_special_a506398c:
    n 1q "Просто... я рада, что оно тебе нужно."

translate russian ch3_n_end_special_3cd314cd:
    "Нацуки обрывает себя на полуслове и на этом замолкает."

translate russian ch3_n_end_special_b62c10bb:
    "Как бы она ни старалась спрятать лицо, я вижу, что она слегка улыбается."

translate russian ch3_n_end_special_842a5d0d:
    n "Пока что всё, так что..."

translate russian ch3_n_end_special_0f718df6:
    n 1s "Иди убери его, пока никто не увидел, ладно?"

translate russian ch3_n_end_special_21d5c9ec:
    mc "А... да."

translate russian ch3_n_end_special_22b3e162:
    mc "Сейчас уберу."

translate russian ch3_n_end_special_e099d11a:
    "И я возвращаюсь на своё место, чтобы убрать стихотворение Нацуки."

translate russian ch1_s_end_e87e0575:
    mc "Сайори..."

translate russian ch1_s_end_c878179c:
    mc "Это просто догадка, но..."

translate russian ch1_s_end_ee942d6f:
    mc "Ты что, написала это только сегодня утром?"

translate russian ch1_s_end_c7a4af52:
    s 4h "Нет!"

translate russian ch1_s_end_659f3f9f:
    s 4l "Ч-чуть-чуть!"

translate russian ch1_s_end_117ad0c7:
    mc "Нельзя отвечать «чуть-чуть», когда спрашивают «да» или «нет»..."

translate russian ch1_s_end_3ec02b40:
    s 5b "Я забыла сделать это вечером..."

translate russian ch1_s_end_1ef71577:
    mc "Что ж, мне от этого хотя бы чуточку легче..."

translate russian ch1_s_end_7794a4fa:
    s 1h "Не вредничай!"

translate russian ch1_s_end_66e312d4:
    s "Я всё равно очень старалась..."

translate russian ch1_s_end_d080b42e:
    mc "А, ну да..."

translate russian ch1_s_end_74f745b3:
    mc "Я не хотел сказать, что стихотворение плохое."

translate russian ch1_s_end_a42d9969:
    mc "Оно вышло милым... или как бы это сказать..."

translate russian ch1_s_end_6eea2305:
    mc "Оно прямо как ты."

translate russian ch1_s_end_e99aeedf:
    s 1d "Правда?"

translate russian ch1_s_end_cf1adef2:
    mc "Ага."

translate russian ch1_s_end_5b9eafb1:
    mc "Особенно последняя строчка..."

translate russian ch1_s_end_513164ac:
    s 4r "Я сделала яичницу с тостами!"

translate russian ch1_s_end_9fbed175:
    mc "Хотя опоздала в школу...?"

translate russian ch1_s_end_53229aa9:
    s 5d "Пропускать завтрак вредно!"

translate russian ch1_s_end_ed9a7c92:
    s "Я тогда становлюсь вреднючая..."

translate russian ch1_s_end_3748b1c9:
    mc "Что ж, спорить, похоже, бесполезно..."

translate russian ch1_s_end_b9610080:
    mc "В общем, спасибо, что показала."

translate russian ch1_s_end_4fe8273d:
    s 1q "Э-хе-хе~"

translate russian ch1_s_end_3dbfe6ed:
    s "Это было так весело."

translate russian ch1_s_end_6eddcdae:
    s "Моника — лучшая!"

translate russian ch1_s_end_21d5c9ec:
    mc "А... да."

translate russian ch1_s_end_6f0fbb10:
    s "Но в следующий раз я не забуду."

translate russian ch1_s_end_bcd6ab2b:
    s 4x "И напишу самое лучшее стихотворение на свете!"

translate russian ch1_s_end_22f6c2ab:
    mc "Что ж, буду ждать."

translate russian ch2_s_end_b948e61c:
    mc "Офигеть..."

translate russian ch2_s_end_8fb6ea4c:
    mc "Сайори, ты правда сама это написала?"

translate russian ch2_s_end_16644702:
    s 2j "Конечно, сама!"

translate russian ch2_s_end_b86c1a4e:
    s "Я же вчера говорила, что напишу самое лучшее стихотворение на свете!"

translate russian ch2_s_end_3f1ca1d2:
    mc "Да, но..."

translate russian ch2_s_end_640c011f:
    mc "В смысле, я не ожидал от тебя чего-то подобного."

translate russian ch2_s_end_c9617efa:
    s 4x "Моника меня столькому научила!"

translate russian ch2_s_end_5b6217f3:
    s "И в последнее время я очень хорошо чувствую свои чувства..."

translate russian ch2_s_end_db0a80fc:
    mc "Это видно..."

translate russian ch2_s_end_23f147a9:
    mc "Даже как-то жутковато."

translate russian ch2_s_end_1e5c8711:
    s 1b "Жутковато...?"

translate russian ch2_s_end_0a69f140:
    mc "Ну, не совсем..."

translate russian ch2_s_end_a3d4a943:
    mc "Может, потому что я так привык, что ты всегда весёлая..."

translate russian ch2_s_end_b28a88bd:
    mc "...Ладно, неважно."

translate russian ch2_s_end_a4854ef3:
    mc "Я слишком много об этом думаю."

translate russian ch2_s_end_128af0a1:
    mc "Главное — получилось хорошо, так что можешь им гордиться."

translate russian ch2_s_end_ad10533a:
    s 1y "Ой, спасибо~"

translate russian ch2_s_end_3230acd6:
    s "Мне кажется..."

translate russian ch2_s_end_55e33248:
    s "Мне кажется, мне суждено было выражать себя именно так."

translate russian ch2_s_end_bec738c1:
    s "Это даже помогает мне чуточку лучше понимать свои чувства..."

translate russian ch2_s_end_8672d104:
    s 1a "Писать — это как волшебство!"

translate russian ch2_s_end_3c63b06f:
    mc "Ты и правда здорово увлеклась, а?"

translate russian ch2_s_end_77ffde91:
    mc "Надеюсь, ты не бросишь."

translate russian ch2_s_end_3f7af878:
    s 4r "Да!"

translate russian ch2_s_end_bf0a1a54:
    s "Писать — это лучше всего!"

translate russian ch2_s_end_40f9d900:
    s "Я буду писать, пока не умру!"

translate russian ch2_s_end_11a271d6:
    mc "А-ха-ха... не загадывай так далеко."

translate russian ch2_s_end_6b24e22f:
    "У Сайори всегда была привычка чем-нибудь загореться, а через неделю, не больше, бросить."

translate russian ch2_s_end_6497c710:
    "Интересно, это как раз такой случай?"

translate russian ch2_s_end_71190d58:
    "Но когда я вижу этот огонь в её глазах, мне трудно быть пессимистом."

translate russian ch1_m_end2_f9598f81:
    m 1a "Ну... что скажешь?"

translate russian ch1_m_end2_8951491e:
    mc "Хм... оно очень... свободное, если это так называется."

translate russian ch1_m_end2_ea07765a:
    mc "Прости, я не тот человек, у которого стоит спрашивать отзывы..."

translate russian ch1_m_end2_7baaab6d:
    m 2e "А-ха-ха. Ничего страшного."

translate russian ch1_m_end2_fdd0218d:
    m 2b "Да, в наше время такой стиль стал довольно популярным."

translate russian ch1_m_end2_96b28dbc:
    m "То есть во многих стихах теперь важны паузы между словами и строками."

translate russian ch1_m_end2_159edef2:
    m 2a "Если читать такие вслух, они могут производить очень сильное впечатление."

translate russian ch1_m_end2_d87d0224:
    mc "А что вдохновило тебя на это?"

translate russian ch1_m_end2_f0139694:
    m "Ах..."

translate russian ch1_m_end2_f414689b:
    m 3d "Ну, даже не знаю, как бы это выразить..."

translate russian ch1_m_end2_3647305a:
    m 3a "Можно сказать, что на меня недавно снизошло что-то вроде озарения."

translate russian ch1_m_end2_77a94eab:
    m "И оно немного сказывается на моих стихах."

translate russian ch1_m_end2_0884f9b2:
    mc "Озарения?"

translate russian ch1_m_end2_5a8a1eb2:
    m 1a "Да... что-то вроде того."

translate russian ch1_m_end2_ef875d46:
    m "Мне немного боязно говорить о таких серьёзных вещах, это может прозвучать слишком напористо..."

translate russian ch1_m_end2_8fddb757:
    m "Может, когда мы все получше подружимся."

translate russian ch1_m_end2_cba62eca:
    m 1j "В общем..."

translate russian ch1_m_end2_16f290c4:
    m 3b "Писательский совет дня от Моники!"

translate russian ch1_m_end2_b8a9badc:
    m "Иногда, когда пишешь стихотворение — или рассказ, — мозг слишком зацикливается на чём-то одном..."

translate russian ch1_m_end2_e2b1796a:
    m "Если очень стараться сделать всё идеально, то так и не сдвинешься с места."

translate russian ch1_m_end2_c2f1ac93:
    m "Просто заставь себя хоть что-нибудь записать на бумаге, а доработаешь потом!"

translate russian ch1_m_end2_aab3b6e6:
    m "Можно посмотреть на это и по-другому:"

translate russian ch1_m_end2_a531d1f7:
    m "если слишком долго держать ручку на одном месте, получится просто большая тёмная клякса."

translate russian ch1_m_end2_6b20b3a2:
    m "Так что просто веди рукой и плыви по течению!"

translate russian ch1_m_end2_a33519f4:
    m 3k "...Вот и мой совет на сегодня!"

translate russian ch1_m_end2_d33852a1:
    m "Спасибо, что выслушал~"

translate russian ch2_m_end_a19d2ac7:
    mc "Хм..."

translate russian ch2_m_end_445dfd5f:
    mc "Оно даже абстрактнее твоего прошлого, да?"

translate russian ch2_m_end_4e571793:
    m 5 "А-ха-ха..."

translate russian ch2_m_end_34d9ca1b:
    m "Наверное, я просто так пишу..."

translate russian ch2_m_end_6badc82a:
    m "Прости, если тебе не нравится."

translate russian ch2_m_end_46982dd0:
    mc "Нет, я такого не говорил."

translate russian ch2_m_end_3f6dcb2d:
    mc "Просто я, кажется, никогда раньше такого не видел."

translate russian ch2_m_end_25dc232d:
    m 2a "Мне нравится играть с пространством на листе..."

translate russian ch2_m_end_046fa6c3:
    m "От того, где и как расставить слова, настроение стихотворения может полностью измениться."

translate russian ch2_m_end_bef599f6:
    m 2b "Это почти как волшебство."

translate russian ch2_m_end_3726dbfb:
    m "Из-за того, что строчки такие короткие, кажется, будто они пытаются перекричать шум."

translate russian ch2_m_end_a7bcf340:
    mc "Понятно..."

translate russian ch2_m_end_96778f53:
    mc "Но мне всё равно сложно понять, о чём оно."

translate russian ch2_m_end_02d21b3c:
    m 2k "А-ха-ха."

translate russian ch2_m_end_2d129b79:
    m 4a "Иногда спрашивать, о чём стихотворение, — не совсем правильный вопрос."

translate russian ch2_m_end_634d9df7:
    m "Стихотворение может быть таким же абстрактным, как физическое выражение чувства."

translate russian ch2_m_end_d784117b:
    m "Или разговором с читателем."

translate russian ch2_m_end_961b7248:
    m "Так что, если посмотреть с этой стороны, не каждое стихотворение {i}о{/i} чём-то."

translate russian ch2_m_end_c9062bfa:
    m "В общем..."

translate russian ch2_m_end_16f290c4:
    m 3b "Писательский совет дня от Моники!"

translate russian ch2_m_end_6417a080:
    m "Иногда тебе придётся принимать трудное решение..."

translate russian ch2_m_end_a151287c:
    m "Когда это случится, не забудь сохранить игру!"

translate russian ch2_m_end_3727408b:
    m "Никогда не знаешь, когда передумаешь..."

translate russian ch2_m_end_303c0b3c:
    m "...или когда произойдёт что-нибудь неожиданное!"

translate russian ch2_m_end_9f5e28af:
    m 3d "Подожди... этот совет вообще про писательство?"

translate russian ch2_m_end_abb6063d:
    m 3k "Что я вообще несу?"

translate russian ch2_m_end_30727938:
    m "А-ха-ха!"

translate russian ch2_m_end_fb668315:
    m 3b "...Вот и мой совет на сегодня!"

translate russian ch2_m_end_d33852a1:
    m "Спасибо, что выслушал~"

translate russian ch3_m_end_0d2947fd:
    m 1a "Знаешь..."

translate russian ch3_m_end_736ddbc7:
    m "Мне кажется, именно учёба и поиск ответов придают жизни смысл."

translate russian ch3_m_end_aeaf0049:
    m 1e "Не хочу впадать в философию..."

translate russian ch3_m_end_70059a5b:
    m 1a "Но это не выходило у меня из головы, вот я об этом и написала."

translate russian ch3_m_end_a7bcf340:
    mc "Понятно..."

translate russian ch3_m_end_5698057b:
    mc "Никогда особо об этом не задумывался."

translate russian ch3_m_end_4a5c14cb:
    m 1d "В каком-то смысле это почти парадокс."

translate russian ch3_m_end_c09e1fe0:
    m "Ведь если бы у нас были все ответы, разве мир не начал бы терять смысл?"

translate russian ch3_m_end_d7a970c0:
    mc "Знаешь, я заметил одну вещь..."

translate russian ch3_m_end_4b3c68a6:
    mc "Похоже, все в клубе предпочитают писать скорее о грустном, чем о радостном."

translate russian ch3_m_end_55f7b244:
    m 1k "А-ха-ха. Удивлён?"

translate russian ch3_m_end_22eeeab7:
    m 1a "Ну, если бы всё было хорошо..."

translate russian ch3_m_end_bd63c742:
    m "Нам ведь было бы особо не о чем писать, правда?"

translate russian ch3_m_end_3145f5df:
    m "Люди — не двумерные существа."

translate russian ch3_m_end_e1fd08ed:
    m "Думаю, тебе это известно лучше, чем кому-либо."

translate russian ch3_m_end_171be076:
    mc "Может, ты хотела сказать «одномерные»...?"

translate russian ch3_m_end_7174b56f:
    m 1l "А... да, точно!"

translate russian ch3_m_end_35ec09b1:
    m 1a "В общем..."

translate russian ch3_m_end_16f290c4:
    m 3b "Писательский совет дня от Моники!"

translate russian ch3_m_end_9fc6f159:
    m "Тебе бывает неловко делиться своими текстами, потому что боишься, что они недостаточно хороши?"

translate russian ch3_m_end_82281340:
    m "Очень обидно получить вялый отклик на то, во что вложил столько сил."

translate russian ch3_m_end_789075aa:
    m "Но если найти других людей, которым нравится писать, делиться станет куда проще!"

translate russian ch3_m_end_4726e288:
    m "Ведь вместо того, чтобы просто сказать, что написано хорошо, нормально или плохо..."

translate russian ch3_m_end_b702b7f6:
    m "Они захотят разобраться, что ты в это вложил и над чем ещё можно поработать."

translate russian ch3_m_end_a38a6554:
    m "Так куда воодушевлённее, и тебе захочется становиться всё лучше."

translate russian ch3_m_end_2496c031:
    m "Это почти как свой маленький Литературный клуб, правда?"

translate russian ch3_m_end_a33519f4:
    m 3k "...Вот и мой совет на сегодня!"

translate russian ch3_m_end_d33852a1:
    m "Спасибо, что выслушал~"

translate russian ch1_n_bad_bb2cf764:
    n "..."

translate russian ch1_n_bad_652650d3:
    mc "...?"

translate russian ch1_n_bad_786bdaab:
    n 2b "[player], если не собираешься относиться к клубу всерьёз, иди домой."

translate russian ch1_n_bad_a30b6398:
    mc "Ч-что??"

translate russian ch1_n_bad_5651f4a1:
    mc "Жёстко..."

translate russian ch1_n_bad_26cfc3e6:
    n 42c "Что, думаешь, я поверю, что ты правда постарался?"

translate russian ch1_n_bad_ab684906:
    n "За дуру меня держишь?"

translate russian ch1_n_bad_9f6464ea:
    mc "Я не писатель!"

translate russian ch1_n_bad_c311eb62:
    mc "Может, оно и не очень хорошее, но да, я старался."

translate russian ch1_n_bad_5b1182db:
    mc "Все ведь с чего-то начинают, правда?"

translate russian ch1_n_bad_9d7973b8:
    mc "Если ты до сих пор гордишься самым первым стихотворением, которое {i}ты{/i} написала, я бы с удовольствием его прочитал."

translate russian ch1_n_bad_fb415e31:
    n 1o "!!"

translate russian ch1_n_bad_35c03e92:
    mc "Больно вспоминать?"

translate russian ch1_n_bad_80e20624:
    n 1r "..."

translate russian ch1_n_bad_d98d7b9b:
    n 5q "Ладно."

translate russian ch1_n_bad_6187bb25:
    n "Ну, извини."

translate russian ch1_n_bad_db382f9c:
    n 5c "Всё равно у тебя будет получаться лучше."

translate russian ch1_n_bad_e1238cef:
    n "Я бы сказала, что исправить, но тебе лучше просто попробовать ещё раз."

translate russian ch1_n_bad_b821d969:
    mc "Справедливо..."

translate russian ch1_n_bad_082fbec8:
    mc "Что ж, на вкус и цвет, как говорится."

translate russian ch1_n_bad_77b4fba0:
    n 5q "В общем, видимо, теперь мне надо показать своё..."

translate russian ch1_n_bad_3c64437c:
    n "Зная тебя, ты наверняка решишь, что это глупо."

translate russian ch1_n_med_bb2cf764:
    n "..."

translate russian ch1_n_med_652650d3:
    mc "...?"

translate russian ch1_n_med_f50aa6b2:
    n 2k "...Ну, примерно этого я и ожидала от такого, как ты."

translate russian ch1_n_med_fd658052:
    mc "Как-то резковато..."

translate russian ch1_n_med_c5c0875b:
    n 2c "Ну, извини уж."

translate russian ch1_n_med_6987a57a:
    n "Я же не сказала, что оно плохое."

translate russian ch1_n_med_bc85dd5b:
    n "Просто оно не вызвало никаких эмоций."

translate russian ch1_n_med_a6171a16:
    mc "То есть, по сути, оно недостаточно милое на твой вкус?"

translate russian ch1_n_med_ab6a83ff:
    n 4f "Хочешь получить по шее?"

translate russian ch1_n_med_ba837edb:
    mc "Пожалуй, откажусь..."

translate russian ch1_n_med_145a8f80:
    n 42b "Эх..."

translate russian ch1_n_med_47a17aad:
    n 42c "Ну, в общем, видимо, мне надо показать тебе своё."

translate russian ch1_n_med_a6471b3f:
    n 4q "Не то чтобы тебе понравилось."

translate russian ch1_n_good_bb2cf764:
    n "..."

translate russian ch1_n_good_652650d3:
    mc "...?"

translate russian ch1_n_good_be5d8140:
    n 1t "...Так, начнём с того, что мне не нравится!"

translate russian ch1_n_good_7506a369:
    n "Во-первых, э-э..."

translate russian ch1_n_good_2b35b6fe:
    mc "..."

translate russian ch1_n_good_c10c8081:
    "Нацуки перечитывает моё стихотворение."

translate russian ch1_n_good_9231e4a6:
    n 4c "Н-ну и ладно. Не хочу говорить тебе своё мнение."

translate russian ch1_n_good_92147903:
    mc "А? Тогда какой вообще смысл делиться?"

translate russian ch1_n_good_445bc0d6:
    mc "Я писал его, хотя мог бы заняться чем-то другим."

translate russian ch1_n_good_def3e8a4:
    n 4r "У-у..."

translate russian ch1_n_good_b3544d0e:
    mc "Кстати, помнишь, я говорил, что хочу почитать твои стихи?"

translate russian ch1_n_good_b2849037:
    mc "Вот об этом я и думал, когда писал."

translate russian ch1_n_good_f885db06:
    mc "Мне хочется, чтобы тебе было не так страшно показывать свои."

translate russian ch1_n_good_c9ee794e:
    mc "Как и сказала Моника."

translate russian ch1_n_good_bffa2ce6:
    n 4x "У-у-у-у...!"

translate russian ch1_n_good_0bebb6aa:
    n 1h "Ну, мне было бы проще показать своё, если бы твоё было совсем плохим!"

translate russian ch1_n_good_0692f7bf:
    n 1w "Ты должен был показать какой-нибудь дурацкий стишок, чтобы я сказала: „Ха, ну так себе, а теперь смотри, как выглядит настоящая литература!“"

translate russian ch1_n_good_b0d75767:
    n 1h "А ты взял и всё испортил!"

translate russian ch1_n_good_f92b13ed:
    n "Надеюсь, ты доволен!"

translate russian ch1_n_good_2b35b6fe_1:
    mc "..."

translate russian ch1_n_good_076c375f:
    mc "...То есть, другими словами, тебе понравилось?"

translate russian ch1_n_good_dc97139b:
    n 1o "Кх—"

translate russian ch1_n_good_4cc880ec:
    "Ответ застревает у Нацуки в горле."

translate russian ch1_n_good_729a90d8:
    n 1x "У-у-у-у-у-у-у-у... Какой же ты...!"

translate russian ch1_n_good_edc6ab45:
    n "Ты просто... ты... ничего не понимаешь, да?"

translate russian ch1_n_good_2dd54ba3:
    n 5q "Я тебе уже это сказала, не надо объявлять об этом на весь мир с таким важным видом!"

translate russian ch1_n_good_c83628af:
    mc "Вообще-то, ты этого так и не сказала..."

translate russian ch1_n_good_e5c10794:
    "Это я говорю скорее себе."

translate russian ch1_n_good_3d3eb203:
    "Наверное, Нацуки меня просто ненавидит."

translate russian ch1_n_good_ac559f6e:
    "Не пойму: то, что ей понравилось моё стихотворение, — это победа или поражение?"

translate russian ch1_n_good_442b6d4e:
    mc "В любом случае... Тебе ведь всё равно нужно показать мне своё, да?"

translate russian ch1_n_good_a817884c:
    n 5s "Гр-р... Ладно уж."

translate russian ch1_n_good_d2e89e86:
    n "Только потому, что иначе Моника меня заставит."

translate russian ch2_n_bad_a9238065:
    n "...Хм."

translate russian ch2_n_bad_5d9aad6c:
    n 2k "Что ж, признаю, оно лучше прошлого."

translate russian ch2_n_bad_0d4958b9:
    n "Приятно видеть, что ты хоть немного стараешься."

translate russian ch2_n_bad_0c1a926e:
    mc "Уже хорошо..."

translate russian ch2_n_bad_88ad311c:
    n 2c "Но мне оно всё равно совсем не нравится."

translate russian ch2_n_bad_b0bc4dd3:
    n "Слишком уж оно пытается быть серьёзным."

translate russian ch2_n_bad_d85cb98c:
    mc "А? Что ты имеешь в виду?"

translate russian ch2_n_bad_sharedwithch3_450073cc:
    n 4c "Стихам не нужно звучать глубокомысленно, чтобы что-то выразить."

translate russian ch2_n_bad_sharedwithch3_aad0a30c:
    n "Если ты не настоящий мастер, всё будет звучать натянуто."

translate russian ch2_n_bad_sharedwithch3_5c28c9d7:
    n 4w "Честно... Даже не пытайся писать такие стихи, пока не дорастёшь до уровня Юри—"

translate russian ch2_n_bad_sharedwithch3_cde110ce:
    "Нацуки вдруг осекается."

translate russian ch2_n_bad_sharedwithch3_dc2b3681:
    n 1o "Т-только не говори..."

translate russian ch2_n_bad_sharedwithch3_fb2e5377:
    mc "А?"

translate russian ch2_n_bad_sharedwithch3_241edb08:
    n "Ты ведь... ты ведь не пытаешься просто впечатлить Юри?!"

translate russian ch2_n_bad_sharedwithch3_e942cdcc:
    mc "Ч-что ты несёшь?? И потише...!"

translate russian ch2_n_bad_sharedwithch3_bcaffe77:
    n 1x "Ты же знаешь, что Юри обожает такие... такие страдальческие.......!!"

translate russian ch2_n_bad_sharedwithch3_0beb0948:
    mc "То, что она талантливо пишет, ещё не значит... т-то есть..."

translate russian ch2_n_bad_sharedwithch3_ea8d5567:
    n 1o "У-у....!!"

translate russian ch2_n_bad_sharedwithch3_250ca20f:
    "Похоже, я влип."

translate russian ch2_n_bad_sharedwithch3_a51d3942:
    "Каким-то образом я задел больное место, хотя понятия не имею, что сделал."

translate russian ch2_n_bad_sharedwithch3_a08f0ca4:
    n 1c "Всё, с меня хватит."

translate russian ch2_n_bad_sharedwithch3_c687316f:
    "Нацуки суёт мне обратно стихотворение, которое я ей дал."

translate russian ch2_n_bad_sharedwithch3_3d94c19b:
    n 5w "Забирай свой дурацкий стишок. Если писал его для кого-то другого, так мне и не показывай!"

translate russian ch2_n_bad_sharedwithch3_7b4b2ccf:
    mc "Ай..."

translate russian ch2_n_bad_sharedwithch3_654584f3:
    "Вот что бывает, когда позволяешь девчонке младше лезть в твои дела."

translate russian ch2_n_bad_sharedwithch3_bc3ae6de:
    "Если только я не умею читать мысли, мне с самого начала было суждено нарваться."

translate russian ch2_n_bad_sharedwithch3_227553d4:
    "Хорошо хоть, что впечатлить я хотел вовсе не Нацуки..."

translate russian ch2_n_bad_sharedwithch3_28817dab:
    n 1k "...Хм."

translate russian ch2_n_bad_sharedwithch3_74244aa4:
    n "Прошлое мне понравилось больше."

translate russian ch2_n_bad_sharedwithch3_d7b8459d:
    mc "А? Правда?"

translate russian ch2_n_bad_sharedwithch3_5956e212:
    n 2c "Ну да. Видно, что с этим ты немного рискнул."

translate russian ch2_n_bad_sharedwithch3_deb986a6:
    n "Но для такого ты пока недостаточно хорош. Не вышло."

translate russian ch2_n_bad_sharedwithch3_c267cc85:
    mc "Может, и так, но мне просто хотелось попробовать что-то новое."

translate russian ch2_n_bad_sharedwithch3_192d21e2:
    mc "Я ещё только во всём этом разбираюсь."

translate russian ch2_n_bad_sharedwithch3_c199a9a0:
    n 2k "Ну, мне всегда нравятся стихи, которые не лезут из кожи вон."

translate russian ch2_n_bad_sharedwithch3_9338c573:
    n 2q "Ненавижу, когда люди пытаются казаться умнее или добавить смысла одними только раздражающими заумными словами."

translate russian ch2_n_bad_sharedwithch3_dab4c55a:
    n 4b "Просто пиши проще, милее и по делу!"

translate russian ch2_n_bad_sharedwithch3_1b67f29d:
    n 4y "Юри без ума от всей этой загадочной чепухи, но я эту муть насквозь вижу. Ха!"

translate russian ch2_n_bad_sharedwithch3_b068e777:
    n 42a "Заставлять читателя так усердно искать глубокий смысл — это просто отговорка, чтобы смысла не было вовсе."

translate russian ch2_n_bad_sharedwithch3_27c315b5:
    mc "Ну, можно и так на это посмотреть."

translate russian ch2_n_bad_sharedwithch3_3a5d915e:
    n 2d "Что ж, у каждого своё мнение."

translate russian ch2_n_bad_sharedwithch3_1a138e6d:
    n "Но моё мнение — самое правильное. Уверена, ты уже это понял."

translate russian ch2_n_bad_sharedwithch3_ef59a989:
    mc "Э-э..."

translate russian ch2_n_bad_sharedwithch3_416b2cb7:
    n 2a "В общем, вот моё стихотворение. Может, чему-нибудь научишься."

translate russian ch2_n_med_a9238065:
    n "...Хм."

translate russian ch2_n_med_5d9aad6c:
    n 2k "Что ж, признаю, оно лучше прошлого."

translate russian ch2_n_med_0d4958b9:
    n "Приятно видеть, что ты хоть немного стараешься."

translate russian ch2_n_med_0c1a926e:
    mc "Уже хорошо..."

translate russian ch2_n_med_shared_91c0abf5:
    n 2c "Если подумать, оно чем-то напоминает вчерашнее стихотворение Сайори..."

translate russian ch2_n_med_shared_0d6714e9:
    mc "А? Думаешь?"

translate russian ch2_n_med_shared_a7474c85:
    n 2j "Ага. Ну, если вы так давно дружите, может, вы на одной волне."

translate russian ch2_n_med_shared_975e2e25:
    n 2k "Но мне никогда не казалось, что ты в её вкусе."

translate russian ch2_n_med_shared_ea5f67aa:
    mc "С каких это пор у Сайори появился «вкус»...?"

translate russian ch2_n_med_shared_38b61ed6:
    n 42c "Ну, не знаю я! Но честно, как кто-то настолько... э-э, воздушный... может проводить столько времени с таким, как ты?"

translate russian ch2_n_med_shared_6486d68b:
    n "Будто она таскает за собой мёртвый груз."

translate russian ch2_n_med_shared_556ac253:
    mc "Уф... Это было немного лишнее..."

translate russian ch2_n_med_shared_9ab1c449:
    mc "Но посмотри на это так: если бы не я, она бы, наверное, просто улетела, как отпущенный воздушный шарик."

translate russian ch2_n_med_shared_5fc52632:
    mc "Можно сказать, мы каждый по-своему друг о друге заботимся."

translate russian ch2_n_med_shared_71de0e61:
    n 2q "Как бы там ни было, я этого не понимаю..."

translate russian ch2_n_med_shared_ac64fb80:
    n "...А, точно, мне ведь полагается показать тебе своё стихотворение."

translate russian ch2_n_med_shared_2466ac54:
    n "Вот."

translate russian ch2_n_med_shared_a9238065:
    n "...Хм."

translate russian ch2_n_med_shared_96bb6129:
    n 2k "Что ж, оно не то чтобы хуже твоего прошлого."

translate russian ch2_n_med_shared_1a05189b:
    n "Но и сказать, что лучше, я тоже не могу."

translate russian ch2_n_med_shared_d91458f0:
    mc "Фух..."

translate russian ch2_n_med_shared_06c9456d:
    n 2c "А? Что значит „фух“?"

translate russian ch2_n_med_shared_f30730dc:
    mc "А... Ну, всё, что не полный провал, я считаю победой."

translate russian ch2_n_med_shared_293ad1f3:
    mc "К тому же мне кажется, что ты здесь самый строгий критик."

translate russian ch2_n_med_shared_7783e711:
    n 1p "Э-эй! С чего ты—"

translate russian ch2_n_med_shared_8968fb51:
    n 1q "{i}(Стоп, может, это был комплимент...?){/i}"

translate russian ch2_n_med_shared_190b81c1:
    n 4y "А-ха! Рада, что хоть кто-то признаёт мой опыт!"

translate russian ch2_n_med_shared_472981db:
    n "Ну что ж, тренируйся, и, может, когда-нибудь станешь таким же хорошим, как я!"

translate russian ch2_n_med_shared_d2fcd254:
    mc "Это... э-э..."

translate russian ch2_n_med_shared_6840c02e:
    "Что-то мне подсказывает, что Нацуки совершенно не поняла, к чему я."

translate russian ch2_n_med_shared_a9238065_1:
    n "...Хм."

translate russian ch2_n_med_shared_80bc2c6d:
    n 2c "Ну, оно не ужасное."

translate russian ch2_n_med_shared_95975dcd:
    n "Но после твоего прошлого — довольно разочаровывает."

translate russian ch2_n_med_shared_d9da8001:
    n 2s "Хотя, если бы это было таким же хорошим, как прошлое, я бы ужасно разозлилась."

translate russian ch2_n_med_shared_b0f3312e:
    mc "Ну, в этот раз мне, пожалуй, захотелось попробовать что-то немного другое."

translate russian ch2_n_med_shared_42b36abf:
    n 2c "Справедливо. Ты ещё новичок, так что я не жду, что ты сразу найдёшь свой стиль."

translate russian ch2_n_good_54255bee:
    n 1h "..."

translate russian ch2_n_good_97bd1d7a:
    "Нацуки читает моё стихотворение."

translate russian ch2_n_good_5d9c392f:
    "Она то и дело поглядывает на меня, а потом снова на листок."

translate russian ch2_n_good_a22373b2:
    "Наверное, она прочитала его уже не один раз."

translate russian ch2_n_good_07a83d30:
    n 1q "...Разве у тебя не должно плохо получаться?"

translate russian ch2_n_good_9d2d1886:
    mc "...Это комплимент?"

translate russian ch2_n_good_9f2b732e:
    n 1o "Н-нет! В смысле... Ну, ты понял..."

translate russian ch2_n_good_d022f701:
    "Нацуки с трудом подбирает слова."

translate russian ch2_n_good_d724ecc5:
    n 5w "Я просто... ждала намного меньшего после того, что ты показал вчера."

translate russian ch2_n_good_726a8413:
    n "Вот и всё."

translate russian ch2_n_good_98006949:
    mc "Ну, видимо, с этим мне просто повезло."

translate russian ch2_n_good_9d8a8a07:
    n 4t "Д-да!! Вот именно!"

translate russian ch2_n_good_cd395bd3:
    n "Тебе просто повезло, понимаешь?"

translate russian ch2_n_good_2f7bee69:
    n 4y "Не привыкай."

translate russian ch2_n_good_8c4104aa:
    n "У тебя не всегда будут получаться такие милые стихи. То есть—!"

translate russian ch2_n_good_c0bba8b4:
    n 1p "То есть хорошо написанные! Нет, то есть—"

translate russian ch2_n_good_89864fa4:
    mc "А, так вот оно что. Моё стихотворение милое?"

translate russian ch2_n_good_9177548a:
    n 1v "Нет! Чего ты улыбаешься?! Не то чтобы мне нравилось всё милое!"

translate russian ch2_n_good_3e83fc51:
    "Нацуки суёт мне моё стихотворение обратно."

translate russian ch2_n_good_a523ab3e:
    n 4w "Х-хмф! Я перечитала и решила, что оно всё-таки так себе."

translate russian ch2_n_good_8c1c0569:
    n "Слишком милое и доки-доки."

translate russian ch2_n_good_7e8bb200:
    n 4t "Оно бы впечатлило разве что... ну, девчонок... которым такое нравится."

translate russian ch2_n_good_5ba50678:
    n "А-ха-ха!"

translate russian ch2_n_good_2e72f39c:
    "Почему-то Нацуки невероятно легко раскусить."

translate russian ch2_n_good_cb8cd814:
    n 1w "Ну, в общем...!"

translate russian ch2_n_good_4a2f1148:
    n 1h "Теперь ты ведь прочитаешь моё, да?"

translate russian ch2_n_good_9a5ef7b8:
    n "Судя по твоим вкусам, оно тебе наверняка очень понравится."

translate russian ch2_n_good_cc5d22cd:
    n 2q "И, наверное, ещё и научишься чему-нибудь. Не забывай, кто тут {i}настоящий{/i} профи."

translate russian ch2_n_good_sharedwithch3_5aa1ff30:
    n 1n "..."

translate russian ch2_n_good_sharedwithch3_97bd1d7a:
    "Нацуки читает моё стихотворение."

translate russian ch2_n_good_sharedwithch3_5d9c392f:
    "Она то и дело поглядывает на меня, а потом снова на листок."

translate russian ch2_n_good_sharedwithch3_a22373b2:
    "Наверное, она прочитала его уже не один раз."

translate russian ch2_n_good_sharedwithch3_e6a78c7f:
    n 1u "Р-р-р..."

translate russian ch2_n_good_sharedwithch3_652650d3:
    mc "...?"

translate russian ch2_n_good_sharedwithch3_be7fa985:
    mc "Неужели всё так плохо?"

translate russian ch2_n_good_sharedwithch3_79c1a47b:
    n 1r "Нет! Нет, не плохо!"

translate russian ch2_n_good_sharedwithch3_8b1793ba:
    n "Хорошо. Очень хорошо, ясно?!"

translate russian ch2_n_good_sharedwithch3_99cef2f4:
    n 5w "Вот, я это сказала!"

translate russian ch2_n_good_sharedwithch3_978ca6b5:
    n "Фу, всё должно было быть совсем не так...!"

translate russian ch2_n_good_sharedwithch3_07910798:
    n 5s "Ну почему у тебя не может просто плохо получаться?"

translate russian ch2_n_good_sharedwithch3_90c281e0:
    n "Это мои стихи должны впечатлять {i}тебя{/i}, а не наоборот!"

translate russian ch2_n_good_sharedwithch3_5551b30c:
    mc "Ты пытаешься меня впечатлить?"

translate russian ch2_n_good_sharedwithch3_7de53070:
    n 12c "Конечно! Думаешь, я позволю, чтобы тебе тексты Юри нравились больше моих?"

translate russian ch2_n_good_sharedwithch3_69bec280:
    n "Ещё чего."

translate russian ch2_n_good_sharedwithch3_c14c584c:
    mc "Ну..."

translate russian ch2_n_good_sharedwithch3_b7135225:
    mc "Тогда что плохого в том, что я пытаюсь впечатлить тебя?"

translate russian ch2_n_good_sharedwithch3_8a25ddee:
    n 1e "Я тебе скажу! Ты—"

translate russian ch2_n_good_sharedwithch3_2486a5e5:
    n 1p "—"

translate russian ch2_n_good_sharedwithch3_8536572a:
    "Лицо Нацуки застывает, будто до неё только что что-то дошло."

translate russian ch2_n_good_sharedwithch3_4c1feebc:
    n "Т-т-ты..."

translate russian ch2_n_good_sharedwithch3_a3d4c47e:
    n "Ты пытаешься... впечатлить {i}меня?{/i}"

translate russian ch2_n_good_sharedwithch3_243885e4:
    "Нацуки ещё раз лихорадочно пробегает глазами моё стихотворение."

translate russian ch2_n_good_sharedwithch3_4199745f:
    "А потом листок выскальзывает у неё из рук и, кружась, падает на пол."

translate russian ch2_n_good_sharedwithch3_e18edf7d:
    n 1p "Мне... нужно в туалет!"

translate russian ch2_n_good_sharedwithch3_ea0086e4:
    "Покрасневшая Нацуки быстро выходит из комнаты."

translate russian ch2_n_good_sharedwithch3_a6fb49ba:
    m "Эй, [player]..."

translate russian ch2_n_good_sharedwithch3_a20e9cb7:
    m "Ты что-то сделал Нацуки?"

translate russian ch2_n_good_sharedwithch3_8d3014e2:
    m "Я только что видела, как она выбежала..."

translate russian ch2_n_good_sharedwithch3_aa43476d:
    m 2g "Ты ведь не сделал ничего ужасного?"

translate russian ch2_n_good_sharedwithch3_8acab5fb:
    mc "Н-нет!"

translate russian ch2_n_good_sharedwithch3_320c5b26:
    mc "Я просто сказал ей, что—"

translate russian ch2_n_good_sharedwithch3_9302a818:
    "Голос застревает у меня в горле."

translate russian ch2_n_good_sharedwithch3_faf29608:
    "Не могу же я сказать Монике, что пытаюсь впечатлить Нацуки."

translate russian ch2_n_good_sharedwithch3_0e31b682:
    m 2d "Хм-м?"

translate russian ch2_n_good_sharedwithch3_9a4f79a4:
    "Моника замечает лежащее на полу стихотворение и быстро его поднимает."

translate russian ch2_n_good_sharedwithch3_973342cf:
    "Она пробегает его глазами ещё раз, и улыбка не сходит с её лица."

translate russian ch2_n_good_sharedwithch3_0a09882b:
    m 2a "Понятно."

translate russian ch2_n_good_sharedwithch3_f3ff0c92:
    m "Сначала я думала, что тебе просто нравится её стиль..."

translate russian ch2_n_good_sharedwithch3_b76314f3:
    m "Но ты ведь написал это {i}для{/i} Нацуки, правда?"

translate russian ch2_n_good_sharedwithch3_4e3bc964:
    "Она читает его, и улыбка не сходит с её лица."

translate russian ch2_n_good_sharedwithch3_0a09882b_1:
    m 2a "Понятно."

translate russian ch2_n_good_sharedwithch3_bd986df2:
    m "Ты ведь написал это для Нацуки, правда?"

translate russian ch2_n_good_sharedwithch3_3c7670fb:
    mc "Н-ну..."

translate russian ch2_n_good_sharedwithch3_5dc02253:
    mc "Не совсем..."

translate russian ch2_n_good_sharedwithch3_43677ffe:
    m 2d "Кстати, разве ей и в прошлый раз не очень понравилось твоё стихотворение?"

translate russian ch2_n_good_sharedwithch3_3700bd3b:
    m "Удивительно, как хорошо ты уже знаешь её вкус."

translate russian ch2_n_good_sharedwithch3_7fc9597e:
    m 4a "Ты уверен, что не жульничаешь, [player]?"

translate russian ch2_n_good_sharedwithch3_f92f7205:
    mc "Жульничаю...?"

translate russian ch2_n_good_sharedwithch3_721d4483:
    mc "Что ты имеешь в виду?"

translate russian ch2_n_good_sharedwithch3_bc6d3c5f:
    m 5a "Не обращай внимания, я просто шучу. А-ха-ха!"

translate russian ch2_n_good_sharedwithch3_4f6c7d41:
    "Я совершенно не понял шутку Моники."

translate russian ch2_n_good_sharedwithch3_c9062bfa:
    m "В общем..."

translate russian ch2_n_good_sharedwithch3_f5b1bb15:
    m 1a "Как думаешь, что Нацуки к тебе чувствует?"

translate russian ch2_n_good_sharedwithch3_e09b3f50:
    m "Ой, можешь не отвечать."

translate russian ch2_n_good_sharedwithch3_1e49d080:
    m "Это просто тебе на подумать."

translate russian ch2_n_good_sharedwithch3_aa90c4d0:
    n "Эй!"

translate russian ch2_n_good_sharedwithch3_a4b785d3:
    "Нацуки подходит и выхватывает стихотворение из рук Моники."

translate russian ch2_n_good_sharedwithch3_4cb5cfc0:
    "Никто из нас не заметил, как она вернулась в класс."

translate russian ch2_n_good_sharedwithch3_f58f57e5:
    n "Ты это прочитала, Моника?"

translate russian ch2_n_good_sharedwithch3_9193d56a:
    m 1j "Конечно! Мне понравилось!"

translate russian ch2_n_good_sharedwithch3_83b5fd61:
    n 1r "Фу..."

translate russian ch2_n_good_sharedwithch3_ba4328fe:
    n "Знаешь, тебе правда пора перестать читать то, что не для тебя."

translate russian ch2_n_good_sharedwithch3_11ad8889:
    n "Это у тебя дурная привычка."

translate russian ch2_n_good_sharedwithch3_8ce7a8ef:
    m 1d "А?"

translate russian ch2_n_good_sharedwithch3_05137ef3:
    m "Но ведь это стихотворение написал [player]."

translate russian ch2_n_good_sharedwithch3_4af522f4:
    m 1a "А мы должны делиться со всеми, разве нет?"

translate russian ch2_n_good_sharedwithch3_f61f9440:
    n 1x "У-у—"

translate russian ch2_n_good_sharedwithch3_c070c3eb:
    "Нацуки застывает."

translate russian ch2_n_good_sharedwithch3_48547038:
    "Она, видимо, забыла, что моё стихотворение формально предназначено для всех."

translate russian ch2_n_good_sharedwithch3_3b4f218b:
    n 42c "Так, ладно, думаю, [player] уже закончил делиться этим стихотворением со всеми."

translate russian ch2_n_good_sharedwithch3_d9a43f7f:
    n "Всё равно никто бы не захотел такое читать."

translate russian ch2_n_good_sharedwithch3_b2461de0:
    n 4h "Вообще-то, я его просто оставлю у себя."

translate russian ch2_n_good_sharedwithch3_d92866e0:
    m 5 "Раз ты настаиваешь~"

translate russian ch2_n_good_sharedwithch3_4c64a273:
    n 1i "Что?"

translate russian ch2_n_good_sharedwithch3_3cff874a:
    n "Чего ты так на меня смотришь??"

translate russian ch2_n_good_sharedwithch3_ad760861:
    m "Как?"

translate russian ch2_n_good_sharedwithch3_010455dc:
    n 12b "Фу..."

translate russian ch2_n_good_sharedwithch3_03648893:
    n "Забудь."

translate russian ch2_n_good_sharedwithch3_2cc77c23:
    "Что ж, похоже, теперь моё стихотворение у Нацуки."

translate russian ch2_n_good_sharedwithch3_40fb236b:
    "Не то чтобы я собирался его хранить."

translate russian ch2_n_good_sharedwithch3_fa810c86:
    mc "А, Нацуки..."

translate russian ch2_n_good_sharedwithch3_96bb8ff6:
    mc "Я отдам тебе стихотворение, но есть ещё [unfairto!t], так что это не совсем честно..."

translate russian ch2_n_good_sharedwithch3_1b2e0949:
    mc "...Она ведь его ещё не прочитала."

translate russian ch2_n_good_sharedwithch3_c23ac386:
    n 2q "И что?"

translate russian ch2_n_good_sharedwithch3_30991aa8:
    m 2a "Что ж... Похоже, [player] прав, Нацуки..."

translate russian ch2_n_good_sharedwithch3_61f4c89a:
    m "Нечестно, если не дать всем его дочитать."

translate russian ch2_n_good_sharedwithch3_bb2cf764:
    n "..."

translate russian ch2_n_good_sharedwithch3_5dbe6e48:
    n 2h "...Ладно."

translate russian ch2_n_good_sharedwithch3_7dbadd1b:
    "Нацуки возвращает мне стихотворение."

translate russian ch2_n_good_sharedwithch3_3b760342:
    n "Хотя ей всё равно не понравится."

translate russian ch2_n_good_sharedwithch3_85597b9e:
    n 2h "В общем, теперь читай моё."

translate russian ch2_n_good_sharedwithch3_1e9c9a1c:
    n 4h "И нет, оставить его себе я не дам."

translate russian ch2_n_good_sharedwithch3_42d61858:
    n "Это мой единственный экземпляр."

translate russian ch3_n_bad12_shared_6bee2785:
    n 5x "Ага, нет уж, спасибо."

translate russian ch3_n_bad12_shared_a48dd8d8:
    mc "А? Ты даже не—"

translate russian ch3_n_bad12_shared_27be8fb9:
    n 5w "{i}Следующий!{/i}"

translate russian ch3_n_bad12_shared_bb2cf764:
    n "..."

translate russian ch3_n_bad12_shared_58f95e02:
    n 2c "...Мда."

translate russian ch3_n_bad12_shared_7337ee1a:
    n "Видимо, ты так ничему и не научился."

translate russian ch3_n_bad12_shared_8e9ab461:
    n "Честно, не понимаю, с чего я вообще на что-то надеялась."

translate russian ch3_n_bad12_shared_a4bd16ec:
    mc "Что? Мне казалось, это вышло не так уж плохо..."

translate russian ch3_n_bad12_shared_f33bb08e:
    mc "Что я сделал не так?"

translate russian ch3_n_bad12_shared_bb2cf764_1:
    n "..."

translate russian ch3_n_bad12_shared_9cc23ece:
    n 2r "Ох, ну ты даёшь."

translate russian ch3_n_bad12_shared_c7c09fee:
    n "Это же серьёзный шаг назад."

translate russian ch3_n_bad12_shared_fb2e5377:
    mc "А?"

translate russian ch3_n_bad12_shared_61696799:
    n 2c "Два прошлых мне понравились гораздо больше."

translate russian ch3_n_bad12_shared_77ec542a:
    n 1k "Ну..."

translate russian ch3_n_bad12_shared_aafe93c7:
    n "Наверное, я не могу злиться на тебя за то, что ты пробуешь разное."

translate russian ch3_n_bad12_shared_038d3f17:
    n 1c "Если только ты не пытаешься впечатлить Юри или что-то вроде того."

translate russian ch3_n_bad12_shared_0c6bd15d:
    n 5x "Фу."

translate russian ch3_n_bad12_shared_c0052b5c:
    mc "Ладно, ладно."

translate russian ch3_n_bad12_shared_7330982b:
    mc "Ты же сама сказала, что мне можно пробовать новое."

translate russian ch3_n_shared_b8e7f1ef:
    mc "И вообще, почему ты так переживаешь из-за моих стихов?"

translate russian ch3_n_shared_32ccf27e:
    mc "Это ведь скорее мне комплимент, разве нет?"

translate russian ch3_n_shared_d2541be1:
    n 1o "...А?"

translate russian ch3_n_shared_77bf10a2:
    n 4x "Н-нет! Фу!"

translate russian ch3_n_shared_e9638fc3:
    n 4w "Мне вообще всё равно!"

translate russian ch3_n_shared_ba434239:
    n "Просто {i}кто-то{/i} в этом клубе должен следить, чтобы ты не халтурил."

translate russian ch3_n_shared_a31340dd:
    mc "Правда?"

translate russian ch3_n_shared_87b706dd:
    mc "А что, если ты меня так совсем отпугнёшь?"

translate russian ch3_n_shared_e871d8ea:
    n 1t "Это— э-э..."

translate russian ch3_n_shared_1bcb59be:
    n "...Ты бы всё равно так не сделал."

translate russian ch3_n_shared_88f3b528:
    mc "Да, ты права."

translate russian ch3_n_shared_eabb89a5:
    mc "Здесь довольно весело проводить время, даже если приходится терпеть тебя."

translate russian ch3_n_shared_9c33ab7c:
    mc "{i}Кх—!!{/i}"

translate russian ch3_n_shared_99e722a6:
    "Локоть Нацуки встречается с моим животом."

translate russian ch3_n_shared_0510d216:
    n 2y "Да ну?"

translate russian ch3_n_shared_69f8d11c:
    n "Пожалуй, я всё-таки не против тебя отпугнуть."

translate russian ch3_n_shared_adfbbab1:
    mc "Я...... просто пошутил...."

translate russian ch3_n_shared_15bacfb3:
    n 4z "О, я знаю!"

translate russian ch3_n_shared_ded86ea5:
    n "Не волнуйся, я тоже."

translate russian ch3_n_shared_f991fa72:
    n "А-ха-ха-ха!"

translate russian ch3_n_shared_2b35b6fe:
    mc "..."

translate russian ch3_n_shared_bdf2c4c5:
    "И как это, чёрт возьми, называется шуткой?"

translate russian ch3_n_shared_8d17c205:
    "Было реально больно."

translate russian ch3_n_shared_d33cbefb:
    "Ну, может, ей было смешно..."

translate russian ch3_n_shared_3556ce64:
    "...Наверное, в этом и смысл."

translate russian ch3_n_shared_4bd96b65:
    "Мне правда стоит следить за языком рядом с Нацуки."

translate russian ch3_n_shared_f431ba0b:
    n 2c "В общем..."

translate russian ch3_n_shared_843d364c:
    "Нацуки протягивает мне своё стихотворение как ни в чём не бывало."

translate russian ch3_n_med_bb2cf764:
    n "..."

translate russian ch3_n_med_3e89254a:
    n 2k "...Это нормальное."

translate russian ch3_n_med_9790cac2:
    mc "Нормальное?"

translate russian ch3_n_med_37f7579e:
    n "Ну да."

translate russian ch3_n_med_f059e661:
    n "Не сказать, чтобы меня сразило наповал."

translate russian ch3_n_med_8f2772b8:
    n "Но и ничего такого, что бы я прямо ненавидела."

translate russian ch3_n_med_197649d3:
    n "Просто это не совсем мой стиль. Ну, ничего страшного."

translate russian ch3_n_med_bb2cf764_1:
    n "..."

translate russian ch3_n_med_3e89254a_1:
    n 2k "...Это нормальное."

translate russian ch3_n_med_9790cac2_1:
    mc "Нормальное?"

translate russian ch3_n_med_37f7579e_1:
    n "Ну да."

translate russian ch3_n_med_ef787c01:
    n "В общем, примерно как вчерашнее."

translate russian ch3_n_med_186fe389:
    n "Я вижу, к чему ты стремишься, но это просто не совсем мой стиль."

translate russian ch3_n_med_1e4151e6:
    n 2a "Ну, ничего страшного."

translate russian ch3_n_med_32f537a6:
    n "Я в основном просто рада, что ты хоть немного стараешься."

translate russian ch3_n_med_9eab8506:
    mc "Ну, конечно, я хотя бы стараюсь."

translate russian ch3_n_good_948d065f:
    n 1l "Давай-ка посмотрим, давай-ка посмотрим!"

translate russian ch3_n_good_8e641cfb:
    mc "Сегодня ты прямо полна энтузиазма."

translate russian ch3_n_good_ed177b07:
    n 2j "Конечно."

translate russian ch3_n_good_63b9a72c:
    n "Ты же знаешь, что мне нравится, как ты пишешь."

translate russian ch3_n_good_903fcba2:
    mc "Я просто удивлён."

translate russian ch3_n_good_398470a1:
    mc "Раньше тебе, похоже, было очень трудно это признать."

translate russian ch3_n_good_cc1d37c9:
    n 5w "Ну... Ну конечно!"

translate russian ch3_n_good_0fa4fdfa:
    n 5q "Мне просто нужно было немного поставить тебя на место!"

translate russian ch3_n_good_321de497:
    n "Не то чтобы..."

translate russian ch3_n_good_078f67a3:
    n "В смысле, не то чтобы я стеснялась или ещё какая-нибудь глупость."

translate russian ch3_n_good_c056cc39:
    n 5t "Или завидовала!"

translate russian ch3_n_good_d9689f56:
    n "Я правда не завидовала."

translate russian ch3_n_good_4298f820:
    n "Только потому, что ты, видите ли, хорошо пишешь?"

translate russian ch3_n_good_1c88772e:
    n 4y "Глупее повода для зависти не придумаешь."

translate russian ch3_n_good_5ba50678:
    n "А-ха-ха!"

translate russian ch3_n_good_3aa42c3b:
    mc "Нацуки..."

translate russian ch3_n_good_c01486b4:
    n 1h "Что??"

translate russian ch3_n_good_a8eec28b:
    mc "Ты не очень-то уверена в своих текстах, да?"

translate russian ch3_n_good_607f2dbb:
    n 1n "...А?"

translate russian ch3_n_good_e96b4a1b:
    n "Ч-что ты несёшь?"

translate russian ch3_n_good_e41cbb41:
    n 1u "Мои тексты, разумеется, лучшие..."

translate russian ch3_n_good_1b4713a6:
    n "...Правда?"

translate russian ch3_n_good_2b35b6fe:
    mc "..."

translate russian ch3_n_good_0eb6e6ac:
    "Мне понадобилось время, чтобы это понять, но, кажется, наконец понял."

translate russian ch3_n_good_18295abf:
    "Может, Нацуки ведёт себя так заносчиво, потому что пытается скрыть собственную неуверенность."

translate russian ch3_n_good_5345b744:
    "Если вести себя так, будто она лучшая, то и другие, может, так подумают."

translate russian ch3_n_good_e3d92c52:
    n 1m "Правда...?"

translate russian ch3_n_good_a51de77b:
    n "[player]..."

translate russian ch3_n_good_69ab276f:
    n "Просто скажи, что тебе нравятся мои стихи."

translate russian ch3_n_good_b301ade1:
    n 1u "Мне всё равно, даже если ты их ненавидишь."

translate russian ch3_n_good_eb1f460e:
    n "Просто, пожалуйста, скажи, что я лучшая."

translate russian ch3_n_good_77dda759:
    n "Мне просто..."

translate russian ch3_n_good_d20244e7:
    n 1q "Мне просто очень нужно услышать это хоть от кого-нибудь."

translate russian ch3_n_good_946e525c:
    n "Знаю, звучит глупо."

translate russian ch3_n_good_d1d33c65:
    n "Но я не зря никогда раньше не показывала свои стихи."

translate russian ch3_n_good_3aa42c3b_1:
    mc "Нацуки..."

translate russian ch3_n_good_3bd14e07:
    n "Потому что..."

translate russian ch3_n_good_cc1abee3:
    n 12c "Потому что меня никто никогда не воспринимает всерьёз!"

translate russian ch3_n_good_ff270aab:
    n "Какой смысл показывать стихи, если люди только смеются и говорят: „Как мило, прямо как ты, Нацуки!“"

translate russian ch3_n_good_39e2ca20:
    n "Иногда я не хочу быть милой!"

translate russian ch3_n_good_83a8f68b:
    n 12d "Но этого никто не понимает!"

translate russian ch3_n_good_7d9df315:
    n "Я очень стараюсь, когда пишу."

translate russian ch3_n_good_e545c83d:
    n 12e "Неважно, какой стиль."

translate russian ch3_n_good_25024747:
    n "Чувства-то там есть."

translate russian ch3_n_good_95a09f7c:
    n 1n "Почему никто этого не {i}видит{/i}...?"

translate russian ch3_n_good_75b57916:
    n 1u "Я просто хочу..."

translate russian ch3_n_good_f4008f69:
    "Нацуки умолкает."

translate russian ch3_n_good_072d63c1:
    "Может, потому, что у неё задрожала губа."

translate russian ch3_n_good_f68cfca4:
    "Я опускаю взгляд."

translate russian ch3_n_good_fab52c90:
    "Её кулаки крепко сжаты."

translate russian ch3_n_good_fb1c5db2:
    mc "Эй, Нацуки."

translate russian ch3_n_good_845be5c2:
    mc "Осторожнее, а то порвёшь собственное стихотворение."

translate russian ch3_n_good_6e9f33a7:
    "Я мягко берусь рукой за листок, пока она не ослабляет хватку."

translate russian ch3_n_good_5e95f879:
    "Я кладу его на парту и разглаживаю складки, которые она успела наделать."

translate russian ch3_n_good_6ff9a79f:
    n 1h "Н-не читай!"

translate russian ch3_n_good_f922e360:
    "Прежде чем я успеваю снова его взять, Нацуки хватает стихотворение с парты."

translate russian ch3_n_good_fd65c270:
    n 5q "Оно никуда не годится."

translate russian ch3_n_good_395ef125:
    n "И я знаю, что ты ненавидишь мои стихи."

translate russian ch3_n_good_c7a152d1:
    n "Так что это можешь не читать, ладно?"

translate russian ch3_n_good_eb802514:
    mc "Но я хочу его прочитать."

translate russian ch3_n_good_2328b9d8:
    n "П-почему?"

translate russian ch3_n_good_e4481ad0:
    mc "Потому что."

translate russian ch3_n_good_e6cfa97c:
    mc "Мне нравятся твои стихи."

translate russian ch3_n_good_e9ca074e:
    mc "Правда нравятся."

translate russian ch3_n_good_89d63b52:
    mc "С чего бы мне осуждать тебя за стиль?"

translate russian ch3_n_good_9a77974b:
    mc "У меня самого стиль не бог весть какой."

translate russian ch3_n_good_671d522b:
    mc "Ну, правда, когда я впервые читал твоё стихотворение, я особо не вникал."

translate russian ch3_n_good_1e0bda50:
    mc "Но теперь я знаю тебя лучше."

translate russian ch3_n_good_ecca07eb:
    mc "И Юри не права, когда считает, что твой стиль более любительский, чем её."

translate russian ch3_n_good_67c00169:
    mc "А Сайори... Она всегда желает добра..."

translate russian ch3_n_good_88f16d00:
    mc "Но иногда она так сосредоточена на простом счастье, что не понимает, чего на самом деле хотят люди."

translate russian ch3_n_good_00a2eab2:
    mc "Да... Наверное, я никогда толком не задумывался, как тебе тяжело."

translate russian ch3_n_good_8225f539:
    mc "И прости, если я тоже был частью этой проблемы."

translate russian ch3_n_good_6c4a9b78:
    mc "Теперь я понимаю."

translate russian ch3_n_good_c1451a07:
    mc "Ты не просто милая — ты гораздо больше, чем это."

translate russian ch3_n_good_834ac17f:
    mc "Ах— Нацуки, ты опять—"

translate russian ch3_n_good_80c2e182:
    "Нацуки снова слишком сильно стискивает своё стихотворение."

translate russian ch3_n_good_ced2c13d:
    "Она опускает голову, пряча от меня глаза."

translate russian ch3_n_good_e149580a:
    "Я и не подозревал, как это для неё тяжело."

translate russian ch3_n_good_70fc924e:
    "Но наконец она заставляет себя протянуть руки и положить стихотворение на стол."

translate russian ch3_n_good_94a91ea6:
    n 12e "Можешь... прочитать."

translate russian ch3_n_good_9f1d5280:
    n "Только отвернись."

translate russian ch3_n_good_4aba9521:
    n "Не хочу, чтобы ты... сейчас смотрел на моё лицо."

translate russian ch3_n_good_d3bee692:
    mc "Хорошо, отвернусь."

translate russian ch3_n_good_bb2cf764:
    n "..."

translate russian ch3_n_good_0e8a5f60:
    n 2k "...Ну наконец-то!"

translate russian ch3_n_good_fb2e5377:
    mc "А?"

translate russian ch3_n_good_1ca18995:
    n 2l "Вот это. Вот это хорошее!"

translate russian ch3_n_good_06ca24ed:
    n "Я уже думала, сколько тебе на это понадобится."

translate russian ch3_n_good_5952193e:
    mc "Отлично!"

translate russian ch3_n_good_c9763026:
    n 4y "Ага, серьёзно."

translate russian ch3_n_good_8d722701:
    n "Не слушай, что говорят другие."

translate russian ch3_n_good_2c54026b:
    n "Особенно Юри."

translate russian ch3_n_good_c6738dd5:
    n 4a "Просто пиши и дальше такие стихи. Больше ничего и не нужно!"

translate russian ch3_n_good_ef59a989:
    mc "Э-э..."

translate russian ch3_n_good_a0ab5d60:
    mc "А ты уверена, что это не просто то, чего хочешь {i}ты{/i}?"

translate russian ch3_n_good_3ae90833:
    n 2h "Прошу прощения?"

translate russian ch3_n_good_63e689c4:
    n "Ты вообще-то разговариваешь с профи."

translate russian ch3_n_good_d9a0e6de:
    n "Тебе не кажется, что моему мнению стоит доверять больше всех?"

translate russian ch3_n_good_d01d054f:
    mc "Смотря как посмотреть."

translate russian ch3_n_good_22d0418b:
    mc "Ты ведь пристрастна к простым и милым стихам?"

translate russian ch3_n_good_dcd93442:
    n 2w "Пристрастна?"

translate russian ch3_n_good_e80b7548:
    n "Конечно, нет."

translate russian ch3_n_good_2d210585:
    n 4y "Просто моё мнение — самое правильное."

translate russian ch3_n_good_2b35b6fe_1:
    mc "..."

translate russian ch3_n_good_49c0bbbf:
    "Одного я до сих пор не могу понять."

translate russian ch3_n_good_47ad060e:
    "Нацуки вообще осознаёт, какая она избалованная?"

translate russian ch3_n_good_366a8912:
    "С такими темпами я, наверное, никогда этого не узнаю."

translate russian ch3_n_good_846589e1:
    mc "...Справедливо."

translate russian ch3_n_good_29966997:
    mc "В конце концов, я рад, что тебе понравилось моё стихотворение."

translate russian ch3_n_good_b579c35e:
    n 4z "А-ха-ха!"

translate russian ch3_n_good_a810284d:
    n 4j "Я знала, что ты наконец поймёшь."

translate russian ch3_n_good_7c5031c8:
    n "Просто продолжай показывать мне свои стихи, и не успеешь оглянуться, как станешь профи."

translate russian ch3_n_good_2056267b:
    n "В общем, вот что написала я."

translate russian ch1_s_bad_67fb702d:
    s 1b "..."

translate russian ch1_s_bad_9826dc3d:
    s "...Ого!"

translate russian ch1_s_bad_23d81314:
    s "[player]..."

translate russian ch1_s_bad_022b2416:
    s 4r "Твоё стихотворение ужасно плохое!"

translate russian ch1_s_bad_47abfe8d:
    s "А-ха-ха-ха!"

translate russian ch1_s_bad_af40f385:
    mc "Что?!"

translate russian ch1_s_bad_347544ae:
    s 4a "Ничего-ничего~"

translate russian ch1_s_bad_a0bb0aac:
    s "Это же твой первый раз."

translate russian ch1_s_bad_64d11557:
    s "К тому же..."

translate russian ch1_s_shared_14a37300:
    s 1a "Я очень рада уже тому, что ты его написал."

translate russian ch1_s_shared_ef8b6102:
    s "Это напоминает мне, что теперь ты по-настоящему часть клуба~"

translate russian ch1_s_shared_444ac926:
    "(Не говоря уже о том, что я стою прямо перед тобой в клубной комнате...?)"

translate russian ch1_s_shared_d484b231:
    mc "Э-э... ну, конечно."

translate russian ch1_s_shared_c589af18:
    mc "Меня это пока не особо увлекает, но это не значит, что я нарушу обещание."

translate russian ch1_s_shared_ec209e53:
    s 1d "Вот видишь?"

translate russian ch1_s_shared_b66e84c5:
    s "Как я и говорила, [player]..."

translate russian ch1_s_shared_16db0b43:
    s "В глубине души ты совсем не эгоист, понимаешь?"

translate russian ch1_s_shared_02c439fe:
    s "Пробовать что-то новое ради других..."

translate russian ch1_s_shared_ab447aba:
    s 2q "Так поступают только по-настоящему хорошие люди!"

translate russian ch1_s_shared_d2b33d55:
    mc "Спасибо... Сайори."

translate russian ch1_s_shared_ef62e224:
    "...Не уверен, что Сайори видит всю картину моих мотивов."

translate russian ch1_s_shared_ec7019ae:
    "Хотя опять же..."

translate russian ch1_s_shared_f3c7c2a3:
    "Не могу отрицать, что она — одна из причин, по которым я вступил."

translate russian ch1_s_shared_fe10b692:
    "Зная, как много это для неё значит, и всё такое..."

translate russian ch1_s_shared_b90838ce:
    s 1x "Ага."

translate russian ch1_s_shared_164855d6:
    s "И я позабочусь, чтобы тебе тут было очень весело, ладно?"

translate russian ch1_s_shared_cf720dd1:
    s "Так я тебя отблагодарю~"

translate russian ch1_s_shared_fba49aeb:
    mc "Ладно, тогда ловлю тебя на слове."

translate russian ch1_s_shared_1223c76e:
    s 4r "Ура~!"

translate russian ch1_s_shared_3e1ce888:
    s "А теперь ты ведь прочитаешь и моё, да?"

translate russian ch1_s_shared_3278a2ba:
    s 1y "Не волнуйся, у меня очень плохо получается."

translate russian ch1_s_shared_cc3db8cd:
    s "Э-хе-хе..."

translate russian ch1_s_shared_bb4834bc:
    mc "Посмотрим."

translate russian ch1_s_med_e1554201:
    s "..."

translate russian ch1_s_med_8d687249:
    s 2x "Хорошее стихотворение, [player]!"

translate russian ch1_s_med_8d93f5d7:
    s "Ты уверен, что пишешь впервые?"

translate russian ch1_s_med_42d3094e:
    mc "Конечно..."

translate russian ch1_s_med_41d6a22d:
    mc "Оно не такое уж хорошее."

translate russian ch1_s_med_7e9e13db:
    mc "Я похож на парня, который пишет стихи в свободное время?"

translate russian ch1_s_med_eb6dee34:
    s 2q "Э-хе-хе, наверное, ты прав~"

translate russian ch1_s_med_1f10f4cb:
    s 1q "Но поэтому оно меня и впечатлило!"

translate russian ch1_s_med_0f23c547:
    s 1d "Ну, если честно..."

translate russian ch1_s_med_e4c57903:
    s "Я боялась, что ты отнесёшься к этому несерьёзно..."

translate russian ch1_s_med_5a2a2aa3:
    s "Или вообще ничего не напишешь."

translate russian ch1_s_good_2d320a81:
    s 1n "..."

translate russian ch1_s_good_a406fe20:
    s "...Божечки!"

translate russian ch1_s_good_8c41300f:
    s 4b "Это та-а-ак здорово, [player]!"

translate russian ch1_s_good_fb2e5377:
    mc "А?"

translate russian ch1_s_good_77d70da9:
    s 4r "Мне очень нравится~!"

translate russian ch1_s_good_586517be:
    s "Я и не знала, что ты так хорошо пишешь!"

translate russian ch1_s_good_e87e0575:
    mc "Сайори..."

translate russian ch1_s_good_c68f34fe:
    mc "Ты явно сильно преувеличиваешь."

translate russian ch1_s_good_de1c655e:
    mc "Я совсем не умею писать."

translate russian ch1_s_good_f407f1ee:
    mc "Честно, я понятия не имею, что делаю."

translate russian ch1_s_good_8e68a8a7:
    s 1x "Ну..."

translate russian ch1_s_good_177d7f82:
    s "Может, поэтому!"

translate russian ch1_s_good_919a3334:
    s "Потому что я тоже понятия не имею, что мне нравится!"

translate russian ch1_s_good_ffae3320:
    s 1r "А-ха-ха-ха!"

translate russian ch1_s_good_9098da49:
    mc "Ну ты даёшь..."

translate russian ch1_s_good_c8a5cb74:
    "Мнение Юри было куда конструктивнее..."

translate russian ch1_s_good_6128e463:
    "Уверен, мнение Юри будет хоть немного конструктивнее."

translate russian ch1_s_good_05dd16ef:
    "Может, даже мнение Нацуки."

translate russian ch1_s_good_85021d96:
    mc "А ты уверена, что оно тебе нравится не просто потому, что его написал я?"

translate russian ch1_s_good_1a235903:
    s 1b "А?"

translate russian ch1_s_good_d38bf0c1:
    s "Ну, наверное, и поэтому тоже."

translate russian ch1_s_good_772e7890:
    s 1x "Мне кажется, я понимаю тебя лучше, чем многие другие, понимаешь?"

translate russian ch1_s_good_78363d80:
    s "Поэтому, когда я читаю твоё стихотворение..."

translate russian ch1_s_good_b7164def:
    s "Это не просто стихотворение..."

translate russian ch1_s_good_89339654:
    s 4q "Это стихотворение, которое написал [player]!"

translate russian ch1_s_good_5570b9ad:
    s "И от этого оно кажется особенным!"

translate russian ch1_s_good_57ac69a8:
    s "Будто я чувствую в нём твои чувства~"

translate russian ch1_s_good_2cf02631:
    "Сайори прижимает листок к груди."

translate russian ch1_s_good_9d3294a0:
    mc "Какая же ты странная, Сайори..."

translate russian ch1_s_good_cc3db8cd:
    s "Э-хе-хе..."

translate russian ch2_s_bad_e1554201:
    s "..."

translate russian ch2_s_bad_240aea9f:
    s 1q "Э-хе-хе, обожаю читать твои стихи~"

translate russian ch2_s_bad_c0d0bf21:
    s "Никогда не знаешь, что получится!"

translate russian ch2_s_bad_10497bf0:
    mc "То есть, по сути, ты говоришь, что оно отстой."

translate russian ch2_s_bad_0582fae9:
    s 4c "Нет! Совсем нет!"

translate russian ch2_s_bad_75b9f8e4:
    s 4l "...Может быть!"

translate russian ch2_s_bad_6c3e3a85:
    s 5a "Чуть-чуть?"

translate russian ch2_s_bad_b7651ced:
    s "Наверное, Юри меня немножко избаловала своими стихами..."

translate russian ch2_s_bad_cc3db8cd:
    s "Э-хе-хе..."

translate russian ch2_s_bad_4255537f:
    mc "Ничего-ничего."

translate russian ch2_s_bad_096388fc:
    mc "В конце концов, я до сих пор понятия не имею, какие тексты тебе вообще нравятся."

translate russian ch2_s_shared_2fadc9c6:
    s 1q "Да!"

translate russian ch2_s_shared_ad466055:
    s "Я тоже!"

translate russian ch2_s_shared_6434dfd2:
    mc "Ох..."

translate russian ch2_s_shared_8b50c0c5:
    mc "Может, ты хотя бы попробуешь об этом подумать?"

translate russian ch2_s_shared_9b20fbf9:
    s 2d "Ой, ты хочешь написать что-нибудь для меня?"

translate russian ch2_s_shared_bba17cf3:
    s "Как мило~"

translate russian ch2_s_shared_3fe7fe09:
    mc "Ага, как же."

translate russian ch2_s_shared_4dbac3b2:
    mc "Но ты всегда думаешь о других."

translate russian ch2_s_shared_3afa292d:
    mc "Тебе нужно хоть иногда думать о себе."

translate russian ch2_s_shared_49697d01:
    mc "Иначе однажды тебе может быть очень больно."

translate russian ch2_s_shared_29a2407f:
    s 1n "Э-э?"

translate russian ch2_s_shared_93f8ec4b:
    s "Ну..."

translate russian ch2_s_shared_36de8e51:
    s 1o "Я не совсем понимаю, о чём ты, но постараюсь запомнить!"

translate russian ch2_s_shared_eed9b3b6:
    mc "Ну, как знаешь..."

translate russian ch2_s_shared_f807de49:
    s 1b "Так, ну-ка посмотрим..."

translate russian ch2_s_shared_b3b9c0e8:
    s "Хм-м..."

translate russian ch2_s_shared_2de73854:
    s 4q "Наверное, мне нравятся... радостные стихи~"

translate russian ch2_s_shared_eaa5bf49:
    s 4i "Хотя нет, иногда мне нравятся и грустные..."

translate russian ch2_s_shared_f3e56294:
    s 1i "Иногда — немножко и того, и другого..."

translate russian ch2_s_shared_ac87057c:
    s "Для этого ведь есть слово, да...?"

translate russian ch2_s_shared_f261931a:
    s "Как же это слово..."

translate russian ch2_s_shared_49cef6d9:
    s 4r "...Светлая грусть!"

translate russian ch2_s_shared_a03b41d0:
    s "Да!"

translate russian ch2_s_shared_c19cb1c4:
    s 1x "Мне нравится и радостное, и грустное."

translate russian ch2_s_shared_0af776dc:
    mc "Радостное и грустное?"

translate russian ch2_s_shared_b04e82f1:
    mc "Не могу представить, чтобы тебе нравилось что-то грустное, Сайори..."

translate russian ch2_s_shared_9ff618f7:
    s 1c "Ну..."

translate russian ch2_s_shared_8dd0a50f:
    s "Больше всего мне нравится радостное!"

translate russian ch2_s_shared_582d4951:
    s 1d "Но иногда, когда у тебя в голове маленькая дождевая тучка..."

translate russian ch2_s_shared_5505f518:
    s "Грустное стихотворение может её немножко обнять..."

translate russian ch2_s_shared_7759f6e3:
    s 4q "...И получится красивая радостная радуга!"

translate russian ch2_s_shared_66ef0676:
    mc "...Сайори, это неожиданно поэтично."

translate russian ch2_s_shared_88719d22:
    s 4n "А? Правда?"

translate russian ch2_s_shared_9dc9b008:
    s "Может, я всё-таки научилась лучше выражать свои чувства!"

translate russian ch2_s_shared_075e3de4:
    s 2q "Спасибо, [player]!"

translate russian ch2_s_shared_4092f3a4:
    s "Тогда пойду запишу это~"

translate russian ch2_s_shared_9703786d:
    s 2a "Теперь можешь прочитать моё стихотворение, ладно?"

translate russian ch2_s_med_e1554201:
    s "..."

translate russian ch2_s_med_e96ec44d:
    s 4x "Ух ты!"

translate russian ch2_s_med_d6de3bd3:
    s "Мне нравится это, [player]!"

translate russian ch2_s_med_81f3fb58:
    s "В нём есть хорошие чувства~"

translate russian ch2_s_med_20cbf2c3:
    mc "А, я рад."

translate russian ch2_s_med_3045af90:
    mc "Значит, оно хотя бы лучше вчерашнего."

translate russian ch2_s_med_a28f881b:
    s 1q "Ага!"

translate russian ch2_s_med_781c4f9b:
    mc "Может, у меня начинает получаться."

translate russian ch2_s_med_shared_0acdc3dc:
    s 1a "Ну, я не очень умею понимать, хорошее стихотворение или плохое..."

translate russian ch2_s_med_shared_656bbe58:
    s "Поэтому я просто слушаю своё сердце~"

translate russian ch2_s_med_shared_bdb83c71:
    s "Если оно вызывает у меня чувства, значит, это хорошее стихотворение!"

translate russian ch2_s_med_shared_6313266e:
    "Не уверен, что это работает именно так..."

translate russian ch2_s_med_shared_802d939a:
    "...Хотя, с другой стороны, передавать чувства — довольно важная часть всего этого."

translate russian ch2_s_med_shared_802764fe:
    mc "Да, может быть..."

translate russian ch2_s_med_shared_c3639613:
    mc "Если честно, я даже не знаю, какие тексты тебе вообще нравятся."

translate russian ch2_s_med_shared_e1554201:
    s "..."

translate russian ch2_s_med_shared_e96ec44d:
    s 4x "Ух ты!"

translate russian ch2_s_med_shared_d6de3bd3:
    s "Мне нравится это, [player]!"

translate russian ch2_s_med_shared_81f3fb58:
    s "В нём есть хорошие чувства~"

translate russian ch2_s_med_shared_20cbf2c3:
    mc "А, я рад."

translate russian ch2_s_med_shared_4ab903ef:
    mc "Значит, оно лучше вчерашнего?"

translate russian ch2_s_med_shared_61b5d998:
    s 4b "М-м-м, дай подумать..."

translate russian ch2_s_med_shared_8837cbad:
    s 1q "Не знаю!"

translate russian ch2_s_med_shared_2e8acb4f:
    s "Наверное, мне нравятся оба!"

translate russian ch2_s_med_shared_c98e38ed:
    s "Э-хе-хе~"

translate russian ch2_s_med_shared_5811b0a6:
    mc "Знаешь, от этого не очень много толку..."

translate russian ch2_s_med_shared_e1554201_1:
    s "..."

translate russian ch2_s_med_shared_e96ec44d_1:
    s 4x "Ух ты!"

translate russian ch2_s_med_shared_d6de3bd3_1:
    s "Мне нравится это, [player]!"

translate russian ch2_s_med_shared_81f3fb58_1:
    s "В нём есть хорошие чувства~"

translate russian ch2_s_med_shared_20cbf2c3_1:
    mc "А, я рад."

translate russian ch2_s_med_shared_e6b66fed:
    mc "И всё же..."

translate russian ch2_s_med_shared_d6499fc7:
    mc "По твоему тону кажется, что вчерашнее тебе понравилось больше."

translate russian ch2_s_med_shared_a642374e:
    s 2l "Э-хе-хе, похоже, ты меня раскусил..."

translate russian ch2_s_med_shared_a453ac40:
    s "Иногда ты знаешь меня даже слишком хорошо!"

translate russian ch2_s_med_shared_b05edc00:
    mc "Слушай, не надо просто пытаться быть вежливой."

translate russian ch2_s_med_shared_21032d1a:
    mc "Если у меня плохо получается, я лучше так и услышу."

translate russian ch2_s_med_shared_58c51c9f:
    s 1c "Нет-нет!"

translate russian ch2_s_med_shared_9302d1cc:
    s "Это мне тоже понравилось! Честно-честно!"

translate russian ch2_s_med_shared_b89b0298:
    s 1h "Ты же знаешь, я бы тебе не соврала, [player]...!"

translate russian ch2_s_med_shared_157a2d00:
    s "Никогда-никогда!"

translate russian ch2_s_med_shared_8e64bc71:
    mc "Да, наверное..."

translate russian ch2_s_med_shared_3ab5816a:
    mc "Тогда чем вчерашнее стихотворение было лучше этого?"

translate russian ch2_s_med_shared_7bf69ced:
    s 1b "Э-эм....."

translate russian ch2_s_good_2d320a81:
    s 1n "..."

translate russian ch2_s_good_a406fe20:
    s "...Божечки!"

translate russian ch2_s_good_64dee5af:
    s 4r "Это та-а-ак здорово, [player]!"

translate russian ch2_s_good_fb2e5377:
    mc "А?"

translate russian ch2_s_good_6661322d:
    s "Мне очень нравится~!"

translate russian ch2_s_good_afe6b9cf:
    s "Особенно после вчерашнего стихотворения!"

translate russian ch2_s_good_6434dfd2:
    mc "Ох..."

translate russian ch2_s_good_df178b27:
    mc "Иногда ты слишком честная, Сайори."

translate russian ch2_s_good_4a200b7a:
    s 4x "Нет, ну правда!!"

translate russian ch2_s_good_b7f6890f:
    s 1x "Хочу повесить его на стенку~"

translate russian ch2_s_good_f606b4d4:
    s "Можно?"

translate russian ch2_s_good_e87e0575:
    mc "Сайори..."

translate russian ch2_s_good_c68f34fe:
    mc "Ты явно сильно преувеличиваешь."

translate russian ch2_s_good_de1c655e:
    mc "Я совсем не умею писать."

translate russian ch2_s_good_f407f1ee:
    mc "Честно, я понятия не имею, что делаю."

translate russian ch2_s_good_b72a2af9:
    s 1l "Ну..."

translate russian ch2_s_good_177d7f82:
    s "Может, поэтому!"

translate russian ch2_s_good_919a3334:
    s "Потому что я тоже понятия не имею, что мне нравится!"

translate russian ch2_s_good_aa59979e:
    s 4r "А-ха-ха-ха!"

translate russian ch2_s_good_9098da49:
    mc "Ну ты даёшь..."

translate russian ch2_s_good_6128e463:
    "Уверен, мнение Юри будет хоть немного конструктивнее."

translate russian ch2_s_good_05dd16ef:
    "Может, даже мнение Нацуки."

translate russian ch2_s_good_85021d96:
    mc "А ты уверена, что оно тебе нравится не просто потому, что его написал я?"

translate russian ch2_s_good_7c1b466a:
    s 4b "А?"

translate russian ch2_s_good_110a73ec:
    s 1b "Ну, наверное, и поэтому тоже."

translate russian ch2_s_good_e86bf751:
    s "Мне кажется, я понимаю тебя лучше, чем многие другие, понимаешь?"

translate russian ch2_s_good_78363d80:
    s "Поэтому, когда я читаю твоё стихотворение..."

translate russian ch2_s_good_b7164def:
    s "Это не просто стихотворение..."

translate russian ch2_s_good_89339654:
    s 4q "Это стихотворение, которое написал [player]!"

translate russian ch2_s_good_5570b9ad:
    s "И от этого оно кажется особенным!"

translate russian ch2_s_good_57ac69a8:
    s "Будто я чувствую в нём твои чувства~"

translate russian ch2_s_good_2cf02631:
    "Сайори прижимает листок к груди."

translate russian ch2_s_good_9d3294a0:
    mc "Какая же ты странная, Сайори..."

translate russian ch2_s_good_7b722849:
    s 4l "Э-хе-хе..."

translate russian ch2_s_good_e1554201:
    s "..."

translate russian ch2_s_good_19925001:
    s 1d "[player]..."

translate russian ch2_s_good_d023d76e:
    s "Мне правда очень нравятся твои стихи."

translate russian ch2_s_good_7a81f9e3:
    s "Поверить не могу, что ты их от меня прятал!"

translate russian ch2_s_good_1a9f656d:
    mc "А? Ничего я не прятал!"

translate russian ch2_s_good_4c4dac2c:
    s 1b "Но..."

translate russian ch2_s_good_01e8506a:
    s "Твои стихи та-а-акие хорошие..."

translate russian ch2_s_good_53704d43:
    s "И вчерашнее, и это тоже!"

translate russian ch2_s_good_17654755:
    s "Не говори мне, что раньше этим не занимался!"

translate russian ch2_s_good_7136c946:
    mc "Ну..."

translate russian ch2_s_good_a6c8ccf8:
    mc "Вообще-то, так думаешь только ты, так что..."

translate russian ch2_s_good_c3597975:
    s 4h "А?!"

translate russian ch2_s_good_5a65c597:
    s "Быть не может!!"

translate russian ch2_s_good_8ea5f892:
    s "Даже Нацуки не...?"

translate russian ch2_s_good_efbbb452:
    mc "Ну, Нацуки, наверное, меньше всех склонна признаваться, что ей что-то нравится..."

translate russian ch2_s_good_69714dd2:
    mc "Но, по-моему, дело не в этом."

translate russian ch2_s_good_632bed9b:
    s 1b "А в чём?"

translate russian ch2_s_good_c14c584c:
    mc "Ну..."

translate russian ch2_s_good_ce38a2d6:
    mc "Пожалуй, скажу честно."

translate russian ch2_s_good_36641644:
    mc "Мне гораздо легче писать стихи, когда я думаю о тебе."

translate russian ch2_s_good_806e27d7:
    s 4m "Ч-что?!"

translate russian ch2_s_good_63facf00:
    s "Ва-ва-ва—!"

translate russian ch2_s_good_8c3b599c:
    mc "Не думай всякие глупости, дурочка!"

translate russian ch2_s_good_c261b028:
    mc "Я просто имею в виду, что ты очень... эмоциональный человек, что ли."

translate russian ch2_s_good_8ead5175:
    mc "Как мне писать стихи о моей дурацкой жизни?"

translate russian ch2_s_good_282aa621:
    mc "А ты каким-то образом превращаешь всё в своей жизни в приключение."

translate russian ch2_s_good_67d2ee07:
    mc "Даже мелочи."

translate russian ch2_s_good_f134be96:
    s 4o "Например, готовку!!"

translate russian ch2_s_good_b5271163:
    mc "Давай не будем об этом!"

translate russian ch2_s_good_ca861a06:
    s 5a "Э-хе-хе..."

translate russian ch2_s_good_3f91f62a:
    mc "Так что вот..."

translate russian ch2_s_good_0a9c77e5:
    mc "Наверное, я хочу сказать, что через тебя я чувствую больше, чем через себя самого."

translate russian ch2_s_good_223cce22:
    mc "Между нами есть какая-то странная связь."

translate russian ch2_s_good_7d825342:
    mc "Сама виновата, что вечно лезешь в мои дела."

translate russian ch2_s_good_7195c3fd:
    s 1e "Э-э...?"

translate russian ch2_s_good_bcbd9d1c:
    s "Не уверена, что понимаю..."

translate russian ch2_s_good_0a69f768:
    mc "Эх..."

translate russian ch2_s_good_e93d5dfb:
    mc "Ты никогда не понимаешь, когда я пытаюсь тебе что-то объяснить, правда, Сайори?"

translate russian ch2_s_good_797d00ee:
    "Я глажу Сайори по голове."

translate russian ch2_s_good_4df84939:
    s 4s "А-ха-ха! Эй!"

translate russian ch2_s_good_045a2219:
    s "Я тебе не маленькая, вообще-то!"

translate russian ch2_s_good_88e906b0:
    mc "Уверена?"

translate russian ch2_s_good_af24a934:
    s 4l "М-м-м, может быть~"

translate russian ch2_s_good_e6ad06e1:
    "Сайори начинает вертеть в руках карандаш."

translate russian ch2_s_good_63ef6bb1:
    s "Эй, [player]..."

translate russian ch2_s_good_3fbe8052:
    s 2d "А ты отдашь мне своё стихотворение?"

translate russian ch2_s_good_ebdc9bb3:
    s "Мне хочется его оставить себе."

translate russian ch2_s_good_69fb21f6:
    mc "А? Зачем?"

translate russian ch2_s_good_a98f476a:
    s 1y "Потому что..."

translate russian ch2_s_good_93f8ec4b:
    s "Ну..."

translate russian ch2_s_good_a63dcff6:
    s "Ты ведь впервые написал что-то для меня..."

translate russian ch2_s_good_cc3db8cd:
    s "Э-хе-хе..."

translate russian ch2_s_good_56edf709:
    mc "!!"

translate russian ch2_s_good_300eb585:
    mc "Сайори, ты всё совершенно не так поняла!"

translate russian ch2_s_good_b475a49b:
    mc "Я писал его не для тебя!"

translate russian ch2_s_good_db8f0469:
    s 5b "Э-хе-хе-хе-хе..."

translate russian ch2_s_good_0a69f768_1:
    mc "Эх..."

translate russian ch2_s_good_5de8d254:
    mc "Ты меня вообще слушаешь?"

translate russian ch2_s_good_826915c4:
    mc "Ну и ладно."

translate russian ch2_s_good_af05be4e:
    mc "Отдам, когда пойдём домой."

translate russian ch2_s_good_b31855c1:
    s 4m "Правда?!"

translate russian ch2_s_good_41c9923e:
    "{i}Хрусь!{/i}"

translate russian ch2_s_good_ee45c1c9:
    s 4p "А-ай!!"

translate russian ch2_s_good_ae4514c3:
    s "Я сломала карандаш..."

translate russian ch2_s_good_f880b509:
    "Сайори торопливо наклоняется, чтобы поднять обломок."

translate russian ch2_s_good_2fbc1b54:
    "Но, не глядя по сторонам, врезается прямо в меня."

translate russian ch2_s_good_0af8ea64:
    s 4l "П-п-прости—!!"

translate russian ch2_s_good_4255537f:
    mc "Ничего-ничего."

translate russian ch2_s_good_f1835c61:
    mc "Я подниму."

translate russian ch2_s_good_588d9120:
    "Я наклоняюсь и поднимаю сломанный карандаш."

translate russian ch2_s_good_bd41d9d6:
    "Сайори хватается за соседнюю парту, чтобы удержаться, — колени у неё дрожат."

translate russian ch2_s_good_1e3877e5:
    s 5b "Я-я сегодня немножко неуклюжая..."

translate russian ch2_s_good_bd4eb340:
    s "А-ха-ха-ха..."

translate russian ch2_s_good_a9e20081:
    mc "Давай сядем, Сайори..."

translate russian ch2_s_good_e7bbb62b:
    s 4y "Д-давай..."

translate russian ch2_s_good_7385e272:
    "Я беру Сайори за руку и помогаю ей сесть за парту."

translate russian ch2_s_good_a9927873:
    mc "Кстати, я ведь до сих пор не прочитал твоё стихотворение..."

translate russian ch2_s_good_148a2d6d:
    s 4b "Ой!"

translate russian ch2_s_good_1bc59e38:
    s "Прости, я совсем забыла~"

translate russian ch2_s_good_01ee1233:
    s 1h "Но оно не такое хорошее, как твоё!!"

translate russian ch2_s_good_1cba9adb:
    mc "Боже, не волнуйся."

translate russian ch2_s_good_e8f94437:
    mc "Уверен, мне понравится."

translate russian ch3_s_bad_e1554201:
    s "..."

translate russian ch3_s_bad_826ee4b4:
    s 1k "...Хм."

translate russian ch3_s_bad_15f8d5bb:
    s "Оно милое, наверное~"

translate russian ch3_s_bad_70fe31f6:
    mc "Да ладно, я же вижу, что тебе не нравится."

translate russian ch3_s_bad_bc57d696:
    s 1d "Ну..."

translate russian ch3_s_bad_de7d409a:
    s "Тебе не нужно переживать, что я думаю."

translate russian ch3_s_bad_27d55987:
    s 2y "Ты ведь писал его для кого-то другого, правда?"

translate russian ch3_s_bad_d782c986:
    s "Наверное, это всё [currentname!t]..."

translate russian ch3_s_bad_b8c522fc:
    mc "Что??"

translate russian ch3_s_bad_cc4d0854:
    mc "Я его ни для кого конкретно не писал!"

translate russian ch3_s_bad_42c3de85:
    s "Может быть..."

translate russian ch3_s_bad_d2815214:
    s 1d "Хотя я не совсем это имела в виду."

translate russian ch3_s_bad_68058b71:
    s "Но всё в порядке."

translate russian ch3_s_bad_904a3174:
    s "Ты находишь новых друзей, как я и надеялась."

translate russian ch3_s_bad_468760bf:
    s 1q "Это меня... очень радует."

translate russian ch3_s_bad_e6acf7be:
    s "И ты ведь тоже счастлив, правда?"

translate russian ch3_s_bad_a59ef9e9:
    s 1a "В этом клубе?"

translate russian ch3_s_bad_c14c584c:
    mc "Ну..."

translate russian ch3_s_bad_f2a59416:
    mc "Конечно."

translate russian ch3_s_bad_42dab8b7:
    s 4q "Вот и хорошо~"

translate russian ch3_s_bad_194142fb:
    s "Для меня только это и важно."

translate russian ch3_s_bad_605b7d7a:
    s 1d "Спасибо тебе, [player]."

translate russian ch3_s_bad_e87e0575:
    mc "Сайори..."

translate russian ch3_s_bad_56e8300e:
    mc "Что-то случилось?"

translate russian ch3_s_bad_ce9e0888:
    s 1b "А?"

translate russian ch3_s_bad_d0f5a386:
    s 1k "Нет, ничего."

translate russian ch3_s_bad_f7b2ed6b:
    s "Я просто сегодня немножко устала."

translate russian ch3_s_bad_7b2365c3:
    s 1l "Э-хе-хе."

translate russian ch3_s_bad_b12907fb:
    mc "Ладно..."

translate russian ch3_s_bad_a3847011:
    mc "Если что-нибудь понадобится, просто скажи."

translate russian ch3_s_bad_d43dfd71:
    s 1a "Скажу."

translate russian ch3_s_bad_075703d6:
    s "Не переживай за меня, ладно?"

translate russian ch3_s_bad_2c8d383a:
    s "Теперь можешь пойти поиграть с остальными."

translate russian ch3_s_bad_0385b06b:
    mc "Раз ты настаиваешь..."

translate russian ch3_s_bad_df253bf7:
    s 4q "Ура-а~"

translate russian ch3_s_bad_b3d216a1:
    s 4a "Я сегодня уйду домой чуть пораньше."

translate russian ch3_s_bad_e47a0e88:
    mc "Сайори...?"

translate russian ch3_s_bad_951b4bf7:
    s 1q "Скажи Монике, что мне нездоровилось, ладно?"

translate russian ch3_s_bad_2c824509:
    s "Увидимся завтра~"

translate russian ch3_s_bad_5d66f349:
    "Прежде чем я успеваю что-то сказать, Сайори весело выходит из класса, напевая себе под нос."

translate russian ch3_s_good_e9fdfc88:
    s 1d "..."

translate russian ch3_s_good_dccd2575:
    s "Это твоё лучшее стихотворение."

translate russian ch3_s_good_41eaeea5:
    s "Оно очень-очень хорошее, [player]~"

translate russian ch3_s_good_eece8b48:
    mc "Э-э— Спасибо."

translate russian ch3_s_good_8936817a:
    s 1q "Угу~"

translate russian ch3_s_good_2b35b6fe:
    mc "..."

translate russian ch3_s_good_d8faa5f8:
    mc "Сайори, ты сегодня какая-то тихая."

translate russian ch3_s_good_86bcc222:
    mc "Всё в порядке?"

translate russian ch3_s_good_f8816a49:
    s 4m "А-а??"

translate russian ch3_s_good_6b7d410a:
    s "Конечно!"

translate russian ch3_s_good_5a33dc51:
    s 4l "Всё хорошо~"

translate russian ch3_s_good_2eb8abb8:
    s "Может, я просто сегодня немножко устала."

translate russian ch3_s_good_7b2365c3:
    s 1l "Э-хе-хе."

translate russian ch3_s_good_a68fb8d9:
    mc "Хочешь вздремнуть или вроде того?"

translate russian ch3_s_good_63e8f1c5:
    s 1h "Нет, это глупо!"

translate russian ch3_s_good_075703d6:
    s "Не переживай за меня, ладно?"

translate russian ch3_s_good_d4a14fcf:
    s 1q "Я хочу видеть у вас на лицах только улыбки~"

translate russian ch3_s_good_aa6cef40:
    mc "Ну, ладно..."

translate russian ch3_s_good_9898a3fc:
    s 1b "Эй, [player]..."

translate russian ch3_s_good_2f3cf047:
    s "Я всё ещё немножко удивлена."

translate russian ch3_s_good_c039897b:
    s "Я правда думала, что ты начнёшь писать стихи так, как пишет Юри..."

translate russian ch3_s_good_d546d225:
    s 1y "Или даже Нацуки..."

translate russian ch3_s_good_534eeda5:
    s "Но в итоге..."

translate russian ch3_s_good_c300082f:
    mc "...Да."

translate russian ch3_s_good_4e7b6fec:
    mc "Похоже, это стихотворение нравится больше всех именно тебе."

translate russian ch3_s_good_028e5587:
    s 1k "...Почему?"

translate russian ch3_s_good_47a60e18:
    s "Ты разве не хочешь сблизиться с остальными?"

translate russian ch3_s_good_8b5e620a:
    mc "Подожди!"

translate russian ch3_s_good_7ee22fb4:
    mc "Конечно, хочу!"

translate russian ch3_s_good_47bfdc11:
    mc "Но это не значит, что я должен так уж стараться их впечатлить."

translate russian ch3_s_good_3e0d6383:
    mc "Тебя я всё равно понимаю лучше всех, Сайори."

translate russian ch3_s_good_57abb626:
    mc "Я знаю, что тебе иногда приходится меня терпеть."

translate russian ch3_s_good_8fdab651:
    mc "А мне иногда приходится терпеть тебя."

translate russian ch3_s_good_e9abcaf6:
    mc "Но мы как будто... на одной волне, что ли."

translate russian ch3_s_good_7c54dd2e:
    mc "Вот и стихотворение вышло таким."

translate russian ch3_s_good_f63822c7:
    mc "Иногда мне кажется, что ты — единственное, что есть интересного в моей жизни."

translate russian ch3_s_good_d2b4a4a0:
    mc "Поэтому иногда мне просто легче писать, когда я думаю о тебе."

translate russian ch3_s_good_afb84914:
    mc "...Сайори?"

translate russian ch3_s_good_ef7ef4bc:
    s 4v "Н-нет..."

translate russian ch3_s_good_23d81314:
    s "[player]..."

translate russian ch3_s_good_fb0a2b81:
    s "Я не... заслуживаю этого..."

translate russian ch3_s_good_41cb4dd1:
    s "Ты слишком добр ко мне..."

translate russian ch3_s_good_2dd1d27f:
    s "Зачем ты так...?"

translate russian ch3_s_good_8ad9226e:
    "Сайори вдруг с трудом удаётся говорить ровным голосом."

translate russian ch3_s_good_4a2ea0b8:
    s "Если бы ты веселился с остальными..."

translate russian ch3_s_good_7770f345:
    s "Всё было бы... гораздо проще!"

translate russian ch3_s_good_4f50e214:
    mc "Сайори...!"

translate russian ch3_s_good_bd584f4a:
    "Я оглядываю комнату, чтобы убедиться, что никто этого не заметил."

translate russian ch3_s_good_bf3e34d4:
    mc "Сайори."

translate russian ch3_s_good_b0c434f0:
    mc "Наверное, я никогда раньше такого не говорил, но я не понимаю, что ты сейчас чувствуешь."

translate russian ch3_s_good_1a7043e5:
    mc "Скажи, что тебя развеселит."

translate russian ch3_s_good_00494714:
    "Сайори качает головой."

translate russian ch3_s_good_619857fb:
    "Она шмыгает носом и продолжает качать головой."

translate russian ch3_s_good_b54b1753:
    "Наконец она берёт себя в руки и натягивает улыбку."

translate russian ch3_s_good_657ecaac:
    s 1y "Ничего, [player]."

translate russian ch3_s_good_0e0f73ec:
    s "Это просто маленькая дождевая тучка."

translate russian ch3_s_good_92b876c0:
    s 4r "Прости, что тебе пришлось это увидеть. А-ха-ха-ха!"

translate russian ch3_s_good_57b21542:
    s "Обещаю, такого больше не повторится."

translate russian ch3_s_good_a8a1c355:
    s 1a "Только улыбки у всех, ладно?"

translate russian ch3_s_good_e1ff45cf:
    s "Только это и важно."

translate russian ch3_s_good_e15d60a5:
    s "Иди поиграй с остальными."

translate russian ch3_s_good_1952a617:
    s "Я сегодня уйду домой чуть пораньше~"

translate russian ch3_s_good_4de86fac:
    mc "Сайори—"

translate russian ch3_s_good_fe87d870:
    s 2q "Скажи Монике, что мне нездоровилось, ладно?"

translate russian ch3_s_good_2c824509:
    s "Увидимся завтра~"

translate russian ch3_s_good_5d66f349:
    "Прежде чем я успеваю что-то сказать, Сайори весело выходит из класса, напевая себе под нос."

translate russian ch1_y_bad_345ff396:
    y 1g "..."

translate russian ch1_y_bad_6cef37bf:
    y "М-м..."

translate russian ch1_y_bad_71a86863:
    y "..."

translate russian ch1_y_bad_629c16c3:
    "Юри смотрит на стихотворение."

translate russian ch1_y_bad_7803dd5b:
    "Проходит минута — более чем достаточно, чтобы его дочитать."

translate russian ch1_y_bad_6b0ed824:
    mc "Э-э..."

translate russian ch1_y_bad_2b30c5bc:
    y "Ой!"

translate russian ch1_y_bad_2ec78d55:
    y 3n "П-прости...!"

translate russian ch1_y_bad_9b9fe018:
    y "Я забыла начать говорить..."

translate russian ch1_y_bad_d782d4e1:
    y "Э-э-эй!"

translate russian ch1_y_bad_b813612c:
    mc "Ничего, не заставляй себя."

translate russian ch1_y_bad_d96a1c53:
    y 2v "Я не заставляю..."

translate russian ch1_y_bad_6ac96bae:
    y "Мне просто нужно облечь мысли в слова."

translate russian ch1_y_bad_17b5b652:
    y "Подожди..."

translate russian ch1_y_bad_4581b981:
    y "...Так."

translate russian ch1_y_bad_bfcd5846:
    y 1f "Ты ведь впервые пишешь стихотворение, верно?"

translate russian ch1_y_bad_424bb874:
    mc "Э-э, да..."

translate russian ch1_y_bad_fccb9547:
    mc "А почему ты спрашиваешь?"

translate russian ch1_y_bad_37aaa19b:
    y "Просто хочу убедиться."

translate russian ch1_y_bad_d418a8e8:
    y "Я догадалась об этом, когда его прочитала."

translate russian ch1_y_bad_118be887:
    mc "А, значит, всё так плохо."

translate russian ch1_y_bad_9e6f3036:
    y 2p "Нет!!"

translate russian ch1_y_bad_900da743:
    y 2o "...Я что, повысила голос...?"

translate russian ch1_y_bad_b592d04c:
    y 4c "У-у, мне так жаль..."

translate russian ch1_y_bad_51b19f77:
    "Юри закрывает лицо руками."

translate russian ch1_y_bad_ad0dee08:
    "Не могу не заметить, что прошло уже несколько минут, а мы так ни к чему и не пришли."

translate russian ch1_y_bad_55519dbe:
    "Юри, видимо, нужно время, чтобы привыкнуть к новым людям..."

translate russian ch1_y_bad_53c85a47:
    mc "Ничего, я правда даже не заметил."

translate russian ch1_y_bad_75c873de:
    mc "Так что ты говорила?"

translate russian ch1_y_bad_15fe30f1:
    y 2u "Да... э-э..."

translate russian ch1_y_shared_7c507061:
    y 1a "Просто есть определённые привычки, которые обычно свойственны начинающим авторам."

translate russian ch1_y_shared_d0549eec:
    y "И раз уж я сама через это прошла, то научилась их замечать."

translate russian ch1_y_shared_b82469fb:
    y 1i "По-моему, сильнее всего у новичков заметно то, что они стараются сделать свой стиль очень нарочитым."

translate russian ch1_y_shared_de867a0a:
    y "Иначе говоря, они выбирают стиль отдельно от темы, а потом подгоняют одно к другому."

translate russian ch1_y_shared_7aa556cf:
    y 1a "В итоге страдают и стиль, и выразительность."

translate russian ch1_y_shared_fde92c86:
    "Стоит Юри поймать нить мысли, как она будто становится совсем другим человеком."

translate russian ch1_y_shared_b63ac72e:
    "Она больше совсем не запинается и говорит как настоящий знаток."

translate russian ch1_y_shared_24743e8b:
    y 1k "Конечно, тебя в этом винить нельзя."

translate russian ch1_y_shared_cdb2ff35:
    y "Даже в простое стихотворение вкладывается столько разных навыков и приёмов."

translate russian ch1_y_shared_0e73ed18:
    y 1a "Мало их найти и развить — заставить их работать вместе, наверное, сложнее всего."

translate russian ch1_y_shared_92e06664:
    y "Возможно, на это уйдёт время, но всё приходит с практикой, с изучением чужих примеров и с поиском нового."

translate russian ch1_y_shared_59e9071e:
    y "Ещё я надеюсь, что остальные в клубе тоже дадут тебе полезные отзывы."

translate russian ch1_y_shared_2208d43b:
    y 1l "Хотя Нацуки бывает немного пристрастна..."

translate russian ch1_y_shared_f14b44ed:
    mc "Пристрастна? В чём?"

translate russian ch1_y_shared_10588528:
    y 2j "Э-э..."

translate russian ch1_y_shared_ae7f22e8:
    y "Ну..."

translate russian ch1_y_shared_0b1a4f2b:
    y "Забудь..."

translate russian ch1_y_shared_48f7b580:
    y "Мне не стоит так говорить о людях..."

translate russian ch1_y_shared_485fb852:
    y "Прости..."

translate russian ch1_y_shared_a75a132d:
    mc "Ничего страшного."

translate russian ch1_y_shared_98dd47bb:
    "Не уверен, перед кем Юри извиняется — перед собой, передо мной или перед Нацуки."

translate russian ch1_y_shared_95f8117c:
    mc "Не возражаешь, если я теперь прочитаю твоё стихотворение?"

translate russian ch1_y_shared_a6d1cfca:
    y 3c "Пожалуйста!"

translate russian ch1_y_shared_f59e1313:
    y "Я с радостью расскажу, как я его придумывала..."

translate russian ch1_y_shared_3e61fb73:
    "Юри мечтательно улыбается, словно ей нечасто выпадает такая возможность."

translate russian ch1_y_shared_54073218:
    "Что само по себе довольно забавно..."

translate russian ch1_y_shared_e114fd69:
    "...Это ведь вроде как литературный клуб?"

translate russian ch1_y_good_ed5682e0:
    y 1e "..."

translate russian ch1_y_good_0e085f24:
    "Пока Юри читает стихотворение, я замечаю, как светлеют её глаза."

translate russian ch1_y_good_2faf097b:
    y 2f "...Исключительно."

translate russian ch1_y_good_dfdd7fc8:
    mc "А? Что ты сказала?"

translate russian ch1_y_good_1ce9c404:
    y "...?"

translate russian ch1_y_good_976d4012:
    y 2n "Я-я сказала это вслух...?"

translate russian ch1_y_good_bf362c99:
    "Сначала Юри прикрывает рот, а потом и вовсе закрывает лицо руками."

translate russian ch1_y_good_1fe24cdc:
    y 4c "Я...!"

translate russian ch1_y_good_6559e79e:
    y "У-у..."

translate russian ch1_y_good_c7f94487:
    y "{i}(Он меня возненавидит...){/i}"

translate russian ch1_y_good_6b0ed824:
    mc "Э-э..."

translate russian ch1_y_good_b5b5009c:
    mc "Ты правда не сделала ничего плохого, Юри..."

translate russian ch1_y_good_f535a4f0:
    y 4a "А...?"

translate russian ch1_y_good_717cb0f3:
    y "Это..."

translate russian ch1_y_good_095e579f:
    y 2q "Н-наверное, ты прав..."

translate russian ch1_y_good_c2afc78a:
    y "Чего это я так разволновалась?"

translate russian ch1_y_good_a2ff911b:
    y "А-ха-ха..."

translate russian ch1_y_good_58917022:
    "Юри делает вдох."

translate russian ch1_y_good_87f9f194:
    y "Так что..."

translate russian ch1_y_good_3d222e4c:
    y 1a "Какой у тебя опыт в писательстве?"

translate russian ch1_y_good_cfb79c7c:
    y "То, как ты используешь образы и метафоры, говорит о том, что ты уже много писал стихов."

translate russian ch1_y_good_72610a7c:
    mc "Правда...?"

translate russian ch1_y_good_79eb53c0:
    mc "Ого, от тебя это огромный комплимент."

translate russian ch1_y_good_6e3de235:
    mc "Вообще-то, я пишу впервые, честно."

translate russian ch1_y_good_d670fa93:
    y 1e "А...?"

translate russian ch1_y_good_18154cf1:
    "Юри непонимающе смотрит на меня, а потом снова на моё стихотворение."

translate russian ch1_y_good_71a86863:
    y "..."

translate russian ch1_y_good_f9742e44:
    y 2h "...Ну, я это знаю!"

translate russian ch1_y_good_e3f2d640:
    y "Я просто имела в виду... э-э..."

translate russian ch1_y_good_44388ab3:
    "Юри умолкает, не найдя оправдания."

translate russian ch1_y_good_83c56976:
    "Она ведёт пальцем по строчкам, словно разбирая стихотворение ещё тщательнее."

translate russian ch1_y_good_12c616eb:
    y 2l "...Да."

translate russian ch1_y_good_0b77dadf:
    y "Хорошо."

translate russian ch1_y_good_e1b568f9:
    y "Вот почему я смогла это понять."

translate russian ch2_y_bad_71a86863:
    y "..."

translate russian ch2_y_bad_57baf64f:
    y 2h "Э-э..."

translate russian ch2_y_bad_211dfb12:
    y "...Ты всё ещё на меня сердишься?"

translate russian ch2_y_bad_af40f385:
    mc "Что?!"

translate russian ch2_y_bad_21ef176b:
    y "За то, что я вчера была неуважительна к Нацуки..."

translate russian ch2_y_bad_5f0c0a6f:
    y "Потому что, читая это стихотворение..."

translate russian ch2_y_bad_8e14cddd:
    y "Теперь я понимаю, почему ты на меня рассердился."

translate russian ch2_y_bad_19b892a2:
    y "Потому что ты..."

translate russian ch2_y_bad_99414671:
    y 3v "Тебе её тексты нравятся больше моих!"

translate russian ch2_y_bad_69ee3afb:
    mc "Это не совсем так...!"

translate russian ch2_y_bad_00ecc785:
    y "А значит, когда я проявила неуважение к ней..."

translate russian ch2_y_bad_a514372f:
    y "Я проявила неуважение и к тебе... правда ведь?"

translate russian ch2_y_bad_6c9e27e0:
    y 4c "О нет..."

translate russian ch2_y_bad_d90390e4:
    mc "Юри..."

translate russian ch2_y_bad_d07f142c:
    mc "Кажется, ты слишком много в это вчитываешься..."

translate russian ch2_y_bad_27b70dee:
    y "Как я могла быть такой глупой...?"

translate russian ch2_y_bad_782a2639:
    y "Я вечно это допускаю..."

translate russian ch2_y_bad_f54886c3:
    y "Когда я думаю, прежде чем говорить, то выгляжу неловкой и неприятной."

translate russian ch2_y_bad_6d46a01b:
    y "А если говорю не подумав, наружу вырывается то, что я хочу держать в себе, и люди начинают меня ненавидеть."

translate russian ch2_y_bad_3a084ebc:
    y 2v "Так что... пожалуйста, не заставляй себя быть рядом со мной."

translate russian ch2_y_bad_8d6c70f2:
    y "Я знаю, что этого хочет Моника."

translate russian ch2_y_bad_6f728f91:
    y "Но это нечестно по отношению к тебе — ты мог бы приятно проводить время с Нацуки и Сайори."

translate russian ch2_y_bad_40d9123c:
    mc "Юри—"

translate russian ch2_y_bad_aa4ccf7a:
    y 4b "Пожалуйста..."

translate russian ch2_y_bad_024a7ff4:
    y "Мне будет легче, если ты не станешь за меня беспокоиться."

translate russian ch2_y_bad_a7b7bd96:
    y "К тому же..."

translate russian ch2_y_bad_9f840a77:
    y "У меня есть мои книги."

translate russian ch2_y_bad_2cc7794c:
    y 3u "Это... всё, что мне нужно."

translate russian ch2_y_bad_2b35b6fe:
    mc "..."

translate russian ch2_y_bad_b75c60f5:
    "Юри грустно улыбается и опускает голову на парту."

translate russian ch2_y_bad_f06a89d6:
    "Меня это задевает."

translate russian ch2_y_bad_8e149fef:
    "Я её не ненавижу, но она словно не способна расслышать меня сквозь собственные мысли."

translate russian ch2_y_bad_4a07b043:
    "Я вздыхаю про себя."

translate russian ch2_y_bad_c8d8f3ef:
    "Мне остаётся только принять, что она такая."

translate russian ch2_y_bad_d6dbd480:
    "Если она хочет, чтобы её оставили в покое, у меня нет выбора — придётся уважить её просьбу."

translate russian ch2_y_bad_1ef211b6:
    y 2a "Ах, теперь моя очередь?"

translate russian ch2_y_bad_4836265b:
    y "Посмотрим, как оно в сравнении со вчерашним..."

translate russian ch2_y_bad_6cef37bf:
    y "М-м..."

translate russian ch2_y_bad_dde3ed59:
    y "Понятно..."

translate russian ch2_y_bad_b951602e:
    y "Оно немного другое."

translate russian ch2_y_bad_1e6a485b:
    y 1a "Я уважаю тебя за то, что ты пробуешь разное, [player]."

translate russian ch2_y_bad_61bef8d5:
    y "Тебя вдохновило стихотворение Нацуки?"

translate russian ch2_y_bad_3e9b9b8b:
    y "Или, может, Сайори?"

translate russian ch2_y_bad_c14c584c:
    mc "Ну..."

translate russian ch2_y_bad_8640be65:
    mc "Можно и так сказать..."

translate russian ch2_y_bad_4dfc34ef:
    y "Я так и думала."

translate russian ch2_y_bad_0b5c0cf4:
    y 2u "Я рада за тебя."

translate russian ch2_y_bad_16c5dfa8:
    y "Тебе не нужно искать вдохновения в моих стихах."

translate russian ch2_y_bad_877dc66e:
    y "Я пишу их для себя..."

translate russian ch2_y_bad_30ff2bc1:
    y 4b "...А не для кого-то другого."

translate russian ch2_y_bad_42db5513:
    y "Так что мне не очень... нужно, чтобы они кому-то нравились."

translate russian ch2_y_bad_530f484c:
    mc "Юри!"

translate russian ch2_y_bad_b953c215:
    y 3t "А-а?"

translate russian ch2_y_bad_efd36996:
    mc "Прости за прямоту, но ты немного накручиваешь себя."

translate russian ch2_y_bad_020f8801:
    mc "То, что у нас разные стили, ещё не значит, что мне не нравятся твои стихи..."

translate russian ch2_y_bad_9c1d1b3f:
    mc "Наоборот, если бы я попробовал писать в твоём стиле, у меня бы, наверное, вышло просто ужасно."

translate russian ch2_y_bad_593dcbdd:
    y 4a "Я... понятно..."

translate russian ch2_y_bad_df164599:
    y "Прости..."

translate russian ch2_y_bad_50f9cd72:
    y "Мой глупый разум... иногда он так делает."

translate russian ch2_y_bad_c03f336e:
    y "В общем..."

translate russian ch2_y_shared_f1a72134:
    y 2h "Не бойся быть чуточку смелее..."

translate russian ch2_y_shared_7f01fce7:
    y "Метафоры способны на многое."

translate russian ch2_y_shared_4b5ff4b6:
    y "Не думай, что нужно заставлять мозг работать, будто крутишь кучу шестерёнок."

translate russian ch2_y_shared_8bfd21ff:
    y 1m "Попробуй позволить мыслям бродить среди твоих чувств..."

translate russian ch2_y_shared_2aa04967:
    y "И записывай то, что видишь и слышишь."

translate russian ch2_y_shared_6634f898:
    y "Это один из способов по-настоящему впустить читателя в свою голову."

translate russian ch2_y_shared_8b8a28d2:
    y 2u "Это очень сокровенное упражнение..."

translate russian ch2_y_shared_054c5ee0:
    mc "Понятно."

translate russian ch2_y_shared_882a966d:
    mc "Определённо интересный приём."

translate russian ch2_y_shared_aa50b32a:
    mc "Спасибо, что поделилась."

translate russian ch2_y_shared_5ef13d0d:
    y 2v "У меня есть, э-э..."

translate russian ch2_y_shared_7203aec2:
    y "...Ну, пример этого, если хочешь прочитать..."

translate russian ch2_y_shared_1bf60051:
    mc "Конечно."

translate russian ch2_y_shared_76dc218a:
    mc "Это стихотворение ты написала на сегодня?"

translate russian ch2_y_shared_a4c69661:
    "Юри кивает и робко протягивает мне своё стихотворение."

translate russian ch2_y_med_595439f7:
    y 1a "Давай посмотрим, что ты написал на сегодня."

translate russian ch2_y_med_71a86863:
    y "..."

translate russian ch2_y_med_6cef37bf:
    y "М-м..."

translate russian ch2_y_med_49a42ec0:
    y 1c "Отличная работа, [player]."

translate russian ch2_y_med_1e180b13:
    y "Твоё мастерство уже растёт."

translate russian ch2_y_med_a31340dd:
    mc "Правда?"

translate russian ch2_y_med_0fb9fde4:
    mc "Спасибо, Юри."

translate russian ch2_y_med_aaf816b0:
    mc "От тебя это многого стоит."

translate russian ch2_y_med_6dde5b86:
    y 3f "А?"

translate russian ch2_y_med_ea00163a:
    y 3v "Д-да ничего особенного!"

translate russian ch2_y_med_e307176a:
    y "Я просто рада вдохновлять собратьев по перу..."

translate russian ch2_y_med_79d95be2:
    y "Я знаю, что ты в этом новичок, так что не переживай, если кажется, что стихотворение никак не выходит идеальным."

translate russian ch2_y_med_595439f7_1:
    y 1a "Давай посмотрим, что ты написал на сегодня."

translate russian ch2_y_med_71a86863_1:
    y "..."

translate russian ch2_y_med_6cef37bf_1:
    y "М-м..."

translate russian ch2_y_med_38f760a5:
    y "Это довольно хорошо, [player]."

translate russian ch2_y_med_801babe4:
    y "На тебя повлияло то, как по-разному все пишут, — после вчерашнего?"

translate russian ch2_y_med_8640be65:
    mc "Можно и так сказать..."

translate russian ch2_y_med_ca256f9f:
    y 1m "Меня тоже немного удивило, насколько разные у всех стили."

translate russian ch2_y_med_ef4e562e:
    y "Поэтому я уважаю тебя за то, что пробуешь новое."

translate russian ch2_y_good_595439f7:
    y 1a "Давай посмотрим, что ты написал на сегодня."

translate russian ch2_y_good_71a86863:
    y "..."

translate russian ch2_y_good_653f3d05:
    y 2e "......"

translate russian ch2_y_good_60fd42a2:
    "Юри с удивлённым лицом смотрит на стихотворение."

translate russian ch2_y_good_a4fb38a3:
    mc "Тебе... нравится?"

translate russian ch2_y_good_c60c5441:
    y "[player]..."

translate russian ch2_y_good_9c78e0ce:
    y "...Как ты так быстро это уловил?"

translate russian ch2_y_good_shared_9b7b3447:
    y 2v "Ведь только вчера я рассказывала тебе, какие приёмы стоит отрабатывать..."

translate russian ch2_y_good_shared_73030027:
    mc "Может, поэтому..."

translate russian ch2_y_good_shared_f8777275:
    mc "Ты хорошо объяснила."

translate russian ch2_y_good_shared_4ff08e3f:
    mc "Мне очень хотелось попробовать добавить больше образов."

translate russian ch2_y_good_shared_4ba84665:
    "Юри заметно сглатывает."

translate russian ch2_y_good_shared_886256e6:
    "Кажется, у неё даже вспотели ладони."

translate russian ch2_y_good_shared_b0152027:
    y "Я не... привыкла к такому..."

translate russian ch2_y_good_shared_4f3efe52:
    mc "К чему?"

translate russian ch2_y_good_shared_a4567583:
    y 3o "Не знаю...!"

translate russian ch2_y_good_shared_b8557127:
    mc "Ничего, не торопись..."

translate russian ch2_y_good_shared_0bf00bc2:
    "Юри делает вдох и собирается с мыслями."

translate russian ch2_y_good_shared_1ac6f898:
    "Я знаю, что Юри любит подумать, прежде чем говорить, поэтому даю ей время."

translate russian ch2_y_good_shared_efa77fe0:
    y 4a "Ну вот..."

translate russian ch2_y_good_shared_a932fb2a:
    y "Просто... что меня вот так ценят... наверное."

translate russian ch2_y_good_shared_06f847e6:
    y "Это, наверное, звучит очень глупо..."

translate russian ch2_y_good_shared_7996203f:
    y "Но когда я вижу, что мои тексты кого-то вдохновляют..."

translate russian ch2_y_good_shared_459f3416:
    y "Мне просто становится..."

translate russian ch2_y_good_shared_43a35ba2:
    y "Очень радостно..."

translate russian ch2_y_good_shared_a92cdcaf:
    mc "Хочешь сказать, ты никогда раньше не показывала свои тексты?"

translate russian ch2_y_good_shared_c588c8d6:
    "Юри кивает."

translate russian ch2_y_good_shared_938e8e07:
    mc "Правда? Не верю."

translate russian ch2_y_good_shared_f7679d98:
    y "Я правда пишу только для себя..."

translate russian ch2_y_good_shared_5166aceb:
    y "И к тому же..."

translate russian ch2_y_good_shared_d271e484:
    y 3w "...Люди бы надо мной просто смеялись!"

translate russian ch2_y_good_shared_b0a23e4c:
    mc "Ты правда так думаешь...?"

translate russian ch2_y_good_shared_62bda041:
    "Юри снова кивает."

translate russian ch2_y_good_shared_5693a819:
    mc "Хм..."

translate russian ch2_y_good_shared_e34bd1c4:
    mc "Даже близкие друзья?"

translate russian ch2_y_good_shared_a3dfe221:
    y 2v "..."

translate russian ch2_y_good_shared_bf9c5fa0:
    "На это Юри ничего не отвечает."

translate russian ch2_y_good_shared_e9eaa872:
    "Интересно почему..."

translate russian ch2_y_good_shared_7e00e9ab:
    mc "Как бы то ни было..."

translate russian ch2_y_good_shared_54d97cf3:
    mc "Покажешь стихотворение, которое написала на сегодня?"

translate russian ch2_y_good_shared_661f416a:
    y "...Да."

translate russian ch2_y_good_shared_f12cd7a9:
    y 3t "Покажу!"

translate russian ch2_y_good_shared_be79ad3c:
    y "Если тебе..."

translate russian ch2_y_good_shared_595439f7:
    y 1a "Давай посмотрим, что ты написал на сегодня."

translate russian ch2_y_good_shared_71a86863:
    y "..."

translate russian ch2_y_good_shared_653f3d05:
    y 2e "......"

translate russian ch2_y_good_shared_60fd42a2:
    "Юри с удивлённым лицом смотрит на стихотворение."

translate russian ch2_y_good_shared_a4fb38a3:
    mc "Тебе... нравится?"

translate russian ch2_y_good_shared_c60c5441:
    y "[player]..."

translate russian ch2_y_good_shared_84956fed:
    y "Это, возможно, даже лучше вчерашнего..."

translate russian ch2_y_good_shared_0b22d8b2:
    y "...Как ты вообще так быстро это уловил?"

translate russian ch3_y_bad12_shared_0dbaabdd:
    y 4b "..."

translate russian ch3_y_bad12_shared_ec0cd1d2:
    "Не похоже, чтобы Юри так уж хотелось проводить со мной время..."

translate russian ch3_y_bad12_shared_a6b51c30:
    "Наверное, если она передумает, то сама ко мне подойдёт."

translate russian ch3_y_bad12_shared_63765ee1:
    "Но пока лучше оставить её в покое."

translate russian ch3_y_bad12_shared_777f843d:
    y 1i "..."

translate russian ch3_y_bad12_shared_48e88d00:
    y "...Понятно."

translate russian ch3_y_bad12_shared_7b08ec51:
    y "Мне кажется, в целом ты пишешь всё лучше, [player]."

translate russian ch3_y_bad12_shared_fc57f812:
    y 2i "Но я не могу отделаться от ощущения, что выгляжу немного глупо."

translate russian ch3_y_bad12_shared_abf37378:
    mc "А? Почему?"

translate russian ch3_y_bad12_shared_fc0dc6fb:
    y "Просто..."

translate russian ch3_y_bad12_shared_2609bfc0:
    y "Мне кажется, я всё пыталась давать тебе советы..."

translate russian ch3_y_bad12_shared_1ebce6f7:
    y "Хотя мне должно было быть ясно, что тебе ближе другой стиль."

translate russian ch3_y_bad12_shared_c4055878:
    y 3w "Наверное, это звучало просто высокомерно!"

translate russian ch3_y_bad12_shared_ae76b5dc:
    y "Какая же я глупая..."

translate russian ch3_y_bad12_shared_83a1fc5d:
    mc "Юри, это уже немного—"

translate russian ch3_y_bad12_shared_c1612054:
    y 4b "Нет..."

translate russian ch3_y_bad12_shared_26ce1ca1:
    y "Ты не понимаешь."

translate russian ch3_y_bad12_shared_d4b1c4e0:
    y "Я столько времени переживала о том, что лучше, а что хуже."

translate russian ch3_y_bad12_shared_b8e047f7:
    y "Не только с тобой..."

translate russian ch3_y_bad12_shared_0ec92cb2:
    y "С Нацуки, с Сайори..."

translate russian ch3_y_bad12_shared_8bdc4334:
    y "Теперь очевидно, почему никому не нравится со мной разговаривать..."

translate russian ch3_y_bad12_shared_a2e2d428:
    y "И поэтому..."

translate russian ch3_y_bad12_shared_bb44206d:
    y 4c "...о твоём стихотворении я лучше промолчу!"

translate russian ch3_y_bad12_shared_2b35b6fe:
    mc "..."

translate russian ch3_y_bad12_shared_1700fb00:
    "Юри зарывается лицом в руки, сложенные на парте."

translate russian ch3_y_bad12_shared_07eeacef:
    "Уже не в первый раз я вижу, как она это делает."

translate russian ch3_y_bad12_shared_08b9e385:
    mc "По-моему, всё никогда не бывает так плохо, как тебе кажется..."

translate russian ch3_y_bad12_shared_71a86863:
    y "..."

translate russian ch3_y_bad12_shared_9c59a2cf:
    mc "Мне кажется, если бы людям правда не нравилось с тобой разговаривать..."

translate russian ch3_y_bad12_shared_40909dc5:
    mc "Это было бы куда заметнее."

translate russian ch3_y_bad12_shared_1fab1b1f:
    mc "Я знаю, что тебе нравится вчитываться во всё глубоко."

translate russian ch3_y_bad12_shared_e463565f:
    mc "Но некоторые вещи стоит просто принимать как есть."

translate russian ch3_y_bad12_shared_566499ce:
    y 4b "Мне просто..."

translate russian ch3_y_bad12_shared_eb3bcb9f:
    y "Я так к этому привыкла..."

translate russian ch3_y_bad12_shared_d888c284:
    y "...Что мне трудно представить что-то другое."

translate russian ch3_y_bad12_shared_21d37173:
    mc "Привыкла к чему?"

translate russian ch3_y_bad12_shared_815e7060:
    mc "Вчитываться во всё?"

translate russian ch3_y_bad12_shared_e9932589:
    y "К тому, что меня не любят."

translate russian ch3_y_bad12_shared_d90390e4:
    mc "Юри..."

translate russian ch3_y_bad12_shared_254d073a:
    y 2v "Что... что я такое говорю?"

translate russian ch3_y_bad12_shared_df164599:
    y "Прости..."

translate russian ch3_y_bad12_shared_a1871f95:
    y "Я вовсе не собиралась об этом заговаривать..."

translate russian ch3_y_bad12_shared_c85aa698:
    "Юри отворачивается от меня."

translate russian ch3_y_bad12_shared_ced625d1:
    y 4b "Тебе лучше уйти..."

translate russian ch3_y_bad12_shared_bbe4458e:
    mc "А...?"

translate russian ch3_y_bad12_shared_cb16339d:
    y "Пожалуйста..."

translate russian ch3_y_bad12_shared_fec454d5:
    y "Пожалуйста, не смотри на меня сейчас."

translate russian ch3_y_bad12_shared_8661f587:
    y "Мне нужно подумать..."

translate russian ch3_y_bad12_shared_977e733b:
    mc "Ты уверена...?"

translate russian ch3_y_bad12_shared_c588c8d6:
    "Юри кивает."

translate russian ch3_y_bad12_shared_b12907fb:
    mc "Ладно..."

translate russian ch3_y_bad12_shared_431bf265:
    "Я оставляю Юри в покое."

translate russian ch3_y_bad12_shared_73010dc3:
    "Утешить или успокоить её и так почти невозможно."

translate russian ch3_y_bad12_shared_0bd2ea2c:
    "Поэтому, когда она хочет побыть одна, мне кажется, что любые мои слова сделают только хуже."

translate russian ch3_y_bad12_shared_6fe25445:
    "Мне неловко, но, к счастью, она не вымещает это на мне..."

translate russian ch3_y_bad12_shared_0a2bcd74:
    "Подожду, пока ей станет чуть лучше."

translate russian ch3_y_bad12_shared_cea5be14:
    y 1a "..."

translate russian ch3_y_bad12_shared_6885d9b7:
    y "...А."

translate russian ch3_y_bad12_shared_c454591a:
    y "Решил сегодня попробовать что-то другое?"

translate russian ch3_y_bad12_shared_8cc105c3:
    mc "Похоже на то."

translate russian ch3_y_bad12_shared_478539f7:
    mc "Это хорошо или плохо?"

translate russian ch3_y_bad12_shared_05404a6a:
    y 2g "Ну, ни то ни другое."

translate russian ch3_y_bad12_shared_2f21e1e0:
    y "У меня есть свои предпочтения."

translate russian ch3_y_bad12_shared_437aa0a5:
    y "Но было бы нечестно с моей стороны называть что-то хорошим или плохим, исходя только из них."

translate russian ch3_y_shared_577c823e:
    y 1f "Как всегда, я считаю, что самое важное — исследовать и открывать себя."

translate russian ch3_y_shared_2fe267d0:
    mc "Это успокаивает."

translate russian ch3_y_shared_79aae1ab:
    mc "Я немного боюсь тебя чем-нибудь разочаровать."

translate russian ch3_y_shared_45973046:
    y 2t "А...?"

translate russian ch3_y_shared_a2a517f3:
    y "Почему именно меня...?"

translate russian ch3_y_shared_8379c136:
    mc "Ну, ты всегда пишешь так изысканно, и советов у тебя больше всех."

translate russian ch3_y_shared_7fb3257f:
    y 4a "Правда...?"

translate russian ch3_y_shared_71a86863:
    y "..."

translate russian ch3_y_shared_ee768c9b:
    "Юри задумывается на целую минуту."

translate russian ch3_y_shared_6308e345:
    y 4c "...Это, должно быть, ужасно."

translate russian ch3_y_shared_fb2e5377:
    mc "А?"

translate russian ch3_y_shared_92ba95d4:
    y "Что я стала человеком, чьего мнения боятся..."

translate russian ch3_y_shared_799e459f:
    y "Как же это неприятно с моей стороны..."

translate russian ch3_y_shared_d90390e4:
    mc "Юри..."

translate russian ch3_y_shared_f0537c6d:
    mc "Всё не так плохо, как тебе кажется."

translate russian ch3_y_shared_6543ba0e:
    mc "Я просто имел в виду, что уважаю твоё мнение."

translate russian ch3_y_shared_07dea637:
    y 2v "Понятно..."

translate russian ch3_y_shared_098bd730:
    y "Прости, что я вечно всё обдумываю и прихожу к таким выводам..."

translate russian ch3_y_shared_5b9ca5be:
    y "Просто я... слишком к этому привыкла."

translate russian ch3_y_shared_1add665c:
    mc "К тому, чтобы всё обдумывать?"

translate russian ch3_y_shared_e9932589:
    y "К тому, что меня не любят."

translate russian ch3_y_shared_d90390e4_1:
    mc "Юри..."

translate russian ch3_y_shared_37bb71fc:
    y 3w "Что... что я такое говорю?"

translate russian ch3_y_shared_17f09c33:
    y "Прости, я не хотела об этом заговаривать..."

translate russian ch3_y_shared_564e0659:
    y "Давай дальше..."

translate russian ch3_y_shared_b12907fb:
    mc "Ладно..."

translate russian ch3_y_shared_9cce0e4a:
    mc "Покажешь теперь своё стихотворение?"

translate russian ch3_y_shared_46c645e6:
    y 2i "Хорошо..."

translate russian ch3_y_shared_b10f1203:
    y "Вот."

translate russian ch3_y_med_71a86863:
    y "..."

translate russian ch3_y_med_669876fa:
    y 1a "Отличная работа, [player]."

translate russian ch3_y_med_380fd70c:
    y "За эти несколько дней ты определённо стал писать лучше."

translate russian ch3_y_med_f8ed6357:
    y "Мои советы тебе помогли?"

translate russian ch3_y_med_645127f3:
    mc "Да... Определённо."

translate russian ch3_y_med_74cdff1d:
    y 2m "Я рада..."

translate russian ch3_y_med_cd3ace5b:
    y "Вот так делиться своими текстами..."

translate russian ch3_y_med_179fad61:
    y 2a "Это куда веселее и приятнее, чем я ожидала."

translate russian ch3_y_med_bdd2dc17:
    y "Нужно не забыть поблагодарить Монику..."

translate russian ch3_y_med_91e1d5bc:
    y "Думаю, поначалу нам всем было немного неловко."

translate russian ch3_y_med_22bdf28f:
    y 1a "Но теперь, кажется, всем нравится делиться своими текстами и узнавать, что думают другие."

translate russian ch3_y_med_76d238ae:
    mc "Пожалуй, не могу не согласиться."

translate russian ch3_y_med_521db46f:
    mc "Я боялся, что всё это будет тягостной обязанностью..."

translate russian ch3_y_med_07bc2355:
    "Но это отличный способ побыть наедине с каждой девушкой из клуба."

translate russian ch3_y_med_1259b64a:
    mc "Но было здорово узнать всех получше — и их тексты тоже."

translate russian ch3_y_med_a65db07b:
    mc "Ну и самому немного пописать..."

translate russian ch3_y_med_ddbc5dc6:
    y 2a "Ну..."

translate russian ch3_y_med_e94d8c8e:
    y "Ты узнал что-нибудь о себе, [player]?"

translate russian ch3_y_med_fb2e5377:
    mc "А?"

translate russian ch3_y_med_c22bb7f1:
    y 2i "Ну, ты ведь знаешь, я люблю повторять, что писательство — очень личный способ лучше понять себя..."

translate russian ch3_y_med_d5097b5b:
    y 1a "В конце концов, неважно, хорошо ты пишешь или плохо."

translate russian ch3_y_med_3f196977:
    y "И даже моё мнение — это всего лишь мнение... понимаешь?"

translate russian ch3_y_med_ed5682e0:
    y 1e "..."

translate russian ch3_y_med_6885d9b7:
    y "...А."

translate russian ch3_y_med_c454591a:
    y "Решил сегодня попробовать что-то другое?"

translate russian ch3_y_med_8cc105c3:
    mc "Похоже на то."

translate russian ch3_y_med_478539f7:
    mc "Это хорошо или плохо?"

translate russian ch3_y_med_e56e795d:
    y 2i "Ну, ни то ни другое."

translate russian ch3_y_med_2f21e1e0:
    y "У меня есть свои предпочтения."

translate russian ch3_y_med_437aa0a5:
    y "Но было бы нечестно с моей стороны называть что-то хорошим или плохим, исходя только из них."

translate russian ch3_y_good_71a86863:
    y "..."

translate russian ch3_y_good_5247301a:
    y 2u "[player]..."

translate russian ch3_y_good_45acf756:
    y "...Это чудесно."

translate russian ch3_y_good_1d893e91:
    y "Я чувствую эмоции, которые ты в него вложил."

translate russian ch3_y_good_3f72e1df:
    y "Это результат того, что ты попробовал мой вчерашний совет?"

translate russian ch3_y_good_8e64bc71:
    mc "Да, наверное..."

translate russian ch3_y_good_f8777275:
    mc "Ты хорошо объяснила."

translate russian ch3_y_good_34dbd777:
    mc "Мне очень хотелось вложить в него больше чувства."

translate russian ch3_y_good_4ba84665:
    "Юри заметно сглатывает."

translate russian ch3_y_good_886256e6:
    "Кажется, у неё даже вспотели ладони."

translate russian ch3_y_good_b0152027:
    y "Я не... привыкла к такому..."

translate russian ch3_y_good_4f3efe52:
    mc "К чему?"

translate russian ch3_y_good_a4567583:
    y 3o "Не знаю...!"

translate russian ch3_y_good_b8557127:
    mc "Ничего, не торопись..."

translate russian ch3_y_good_0bf00bc2:
    "Юри делает вдох и собирается с мыслями."

translate russian ch3_y_good_1ac6f898:
    "Я знаю, что Юри любит подумать, прежде чем говорить, поэтому даю ей время."

translate russian ch3_y_good_efa77fe0:
    y 4a "Ну вот..."

translate russian ch3_y_good_a932fb2a:
    y "Просто... что меня вот так ценят... наверное."

translate russian ch3_y_good_06f847e6:
    y "Это, наверное, звучит очень глупо..."

translate russian ch3_y_good_7996203f:
    y "Но когда я вижу, что мои тексты кого-то вдохновляют..."

translate russian ch3_y_good_459f3416:
    y "Мне просто становится..."

translate russian ch3_y_good_43a35ba2:
    y "Очень радостно..."

translate russian ch3_y_good_a92cdcaf:
    mc "Хочешь сказать, ты никогда раньше не показывала свои тексты?"

translate russian ch3_y_good_c588c8d6:
    "Юри кивает."

translate russian ch3_y_good_938e8e07:
    mc "Правда? Не верю."

translate russian ch3_y_good_f7679d98:
    y "Я правда пишу только для себя..."

translate russian ch3_y_good_5166aceb:
    y "И к тому же..."

translate russian ch3_y_good_d271e484:
    y 3w "...Люди бы надо мной просто смеялись!"

translate russian ch3_y_good_b0a23e4c:
    mc "Ты правда так думаешь...?"

translate russian ch3_y_good_62bda041:
    "Юри снова кивает."

translate russian ch3_y_good_5693a819:
    mc "Хм..."

translate russian ch3_y_good_e34bd1c4:
    mc "Даже близкие друзья?"

translate russian ch3_y_good_a3dfe221:
    y 2v "..."

translate russian ch3_y_good_329f33d7:
    "Почему-то Юри не отвечает."

translate russian ch3_y_good_c934e5a0:
    mc "Юри...?"

translate russian ch3_y_good_shared_668d0cb3:
    "Юри грустно улыбается."

translate russian ch3_y_good_shared_eb40cd87:
    y 1u "[player], на обеденном перерыве я ем одна."

translate russian ch3_y_good_shared_9a32aa71:
    y "Ты знал?"

translate russian ch3_y_good_shared_44c18a88:
    y "Это отличное время, чтобы найти тихий уголок и почитать."

translate russian ch3_y_good_shared_ab1aa460:
    y "Вообще..."

translate russian ch3_y_good_shared_c753dabd:
    y 2s "У меня всегда с собой есть книги."

translate russian ch3_y_good_shared_660631e2:
    y "Можно сказать, я очень люблю читать..."

translate russian ch3_y_good_shared_208c01ac:
    y "...Ну, это один из способов это выразить..."

translate russian ch3_y_good_shared_e45b137d:
    y "Но..."

translate russian ch3_y_good_shared_f111077a:
    y "Книги полны удивительных и вдохновляющих людей."

translate russian ch3_y_good_shared_662d32d4:
    y "Людей, в которых хочется влюбиться."

translate russian ch3_y_good_shared_b6e32d40:
    y "Или тех, о ком сразу понимаешь, что они стали бы прекрасными друзьями."

translate russian ch3_y_good_shared_2c838c68:
    y 1m "Весёлых людей, которые всегда вызывают у тебя улыбку..."

translate russian ch3_y_good_shared_a3ae4bd4:
    y "Или глубоких мыслителей и тех, кто разгадывает загадки жизни."

translate russian ch3_y_good_shared_153da9cf:
    y "Так что, если посмотреть с этой стороны..."

translate russian ch3_y_good_shared_70f0334d:
    y "Меня каждый день окружают друзья..."

translate russian ch3_y_good_shared_8a981dd2:
    y "...Понимаешь?"

translate russian ch3_y_good_shared_de5730b7:
    y 2s "И эти друзья не смеются надо мной..."

translate russian ch3_y_good_shared_69d6f1d1:
    y "Не дразнят меня за то, что я вечно витаю в облаках..."

translate russian ch3_y_good_shared_fce8d15a:
    y "Не насмехаются над моей фигурой..."

translate russian ch3_y_good_shared_83f5f92a:
    y "И..."

translate russian ch3_y_good_shared_bc45f6a9:
    y 3v "...И не ненавидят меня за то, что я веду себя как всезнайка!"

translate russian ch3_y_good_shared_dff3eb1c:
    mc "Люди... так о тебе говорят?"

translate russian ch3_y_good_shared_c03ad752:
    y "Я не всезнайка, [player]!"

translate russian ch3_y_good_shared_3e0267ac:
    y "Наоборот. Я ничего не знаю!"

translate russian ch3_y_good_shared_e292a19f:
    y 4b "Я не знаю, как разговаривать с людьми."

translate russian ch3_y_good_shared_0b001879:
    y "Не знаю, как сделать так, чтобы меня считали нормальной."

translate russian ch3_y_good_shared_5cc115c1:
    y "Я даже не знаю, как сделать саму себя счастливой!"

translate russian ch3_y_good_shared_be2cc099:
    y "У меня столько чувств..."

translate russian ch3_y_good_shared_ba0fcb81:
    y "А всё, что я могу с ними делать, — это читать и писать..."

translate russian ch3_y_good_shared_a73b9641:
    y "Но только сейчас..."

translate russian ch3_y_good_shared_4e62cde5:
    y 2s "Когда я начала делиться ими с тобой..."

translate russian ch3_y_good_shared_4406fe22:
    y "...Я по-настоящему поняла, чего мне всё это время не хватало."

translate russian ch3_y_good_shared_3fd0c4fb:
    mc "Но я же ничего особенного не сделал..."

translate russian ch3_y_good_shared_bfadd2bc:
    y "Нет..."

translate russian ch3_y_good_shared_95388211:
    y "Это не так."

translate russian ch3_y_good_shared_3043826f:
    y "Просто быть терпеливым и уважительным..."

translate russian ch3_y_good_shared_aba67f61:
    y 3u "Это очень... важно для меня."

translate russian ch3_y_good_shared_38fccb17:
    y "Я знаю, что со мной тяжело, [player]..."

translate russian ch3_y_good_shared_6db9e6c3:
    y "Я слишком медленно говорю..."

translate russian ch3_y_good_shared_b61d2c9c:
    y "Вечно в себе сомневаюсь..."

translate russian ch3_y_good_shared_1a544482:
    y "Слишком глубоко во всё вчитываюсь..."

translate russian ch3_y_good_shared_03ae49d6:
    y "Но каждый раз..."

translate russian ch3_y_good_shared_b760e366:
    y "Ты всегда относился ко мне так же, как ко всем остальным."

translate russian ch3_y_good_shared_7462ecda:
    y "Мне так редко бывает спокойно с самой собой, когда я говорю с другими..."

translate russian ch3_y_good_shared_bbbbfa1f:
    y "Но поэтому каждый раз, когда я говорю с тобой..."

translate russian ch3_y_good_shared_cc6bbd69:
    y 2s "...Мне просто очень хорошо."

translate russian ch3_y_good_shared_a7bcf340:
    mc "Понятно..."

translate russian ch3_y_good_shared_a1415db5:
    mc "Ну, я отношусь к тебе так, как ты того заслуживаешь, Юри."

translate russian ch3_y_good_shared_e8173935:
    mc "А если другие этого не видят, то и чёрт с ними."

translate russian ch3_y_good_shared_bbdf4723:
    mc "В смысле, я вступил в этот клуб в надежде завести друзей."

translate russian ch3_y_good_shared_5ea00206:
    mc "И, по-моему, хотя бы одна победа у меня есть."

translate russian ch3_y_good_shared_1ef14b3c:
    mc "Разве нет?"

translate russian ch3_y_good_shared_6897629e:
    y 4b "Э-э..."

translate russian ch3_y_good_shared_c9239ba4:
    y "Если так посмотреть..."

translate russian ch3_y_good_shared_5e56f304:
    y "...Да..."

translate russian ch3_y_good_shared_9a38caf2:
    y 4e "Мы ведь теперь и правда друзья, да?"

translate russian ch3_y_good_shared_aae51a9a:
    "Юри опускает голову на руки."

translate russian ch3_y_good_shared_ad54b0f0:
    "Но на этот раз она улыбается."

translate russian ch3_y_good_shared_1d9f017e:
    mc "Покажешь мне своё стихотворение?"

translate russian ch3_y_good_shared_f7d4bca6:
    y 3s "Ага."

translate russian ch3_y_good_shared_853bcb01:
    y "Покажу!"

translate russian ch3_y_good_shared_695aa4be:
    y "Сейчас достану..."

translate russian ch3_y_good_shared_71a86863:
    y "..."

translate russian ch3_y_good_shared_2f37247c:
    y "[player]."

translate russian ch3_y_good_shared_2ad9deaa:
    y 2s "За последние несколько дней ты пишешь только лучше."

translate russian ch3_y_good_shared_04d8464e:
    y "Каждое стихотворение, которое ты мне показывал, было не иначе как великолепным."

translate russian ch3_y_good_shared_097d7a95:
    y "Я правда чувствую эмоции..."

translate russian ch3_y_good_shared_88eaa9ee:
    y 2m "Даже немного завидую..."

translate russian ch3_y_good_shared_aa05e701:
    y "Не думаю, что мне это когда-нибудь давалось так естественно."

translate russian ch3_y_good_shared_7fbad1a3:
    mc "Юри, ты не так это понимаешь."

translate russian ch3_y_good_shared_4e1c1ec9:
    mc "Мне это никогда не давалось естественно."

translate russian ch3_y_good_shared_6fe9d523:
    mc "Но я смог так вырасти благодаря тебе."

translate russian ch3_y_good_shared_6a32a29f:
    mc "Ты и есть тот пример, за которым я тянулся."

translate russian ch3_y_good_shared_a4994e95:
    y 3u "П-правда...?"

translate russian ch3_y_good_shared_46707697:
    "Юри мягко улыбается сама себе."

translate russian ch3_y_good_shared_44983fcd:
    y "Это чувство..."

translate russian ch3_y_good_shared_d1033fb0:
    y "Я так рада... что мне выпала возможность поделиться своими текстами."

translate russian ch3_y_good_shared_72c1f337:
    y 4e "Никогда не думала, что это будет так."

translate russian ch3_y_good_shared_a68ee7ab:
    mc "Помню, ты вчера об этом говорила."

translate russian ch3_y_good_shared_1df4e714:
    mc "Не могу поверить, что ты так хорошо что-то умеешь и ни разу никому этого не показывала."

translate russian ch3_y_good_shared_4e2b5afe:
    mc "Даже как-то жаль."

translate russian ch3_y_good_shared_ed5cf224:
    y 2u "Может быть, но..."

translate russian ch3_y_good_shared_e6cffa74:
    y "Не то чтобы у меня... был выбор."

translate russian ch3_y_good_shared_fe7c242f:
    mc "Что ты имеешь в виду...?"

translate russian ch3_y_good_shared_ae7f22e8:
    y "Ну..."

translate russian ch1_m_start_b00bb3c8:
    m 1b "Привет, [player]!"

translate russian ch1_m_start_1bd46f58:
    m "Пока всё нравится?"

translate russian ch1_m_start_21d5c9ec:
    mc "А... да."

translate russian ch1_m_start_666605e3:
    m 1k "Вот и хорошо! Рада это слышать!"

translate russian ch1_m_start_93e2ca00:
    m 4a "Кстати, раз уж ты новенький и всё такое..."

translate russian ch1_m_start_2c3797ba:
    m "Если у тебя появятся предложения для клуба — новые занятия или что мы могли бы делать лучше..."

translate russian ch1_m_start_c62ec065:
    m 4b "Я всегда готова выслушать!"

translate russian ch1_m_start_34df4ece:
    m "Не бойся говорить, хорошо?"

translate russian ch1_m_start_5c96db76:
    mc "Хорошо... буду иметь в виду."

translate russian ch1_m_start_5cef0dd8:
    "Конечно, я буду бояться что-то предлагать."

translate russian ch1_m_start_9a72c3bb:
    "Куда лучше просто плыть по течению, пока не освоюсь."

translate russian ch1_m_start_35ec09b1:
    m 1a "В общем..."

translate russian ch1_m_start_cfa8c28b:
    m "Покажешь мне своё стихотворение?"

translate russian ch1_m_start_81b8811a:
    mc "Немного стыдно, но, видимо, придётся."

translate russian ch1_m_start_8b55ecf2:
    m 5a "А-ха-ха-ха!"

translate russian ch1_m_start_5af81672:
    m "Не волнуйся, [player]!"

translate russian ch1_m_start_b174058f:
    m "Знаешь, нам всем сегодня немного неловко."

translate russian ch1_m_start_5fd498a1:
    m "Но мы все скоро научимся преодолевать этот барьер."

translate russian ch1_m_start_5cc82dfc:
    mc "Да, это правда."

translate russian ch1_m_start_18b074dd:
    "Я протягиваю Монике своё стихотворение."

translate russian ch1_m_start_e918c8cd:
    m 2a "...Угу!"

translate russian ch1_m_start_d52a0336:
    mc "Уверен, я ещё не раз попробую разное."

translate russian ch1_m_start_39fb2380:
    mc "Может пройти время, прежде чем мне станет комфортно этим заниматься."

translate russian ch1_m_start_d86c07aa:
    m 1k "Ничего страшного!"

translate russian ch1_m_start_b46dbd55:
    m 1b "Я бы с радостью посмотрела, как ты пробуешь новое."

translate russian ch1_m_start_37541404:
    m "Это лучший способ найти свой стиль."

translate russian ch1_m_start_ca502e1b:
    m 3e "Остальные, может, немного пристрастны к своим стилям..."

translate russian ch1_m_start_e6431513:
    m 3a "Но я всегда помогу тебе найти то, что подходит тебе больше всего!"

translate russian ch1_m_start_7cffffc8:
    m "Так что не заставляй себя писать так, как хотят другие."

translate russian ch1_m_start_ae46059a:
    m "Тебе ведь не нужно стараться их впечатлить или что-то в этом роде."

translate russian ch1_m_start_fd6a9371:
    m 5 "А-ха-ха!"

translate russian ch1_m_start_7a59b594:
    mc "А-ха-ха..."

translate russian ch1_m_start_9d47e097:
    m 1a "В общем, хочешь теперь прочитать моё стихотворение?"

translate russian ch1_m_start_59efb257:
    m 1e "Не волнуйся, у меня не очень хорошо получается..."

translate russian ch1_m_start_1c27ea40:
    mc "Ты говоришь довольно уверенно для человека, который утверждает, что у него не очень получается."

translate russian ch1_m_start_e7765480:
    m 1j "Ну... это потому, что я должна звучать уверенно."

translate russian ch1_m_start_5f9f46a2:
    m 1b "Но это не значит, что я всегда себя так чувствую, понимаешь?"

translate russian ch1_m_start_a7bcf340:
    mc "Понятно..."

translate russian ch1_m_start_32258afa:
    mc "Что ж, тогда давай почитаем."

translate russian ch2_m_start_88abc401:
    m 1b "Снова привет, [player]!"

translate russian ch2_m_start_b0c674af:
    m "С Нацуки тогда вышло немного глупо, правда?"

translate russian ch2_m_start_b6b9632c:
    m 1j "Я рада, что вы двое так хорошо поладили."

translate russian ch2_m_start_2b35b6fe:
    mc "..."

translate russian ch2_m_start_a02765f7:
    "Можно и так сказать..."

translate russian ch2_m_start_dd03a39d:
    m 2a "В общем, твоё стихотворение я уже прочитала, а ты теперь можешь почитать моё."

translate russian ch2_m_start_bd7f69ac:
    m 1a "Мне нравится, как оно получилось, так что надеюсь, тебе тоже понравится~"

translate russian ch2_m_start_3b003159:
    m "Как продвигается писательство?"

translate russian ch2_m_start_e244b62c:
    mc "Нормально, наверное..."

translate russian ch2_m_start_bc898487:
    m 2k "Меня это устраивает."

translate russian ch2_m_start_dc4a1325:
    m 2b "Главное, чтобы не плохо!"

translate russian ch2_m_start_b5f97e3d:
    m 2a "Я рада, что ты стараешься."

translate russian ch2_m_start_2d8272d9:
    m "Может, скоро у тебя выйдет шедевр!"

translate russian ch2_m_start_a7b161e3:
    mc "А-ха-ха, я бы на это не рассчитывал..."

translate russian ch2_m_start_a73bf817:
    m 2a "Никогда не знаешь!"

translate russian ch2_m_start_42555ab9:
    m "Поделишься тем, что написал на сегодня?"

translate russian ch2_m_start_23eb6a63:
    mc "Конечно... Держи."

translate russian ch2_m_start_42bf4313:
    "Я отдаю своё стихотворение Монике."

translate russian ch2_m_start_e612037c:
    m "..."

translate russian ch2_m_start_42cf1711:
    m "...Отлично!"

translate russian ch2_m_start_c2677273:
    m 1a "Но в общем..."

translate russian ch2_m_start_333a7a57:
    m "Хочешь теперь прочитать моё?"

translate russian ch2_m_start_d3a78cd2:
    m "Мне нравится, как оно получилось, так что надеюсь, тебе тоже понравится~"

translate russian ch2_m_start_12abdfd9:
    mc "Хорошо, давай посмотрим."

translate russian ch3_m_start_06937b8f:
    m 2a "Привет, [player]~"

translate russian ch3_m_start_f87a90cf:
    m "Ты уже подумал, с чем хочешь выступить на фестивале?"

translate russian ch3_m_start_c14c584c:
    mc "Ну..."

translate russian ch3_m_start_38efc6ca:
    "Быть в этом клубе — это одно, но выступать перед кучей народу..."

translate russian ch3_m_start_a59ecd81:
    mc "...Мне нужно ещё подумать."

translate russian ch3_m_start_803cb348:
    m 2b "Хорошо, никакого давления!"

translate russian ch3_m_start_19bceb84:
    m "Но что бы ты ни сделал, уверена, получится здорово."

translate russian ch3_m_start_e6d6f04f:
    m "И мне было бы приятно это увидеть."

translate russian ch3_m_start_1459477f:
    m 2k "А-ха-ха!"

translate russian ch3_m_start_707101ed:
    m 1a "В общем, твоё стихотворение я уже прочитала, а ты теперь можешь почитать моё."

translate russian ch3_m_start_871ff519:
    m 1a "В общем, давай посмотрим на сегодняшнее стихотворение!"

translate russian ch3_m_start_2fcc7ac5:
    mc "Конечно..."

translate russian ch3_m_start_afad7e6e:
    "Я позволяю Монике забрать стихотворение у меня из рук."

translate russian ch3_m_start_e612037c:
    m "..."

translate russian ch3_m_start_89ab468e:
    m 1a "В общем...!"

translate russian ch3_m_start_5361963f:
    m "А теперь я покажу тебе своё, хорошо?"

translate russian ch3_m_start_ef59a989:
    mc "Э-э..."

translate russian ch3_m_start_b12907fb:
    mc "Ладно..."

translate russian m_natsuki_1_7c4c4591:
    m 2b "Мне нравится, [player]!"

translate russian m_natsuki_1_72610a7c:
    mc "Правда...?"

translate russian m_natsuki_1_0e8e49b9:
    m 2e "Оно гораздо милее, чем я ожидала."

translate russian m_natsuki_1_e0245251:
    m 2k "А-ха-ха-ха!"

translate russian m_natsuki_1_51ae0416:
    mc "Ох, ну вот..."

translate russian m_natsuki_1_8760977f:
    m 1b "Нет-нет!"

translate russian m_natsuki_1_525bf306:
    m "Оно чем-то напоминает то, что могла бы написать Нацуки."

translate russian m_natsuki_1_7636a49e:
    m "А она, между прочим, хорошо пишет."

translate russian m_natsuki_1_7524d622:
    m 5a "Так что считай это комплиментом!"

translate russian m_natsuki_1_7a59b594:
    mc "А-ха-ха..."

translate russian m_natsuki_1_f16c798b:
    mc "Раз ты так говоришь."

translate russian m_natsuki_1_912606f9:
    m "Ага!"

translate russian m_natsuki_1_5ed8a3d9:
    m 1a "Ты случайно не читал Шела Силверстайна?"

translate russian m_natsuki_1_fb2e5377:
    mc "А?"

translate russian m_natsuki_1_792a756d:
    mc "Может, очень давно..."

translate russian m_natsuki_1_952e0b84:
    m "Он знаменит тем, что рассказывал самые разные истории всего несколькими простыми словами."

translate russian m_natsuki_1_b8251a40:
    m "Его стихи бывают смешными, трогательными и даже грустными..."

translate russian m_natsuki_1_7cf65415:
    m 3d "А иногда в них всего несколько строчек."

translate russian m_natsuki_1_f04b83d5:
    m "Может даже показаться, что они написаны для детей, но если задуматься..."

translate russian m_natsuki_1_5b5818e1:
    m "В них такой взгляд на мир, который подходит кому угодно."

translate russian m_natsuki_1_a7bcf340:
    mc "Понятно..."

translate russian m_natsuki_1_a73f3323:
    mc "То есть ты хочешь сказать, что Нацуки чем-то похожа на него?"

translate russian m_natsuki_1_050bef70:
    m 2a "Вроде того."

translate russian m_natsuki_1_52f1da90:
    m "Может, она и не мастер..."

translate russian m_natsuki_1_0123d17d:
    m "Но лишнего в её стихах ты, скорее всего, не найдёшь."

translate russian m_natsuki_1_f4f9c07c:
    m "Писать их, может, и легко, но донести смысл — ужасно сложно."

translate russian m_natsuki_1_f3a3857f:
    m 2b "Так что я понимаю, почему тебе захотелось исследовать именно такие стихи!"

translate russian m_sayori_1_4d8b8152:
    m 2a "Мне нравится это!"

translate russian m_sayori_1_29be6c3b:
    m "Оно напоминает мне то, что понравилось бы Сайори."

translate russian m_sayori_1_09f2de35:
    mc "Правда?"

translate russian m_sayori_1_c82370e4:
    m 2d "Вы с Сайори ведь очень хорошие друзья, да?"

translate russian m_sayori_1_d67a109c:
    m "Я бы не удивилась, если бы у вас нашлось что-то общее и в этом."

translate russian m_sayori_1_9b1a0bbf:
    mc "А, ну..."

translate russian m_sayori_1_56c5f4e9:
    mc "Мы, может, и хорошие друзья, но на самом деле мы с Сайори очень разные."

translate russian m_sayori_1_6d1d2d28:
    m "Хм-м..."

translate russian m_sayori_1_e8b4d61d:
    m "Что ж, может, и так."

translate russian m_sayori_1_16da7d94:
    m 3a "Но, возможно, есть и сходство, которого ты не ожидаешь."

translate russian m_sayori_1_8bf52d21:
    m "То, как она о тебе говорит..."

translate russian m_sayori_1_447fd222:
    m "Похоже, вы оба очень заботитесь о благополучии друг друга."

translate russian m_sayori_1_e6f0a26d:
    m "Пусть вы и показываете это по-разному, в итоге это ближе, чем можно подумать."

translate russian m_sayori_1_d38dfb00:
    m 1a "Вот такое ощущение у меня и возникает, когда я читаю твоё стихотворение."

translate russian m_sayori_1_8fea2db2:
    mc "Хм-м..."

translate russian m_sayori_1_3434c3f4:
    mc "Ты уверена, что не слишком в него вчитываешься?"

translate russian m_sayori_1_4f983a35:
    m 5 "А-ха-ха! Возможно!"

translate russian m_sayori_1_6b60e626:
    m "Боже, я говорю прямо как Юри..."

translate russian m_sayori_1_0faddcc0:
    m 2a "...Но в любом случае в текстах Сайори есть какая-то мягкость."

translate russian m_sayori_1_04eb9702:
    m "Видно, что ей нравится исследовать эмоции — радость и грусть."

translate russian m_sayori_1_c5c4044f:
    m "Кто бы мог подумать, что такой жизнерадостный человек любит и грустное?"

translate russian m_sayori_1_e15e9640:
    mc "Да... Совершенно неожиданно."

translate russian m_sayori_1_022e3621:
    m 2j "Что ж, у каждого свой вкус~"

translate russian m_sayori_1_278cd0cd:
    m 2a "И тебе тоже не стоит бояться немного поэкспериментировать."

translate russian m_yuri_1_8702c778:
    m 1a "Отличная работа, [player]!"

translate russian m_yuri_1_51d5365e:
    m "Пока читала, у меня в голове только и было: „Ух ты!“"

translate russian m_yuri_1_68322c07:
    m 1j "Оно такое метафоричное!"

translate russian m_yuri_1_df8cf596:
    m 1a "Не знаю почему, но я не ожидала, что ты возьмёшься за что-то настолько глубокое."

translate russian m_yuri_1_a9a4780f:
    m 3b "Видимо, я тебя недооценивала!"

translate russian m_yuri_1_3796b1c6:
    mc "Мне проще всего держать ожидания окружающих на низком уровне."

translate russian m_yuri_1_b811b3be:
    mc "Тогда стоит мне хоть немного постараться — это сразу засчитывается."

translate russian m_yuri_1_dc0ab338:
    m 5a "А-ха-ха! Это не очень-то честно!"

translate russian m_yuri_1_820fd59f:
    m "Что ж, в любом случае это сработало."

translate russian m_yuri_1_8d0f13fc:
    m 2a "Ты ведь знаешь, что Юри любит такие тексты?"

translate russian m_yuri_1_0ec7a5f5:
    m "Тексты, полные образов и символов."

translate russian m_yuri_1_b447b75b:
    m 2d "В отличие от Сайори, которая любит описывать радость и грусть простыми и прямыми словами..."

translate russian m_yuri_1_7721dc77:
    m "Юри нравится, когда читателю оставляют самому найти в тексте смысл."

translate russian m_yuri_1_b33751ab:
    m 4d "Писать так, чтобы это работало, очень сложно."

translate russian m_yuri_1_5b9f294d:
    m "И чтобы люди что-то вынесли из текста, просто прочувствовав его..."

translate russian m_yuri_1_129d6b25:
    m "И чтобы могли глубоко разобрать все его нюансы."

translate russian m_yuri_1_8dc582a2:
    m "На это могут уйти годы практики, которые, полагаю, у Юри за плечами уже есть."

translate russian m_yuri_1_33407c54:
    m 1e "Хотя я никогда толком не спрашивала..."

translate russian m_yuri_1_7b4be666:
    mc "Уверен, до её уровня мне ещё очень далеко."

translate russian m_yuri_1_65ac51ae:
    m 2b "Не переживай так об этом!"

translate russian m_yuri_1_e384cb4c:
    m "Делай по-своему."

translate russian m_yuri_1_d258e98b:
    m "Просто продолжай исследовать и учиться, пробуя новое!"

translate russian m_natsuki_2_1141cfe5:
    m 1j "Довольно неплохо~"

translate russian m_natsuki_2_7b2b6d58:
    m 1a "Ты ведь проводишь время с Нацуки, да?"

translate russian m_natsuki_2_b03c2cd8:
    m "Тебе, должно быть, нравится её стиль."

translate russian m_natsuki_2_d080b42e:
    mc "А, ну да..."

translate russian m_natsuki_2_56691d3e:
    mc "По-моему, это интересный способ рассказать историю."

translate russian m_natsuki_2_6a54e562:
    m 2a "Угу. Не могу не согласиться."

translate russian m_natsuki_2_ad415b83:
    m "Стихи Нацуки, может, и милые, но в них есть смысл."

translate russian m_natsuki_2_ee1667f2:
    m "Понимаю, почему тебе нравится такой стиль."

translate russian m_natsuki_2_2aee740c:
    m "Значит, стихи Юри тебе не так нравятся?"

translate russian m_natsuki_2_bc5f3817:
    mc "А— Я бы так не сказал..."

translate russian m_natsuki_2_8d617744:
    mc "Мне вроде как нравятся стихи всех."

translate russian m_natsuki_2_3c23c530:
    m 2d "Это так, но наверняка какие-то нравятся тебе больше других, правда?"

translate russian m_natsuki_2_095b88be:
    m "Например, сложные слова и символизм Юри..."

translate russian m_natsuki_2_bea18e79:
    m "Или то, как прямо Сайори выражает радость и грусть."

translate russian m_natsuki_2_03e364a9:
    m 2a "У тебя ведь наверняка есть какие-то предпочтения?"

translate russian m_natsuki_2_5de9588c:
    m 4l "Ой, не то чтобы это было соревнование или что-то такое!"

translate russian m_natsuki_2_b6172172:
    m 4a "Мне просто было любопытно, вот и всё."

translate russian m_sayori_2_1141cfe5:
    m 1j "Довольно неплохо~"

translate russian m_sayori_2_e8c45146:
    m 1a "Оно напоминает мне Сайори, как и то, что ты написал раньше."

translate russian m_sayori_2_98b2571a:
    m 4b "Вы с ней прямо неразлучная парочка!"

translate russian m_sayori_2_15a9cea5:
    mc "А-ха-ха... Это уж ты преувеличиваешь."

translate russian m_sayori_2_5e429b1e:
    m 2a "Да, наверное."

translate russian m_sayori_2_eb83df23:
    m "Но ты ведь и в клубе проводишь с ней много времени, правда?"

translate russian m_sayori_2_7afd8b12:
    m 2j "Хотя я не виню тебя за то, что ты немного стесняешься~"

translate russian m_sayori_2_9dbf3614:
    mc "Я-я не стесняюсь, просто..."

translate russian m_sayori_2_6e8a8e65:
    m 5 "А-ха-ха! Я просто дразню."

translate russian m_sayori_2_72eac543:
    m "Я знаю, что нужно время, чтобы подружиться со всеми."

translate russian m_sayori_2_d04eb98e:
    m 2d "Но Юри и Нацуки — очень интересные люди, так что не бойся уделять время и им!"

translate russian m_sayori_2_7271c488:
    m "И со мной тоже можешь иногда поговорить..."

translate russian m_sayori_2_30767fee:
    m 1e "Я ведь не какая-нибудь неприступная, правда?"

translate russian m_sayori_2_8af2273c:
    mc "А, нет, ничего такого..."

translate russian m_sayori_2_f01950e5:
    mc "Я просто ещё привыкаю, вот и всё."

translate russian m_sayori_2_479c6697:
    m 1a "Ну вот..."

translate russian m_sayori_2_301ec402:
    m 1l "Прости, если я на тебя давила или что-то такое!"

translate russian m_sayori_2_0e6844fa:
    m "Я правда не это имела в виду."

translate russian m_sayori_2_5af855fd:
    mc "Нет, не переживай."

translate russian m_sayori_2_ba86ad07:
    mc "Я понимаю, о чём ты."

translate russian m_sayori_2_0167ecce:
    m 1a "Ну, хорошо~"

translate russian m_yuri_2_7ee909e9:
    m 2b "Это хорошее!"

translate russian m_yuri_2_cbaab9fd:
    m "Похоже, тебе не только всё комфортнее в своём стиле..."

translate russian m_yuri_2_4d9b0e7a:
    m "Но и образы стали лучше, чем в прошлом, которое я читала!"

translate russian m_yuri_2_b8b959f1:
    m 2a "Просто интересно: тебя вдохновляет стиль Юри?"

translate russian m_yuri_2_8fea2db2:
    mc "Хм-м..."

translate russian m_yuri_2_8cc105c3:
    mc "Похоже на то."

translate russian m_yuri_2_c4edcc97:
    mc "Нельзя отрицать, что она талантлива."

translate russian m_yuri_2_9bf3f82f:
    m 4k "Да, абсолютно!"

translate russian m_yuri_2_b26a949d:
    m 4a "По-моему, её стихи самые..."

translate russian m_yuri_2_8a0882df:
    m "...Романтичные."

translate russian m_yuri_2_a3dcdbac:
    m 1a "Лучше и не скажешь."

translate russian m_yuri_2_f4dc5b61:
    m 1d "Когда она берёт в руки ручку, она будто становится совсем другим человеком..."

translate russian m_yuri_2_dd38b0d2:
    mc "Я тоже это заметил."

translate russian m_yuri_2_08d4cba9:
    mc "Или когда она говорит о литературе — у неё будто внутри зажигается свет."

translate russian m_yuri_2_78e4bc5a:
    m 2a "Угу!"

translate russian m_yuri_2_4dad2cf7:
    m "К сожалению, разговорить её о чём-то личном очень трудно..."

translate russian m_yuri_2_dae34b40:
    m 2m "Поверь, я пыталась..."

translate russian m_yuri_2_e8bbc7eb:
    m "Кто знает, что творится у неё в голове?"

translate russian m_yuri_2_28a3d670:
    mc "Надеюсь, ты не в плохом смысле."

translate russian m_yuri_2_9c8b02ec:
    m 1g "Нет, конечно!"

translate russian m_yuri_2_13778766:
    m "Я просто хотела бы, чтобы она не держала столько всего в себе..."

translate russian m_yuri_2_9cdf1041:
    m 1e "Но всё-таки, раз ты её так защищаешь..."

translate russian m_yuri_2_e8a8295a:
    m 5 "Ты, наверное, на неё запал..."

translate russian m_yuri_2_af40f385:
    mc "Что?!"

translate russian m_yuri_2_62e351ed:
    mc "Ты... совершенно не так поняла!"

translate russian m_yuri_2_2c30df54:
    m "А-ха-ха! Успокойся, я шучу!"

translate russian m_yuri_2_50538495:
    m 2a "К тому же я почти уверена, что у неё уже есть парень..."

translate russian m_yuri_2_690165fb:
    mc "Стоп, правда?"

translate russian m_yuri_2_42d27796:
    m 2k "Ага. Правда, выдуманный."

translate russian m_yuri_2_7630bfee:
    "Последнее Моника говорит мне почти шёпотом."

translate russian m_yuri_2_153168c3:
    m 5 "Это просто догадка, но..."

translate russian m_yuri_2_4ec89289:
    mc "...Ну, в этом нет ничего плохого!"

translate russian m_yuri_2_4b933e75:
    m 1n "Ой, ну я знаю...!"

translate russian m_yuri_2_ef56858b:
    m "Я просто сказала~"

translate russian m_natsuki_3_f7a98180:
    m 2j "Снова в стиле Нацуки, я смотрю~"

translate russian m_natsuki_3_a6da3a67:
    m 2d "Хм-м..."

translate russian m_natsuki_3_deefaaae:
    m "Тебе ведь очень нравится Нацуки, да?"

translate russian m_natsuki_3_fa8dc647:
    mc "А? Это—"

translate russian m_natsuki_3_83ddedb3:
    m 5 "Ой, да брось, [player]."

translate russian m_natsuki_3_be3ef178:
    m "Знаешь, это ужасно подозрительно."

translate russian m_natsuki_3_440f4ad9:
    m "Каждый день проводишь с ней время в клубной комнате..."

translate russian m_natsuki_3_dbb63ac1:
    m "Делаешь вид, что тебе нравится её манга..."

translate russian m_natsuki_3_db355bce:
    mc "Т-ты же знаешь, какая Нацуки...!"

translate russian m_natsuki_3_3a9c0991:
    mc "Если ей не потакать, она меня возненавидит."

translate russian m_natsuki_3_63a66e72:
    m 2e "А?"

translate russian m_natsuki_3_027144cb:
    m 2a "Нет, мне кажется, ты не так понимаешь, [player]."

translate russian m_natsuki_3_baf76466:
    m "Не то чтобы Нацуки просто ненавидит всех, кто не даёт ей того, чего она хочет."

translate russian m_natsuki_3_9ef74efc:
    m 2d "Да, она напористая, но не настолько эгоистичная..."

translate russian m_natsuki_3_bcc18b9f:
    m "Наоборот, мне кажется, только ты так ей и потакаешь."

translate russian m_natsuki_3_82346b47:
    mc "Вот как..."

translate russian m_natsuki_3_d9ba18c7:
    "Я, в общем-то, это знал, просто не хотел признавать."

translate russian m_natsuki_3_37da5f08:
    m "Так что у меня к тебе всего одна просьба..."

translate russian m_natsuki_3_233b44d4:
    m 1e "...Будь осторожен. Пожалуйста."

translate russian m_natsuki_3_8b752bc9:
    m "Нацуки довольно непредсказуемая."

translate russian m_natsuki_3_9a54b5e5:
    m "Часто она сама не знает, чего хочет."

translate russian m_natsuki_3_baa3c064:
    m 1i "Она ведь самая младшая из нас."

translate russian m_natsuki_3_81d02ff0:
    m "Она может не знать, как правильно справляться со своими чувствами."

translate russian m_natsuki_3_3f51cbbb:
    m "Я хочу сказать..."

translate russian m_natsuki_3_ff0a4347:
    m 1m "Если случится что-то плохое, это может навредить и клубу..."

translate russian m_natsuki_3_8bbc5c20:
    m 5 "А ты бы ведь так со мной не поступил... правда?"

translate russian m_natsuki_3_db2f7cec:
    mc "Это—"

translate russian m_natsuki_3_ae6d8407:
    "Я не знаю, что ответить Монике."

translate russian m_natsuki_3_1a2d457a:
    "Мне не всё равно и на неё, и на клуб, но вот так выставлять это — как-то нечестно."

translate russian m_natsuki_3_c8d1fac8:
    m "Что ж... ты умный."

translate russian m_natsuki_3_41abe421:
    m "Уверена, ты поступишь правильно."

translate russian m_natsuki_3_3049c3ae:
    "Моника мило улыбается."

translate russian m_sayori_3_716c1a0f:
    m 1k "А-ха-ха."

translate russian m_sayori_3_7f78190d:
    m "Как-то забавно..."

translate russian m_sayori_3_822aa5c3:
    mc "Что именно?"

translate russian m_sayori_3_e90e3774:
    m 1a "Нет, не стихотворение..."

translate russian m_sayori_3_ccf81afb:
    m 2a "Я про то, как забавно, что твои стихи и стихи Сайори с каждым днём становятся всё больше похожи."

translate russian m_sayori_3_9a581250:
    m "Удивительно, как вы с ней на одной волне."

translate russian m_sayori_3_4b89f159:
    m 2d "Хотя вы ведь в последнее время много времени проводите вместе, правда?"

translate russian m_sayori_3_89783ca5:
    mc "А, ну, можно и так сказать..."

translate russian m_sayori_3_60d182fc:
    mc "Хоть мы и выросли лучшими друзьями, за последний год я виделся с ней не так часто..."

translate russian m_sayori_3_aa461243:
    mc "Но с тех пор как я вступил в клуб, мы снова много времени проводим вместе."

translate russian m_sayori_3_d38bbd3f:
    m 1a "Понятно, понятно~"

translate russian m_sayori_3_5e1add9f:
    m "Кстати, вспомнила..."

translate russian m_sayori_3_db98a6f5:
    m "Насчёт того, что Сайори сегодня какая-то не такая..."

translate russian m_sayori_3_9bffe845:
    mc "Да? Она тебе что-то сказала?"

translate russian m_sayori_3_b90d1b34:
    m 1n "Ах..."

translate russian m_sayori_3_d3107ef6:
    m "Ну..."

translate russian m_sayori_3_289f055a:
    m 2l "[player], ты ведь с ней не заигрывал?"

translate russian m_sayori_3_3ccbf055:
    mc "К-конечно, нет!"

translate russian m_sayori_3_1369965e:
    mc "Я веду себя с ней как всегда."

translate russian m_sayori_3_04700d81:
    m 2a "Хорошо."

translate russian m_sayori_3_17c5aaac:
    m 5 "Просто хотела убедиться~"

translate russian m_sayori_3_429093d5:
    m "Я знаю, как она тебе дорога..."

translate russian m_sayori_3_bd32bc7a:
    m "Будет ужасно, если с ней что-то случится, так что присматривай за ней."

translate russian m_sayori_3_df3b6f8b:
    m 2d "С тех пор как ты вступил в клуб, Сайори стала гораздо счастливее."

translate russian m_sayori_3_da4a7a56:
    m "Что же могло вдруг случиться...?"

translate russian m_sayori_3_2b35b6fe:
    mc "..."

translate russian m_sayori_3_38a280bb:
    m 1l "...Ладно, неважно."

translate russian m_sayori_3_1a0c7af6:
    m "Сейчас правда не время об этом говорить..."

translate russian m_yuri_3_0e1b4ab3:
    m 2e "Твой стиль стал таким изысканным, [player]."

translate russian m_yuri_3_27dc2b9c:
    m "Юри многому тебя научила, правда?"

translate russian m_yuri_3_8c731859:
    mc "Ну—"

translate russian m_yuri_3_8cc105c3:
    mc "Похоже на то."

translate russian m_yuri_3_f8705f20:
    m 2a "Да... Я замечаю, сколько времени ты с ней проводишь."

translate russian m_yuri_3_cc0b9d72:
    m 2d "Кажется, за последние пару дней она сказала больше слов, чем за весь год."

translate russian m_yuri_3_a6d1671b:
    m "Не знаю, как тебе это удалось, но это впечатляет..."

translate russian m_yuri_3_6411ddd7:
    mc "Ну, ей просто нужно терпение и возможность выговорить всё, что у неё в голове, наверное..."

translate russian m_yuri_3_5f05b29a:
    mc "Я и сам ещё только учусь."

translate russian m_yuri_3_14011fc8:
    m 2a "Хм..."

translate russian m_yuri_3_f1037a7b:
    m "Ты определённо прикладываешь немало усилий."

translate russian m_yuri_3_33a54f5d:
    m 2e "Она тебе, должно быть, очень нравится."

translate russian m_yuri_3_fa8dc647:
    mc "А? Это—"

translate russian m_yuri_3_fd6a9371:
    m 5 "А-ха-ха!"

translate russian m_yuri_3_be3ef178:
    m "Знаешь, это ужасно подозрительно."

translate russian m_yuri_3_440f4ad9:
    m "Каждый день проводишь с ней время в клубной комнате..."

translate russian m_yuri_3_c430545e:
    m "Читаешь с ней этот мрачный роман..."

translate russian m_yuri_3_e5293ce8:
    mc "Ну—!"

translate russian m_yuri_3_b2aaefec:
    mc "Мне просто... жаль, что ей так трудно общаться с людьми."

translate russian m_yuri_3_909d6afc:
    mc "Хочется, чтобы она не проводила всё время в одиночестве."

translate russian m_yuri_3_22db7fde:
    mc "К тому же, знаешь, роман и правда неплохой..."

translate russian m_yuri_3_c9922848:
    m 1k "Ладно, ладно~"

translate russian m_yuri_3_d23928af:
    m "Я тебя поняла."

translate russian m_yuri_3_d9cf6136:
    m 1a "Просто... будь осторожен, хорошо?"

translate russian m_yuri_3_da327170:
    m "Я знаю, что Юри не привыкла раскрываться..."

translate russian m_yuri_3_0dd92aa0:
    m 2d "Так что если с ней случится что-то плохое, пока она так уязвима..."

translate russian m_yuri_3_113b7ab9:
    m "Ей может быть очень тяжело."

translate russian m_yuri_3_083f2f6a:
    m 2i "Книги — это не настоящее бегство от реальности."

translate russian m_yuri_3_26c60742:
    m "Это всего лишь пластырь."

translate russian m_yuri_3_17a15afe:
    mc "Ты так говоришь, будто я собираюсь её обидеть..."

translate russian m_yuri_3_d3af29cc:
    m 1l "Прости, я не это имела в виду~"

translate russian m_yuri_3_e903db06:
    m "Скорее она может случайно навредить сама себе."
